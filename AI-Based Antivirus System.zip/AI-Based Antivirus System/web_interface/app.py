"""
Antivirus Web Interface - Main Application
Flask-based web application with real-time capabilities following
client-server and microservices architecture patterns from the
antivirus system documentation.

Developer: Dr. Mohammed Tawfik
Email: Kmkhol01@gmail.com
Version: 1.0.0
Created: 2025-11-10
"""

from flask import Flask, render_template, jsonify, request, session, redirect, url_for, flash
from flask_socketio import SocketIO, emit
import json
import time
import threading
from datetime import datetime, timedelta
import hashlib
import sqlite3
import os
import random
import uuid
from typing import Dict, List, Optional, Any
import psutil
import logging

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

app = Flask(__name__)
app.config['SECRET_KEY'] = 'antivirus-web-interface-secret-key'
app.config['DATABASE'] = '/workspace/code/web_interface/antivirus.db'

# Initialize SocketIO for real-time communication
socketio = SocketIO(app, cors_allowed_origins="*")

# Global state management for real-time features
class AntivirusState:
    def __init__(self):
        self.scans: Dict[str, Dict] = {}
        self.threats: List[Dict] = []
        self.system_status = {
            'status': 'healthy',
            'last_update': datetime.now(),
            'cpu_usage': 0,
            'memory_usage': 0,
            'disk_usage': 0,
            'engine_status': 'running',
            'definitions_version': '2024.11.10',
            'last_scan_time': None
        }
        self.config = {
            'real_time_protection': True,
            'auto_update': True,
            'scan_schedule': 'daily',
            'quarantine_action': 'quarantine',
            'email_notifications': True,
            'cloud_scanning': True
        }
        self.is_scanning = False
        self.scan_progress = 0
        self.scan_threads = []
        
    def start_scan(self, scan_type: str = 'full', target_path: str = None):
        """Start a new scan and return scan ID"""
        scan_id = str(uuid.uuid4())
        scan_data = {
            'id': scan_id,
            'type': scan_type,
            'status': 'running',
            'start_time': datetime.now(),
            'progress': 0,
            'files_scanned': 0,
            'threats_found': 0,
            'target_path': target_path,
            'estimated_completion': datetime.now() + timedelta(minutes=30)
        }
        self.scans[scan_id] = scan_data
        return scan_id
    
    def add_threat(self, threat_data: Dict):
        """Add a new threat to the system"""
        threat_id = str(uuid.uuid4())
        threat = {
            'id': threat_id,
            'name': threat_data.get('name', 'Unknown Threat'),
            'type': threat_data.get('type', 'Unknown'),
            'severity': threat_data.get('severity', 'medium'),
            'file_path': threat_data.get('file_path', ''),
            'scan_id': threat_data.get('scan_id'),
            'detection_time': datetime.now(),
            'status': 'active',
            'action_taken': 'none'
        }
        self.threats.append(threat)
        return threat_id
    
    def update_system_stats(self):
        """Update system statistics"""
        self.system_status['cpu_usage'] = psutil.cpu_percent()
        self.system_status['memory_usage'] = psutil.virtual_memory().percent
        self.system_status['disk_usage'] = psutil.disk_usage('/').percent
        self.system_status['last_update'] = datetime.now()
    
    def get_scan_statistics(self) -> Dict:
        """Get comprehensive scan statistics"""
        total_scans = len(self.scans)
        completed_scans = sum(1 for scan in self.scans.values() if scan['status'] == 'completed')
        threats_detected = len(self.threats)
        high_severity_threats = sum(1 for threat in self.threats if threat['severity'] == 'high')
        
        return {
            'total_scans': total_scans,
            'completed_scans': completed_scans,
            'running_scans': total_scans - completed_scans,
            'threats_detected': threats_detected,
            'high_severity_threats': high_severity_threats,
            'system_health': self.get_system_health_score()
        }
    
    def get_system_health_score(self) -> int:
        """Calculate system health score (0-100)"""
        health_factors = [
            self.system_status['cpu_usage'] < 80,
            self.system_status['memory_usage'] < 80,
            self.system_status['disk_usage'] < 90,
            self.system_status['engine_status'] == 'running',
            self.system_status['status'] == 'healthy'
        ]
        return sum(health_factors) * 20

# Global instance
antivirus_state = AntivirusState()

# Database functions
def init_database():
    """Initialize SQLite database for the web interface"""
    conn = sqlite3.connect(app.config['DATABASE'])
    cursor = conn.cursor()
    
    # Scans table
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS scans (
            id TEXT PRIMARY KEY,
            type TEXT NOT NULL,
            status TEXT NOT NULL,
            start_time TEXT NOT NULL,
            end_time TEXT,
            progress INTEGER DEFAULT 0,
            files_scanned INTEGER DEFAULT 0,
            threats_found INTEGER DEFAULT 0,
            target_path TEXT
        )
    ''')
    
    # Threats table
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS threats (
            id TEXT PRIMARY KEY,
            name TEXT NOT NULL,
            type TEXT NOT NULL,
            severity TEXT NOT NULL,
            file_path TEXT,
            scan_id TEXT,
            detection_time TEXT NOT NULL,
            status TEXT NOT NULL,
            action_taken TEXT,
            FOREIGN KEY (scan_id) REFERENCES scans (id)
        )
    ''')
    
    # Configuration table
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS configuration (
            key TEXT PRIMARY KEY,
            value TEXT NOT NULL,
            updated_time TEXT NOT NULL
        )
    ''')
    
    # System logs table
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS system_logs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            level TEXT NOT NULL,
            message TEXT NOT NULL,
            timestamp TEXT NOT NULL,
            source TEXT
        )
    ''')
    
    conn.commit()
    conn.close()

def save_to_database():
    """Save current state to database"""
    conn = sqlite3.connect(app.config['DATABASE'])
    cursor = conn.cursor()
    
    # Save scans
    for scan_id, scan in antivirus_state.scans.items():
        cursor.execute('''
            INSERT OR REPLACE INTO scans 
            (id, type, status, start_time, end_time, progress, files_scanned, threats_found, target_path)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        ''', (
            scan_id, scan['type'], scan['status'], 
            scan['start_time'].isoformat(),
            scan.get('end_time', '').isoformat() if scan.get('end_time') else None,
            scan['progress'], scan['files_scanned'], scan['threats_found'], scan.get('target_path')
        ))
    
    # Save threats
    for threat in antivirus_state.threats:
        cursor.execute('''
            INSERT OR REPLACE INTO threats 
            (id, name, type, severity, file_path, scan_id, detection_time, status, action_taken)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        ''', (
            threat['id'], threat['name'], threat['type'], threat['severity'],
            threat['file_path'], threat['scan_id'], 
            threat['detection_time'].isoformat(), threat['status'], threat['action_taken']
        ))
    
    # Save configuration
    for key, value in antivirus_state.config.items():
        cursor.execute('''
            INSERT OR REPLACE INTO configuration (key, value, updated_time)
            VALUES (?, ?, ?)
        ''', (key, json.dumps(value), datetime.now().isoformat()))
    
    conn.commit()
    conn.close()

# Background tasks
def update_system_stats():
    """Background task to update system statistics"""
    while True:
        antivirus_state.update_system_stats()
        # Emit real-time update to connected clients
        socketio.emit('system_update', {
            'status': antivirus_state.system_status,
            'stats': antivirus_state.get_scan_statistics()
        })
        time.sleep(5)

def simulate_scan_progress(scan_id: str):
    """Simulate scan progress for demonstration"""
    scan = antivirus_state.scans.get(scan_id)
    if not scan:
        return
    
    while scan['status'] == 'running' and scan['progress'] < 100:
        # Simulate scan progress
        time.sleep(random.uniform(1, 3))
        scan['progress'] += random.randint(1, 5)
        scan['files_scanned'] += random.randint(10, 100)
        
        # Simulate threat detection occasionally
        if random.random() < 0.1:  # 10% chance per interval
            threat_types = ['Trojan', 'Virus', 'Worm', 'Adware', 'Ransomware']
            severities = ['low', 'medium', 'high']
            
            threat = {
                'name': f'Suspicious.{random.randint(100, 999)}',
                'type': random.choice(threat_types),
                'severity': random.choice(severities),
                'file_path': f'/path/to/file_{random.randint(1000, 9999)}.exe',
                'scan_id': scan_id
            }
            threat_id = antivirus_state.add_threat(threat)
            scan['threats_found'] += 1
            
            # Emit threat detection
            socketio.emit('threat_detected', {
                'threat': threat,
                'threat_id': threat_id
            })
        
        # Emit scan progress update
        socketio.emit('scan_progress', {
            'scan_id': scan_id,
            'progress': scan['progress'],
            'files_scanned': scan['files_scanned'],
            'threats_found': scan['threats_found']
        })
        
        if scan['progress'] >= 100:
            scan['status'] = 'completed'
            scan['end_time'] = datetime.now()
            antivirus_state.system_status['last_scan_time'] = datetime.now()
            
            # Emit scan completion
            socketio.emit('scan_completed', {
                'scan_id': scan_id,
                'results': {
                    'files_scanned': scan['files_scanned'],
                    'threats_found': scan['threats_found']
                }
            })
            break

def generate_sample_data():
    """Generate sample data for demonstration"""
    # Create a completed scan
    completed_scan = antivirus_state.start_scan('full', '/')
    completed_scan_data = antivirus_state.scans[completed_scan]
    completed_scan_data['status'] = 'completed'
    completed_scan_data['progress'] = 100
    completed_scan_data['files_scanned'] = 15420
    completed_scan_data['threats_found'] = 3
    completed_scan_data['end_time'] = datetime.now() - timedelta(hours=2)
    
    # Add some sample threats
    sample_threats = [
        {
            'name': 'Win32.Trojan.Backdoor',
            'type': 'Trojan',
            'severity': 'high',
            'file_path': '/home/user/downloads/malicious.exe',
            'scan_id': completed_scan
        },
        {
            'name': 'Adware.Generic.123',
            'type': 'Adware',
            'severity': 'medium',
            'file_path': '/tmp/suspicious_file.dat',
            'scan_id': completed_scan
        },
        {
            'name': 'PUP.Optional.Toolbar',
            'type': 'Potentially Unwanted Program',
            'severity': 'low',
            'file_path': '/browser/extensions/bundle/',
            'scan_id': completed_scan
        }
    ]
    
    for threat in sample_threats:
        antivirus_state.add_threat(threat)

# Routes
@app.route('/')
def index():
    """Main dashboard page"""
    stats = antivirus_state.get_scan_statistics()
    return render_template('dashboard.html', stats=stats)

@app.route('/dashboard')
def dashboard():
    """Dashboard with overview statistics"""
    stats = antivirus_state.get_scan_statistics()
    return render_template('dashboard.html', stats=stats)

@app.route('/scans')
def scans():
    """Scan management page"""
    return render_template('scans.html')

@app.route('/threats')
def threats():
    """Threat management page"""
    return render_template('threats.html')

@app.route('/system')
def system():
    """System status and monitoring"""
    return render_template('system.html')

@app.route('/settings')
def settings():
    """Configuration and settings"""
    return render_template('settings.html')

@app.route('/reports')
def reports():
    """Reports and analytics"""
    return render_template('reports.html')

# API endpoints
@app.route('/api/scans', methods=['GET'])
def get_scans():
    """Get all scans"""
    return jsonify({
        'scans': [
            {
                **scan,
                'start_time': scan['start_time'].isoformat(),
                'end_time': scan.get('end_time', '').isoformat() if scan.get('end_time') else None,
                'estimated_completion': scan.get('estimated_completion', '').isoformat() if scan.get('estimated_completion') else None
            }
            for scan in antivirus_state.scans.values()
        ]
    })

@app.route('/api/scans', methods=['POST'])
def start_scan():
    """Start a new scan"""
    data = request.get_json()
    scan_type = data.get('type', 'full')
    target_path = data.get('target_path')
    
    scan_id = antivirus_state.start_scan(scan_type, target_path)
    
    # Start simulation thread
    thread = threading.Thread(target=simulate_scan_progress, args=(scan_id,))
    thread.daemon = True
    thread.start()
    
    return jsonify({
        'scan_id': scan_id,
        'message': f'Scan started with ID: {scan_id}'
    })

@app.route('/api/scans/<scan_id>', methods=['GET'])
def get_scan_status(scan_id):
    """Get specific scan status"""
    scan = antivirus_state.scans.get(scan_id)
    if not scan:
        return jsonify({'error': 'Scan not found'}), 404
    
    return jsonify({
        'scan': {
            **scan,
            'start_time': scan['start_time'].isoformat(),
            'end_time': scan.get('end_time', '').isoformat() if scan.get('end_time') else None,
            'estimated_completion': scan.get('estimated_completion', '').isoformat() if scan.get('estimated_completion') else None
        }
    })

@app.route('/api/threats', methods=['GET'])
def get_threats():
    """Get all threats"""
    return jsonify({
        'threats': [
            {
                **threat,
                'detection_time': threat['detection_time'].isoformat()
            }
            for threat in antivirus_state.threats
        ]
    })

@app.route('/api/threats/<threat_id>', methods=['PUT'])
def update_threat(threat_id):
    """Update threat status/action"""
    data = request.get_json()
    action = data.get('action', 'none')
    
    # Find and update threat
    for threat in antivirus_state.threats:
        if threat['id'] == threat_id:
            threat['action_taken'] = action
            threat['status'] = 'quarantined' if action == 'quarantine' else 'active'
            break
    
    return jsonify({
        'message': 'Threat updated successfully',
        'threat_id': threat_id,
        'action': action
    })

@app.route('/api/threats/<threat_id>', methods=['DELETE'])
def delete_threat(threat_id):
    """Delete/remove threat"""
    # Remove from threats list
    original_count = len(antivirus_state.threats)
    antivirus_state.threats = [t for t in antivirus_state.threats if t['id'] != threat_id]
    
    if len(antivirus_state.threats) < original_count:
        return jsonify({'message': 'Threat deleted successfully'})
    else:
        return jsonify({'error': 'Threat not found'}), 404

@app.route('/api/system/status', methods=['GET'])
def get_system_status():
    """Get system status and statistics"""
    return jsonify({
        'status': antivirus_state.system_status,
        'stats': antivirus_state.get_scan_statistics(),
        'config': antivirus_state.config
    })

@app.route('/api/config', methods=['GET'])
def get_config():
    """Get configuration settings"""
    return jsonify(antivirus_state.config)

@app.route('/api/config', methods=['PUT'])
def update_config():
    """Update configuration settings"""
    data = request.get_json()
    
    # Update configuration
    for key, value in data.items():
        if key in antivirus_state.config:
            antivirus_state.config[key] = value
    
    return jsonify({
        'message': 'Configuration updated successfully',
        'config': antivirus_state.config
    })

@app.route('/api/reports/overview', methods=['GET'])
def get_reports_overview():
    """Get reports overview data"""
    # Generate sample report data
    return jsonify({
        'scan_statistics': antivirus_state.get_scan_statistics(),
        'threat_trends': {
            'last_30_days': [
                {'date': '2024-10-15', 'threats': 12, 'scans': 45},
                {'date': '2024-10-16', 'threats': 8, 'scans': 52},
                {'date': '2024-10-17', 'threats': 15, 'scans': 38},
                # ... more data
            ]
        },
        'threat_distribution': {
            'Trojan': 35,
            'Virus': 25,
            'Worm': 15,
            'Adware': 20,
            'Ransomware': 5
        },
        'system_performance': {
            'avg_scan_time': '2m 34s',
            'cpu_usage_avg': 25.6,
            'memory_usage_avg': 42.3,
            'disk_impact': 'Minimal'
        }
    })

# SocketIO events
@socketio.on('connect')
def handle_connect():
    """Handle client connection"""
    logger.info('Client connected')
    # Send current state to new client
    emit('system_update', {
        'status': antivirus_state.system_status,
        'stats': antivirus_state.get_scan_statistics()
    })

@socketio.on('disconnect')
def handle_disconnect():
    """Handle client disconnection"""
    logger.info('Client disconnected')

@socketio.on('start_scan_realtime')
def handle_start_scan(data):
    """Handle real-time scan start request"""
    scan_id = antivirus_state.start_scan(data.get('type', 'full'), data.get('target_path'))
    
    # Start simulation thread
    thread = threading.Thread(target=simulate_scan_progress, args=(scan_id,))
    thread.daemon = True
    thread.start()
    
    emit('scan_started', {'scan_id': scan_id})

if __name__ == '__main__':
    # Initialize database
    init_database()
    
    # Generate sample data
    generate_sample_data()
    
    # Start background system stats updater
    stats_thread = threading.Thread(target=update_system_stats, daemon=True)
    stats_thread.start()
    
    # Start periodic database save
    def save_periodically():
        while True:
            time.sleep(30)  # Save every 30 seconds
            save_to_database()
    
    save_thread = threading.Thread(target=save_periodically, daemon=True)
    save_thread.start()
    
    # Run the application
    socketio.run(app, debug=True, host='0.0.0.0', port=5000)