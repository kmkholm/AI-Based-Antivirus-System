# Antivirus Web Interface

A comprehensive web-based user interface for the antivirus application, built with Flask and featuring real-time capabilities, dashboard monitoring, threat management, and system configuration.

## Features

### 🛡️ Core Functionality
- **Real-time Dashboard** - Live system monitoring with interactive charts
- **Scan Management** - Start, monitor, and manage antivirus scans
- **Threat Detection** - View, quarantine, and manage detected threats
- **System Monitoring** - Real-time performance and health metrics
- **Configuration Management** - Comprehensive settings interface
- **Reporting & Analytics** - Detailed reports with export capabilities

### 🔧 Technical Features
- **Real-time Updates** - WebSocket-based live data streaming
- **Responsive Design** - Mobile-friendly Bootstrap-based interface
- **Interactive Charts** - Chart.js integration for data visualization
- **RESTful API** - Clean API endpoints for all operations
- **Database Integration** - SQLite for data persistence
- **Modular Architecture** - Clean, maintainable codebase

## Architecture

The web interface follows the modern antivirus system architecture patterns described in the documentation:

### Client-Server Architecture
```
[Web Browser] ↔ [Flask Web Server] ↔ [Antivirus Engine]
     ↑              ↑                     ↑
  UI/JS         Business Logic       Core Scanning
```

### Real-time Communication
```
[WebSocket Server] ↔ [Real-time Data Processor] ↔ [System Monitors]
        ↑                    ↑                        ↑
   Live Updates          Event Processing         System Telemetry
```

### Microservices Patterns
- **Publisher/Subscriber** for event handling
- **Sidecar** pattern for telemetry and logging
- **Bulkhead** isolation for different threat levels
- **Rate Limiting** for API protection

## Installation

### Prerequisites
- Python 3.8+
- pip (Python package manager)

### Setup
1. **Clone or extract the web interface:**
   ```bash
   cd /workspace/code/web_interface
   ```

2. **Install dependencies:**
   ```bash
   pip install -r requirements.txt
   ```

3. **Run the application:**
   ```bash
   python app.py
   ```

4. **Access the interface:**
   - Open your browser to `http://localhost:5000`
   - The web interface will be available immediately

## Usage

### Dashboard
- **Overview** - System health, threat statistics, scan activity
- **Charts** - Interactive visualizations of scan trends and threat distribution
- **Real-time Updates** - Live system status and progress indicators

### Scan Management
- **Start Scans** - Quick, full, or custom scan options
- **Monitor Progress** - Real-time scan progress and statistics
- **Scan History** - Complete scan history with detailed results

### Threat Management
- **Threat View** - List of all detected threats with filtering options
- **Actions** - Quarantine, delete, or analyze threats
- **Bulk Operations** - Select multiple threats for batch operations

### System Monitoring
- **Performance Metrics** - CPU, memory, and disk usage
- **Component Status** - Real-time status of all antivirus components
- **System Logs** - Comprehensive logging with filtering options

### Configuration
- **Protection Settings** - Real-time protection configuration
- **Scanning Options** - Scan schedules, exclusions, and behavior
- **Notifications** - Email, desktop, and alert configuration
- **Updates** - Automatic update settings and version information

### Reports
- **Security Overview** - Comprehensive security statistics
- **Threat Analysis** - Detailed threat trends and patterns
- **System Performance** - Performance metrics and optimization data
- **Export Options** - PDF, Excel, and CSV export capabilities

## API Endpoints

### Scans
- `GET /api/scans` - Get all scans
- `POST /api/scans` - Start a new scan
- `GET /api/scans/<scan_id>` - Get specific scan status

### Threats
- `GET /api/threats` - Get all threats
- `PUT /api/threats/<threat_id>` - Update threat (quarantine/delete)
- `DELETE /api/threats/<threat_id>` - Remove threat

### System
- `GET /api/system/status` - Get system status and statistics
- `GET /api/config` - Get configuration settings
- `PUT /api/config` - Update configuration

### Reports
- `GET /api/reports/overview` - Get reports overview data

## WebSocket Events

### Client → Server
- `start_scan_realtime` - Start a scan with real-time updates

### Server → Client
- `system_update` - System status and statistics update
- `scan_progress` - Real-time scan progress updates
- `scan_completed` - Scan completion notification
- `threat_detected` - New threat detection notification

## Configuration

### Environment Variables
- `FLASK_ENV` - Development/Production environment
- `FLASK_DEBUG` - Enable debug mode
- `SECRET_KEY` - Flask secret key for sessions
- `DATABASE_PATH` - SQLite database file path

### Database
The interface uses SQLite for data persistence:
- `antivirus.db` - Main database file
- Tables: `scans`, `threats`, `configuration`, `system_logs`

## Customization

### Styling
- **CSS Framework** - Bootstrap 5.1.3
- **Custom Styles** - `/static/css/style.css`
- **Icons** - Font Awesome 6.0.0
- **Charts** - Chart.js 3.7.0

### JavaScript
- **Framework** - Vanilla JavaScript with modern ES6+ features
- **WebSocket** - Socket.IO for real-time communication
- **Charts** - Chart.js for data visualization
- **Bootstrap** - Bootstrap JavaScript components

### Templates
- **Engine** - Jinja2 templating
- **Layout** - Base template with inheritance
- **Pages** - Individual page templates
- **Components** - Reusable template components

## Security Considerations

### Input Validation
- All user inputs are validated server-side
- SQL injection protection via parameterized queries
- XSS protection via proper output encoding

### Authentication
- Session-based authentication (extendable)
- CSRF protection via Flask-WTF (optional)
- Rate limiting for API endpoints

### Data Protection
- Secure session management
- Input sanitization
- Output encoding

## Performance

### Optimization Features
- **Database Indexing** - Optimized queries for large datasets
- **Caching** - Client-side caching of static resources
- **Minification** - Compressed CSS/JS for production
- **Lazy Loading** - Progressive data loading for large tables

### Scalability
- **Connection Pooling** - Efficient database connections
- **Asynchronous Processing** - Non-blocking I/O operations
- **Event-Driven Architecture** - Efficient real-time updates

## Browser Compatibility

### Supported Browsers
- **Chrome** 90+
- **Firefox** 88+
- **Safari** 14+
- **Edge** 90+

### Features Used
- ES6+ JavaScript features
- CSS Grid and Flexbox
- WebSocket API
- Fetch API

## Troubleshooting

### Common Issues

1. **Port Already in Use**
   ```bash
   # Change port in app.py or kill existing process
   lsof -ti:5000 | xargs kill
   ```

2. **WebSocket Connection Failed**
   - Check firewall settings
   - Ensure WebSocket support in browser
   - Verify network connectivity

3. **Database Issues**
   ```bash
   # Reset database
   rm antivirus.db
   python app.py  # Recreates database
   ```

### Debug Mode
Enable debug mode in `app.py`:
```python
socketio.run(app, debug=True, host='0.0.0.0', port=5000)
```

### Logs
Check application logs for detailed error information:
```bash
python app.py 2>&1 | tee antivirus.log
```

## Development

### File Structure
```
web_interface/
├── app.py                 # Main Flask application
├── requirements.txt       # Python dependencies
├── README.md             # This file
├── templates/            # HTML templates
│   ├── base.html         # Base template
│   ├── dashboard.html    # Dashboard page
│   ├── scans.html        # Scan management
│   ├── threats.html      # Threat management
│   ├── system.html       # System monitoring
│   ├── settings.html     # Configuration
│   └── reports.html      # Reports & analytics
└── static/               # Static assets
    ├── css/
    │   └── style.css     # Custom styles
    └── js/
        └── main.js       # Main JavaScript
```

### Adding New Features
1. Create new API endpoint in `app.py`
2. Add corresponding HTML template in `templates/`
3. Implement JavaScript handlers in `static/js/main.js`
4. Add CSS styling in `static/css/style.css` if needed

### Testing
- Manual testing through the web interface
- API testing via tools like curl or Postman
- Browser developer tools for JavaScript debugging

## Integration

### Antivirus Engine Integration
The web interface is designed to integrate with the antivirus core engine:

1. **Plugin Architecture** - Matches the Python plugin system
2. **Event-Driven** - Receives real-time events from the engine
3. **Configuration Sync** - Reads/writes configuration to engine
4. **Status Monitoring** - Displays engine health and performance

### Extension Points
- **Custom Threat Handlers** - Add custom threat processing
- **Additional Charts** - Extend analytics with new visualizations
- **Custom Reports** - Add specialized reporting features
- **Third-party Integrations** - Connect to SIEM, SIEM, or other tools

## Support

### Documentation
- Internal documentation in code comments
- API documentation via Flask's built-in tools
- User guide through the web interface help sections

### Contributing
1. Follow the existing code style and patterns
2. Add appropriate error handling and logging
3. Include tests for new functionality
4. Update documentation for changes

## License

This web interface is part of the antivirus application system and follows the same licensing terms.

---

**Note**: This web interface is designed as a demonstration and template for antivirus system management. For production use, additional security hardening, authentication, and enterprise features should be implemented.