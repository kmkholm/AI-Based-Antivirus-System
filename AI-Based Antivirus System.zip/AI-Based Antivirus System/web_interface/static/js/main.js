/**
 * Antivirus Web Interface - Main JavaScript
 * Handles real-time communication, API calls, and user interactions
 */

class AntivirusInterface {
    constructor() {
        this.socket = null;
        this.currentUser = null;
        this.isConnected = false;
        this.retryCount = 0;
        this.maxRetries = 5;
        this.retryInterval = 5000; // 5 seconds
        
        this.init();
    }
    
    init() {
        this.connectSocket();
        this.setupEventListeners();
        this.initializeComponents();
        
        // Auto-refresh data
        setInterval(() => {
            this.refreshData();
        }, 30000); // 30 seconds
    }
    
    connectSocket() {
        try {
            this.socket = io();
            
            this.socket.on('connect', () => {
                console.log('Connected to WebSocket server');
                this.isConnected = true;
                this.retryCount = 0;
                this.updateConnectionStatus(true);
            });
            
            this.socket.on('disconnect', () => {
                console.log('Disconnected from WebSocket server');
                this.isConnected = false;
                this.updateConnectionStatus(false);
            });
            
            this.socket.on('system_update', (data) => {
                this.handleSystemUpdate(data);
            });
            
            this.socket.on('scan_progress', (data) => {
                this.handleScanProgress(data);
            });
            
            this.socket.on('scan_completed', (data) => {
                this.handleScanCompleted(data);
            });
            
            this.socket.on('threat_detected', (data) => {
                this.handleThreatDetected(data);
            });
            
        } catch (error) {
            console.error('Failed to connect to WebSocket:', error);
            this.scheduleReconnect();
        }
    }
    
    setupEventListeners() {
        // Connection retry on button click
        document.addEventListener('click', (e) => {
            if (e.target.id === 'retryConnection') {
                this.retryConnection();
            }
        });
        
        // Handle page visibility change
        document.addEventListener('visibilitychange', () => {
            if (document.visibilityState === 'visible' && !this.isConnected) {
                this.retryConnection();
            }
        });
    }
    
    initializeComponents() {
        this.initializeCharts();
        this.initializeTooltips();
        this.loadInitialData();
    }
    
    async apiCall(endpoint, options = {}) {
        const defaultOptions = {
            method: 'GET',
            headers: {
                'Content-Type': 'application/json',
            },
        };
        
        const mergedOptions = { ...defaultOptions, ...options };
        
        try {
            const response = await fetch(endpoint, mergedOptions);
            
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            
            const data = await response.json();
            return data;
        } catch (error) {
            console.error('API call failed:', error);
            this.showAlert('Network error: ' + error.message, 'error');
            throw error;
        }
    }
    
    async loadInitialData() {
        try {
            // Load system status
            const systemData = await this.apiCall('/api/system/status');
            this.updateSystemStatus(systemData);
            
            // Load recent scans
            const scansData = await this.apiCall('/api/scans');
            this.updateScansTable(scansData.scans);
            
            // Load recent threats
            const threatsData = await this.apiCall('/api/threats');
            this.updateThreatsTable(threatsData.threats);
            
            // Load configuration
            const configData = await this.apiCall('/api/config');
            this.updateConfiguration(configData);
            
        } catch (error) {
            console.error('Failed to load initial data:', error);
        }
    }
    
    refreshData() {
        if (this.isConnected) {
            // Data will be updated via WebSocket events
            console.log('Data refresh via WebSocket');
        } else {
            // Fallback to API calls
            this.loadInitialData();
        }
    }
    
    updateSystemStatus(data) {
        const status = data.status;
        const stats = data.stats;
        
        // Update system health
        const healthElement = document.getElementById('overallHealth');
        if (healthElement) {
            healthElement.textContent = stats.system_health + '%';
        }
        
        // Update system metrics
        const cpuElement = document.getElementById('cpuUsage');
        if (cpuElement) {
            cpuElement.textContent = status.cpu_usage + '%';
        }
        
        const memoryElement = document.getElementById('memoryUsage');
        if (memoryElement) {
            memoryElement.textContent = status.memory_usage + '%';
        }
        
        const diskElement = document.getElementById('diskUsage');
        if (diskElement) {
            diskElement.textContent = status.disk_usage + '%';
        }
        
        // Update last update time
        const lastUpdateElement = document.getElementById('lastUpdate');
        if (lastUpdateElement) {
            const lastUpdate = new Date(status.last_update);
            lastUpdateElement.textContent = this.formatRelativeTime(lastUpdate);
        }
        
        this.updateSystemStats(stats);
    }
    
    updateSystemStats(stats) {
        // Update dashboard statistics
        this.updateElement('totalScans', stats.total_scans);
        this.updateElement('threatsDetected', stats.threats_detected);
        this.updateElement('highSeverityThreats', stats.high_severity_threats);
        this.updateElement('systemHealth', stats.system_health + '%');
        
        // Update status bar
        this.updateElement('threatCount', stats.threats_detected + ' Threats');
        this.updateElement('scanCount', stats.total_scans + ' Scans');
        this.updateElement('healthScore', stats.system_health + '% Health');
    }
    
    updateScansTable(scans) {
        const tableBody = document.getElementById('scansTableBody');
        const recentScansBody = document.getElementById('recentScansBody');
        
        if (!tableBody) return;
        
        // Clear existing rows
        tableBody.innerHTML = '';
        if (recentScansBody) recentScansBody.innerHTML = '';
        
        // Add scan rows
        scans.slice(0, 10).forEach(scan => {
            const row = this.createScanRow(scan);
            tableBody.appendChild(row);
            
            // Add to recent scans if not full table
            if (recentScansBody) {
                const recentRow = this.createScanRow(scan);
                recentScansBody.appendChild(recentRow);
            }
        });
    }
    
    createScanRow(scan) {
        const row = document.createElement('tr');
        
        const statusBadge = this.getStatusBadge(scan.status);
        const duration = this.calculateDuration(scan.start_time, scan.end_time);
        
        row.innerHTML = `
            <td><code>${scan.id.substring(0, 8)}...</code></td>
            <td><span class="badge bg-info">${scan.type}</span></td>
            <td>${statusBadge}</td>
            <td>
                <div class="progress" style="height: 6px;">
                    <div class="progress-bar" style="width: ${scan.progress}%"></div>
                </div>
                <small>${scan.progress}%</small>
            </td>
            <td>${this.formatTime(scan.start_time)}</td>
            <td>${scan.files_scanned.toLocaleString()}</td>
            <td><span class="badge bg-danger">${scan.threats_found}</span></td>
            <td>${duration}</td>
            <td>
                <div class="btn-group" role="group">
                    <button class="btn btn-sm btn-outline-info" onclick="viewScanDetails('${scan.id}')">
                        <i class="fas fa-eye"></i>
                    </button>
                    ${scan.status === 'running' ? `
                        <button class="btn btn-sm btn-outline-warning" onclick="stopScan('${scan.id}')">
                            <i class="fas fa-stop"></i>
                        </button>
                    ` : ''}
                </div>
            </td>
        `;
        
        return row;
    }
    
    updateThreatsTable(threats) {
        const tableBody = document.getElementById('threatsTableBody');
        const recentThreatsBody = document.getElementById('recentThreatsBody');
        
        if (!tableBody) return;
        
        // Clear existing rows
        tableBody.innerHTML = '';
        if (recentThreatsBody) recentThreatsBody.innerHTML = '';
        
        // Update statistics
        this.updateThreatStatistics(threats);
        
        // Add threat rows
        threats.slice(0, 10).forEach(threat => {
            const row = this.createThreatRow(threat);
            tableBody.appendChild(row);
            
            // Add to recent threats if not full table
            if (recentThreatsBody) {
                const recentRow = this.createThreatRow(threat);
                recentThreatsBody.appendChild(recentRow);
            }
        });
    }
    
    createThreatRow(threat) {
        const row = document.createElement('tr');
        const severityClass = this.getSeverityClass(threat.severity);
        
        row.innerHTML = `
            <td>
                <input type="checkbox" class="threat-checkbox" value="${threat.id}">
            </td>
            <td>
                <div class="d-flex align-items-center">
                    <i class="fas fa-exclamation-triangle ${severityClass} me-2"></i>
                    <strong>${threat.name}</strong>
                </div>
            </td>
            <td><span class="badge bg-secondary">${threat.type}</span></td>
            <td><span class="badge bg-${this.getSeverityBadgeColor(threat.severity)}">${threat.severity}</span></td>
            <td><code>${this.truncatePath(threat.file_path)}</code></td>
            <td>${this.formatRelativeTime(threat.detection_time)}</td>
            <td>
                <span class="badge bg-${this.getStatusBadgeColor(threat.status)}">
                    ${threat.status}
                </span>
            </td>
            <td>
                <small class="text-muted">${threat.action_taken || 'None'}</small>
            </td>
            <td>
                <div class="btn-group" role="group">
                    <button class="btn btn-sm btn-outline-primary" onclick="viewThreatDetails('${threat.id}')">
                        <i class="fas fa-eye"></i>
                    </button>
                    <button class="btn btn-sm btn-outline-warning" onclick="quarantineThreat('${threat.id}')">
                        <i class="fas fa-quarantine"></i>
                    </button>
                    <button class="btn btn-sm btn-outline-danger" onclick="deleteThreat('${threat.id}')">
                        <i class="fas fa-trash"></i>
                    </button>
                </div>
            </td>
        `;
        
        return row;
    }
    
    updateThreatStatistics(threats) {
        const activeThreats = threats.filter(t => t.status === 'active').length;
        const highSeverity = threats.filter(t => t.severity === 'high').length;
        const quarantined = threats.filter(t => t.status === 'quarantined').length;
        
        this.updateElement('activeThreatsCount', activeThreats);
        this.updateElement('highSeverityCount', highSeverity);
        this.updateElement('quarantinedCount', quarantined);
        
        // Calculate resolved today
        const today = new Date().toDateString();
        const resolvedToday = threats.filter(t => {
            const detectionTime = new Date(t.detection_time);
            return detectionTime.toDateString() === today && t.status === 'resolved';
        }).length;
        
        this.updateElement('resolvedTodayCount', resolvedToday);
    }
    
    handleSystemUpdate(data) {
        this.updateSystemStatus(data);
    }
    
    handleScanProgress(data) {
        // Update scan progress in real-time
        const progressBar = document.getElementById(`progress-${data.scan_id}`);
        if (progressBar) {
            progressBar.style.width = data.progress + '%';
        }
        
        // Update scan statistics
        const filesScannedElement = document.getElementById('progressFilesScanned');
        if (filesScannedElement) {
            filesScannedElement.textContent = data.files_scanned.toLocaleString();
        }
        
        const threatsFoundElement = document.getElementById('progressThreatsFound');
        if (threatsFoundElement) {
            threatsFoundElement.textContent = data.threats_found;
        }
        
        // Refresh the scans table
        this.loadInitialData();
    }
    
    handleScanCompleted(data) {
        this.showAlert(`Scan completed! Found ${data.results.threats_found} threats.`, 'success');
        
        // Refresh data
        this.refreshData();
    }
    
    handleThreatDetected(data) {
        this.showAlert(`New threat detected: ${data.threat.name}`, 'warning');
        
        // Add to threats table
        this.refreshData();
    }
    
    getStatusBadge(status) {
        const statusMap = {
            'running': '<span class="badge bg-warning">Running</span>',
            'completed': '<span class="badge bg-success">Completed</span>',
            'failed': '<span class="badge bg-danger">Failed</span>',
            'paused': '<span class="badge bg-info">Paused</span>'
        };
        
        return statusMap[status] || `<span class="badge bg-secondary">${status}</span>`;
    }
    
    getSeverityClass(severity) {
        const classMap = {
            'high': 'text-danger',
            'medium': 'text-warning',
            'low': 'text-info'
        };
        
        return classMap[severity] || 'text-muted';
    }
    
    getSeverityBadgeColor(severity) {
        const colorMap = {
            'high': 'danger',
            'medium': 'warning',
            'low': 'info'
        };
        
        return colorMap[severity] || 'secondary';
    }
    
    getStatusBadgeColor(status) {
        const colorMap = {
            'active': 'danger',
            'quarantined': 'warning',
            'resolved': 'success',
            'blocked': 'danger'
        };
        
        return colorMap[status] || 'secondary';
    }
    
    formatTime(timestamp) {
        const date = new Date(timestamp);
        return date.toLocaleString();
    }
    
    formatRelativeTime(timestamp) {
        const now = new Date();
        const time = new Date(timestamp);
        const diff = now - time;
        
        const seconds = Math.floor(diff / 1000);
        const minutes = Math.floor(seconds / 60);
        const hours = Math.floor(minutes / 60);
        const days = Math.floor(hours / 24);
        
        if (days > 0) return `${days} day${days > 1 ? 's' : ''} ago`;
        if (hours > 0) return `${hours} hour${hours > 1 ? 's' : ''} ago`;
        if (minutes > 0) return `${minutes} minute${minutes > 1 ? 's' : ''} ago`;
        return 'Just now';
    }
    
    calculateDuration(startTime, endTime) {
        if (!endTime) return 'In progress';
        
        const start = new Date(startTime);
        const end = new Date(endTime);
        const diff = end - start;
        
        const minutes = Math.floor(diff / 60000);
        const hours = Math.floor(minutes / 60);
        const remainingMinutes = minutes % 60;
        
        if (hours > 0) {
            return `${hours}h ${remainingMinutes}m`;
        }
        return `${remainingMinutes}m`;
    }
    
    truncatePath(path, maxLength = 30) {
        if (!path) return 'N/A';
        if (path.length <= maxLength) return path;
        
        const start = path.substring(0, Math.floor(maxLength / 2) - 1);
        const end = path.substring(path.length - Math.floor(maxLength / 2) + 1);
        return `${start}...${end}`;
    }
    
    updateElement(id, value) {
        const element = document.getElementById(id);
        if (element) {
            element.textContent = value;
        }
    }
    
    updateConnectionStatus(connected) {
        const statusElement = document.getElementById('systemStatus');
        if (statusElement) {
            const icon = statusElement.querySelector('i');
            const text = statusElement.querySelector('span');
            
            if (connected) {
                icon.className = 'fas fa-circle text-success';
                text.textContent = 'System Healthy';
                statusElement.className = 'status-indicator text-success';
            } else {
                icon.className = 'fas fa-circle text-danger';
                text.textContent = 'Connection Lost';
                statusElement.className = 'status-indicator text-danger';
            }
        }
    }
    
    scheduleReconnect() {
        if (this.retryCount < this.maxRetries) {
            this.retryCount++;
            setTimeout(() => {
                console.log(`Attempting to reconnect... (${this.retryCount}/${this.maxRetries})`);
                this.connectSocket();
            }, this.retryInterval);
        }
    }
    
    retryConnection() {
        this.retryCount = 0;
        this.connectSocket();
    }
    
    initializeCharts() {
        // Initialize Chart.js instances
        this.initScanActivityChart();
        this.initThreatDistributionChart();
        this.initSystemPerformanceChart();
    }
    
    initScanActivityChart() {
        const ctx = document.getElementById('scanActivityChart');
        if (!ctx) return;
        
        new Chart(ctx, {
            type: 'line',
            data: {
                labels: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'],
                datasets: [{
                    label: 'Scans',
                    data: [12, 19, 3, 5, 2, 3, 10],
                    borderColor: '#4e73df',
                    backgroundColor: 'rgba(78, 115, 223, 0.1)',
                    tension: 0.1
                }, {
                    label: 'Threats',
                    data: [2, 3, 1, 2, 0, 1, 1],
                    borderColor: '#e74a3b',
                    backgroundColor: 'rgba(231, 74, 59, 0.1)',
                    tension: 0.1
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });
    }
    
    initThreatDistributionChart() {
        const ctx = document.getElementById('threatDistributionChart');
        if (!ctx) return;
        
        new Chart(ctx, {
            type: 'doughnut',
            data: {
                labels: ['Trojan', 'Virus', 'Worm', 'Adware', 'Ransomware'],
                datasets: [{
                    data: [35, 25, 15, 20, 5],
                    backgroundColor: [
                        '#e74a3b',
                        '#f6c23e',
                        '#36b9cc',
                        '#1cc88a',
                        '#5a5c69'
                    ]
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'bottom'
                    }
                }
            }
        });
    }
    
    initSystemPerformanceChart() {
        const ctx = document.getElementById('systemPerformanceChart');
        if (!ctx) return;
        
        new Chart(ctx, {
            type: 'line',
            data: {
                labels: ['00:00', '04:00', '08:00', '12:00', '16:00', '20:00'],
                datasets: [{
                    label: 'CPU Usage %',
                    data: [25, 30, 35, 40, 35, 25],
                    borderColor: '#4e73df',
                    backgroundColor: 'rgba(78, 115, 223, 0.1)'
                }, {
                    label: 'Memory Usage %',
                    data: [42, 45, 48, 50, 47, 42],
                    borderColor: '#1cc88a',
                    backgroundColor: 'rgba(28, 200, 138, 0.1)'
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    y: {
                        beginAtZero: true,
                        max: 100
                    }
                }
            }
        });
    }
    
    initializeTooltips() {
        // Initialize Bootstrap tooltips
        const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
        tooltipTriggerList.map(function (tooltipTriggerEl) {
            return new bootstrap.Tooltip(tooltipTriggerEl);
        });
    }
    
    showAlert(message, type = 'info') {
        const alertArea = document.getElementById('alertArea');
        if (!alertArea) return;
        
        const alertId = 'alert-' + Date.now();
        const alertHtml = `
            <div id="${alertId}" class="alert alert-${type} alert-dismissible fade show" role="alert">
                <i class="fas fa-${this.getAlertIcon(type)} me-2"></i>
                ${message}
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        `;
        
        alertArea.insertAdjacentHTML('beforeend', alertHtml);
        
        // Auto-dismiss after 5 seconds
        setTimeout(() => {
            const alert = document.getElementById(alertId);
            if (alert) {
                const bsAlert = new bootstrap.Alert(alert);
                bsAlert.close();
            }
        }, 5000);
    }
    
    getAlertIcon(type) {
        const iconMap = {
            'success': 'check-circle',
            'danger': 'exclamation-circle',
            'warning': 'exclamation-triangle',
            'info': 'info-circle'
        };
        
        return iconMap[type] || 'info-circle';
    }
}

// Global functions for HTML onclick events
function startScan() {
    const form = document.getElementById('newScanForm');
    const formData = new FormData(form);
    
    const scanData = {
        type: formData.get('type') || 'full',
        target_path: formData.get('target_path'),
        priority: formData.get('priority') || 'normal'
    };
    
    // Use WebSocket for real-time updates
    if (window.antivirusInterface && window.antivirusInterface.isConnected) {
        window.antivirusInterface.socket.emit('start_scan_realtime', scanData);
    } else {
        // Fallback to API call
        fetch('/api/scans', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(scanData)
        })
        .then(response => response.json())
        .then(data => {
            window.antivirusInterface.showAlert('Scan started successfully!', 'success');
            bootstrap.Modal.getInstance(document.getElementById('newScanModal')).hide();
            window.antivirusInterface.refreshData();
        })
        .catch(error => {
            window.antivirusInterface.showAlert('Failed to start scan: ' + error.message, 'danger');
        });
    }
}

function stopScan(scanId) {
    if (confirm('Are you sure you want to stop this scan?')) {
        // Implementation would depend on backend API
        window.antivirusInterface.showAlert('Scan stopped', 'info');
        window.antivirusInterface.refreshData();
    }
}

function quarantineThreat(threatId) {
    fetch(`/api/threats/${threatId}`, {
        method: 'PUT',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ action: 'quarantine' })
    })
    .then(response => response.json())
    .then(data => {
        window.antivirusInterface.showAlert('Threat quarantined successfully', 'success');
        window.antivirusInterface.refreshData();
    })
    .catch(error => {
        window.antivirusInterface.showAlert('Failed to quarantine threat', 'danger');
    });
}

function deleteThreat(threatId) {
    if (confirm('Are you sure you want to delete this threat? This action cannot be undone.')) {
        fetch(`/api/threats/${threatId}`, {
            method: 'DELETE'
        })
        .then(response => response.json())
        .then(data => {
            window.antivirusInterface.showAlert('Threat deleted successfully', 'success');
            window.antivirusInterface.refreshData();
        })
        .catch(error => {
            window.antivirusInterface.showAlert('Failed to delete threat', 'danger');
        });
    }
}

function viewScanDetails(scanId) {
    // Implementation would show scan details in a modal
    console.log('View scan details:', scanId);
}

function viewThreatDetails(threatId) {
    // Implementation would show threat details in a modal
    console.log('View threat details:', threatId);
}

// Initialize when DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
    window.antivirusInterface = new AntivirusInterface();
});