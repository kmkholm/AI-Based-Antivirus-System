#!/bin/bash

# Antivirus Web Interface Startup Script

echo "=================================="
echo "Antivirus Web Interface Launcher"
echo "=================================="

# Check if Python is installed
if ! command -v python3 &> /dev/null; then
    echo "Error: Python 3 is not installed or not in PATH"
    exit 1
fi

# Check if we're in the right directory
if [ ! -f "app.py" ]; then
    echo "Error: app.py not found. Please run this script from the web_interface directory."
    exit 1
fi

# Install requirements if not already installed
echo "Checking dependencies..."
if [ ! -d "venv" ]; then
    echo "Creating virtual environment..."
    python3 -m venv venv
fi

source venv/bin/activate
pip install -q -r requirements.txt

# Initialize database
echo "Initializing database..."
python3 -c "
from app import init_database, generate_sample_data
init_database()
generate_sample_data()
print('Database initialized with sample data')
"

# Start the application
echo "Starting Antivirus Web Interface..."
echo "=================================="
echo "🌐 Web Interface: http://localhost:5000"
echo "📊 Dashboard: http://localhost:5000/dashboard"
echo "🔍 Scans: http://localhost:5000/scans"
echo "⚠️  Threats: http://localhost:5000/threats"
echo "💻 System: http://localhost:5000/system"
echo "⚙️  Settings: http://localhost:5000/settings"
echo "📈 Reports: http://localhost:5000/reports"
echo "=================================="
echo "Press Ctrl+C to stop the server"
echo ""

python3 app.py