#!/usr/bin/env python3
"""
Antivirus Web Interface - Test and Validation Script
This script validates the web interface structure and functionality
"""

import os
import sys
import sqlite3
from datetime import datetime

def check_file_structure():
    """Check if all required files and directories exist"""
    print("🔍 Checking file structure...")
    
    required_files = [
        'app.py',
        'requirements.txt',
        'README.md',
        'DEVELOPMENT_SUMMARY.md',
        'start.sh',
        'start.bat'
    ]
    
    required_dirs = [
        'templates',
        'static',
        'static/css',
        'static/js'
    ]
    
    required_templates = [
        'base.html',
        'dashboard.html',
        'scans.html',
        'threats.html',
        'system.html',
        'settings.html',
        'reports.html'
    ]
    
    required_static = [
        'static/css/style.css',
        'static/js/main.js'
    ]
    
    all_good = True
    
    # Check files
    for file in required_files:
        if os.path.exists(file):
            print(f"  ✅ {file}")
        else:
            print(f"  ❌ {file} - MISSING")
            all_good = False
    
    # Check directories
    for dir in required_dirs:
        if os.path.exists(dir):
            print(f"  ✅ {dir}/")
        else:
            print(f"  ❌ {dir}/ - MISSING")
            all_good = False
    
    # Check templates
    for template in required_templates:
        if os.path.exists(f'templates/{template}'):
            print(f"  ✅ templates/{template}")
        else:
            print(f"  ❌ templates/{template} - MISSING")
            all_good = False
    
    # Check static files
    for static_file in required_static:
        if os.path.exists(static_file):
            print(f"  ✅ {static_file}")
        else:
            print(f"  ❌ {static_file} - MISSING")
            all_good = False
    
    return all_good

def check_dependencies():
    """Check if required Python packages can be imported"""
    print("\n📦 Checking dependencies...")
    
    required_packages = [
        'flask',
        'flask_socketio',
        'psutil',
        'sqlite3'
    ]
    
    all_good = True
    
    for package in required_packages:
        try:
            if package == 'sqlite3':
                import sqlite3
            elif package == 'psutil':
                import psutil
            elif package == 'flask':
                import flask
            elif package == 'flask_socketio':
                import flask_socketio
            
            print(f"  ✅ {package}")
        except ImportError as e:
            print(f"  ❌ {package} - {e}")
            all_good = False
    
    return all_good

def check_flask_app():
    """Check if the Flask app can be imported and basic routes exist"""
    print("\n🌐 Checking Flask application...")
    
    try:
        # Add current directory to path
        sys.path.insert(0, '.')
        
        # Import the Flask app
        from app import app, antivirus_state
        
        print("  ✅ Flask app imported successfully")
        
        # Check if app has routes
        with app.app_context():
            routes = [rule.rule for rule in app.url_map.iter_rules()]
            expected_routes = ['/', '/dashboard', '/scans', '/threats', '/system', '/settings', '/reports']
            
            for route in expected_routes:
                if route in routes:
                    print(f"  ✅ Route {route}")
                else:
                    print(f"  ❌ Route {route} - MISSING")
        
        return True
        
    except Exception as e:
        print(f"  ❌ Flask app error: {e}")
        return False

def create_test_database():
    """Create a test database and validate schema"""
    print("\n🗄️  Checking database schema...")
    
    try:
        # Import and initialize database
        from app import init_database, generate_sample_data
        
        # Create test database in memory
        test_db = ':memory:'
        
        # Create tables
        init_database()
        print("  ✅ Database schema created successfully")
        
        # Generate sample data
        generate_sample_data()
        print("  ✅ Sample data generated")
        
        return True
        
    except Exception as e:
        print(f"  ❌ Database error: {e}")
        return False

def check_file_sizes():
    """Check file sizes to ensure they're reasonable"""
    print("\n📊 Checking file sizes...")
    
    size_info = {
        'app.py': ('Main application', 1000, 50000),
        'templates/base.html': ('Base template', 500, 20000),
        'templates/dashboard.html': ('Dashboard template', 500, 20000),
        'static/css/style.css': ('Main stylesheet', 1000, 50000),
        'static/js/main.js': ('Main JavaScript', 1000, 100000)
    }
    
    all_good = True
    
    for file_path, (description, min_size, max_size) in size_info.items():
        if os.path.exists(file_path):
            size = os.path.getsize(file_path)
            if min_size <= size <= max_size:
                print(f"  ✅ {file_path} ({description}) - {size:,} bytes")
            else:
                print(f"  ⚠️  {file_path} ({description}) - {size:,} bytes (unusual size)")
        else:
            print(f"  ❌ {file_path} - MISSING")
            all_good = False
    
    return all_good

def run_validation():
    """Run all validation checks"""
    print("=" * 60)
    print("🛡️  ANTIVIRUS WEB INTERFACE - VALIDATION REPORT")
    print("=" * 60)
    print(f"Timestamp: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print(f"Python Version: {sys.version}")
    print(f"Current Directory: {os.getcwd()}")
    print()
    
    checks = [
        ("File Structure", check_file_structure),
        ("Dependencies", check_dependencies),
        ("Flask Application", check_flask_app),
        ("Database", create_test_database),
        ("File Sizes", check_file_sizes)
    ]
    
    results = []
    
    for check_name, check_function in checks:
        try:
            result = check_function()
            results.append((check_name, result))
        except Exception as e:
            print(f"  ❌ {check_name} check failed: {e}")
            results.append((check_name, False))
    
    # Summary
    print("\n" + "=" * 60)
    print("📋 VALIDATION SUMMARY")
    print("=" * 60)
    
    passed = 0
    total = len(results)
    
    for check_name, result in results:
        status = "✅ PASS" if result else "❌ FAIL"
        print(f"{check_name:.<30} {status}")
        if result:
            passed += 1
    
    print()
    print(f"Results: {passed}/{total} checks passed")
    
    if passed == total:
        print("🎉 All validation checks passed! The web interface is ready to use.")
        print("\n🚀 To start the application:")
        print("   python app.py")
        print("   or")
        print("   ./start.sh")
        print("\n🌐 Then visit: http://localhost:5000")
    else:
        print("⚠️  Some validation checks failed. Please review the issues above.")
        return False
    
    return True

def show_usage_instructions():
    """Show usage instructions"""
    print("\n" + "=" * 60)
    print("📖 USAGE INSTRUCTIONS")
    print("=" * 60)
    print("1. Install dependencies:")
    print("   pip install -r requirements.txt")
    print()
    print("2. Start the application:")
    print("   python app.py")
    print("   ./start.sh    # Linux/macOS")
    print("   start.bat     # Windows")
    print()
    print("3. Access the web interface:")
    print("   http://localhost:5000")
    print()
    print("4. Available pages:")
    print("   Dashboard:    http://localhost:5000/dashboard")
    print("   Scans:        http://localhost:5000/scans")
    print("   Threats:      http://localhost:5000/threats")
    print("   System:       http://localhost:5000/system")
    print("   Settings:     http://localhost:5000/settings")
    print("   Reports:      http://localhost:5000/reports")
    print()
    print("5. API endpoints:")
    print("   GET  /api/scans          - Get all scans")
    print("   POST /api/scans          - Start new scan")
    print("   GET  /api/threats        - Get all threats")
    print("   GET  /api/system/status  - Get system status")
    print("   GET  /api/reports/overview - Get reports data")

if __name__ == "__main__":
    try:
        success = run_validation()
        if success:
            show_usage_instructions()
        else:
            print("\n❌ Validation failed. Please fix the issues and run again.")
            sys.exit(1)
    except KeyboardInterrupt:
        print("\n\n⚠️  Validation interrupted by user.")
        sys.exit(1)
    except Exception as e:
        print(f"\n❌ Unexpected error during validation: {e}")
        sys.exit(1)