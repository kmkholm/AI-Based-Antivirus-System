"""
Model Evaluator

Evaluates trained SVM models with comprehensive metrics, cross-validation,
and performance analysis for malware detection.
"""

import logging
import numpy as np
import time
from typing import Dict, List, Any, Optional, Tuple, Union
from pathlib import Path
import pandas as pd
from sklearn.model_selection import cross_val_score, StratifiedKFold, learning_curve, validation_curve
from sklearn.metrics import (accuracy_score, precision_score, recall_score, f1_score, 
                           roc_auc_score, roc_curve, precision_recall_curve, 
                           confusion_matrix, classification_report)
import matplotlib.pyplot as plt
import seaborn as sns

from .svm_detector import SVMDetector
from .svm_model import SVMModel
from ..utils import get_logger


class ModelEvaluator:
    """
    Comprehensive model evaluation system for SVM-based malware detection
    
    Features:
    - Cross-validation evaluation
    - Learning curve analysis
    - Feature importance analysis
    - Performance visualization
    - Model comparison
    """
    
    def __init__(self, config: Optional[Dict] = None):
        self.logger = get_logger(__name__)
        self.config = config or self._get_default_config()
        
        # Evaluation results
        self.evaluation_results = {}
        self.comparison_results = {}
        
        self.logger.info("Model Evaluator initialized")
    
    def _get_default_config(self) -> Dict:
        """Get default evaluation configuration"""
        return {
            'cv_folds': 5,
            'scoring_metrics': ['accuracy', 'precision_weighted', 'recall_weighted', 'f1_weighted', 'roc_auc'],
            'learning_curve_sizes': np.linspace(0.1, 1.0, 10),
            'validation_curve_params': {
                'C': [0.1, 1, 10, 100],
                'gamma': ['scale', 'auto', 0.001, 0.01, 0.1, 1]
            },
            'save_plots': True,
            'output_directory': './evaluation',
            'plot_format': 'png',
            'figure_size': (10, 8)
        }
    
    def evaluate_model(self, model: SVMDetector, X: np.ndarray, y: np.ndarray, 
                      model_name: str = 'model') -> Dict[str, Any]:
        """
        Comprehensive evaluation of a trained model
        
        Args:
            model: Trained SVM detector
            X: Feature matrix
            y: Labels
            model_name: Name for the model
            
        Returns:
            Evaluation results
        """
        try:
            self.logger.info(f"Starting comprehensive evaluation for {model_name}")
            
            evaluation_start = time.time()
            
            # Basic evaluation
            basic_results = self._basic_evaluation(model, X, y)
            
            # Cross-validation evaluation
            cv_results = self._cross_validation_evaluation(model, X, y)
            
            # Learning curve analysis
            learning_curve_results = self._learning_curve_analysis(model, X, y)
            
            # Validation curve analysis
            validation_curve_results = self._validation_curve_analysis(model, X, y)
            
            # Feature importance analysis
            feature_importance_results = self._feature_importance_analysis(model, X, y)
            
            # Performance visualization
            if self.config['save_plots']:
                self._create_performance_plots(model, X, y, model_name)
            
            evaluation_time = time.time() - evaluation_start
            
            # Combine all results
            evaluation_results = {
                'model_name': model_name,
                'evaluation_time': evaluation_time,
                'basic_evaluation': basic_results,
                'cross_validation': cv_results,
                'learning_curve': learning_curve_results,
                'validation_curve': validation_curve_results,
                'feature_importance': feature_importance_results,
                'timestamp': time.time()
            }
            
            # Store results
            self.evaluation_results[model_name] = evaluation_results
            
            self.logger.info(f"Model evaluation completed for {model_name}")
            
            return evaluation_results
            
        except Exception as e:
            self.logger.error(f"Model evaluation error: {str(e)}")
            raise
    
    def _basic_evaluation(self, model: SVMDetector, X: np.ndarray, y: np.ndarray) -> Dict[str, Any]:
        """Perform basic evaluation metrics"""
        try:
            # Make predictions
            start_time = time.time()
            
            # Get predictions for all samples
            all_results = []
            for i in range(len(X)):
                feature_vector = X[i:i+1]
                result = model._make_prediction(feature_vector)[0]
                all_results.append(result)
            
            predictions = np.array(all_results)
            prediction_time = time.time() - start_time
            
            # Calculate metrics
            accuracy = accuracy_score(y, predictions)
            precision = precision_score(y, predictions, average='weighted', zero_division=0)
            recall = recall_score(y, predictions, average='weighted', zero_division=0)
            f1 = f1_score(y, predictions, average='weighted', zero_division=0)
            
            # AUC for binary classification
            auc = None
            if len(np.unique(y)) == 2:
                try:
                    # Get probabilities for AUC calculation
                    all_probabilities = []
                    for i in range(len(X)):
                        feature_vector = X[i:i+1]
                        probabilities = model._make_prediction(feature_vector)[2]
                        all_probabilities.append(probabilities[1] if len(probabilities) > 1 else 0.5)
                    
                    auc = roc_auc_score(y, all_probabilities)
                except Exception:
                    pass
            
            # Confusion matrix
            cm = confusion_matrix(y, predictions)
            
            # Classification report
            class_report = classification_report(y, predictions, output_dict=True, zero_division=0)
            
            return {
                'accuracy': float(accuracy),
                'precision': float(precision),
                'recall': float(recall),
                'f1_score': float(f1),
                'auc': float(auc) if auc is not None else None,
                'confusion_matrix': cm.tolist(),
                'classification_report': class_report,
                'prediction_time': float(prediction_time),
                'samples_per_second': float(len(X) / prediction_time) if prediction_time > 0 else 0.0
            }
            
        except Exception as e:
            self.logger.error(f"Basic evaluation error: {str(e)}")
            return {}
    
    def _cross_validation_evaluation(self, model: SVMDetector, X: np.ndarray, y: np.ndarray) -> Dict[str, Any]:
        """Perform cross-validation evaluation"""
        try:
            cv_results = {}
            cv_folds = self.config['cv_folds']
            
            # Use StratifiedKFold for balanced cross-validation
            skf = StratifiedKFold(n_splits=cv_folds, shuffle=True, random_state=42)
            
            for metric in self.config['scoring_metrics']:
                try:
                    scores = cross_val_score(
                        model.primary_model.model.pipeline,
                        X, y,
                        cv=skf,
                        scoring=metric,
                        n_jobs=-1
                    )
                    
                    cv_results[metric] = {
                        'scores': scores.tolist(),
                        'mean': float(np.mean(scores)),
                        'std': float(np.std(scores)),
                        'min': float(np.min(scores)),
                        'max': float(np.max(scores))
                    }
                    
                except Exception as e:
                    self.logger.warning(f"Cross-validation failed for metric {metric}: {str(e)}")
                    cv_results[metric] = {'error': str(e)}
            
            return cv_results
            
        except Exception as e:
            self.logger.error(f"Cross-validation evaluation error: {str(e)}")
            return {}
    
    def _learning_curve_analysis(self, model: SVMDetector, X: np.ndarray, y: np.ndarray) -> Dict[str, Any]:
        """Perform learning curve analysis"""
        try:
            train_sizes = self.config['learning_curve_sizes']
            
            # Generate learning curves
            train_sizes_abs, train_scores, val_scores = learning_curve(
                model.primary_model.model.pipeline,
                X, y,
                train_sizes=train_sizes,
                cv=self.config['cv_folds'],
                scoring='f1_weighted',
                n_jobs=-1,
                random_state=42
            )
            
            # Calculate statistics
            train_scores_mean = np.mean(train_scores, axis=1)
            train_scores_std = np.std(train_scores, axis=1)
            val_scores_mean = np.mean(val_scores, axis=1)
            val_scores_std = np.std(val_scores, axis=1)
            
            return {
                'train_sizes': train_sizes_abs.tolist(),
                'train_scores_mean': train_scores_mean.tolist(),
                'train_scores_std': train_scores_std.tolist(),
                'val_scores_mean': val_scores_mean.tolist(),
                'val_scores_std': val_scores_std.tolist(),
                'convergence_analysis': {
                    'final_train_score': float(train_scores_mean[-1]),
                    'final_val_score': float(val_scores_mean[-1]),
                    'score_gap': float(train_scores_mean[-1] - val_scores_mean[-1]),
                    'is_overfitting': bool(train_scores_mean[-1] - val_scores_mean[-1] > 0.1)
                }
            }
            
        except Exception as e:
            self.logger.error(f"Learning curve analysis error: {str(e)}")
            return {}
    
    def _validation_curve_analysis(self, model: SVMDetector, X: np.ndarray, y: np.ndarray) -> Dict[str, Any]:
        """Perform validation curve analysis for hyperparameter tuning"""
        try:
            validation_results = {}
            cv_folds = min(3, self.config['cv_folds'])  # Use fewer folds for speed
            
            # Analyze C parameter
            if 'C' in self.config['validation_curve_params']:
                C_values = self.config['validation_curve_params']['C']
                
                train_scores, val_scores = validation_curve(
                    model.primary_model.model.pipeline,
                    X, y,
                    param_name='svm__C',
                    param_range=C_values,
                    cv=cv_folds,
                    scoring='f1_weighted',
                    n_jobs=-1
                )
                
                validation_results['C_parameter'] = {
                    'C_values': C_values,
                    'train_scores_mean': np.mean(train_scores, axis=1).tolist(),
                    'train_scores_std': np.std(train_scores, axis=1).tolist(),
                    'val_scores_mean': np.mean(val_scores, axis=1).tolist(),
                    'val_scores_std': np.std(val_scores, axis=1).tolist(),
                    'best_C': C_values[np.argmax(np.mean(val_scores, axis=1))]
                }
            
            # Analyze gamma parameter (for RBF kernel)
            if 'gamma' in self.config['validation_curve_params'] and model.primary_model.kernel == 'rbf':
                gamma_values = self.config['validation_curve_params']['gamma']
                
                train_scores, val_scores = validation_curve(
                    model.primary_model.model.pipeline,
                    X, y,
                    param_name='svm__gamma',
                    param_range=gamma_values,
                    cv=cv_folds,
                    scoring='f1_weighted',
                    n_jobs=-1
                )
                
                validation_results['gamma_parameter'] = {
                    'gamma_values': gamma_values,
                    'train_scores_mean': np.mean(train_scores, axis=1).tolist(),
                    'train_scores_std': np.std(train_scores, axis=1).tolist(),
                    'val_scores_mean': np.mean(val_scores, axis=1).tolist(),
                    'val_scores_std': np.std(val_scores, axis=1).tolist(),
                    'best_gamma': gamma_values[np.argmax(np.mean(val_scores, axis=1))]
                }
            
            return validation_results
            
        except Exception as e:
            self.logger.error(f"Validation curve analysis error: {str(e)}")
            return {}
    
    def _feature_importance_analysis(self, model: SVMDetector, X: np.ndarray, y: np.ndarray) -> Dict[str, Any]:
        """Analyze feature importance (simplified implementation)"""
        try:
            if not model.primary_model.model.is_fitted:
                return {'error': 'Model not fitted'}
            
            # Get support vectors
            support_vectors = model.primary_model.model.get_support_vectors()
            if support_vectors is None or len(support_vectors) == 0:
                return {'error': 'No support vectors found'}
            
            # Simplified feature importance based on support vector density
            # In practice, this would use more sophisticated methods
            feature_importance = {}
            
            # Calculate variance in support vectors for each feature
            for i in range(X.shape[1]):
                feature_values = support_vectors[:, i]
                variance = np.var(feature_values)
                feature_importance[f'feature_{i}'] = float(variance)
            
            # Sort by importance
            sorted_features = sorted(feature_importance.items(), key=lambda x: x[1], reverse=True)
            
            return {
                'feature_importance_scores': dict(sorted_features[:20]),  # Top 20 features
                'top_10_features': [f[0] for f in sorted_features[:10]],
                'importance_distribution': {
                    'max_importance': float(max(feature_importance.values())),
                    'min_importance': float(min(feature_importance.values())),
                    'mean_importance': float(np.mean(list(feature_importance.values()))),
                    'std_importance': float(np.std(list(feature_importance.values())))
                }
            }
            
        except Exception as e:
            self.logger.error(f"Feature importance analysis error: {str(e)}")
            return {'error': str(e)}
    
    def _create_performance_plots(self, model: SVMDetector, X: np.ndarray, y: np.ndarray, model_name: str):
        """Create performance visualization plots"""
        try:
            output_dir = Path(self.config['output_directory'])
            output_dir.mkdir(parents=True, exist_ok=True)
            
            # Create plots directory
            plots_dir = output_dir / 'plots'
            plots_dir.mkdir(exist_ok=True)
            
            # Set up matplotlib
            plt.style.use('default')
            
            # 1. Learning Curve Plot
            self._plot_learning_curve(model, X, y, plots_dir / f'{model_name}_learning_curve.png')
            
            # 2. ROC Curve
            self._plot_roc_curve(model, X, y, plots_dir / f'{model_name}_roc_curve.png')
            
            # 3. Precision-Recall Curve
            self._plot_precision_recall_curve(model, X, y, plots_dir / f'{model_name}_pr_curve.png')
            
            # 4. Confusion Matrix
            self._plot_confusion_matrix(model, X, y, plots_dir / f'{model_name}_confusion_matrix.png')
            
            # 5. Feature Importance (if available)
            self._plot_feature_importance(model, plots_dir / f'{model_name}_feature_importance.png')
            
        except Exception as e:
            self.logger.error(f"Plot creation error: {str(e)}")
    
    def _plot_learning_curve(self, model: SVMDetector, X: np.ndarray, y: np.ndarray, output_path: Path):
        """Plot learning curve"""
        try:
            train_sizes = self.config['learning_curve_sizes']
            
            train_sizes_abs, train_scores, val_scores = learning_curve(
                model.primary_model.model.pipeline,
                X, y,
                train_sizes=train_sizes,
                cv=self.config['cv_folds'],
                scoring='f1_weighted',
                n_jobs=-1,
                random_state=42
            )
            
            plt.figure(figsize=self.config['figure_size'])
            
            train_scores_mean = np.mean(train_scores, axis=1)
            train_scores_std = np.std(train_scores, axis=1)
            val_scores_mean = np.mean(val_scores, axis=1)
            val_scores_std = np.std(val_scores, axis=1)
            
            plt.plot(train_sizes_abs, train_scores_mean, 'o-', color='r', label='Training score')
            plt.fill_between(train_sizes_abs, train_scores_mean - train_scores_std,
                           train_scores_mean + train_scores_std, alpha=0.1, color='r')
            
            plt.plot(train_sizes_abs, val_scores_mean, 'o-', color='g', label='Validation score')
            plt.fill_between(train_sizes_abs, val_scores_mean - val_scores_std,
                           val_scores_mean + val_scores_std, alpha=0.1, color='g')
            
            plt.xlabel('Training Set Size')
            plt.ylabel('F1 Score')
            plt.title('Learning Curve')
            plt.legend(loc='best')
            plt.grid(True)
            plt.tight_layout()
            
            plt.savefig(output_path, dpi=300, bbox_inches='tight')
            plt.close()
            
        except Exception as e:
            self.logger.error(f"Learning curve plot error: {str(e)}")
    
    def _plot_roc_curve(self, model: SVMDetector, X: np.ndarray, y: np.ndarray, output_path: Path):
        """Plot ROC curve"""
        try:
            # Get predictions and probabilities
            y_pred_proba = []
            for i in range(len(X)):
                feature_vector = X[i:i+1]
                probabilities = model._make_prediction(feature_vector)[2]
                y_pred_proba.append(probabilities[1] if len(probabilities) > 1 else 0.5)
            
            y_pred_proba = np.array(y_pred_proba)
            
            # Calculate ROC curve
            fpr, tpr, _ = roc_curve(y, y_pred_proba)
            auc_score = roc_auc_score(y, y_pred_proba)
            
            plt.figure(figsize=self.config['figure_size'])
            
            plt.plot(fpr, tpr, color='darkorange', lw=2, label=f'ROC curve (AUC = {auc_score:.3f})')
            plt.plot([0, 1], [0, 1], color='navy', lw=2, linestyle='--', label='Random')
            
            plt.xlim([0.0, 1.0])
            plt.ylim([0.0, 1.05])
            plt.xlabel('False Positive Rate')
            plt.ylabel('True Positive Rate')
            plt.title('Receiver Operating Characteristic (ROC) Curve')
            plt.legend(loc='lower right')
            plt.grid(True, alpha=0.3)
            plt.tight_layout()
            
            plt.savefig(output_path, dpi=300, bbox_inches='tight')
            plt.close()
            
        except Exception as e:
            self.logger.error(f"ROC curve plot error: {str(e)}")
    
    def _plot_precision_recall_curve(self, model: SVMDetector, X: np.ndarray, y: np.ndarray, output_path: Path):
        """Plot precision-recall curve"""
        try:
            # Get predictions and probabilities
            y_pred_proba = []
            for i in range(len(X)):
                feature_vector = X[i:i+1]
                probabilities = model._make_prediction(feature_vector)[2]
                y_pred_proba.append(probabilities[1] if len(probabilities) > 1 else 0.5)
            
            y_pred_proba = np.array(y_pred_proba)
            
            # Calculate precision-recall curve
            precision, recall, _ = precision_recall_curve(y, y_pred_proba)
            
            plt.figure(figsize=self.config['figure_size'])
            
            plt.plot(recall, precision, color='blue', lw=2)
            plt.xlabel('Recall')
            plt.ylabel('Precision')
            plt.title('Precision-Recall Curve')
            plt.grid(True, alpha=0.3)
            plt.tight_layout()
            
            plt.savefig(output_path, dpi=300, bbox_inches='tight')
            plt.close()
            
        except Exception as e:
            self.logger.error(f"Precision-recall curve plot error: {str(e)}")
    
    def _plot_confusion_matrix(self, model: SVMDetector, X: np.ndarray, y: np.ndarray, output_path: Path):
        """Plot confusion matrix"""
        try:
            # Get predictions
            predictions = []
            for i in range(len(X)):
                feature_vector = X[i:i+1]
                prediction = model._make_prediction(feature_vector)[0]
                predictions.append(prediction)
            
            predictions = np.array(predictions)
            
            # Calculate confusion matrix
            cm = confusion_matrix(y, predictions)
            
            plt.figure(figsize=(8, 6))
            
            sns.heatmap(cm, annot=True, fmt='d', cmap='Blues',
                       xticklabels=['Benign', 'Malicious'],
                       yticklabels=['Benign', 'Malicious'])
            
            plt.title('Confusion Matrix')
            plt.ylabel('True Label')
            plt.xlabel('Predicted Label')
            plt.tight_layout()
            
            plt.savefig(output_path, dpi=300, bbox_inches='tight')
            plt.close()
            
        except Exception as e:
            self.logger.error(f"Confusion matrix plot error: {str(e)}")
    
    def _plot_feature_importance(self, model: SVMDetector, output_path: Path):
        """Plot feature importance"""
        try:
            # Get feature importance if available
            feature_importance = model._get_feature_importance()
            
            if not feature_importance:
                # Create a placeholder plot
                plt.figure(figsize=self.config['figure_size'])
                plt.text(0.5, 0.5, 'Feature importance analysis\nnot available', 
                        ha='center', va='center', transform=plt.gca().transAxes,
                        fontsize=16)
                plt.title('Feature Importance')
                plt.axis('off')
                plt.tight_layout()
                
                plt.savefig(output_path, dpi=300, bbox_inches='tight')
                plt.close()
                return
            
            # Plot top 20 features
            features = list(feature_importance.keys())[:20]
            importance = list(feature_importance.values())[:20]
            
            plt.figure(figsize=(12, 8))
            
            y_pos = np.arange(len(features))
            plt.barh(y_pos, importance)
            plt.yticks(y_pos, features)
            plt.xlabel('Importance Score')
            plt.title('Top 20 Feature Importance')
            plt.tight_layout()
            
            plt.savefig(output_path, dpi=300, bbox_inches='tight')
            plt.close()
            
        except Exception as e:
            self.logger.error(f"Feature importance plot error: {str(e)}")
    
    def compare_models(self, evaluation_results: Dict[str, Dict[str, Any]]) -> Dict[str, Any]:
        """
        Compare multiple model evaluation results
        
        Args:
            evaluation_results: Dictionary of model evaluation results
            
        Returns:
            Model comparison results
        """
        try:
            comparison = {
                'models_compared': list(evaluation_results.keys()),
                'comparison_metrics': ['accuracy', 'f1_score', 'auc'],
                'rankings': {},
                'summary': {}
            }
            
            # Extract key metrics for comparison
            for model_name, results in evaluation_results.items():
                basic_eval = results.get('basic_evaluation', {})
                comparison['rankings'][model_name] = {
                    'accuracy': basic_eval.get('accuracy', 0.0),
                    'f1_score': basic_eval.get('f1_score', 0.0),
                    'auc': basic_eval.get('auc', 0.0),
                    'samples_per_second': basic_eval.get('samples_per_second', 0.0)
                }
            
            # Create rankings
            for metric in comparison['comparison_metrics']:
                sorted_models = sorted(
                    comparison['rankings'].items(),
                    key=lambda x: x[1][metric],
                    reverse=True
                )
                comparison[f'{metric}_ranking'] = [model for model, _ in sorted_models]
            
            # Summary statistics
            all_f1_scores = [data['f1_score'] for data in comparison['rankings'].values()]
            all_accuracies = [data['accuracy'] for data in comparison['rankings'].values()]
            
            comparison['summary'] = {
                'best_f1_model': comparison['f1_ranking'][0] if comparison['f1_ranking'] else None,
                'best_accuracy_model': comparison['accuracy_ranking'][0] if comparison['accuracy_ranking'] else None,
                'avg_f1_score': np.mean(all_f1_scores) if all_f1_scores else 0.0,
                'avg_accuracy': np.mean(all_accuracies) if all_accuracies else 0.0,
                'f1_score_std': np.std(all_f1_scores) if all_f1_scores else 0.0,
                'accuracy_std': np.std(all_accuracies) if all_accuracies else 0.0
            }
            
            self.comparison_results = comparison
            
            self.logger.info(f"Model comparison completed: {len(evaluation_results)} models")
            
            return comparison
            
        except Exception as e:
            self.logger.error(f"Model comparison error: {str(e)}")
            raise
    
    def save_evaluation_results(self, output_dir: str):
        """Save all evaluation results to files"""
        try:
            output_path = Path(output_dir)
            output_path.mkdir(parents=True, exist_ok=True)
            
            # Save individual evaluation results
            for model_name, results in self.evaluation_results.items():
                model_file = output_path / f'{model_name}_evaluation.json'
                with open(model_file, 'w') as f:
                    import json
                    json.dump(results, f, indent=2, default=str)
            
            # Save comparison results if available
            if self.comparison_results:
                comparison_file = output_path / 'model_comparison.json'
                with open(comparison_file, 'w') as f:
                    import json
                    json.dump(self.comparison_results, f, indent=2, default=str)
            
            # Create summary report
            self._create_summary_report(output_path)
            
            self.logger.info(f"Evaluation results saved to {output_dir}")
            
        except Exception as e:
            self.logger.error(f"Results saving error: {str(e)}")
    
    def _create_summary_report(self, output_path: Path):
        """Create a summary report of all evaluations"""
        try:
            report_path = output_path / 'evaluation_summary.md'
            
            with open(report_path, 'w') as f:
                f.write("# Model Evaluation Summary\n\n")
                f.write(f"Generated on: {time.strftime('%Y-%m-%d %H:%M:%S')}\n\n")
                
                f.write("## Models Evaluated\n")
                for model_name in self.evaluation_results.keys():
                    f.write(f"- {model_name}\n")
                f.write("\n")
                
                # Best model
                if self.comparison_results:
                    best_model = self.comparison_results['summary']['best_f1_model']
                    if best_model:
                        f.write(f"## Best Model: {best_model}\n\n")
                        f.write(f"- F1 Score: {self.comparison_results['rankings'][best_model]['f1_score']:.4f}\n")
                        f.write(f"- Accuracy: {self.comparison_results['rankings'][best_model]['accuracy']:.4f}\n")
                        if self.comparison_results['rankings'][best_model]['auc']:
                            f.write(f"- AUC: {self.comparison_results['rankings'][best_model]['auc']:.4f}\n")
                        f.write("\n")
                
                # Detailed results
                f.write("## Detailed Results\n\n")
                for model_name, results in self.evaluation_results.items():
                    basic_eval = results.get('basic_evaluation', {})
                    f.write(f"### {model_name}\n")
                    f.write(f"- Accuracy: {basic_eval.get('accuracy', 0.0):.4f}\n")
                    f.write(f"- F1 Score: {basic_eval.get('f1_score', 0.0):.4f}\n")
                    f.write(f"- Precision: {basic_eval.get('precision', 0.0):.4f}\n")
                    f.write(f"- Recall: {basic_eval.get('recall', 0.0):.4f}\n")
                    if basic_eval.get('auc'):
                        f.write(f"- AUC: {basic_eval.get('auc'):.4f}\n")
                    f.write(f"- Samples/second: {basic_eval.get('samples_per_second', 0.0):.1f}\n\n")
            
        except Exception as e:
            self.logger.error(f"Summary report creation error: {str(e)}")
    
    def get_evaluation_statistics(self) -> Dict[str, Any]:
        """Get evaluation statistics"""
        return {
            'models_evaluated': len(self.evaluation_results),
            'comparison_available': bool(self.comparison_results),
            'evaluation_results_keys': list(self.evaluation_results.keys())
        }