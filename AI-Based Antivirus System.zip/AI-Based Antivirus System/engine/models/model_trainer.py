"""
Model Trainer

Trains and manages SVM models for malware detection with cross-validation,
hyperparameter tuning, and ensemble training capabilities.
"""

import logging
import numpy as np
import time
from typing import Dict, List, Any, Optional, Tuple, Union
from pathlib import Path
import pandas as pd
from sklearn.model_selection import train_test_split, cross_val_score, StratifiedKFold, GridSearchCV
from sklearn.metrics import classification_report, confusion_matrix
import matplotlib.pyplot as plt
import seaborn as sns

from .svm_detector import SVMDetector
from .svm_model import create_svm_model
from ..utils import get_logger


class ModelTrainer:
    """
    Comprehensive model training system for SVM-based malware detection
    
    Features:
    - Cross-validation training
    - Hyperparameter optimization
    - Ensemble model training
    - Performance analysis
    - Model selection
    """
    
    def __init__(self, config: Optional[Dict] = None):
        self.logger = get_logger(__name__)
        self.config = config or self._get_default_config()
        
        # Training data
        self.X_train = None
        self.X_test = None
        self.y_train = None
        self.y_test = None
        self.feature_names = []
        
        # Trained models
        self.trained_models = {}
        self.best_model = None
        self.ensemble_models = []
        
        # Training results
        self.training_history = []
        self.validation_results = {}
        
        self.logger.info("Model Trainer initialized")
    
    def _get_default_config(self) -> Dict:
        """Get default training configuration"""
        return {
            'test_size': 0.2,
            'cv_folds': 5,
            'random_state': 42,
            'hyperparameter_tuning': True,
            'tuning_cv': 3,
            'ensemble_training': False,
            'ensemble_size': 3,
            'feature_selection': 'none',  # 'none', 'variance', 'mutual_info', 'rfe'
            'feature_selection_k': 50,
            'scaling': 'standard',  # 'none', 'standard', 'minmax', 'robust'
            'evaluation_metrics': ['accuracy', 'precision', 'recall', 'f1', 'auc'],
            'save_models': True,
            'output_directory': './models'
        }
    
    def prepare_data(self, X: np.ndarray, y: np.ndarray, feature_names: Optional[List[str]] = None):
        """
        Prepare training and validation data
        
        Args:
            X: Feature matrix
            y: Labels (0=benign, 1=malicious)
            feature_names: List of feature names
        """
        try:
            self.logger.info(f"Preparing data: {X.shape[0]} samples, {X.shape[1]} features")
            
            # Validate data
            if X.size == 0 or y.size == 0:
                raise ValueError("Empty training data")
            
            if X.shape[0] != y.shape[0]:
                raise ValueError("X and y must have same number of samples")
            
            # Store feature names
            if feature_names:
                self.feature_names = feature_names
            else:
                self.feature_names = [f'feature_{i}' for i in range(X.shape[1])]
            
            # Split data
            self.X_train, self.X_test, self.y_train, self.y_test = train_test_split(
                X, y,
                test_size=self.config['test_size'],
                random_state=self.config['random_state'],
                stratify=y
            )
            
            # Apply feature selection if configured
            if self.config['feature_selection'] != 'none':
                self._apply_feature_selection()
            
            self.logger.info(f"Data prepared: train={self.X_train.shape}, test={self.X_test.shape}")
            
        except Exception as e:
            self.logger.error(f"Data preparation error: {str(e)}")
            raise
    
    def _apply_feature_selection(self):
        """Apply feature selection to training data"""
        try:
            from sklearn.feature_selection import SelectKBest, f_classif, mutual_info_classif, RFE
            from sklearn.ensemble import RandomForestClassifier
            
            selector_type = self.config['feature_selection']
            k = self.config['feature_selection_k']
            
            if selector_type == 'variance':
                from sklearn.feature_selection import VarianceThreshold
                selector = VarianceThreshold(threshold=0.01)
            elif selector_type == 'mutual_info':
                selector = SelectKBest(score_func=mutual_info_classif, k=min(k, self.X_train.shape[1]))
            elif selector_type == 'rfe':
                estimator = RandomForestClassifier(n_estimators=50, random_state=self.config['random_state'])
                selector = RFE(estimator=estimator, n_features_to_select=min(k, self.X_train.shape[1]))
            else:  # f_classif
                selector = SelectKBest(score_func=f_classif, k=min(k, self.X_train.shape[1]))
            
            # Fit selector and transform data
            self.X_train = selector.fit_transform(self.X_train, self.y_train)
            self.X_test = selector.transform(self.X_test)
            
            # Update feature names
            if hasattr(selector, 'get_support'):
                selected_indices = selector.get_support(indices=True)
                self.feature_names = [self.feature_names[i] for i in selected_indices]
            
            self.logger.info(f"Feature selection applied: {len(self.feature_names)} features selected")
            
        except Exception as e:
            self.logger.error(f"Feature selection error: {str(e)}")
    
    def train_single_model(self, model_type: str = 'binary', kernel: str = 'rbf', 
                          hyperparameters: Optional[Dict] = None) -> Dict[str, Any]:
        """
        Train a single SVM model
        
        Args:
            model_type: 'binary', 'multiclass', 'oneclass'
            kernel: 'rbf', 'linear', 'poly', 'sigmoid'
            hyperparameters: Model hyperparameters
            
        Returns:
            Training results
        """
        try:
            self.logger.info(f"Training single model: {model_type} with {kernel} kernel")
            
            # Create model
            model = create_svm_model(model_type=model_type, kernel=kernel)
            
            # Set hyperparameters
            if hyperparameters:
                # Build pipeline with custom parameters
                C = hyperparameters.get('C', 1.0)
                gamma = hyperparameters.get('gamma', 'scale')
                degree = hyperparameters.get('degree', 3)
                coef0 = hyperparameters.get('coef0', 0.0)
                
                model.build_pipeline(C=C, gamma=gamma, degree=degree, coef0=coef0)
            
            # Train model
            start_time = time.time()
            model.fit(self.X_train, self.y_train, self.feature_names)
            training_time = time.time() - start_time
            
            # Validate model
            validation_results = self._validate_model(model)
            
            # Store model
            model_key = f"{model_type}_{kernel}"
            self.trained_models[model_key] = model
            
            # Create results
            results = {
                'model_key': model_key,
                'model_type': model_type,
                'kernel': kernel,
                'training_time': training_time,
                'validation_results': validation_results,
                'model_parameters': model.get_model_info(),
                'timestamp': time.time()
            }
            
            # Update best model if this is better
            if self.best_model is None or validation_results['f1_score'] > self.validation_results.get('f1_score', 0):
                self.best_model = model
                self.validation_results = validation_results
            
            self.training_history.append(results)
            
            self.logger.info(f"Model training completed: {model_key} (F1: {validation_results['f1_score']:.4f})")
            
            return results
            
        except Exception as e:
            self.logger.error(f"Single model training error: {str(e)}")
            raise
    
    def train_multiple_models(self, model_configs: List[Dict[str, Any]]) -> Dict[str, Any]:
        """
        Train multiple models with different configurations
        
        Args:
            model_configs: List of model configuration dictionaries
            
        Returns:
            Training results for all models
        """
        try:
            self.logger.info(f"Training {len(model_configs)} models")
            
            all_results = {}
            
            for i, config in enumerate(model_configs):
                model_type = config.get('model_type', 'binary')
                kernel = config.get('kernel', 'rbf')
                hyperparameters = config.get('hyperparameters', {})
                
                try:
                    result = self.train_single_model(model_type, kernel, hyperparameters)
                    all_results[f'model_{i}'] = result
                except Exception as e:
                    self.logger.error(f"Model {i} training failed: {str(e)}")
                    all_results[f'model_{i}'] = {'error': str(e)}
            
            # Find best model
            best_key = max(all_results.keys(), key=lambda k: all_results[k].get('validation_results', {}).get('f1_score', 0))
            best_result = all_results[best_key]
            
            self.logger.info(f"Multiple model training completed. Best: {best_key}")
            
            return {
                'all_results': all_results,
                'best_model': best_key,
                'best_result': best_result,
                'training_summary': self._create_training_summary(all_results)
            }
            
        except Exception as e:
            self.logger.error(f"Multiple model training error: {str(e)}")
            raise
    
    def hyperparameter_optimization(self, model_type: str = 'binary', kernel: str = 'rbf',
                                  param_grid: Optional[Dict] = None) -> Dict[str, Any]:
        """
        Perform hyperparameter optimization
        
        Args:
            model_type: Model type
            kernel: Kernel type
            param_grid: Parameter grid for optimization
            
        Returns:
            Optimization results
        """
        try:
            self.logger.info(f"Starting hyperparameter optimization for {model_type} {kernel}")
            
            # Default parameter grids
            if param_grid is None:
                if kernel == 'rbf':
                    param_grid = {
                        'svm__C': [0.1, 1, 10, 100],
                        'svm__gamma': ['scale', 'auto', 0.001, 0.01, 0.1, 1]
                    }
                elif kernel == 'linear':
                    param_grid = {
                        'svm__C': [0.1, 1, 10, 100]
                    }
                elif kernel == 'poly':
                    param_grid = {
                        'svm__C': [0.1, 1, 10],
                        'svm__gamma': ['scale', 'auto'],
                        'svm__degree': [2, 3, 4]
                    }
                else:  # sigmoid
                    param_grid = {
                        'svm__C': [0.1, 1, 10],
                        'svm__gamma': ['scale', 'auto'],
                        'svm__coef0': [0.0, 1.0, 2.0]
                    }
            
            # Create model for optimization
            model = create_svm_model(model_type=model_type, kernel=kernel)
            
            # Create grid search
            from sklearn.model_selection import GridSearchCV
            
            grid_search = GridSearchCV(
                model.model.pipeline,
                param_grid,
                cv=self.config['tuning_cv'],
                scoring='f1_weighted',
                n_jobs=-1,
                verbose=1
            )
            
            # Fit grid search
            start_time = time.time()
            grid_search.fit(self.X_train, self.y_train)
            optimization_time = time.time() - start_time
            
            # Update best model
            best_model = grid_search.best_estimator_
            self.trained_models[f"{model_type}_{kernel}_optimized"] = model.model
            self.best_model = model.model
            
            # Validate optimized model
            optimization_results = self._validate_model(model.model)
            
            results = {
                'best_params': grid_search.best_params_,
                'best_score': grid_search.best_score_,
                'optimization_time': optimization_time,
                'cv_results': {
                    'mean_test_score': float(np.mean(grid_search.cv_results_['mean_test_score'])),
                    'std_test_score': float(np.std(grid_search.cv_results_['std_test_score']))
                },
                'validation_results': optimization_results,
                'timestamp': time.time()
            }
            
            self.logger.info(f"Hyperparameter optimization completed: {grid_search.best_score_:.4f}")
            
            return results
            
        except Exception as e:
            self.logger.error(f"Hyperparameter optimization error: {str(e)}")
            raise
    
    def train_ensemble(self, ensemble_size: Optional[int] = None) -> Dict[str, Any]:
        """
        Train ensemble of models
        
        Args:
            ensemble_size: Number of models in ensemble
            
        Returns:
            Ensemble training results
        """
        try:
            ensemble_size = ensemble_size or self.config['ensemble_size']
            self.logger.info(f"Training ensemble of {ensemble_size} models")
            
            # Create diverse model configurations
            model_configs = self._generate_ensemble_configs(ensemble_size)
            
            # Train ensemble
            ensemble_results = self.train_multiple_models(model_configs)
            
            # Store ensemble models
            self.ensemble_models = list(ensemble_results['all_results'].values())
            
            # Validate ensemble
            ensemble_performance = self._validate_ensemble()
            
            results = {
                'ensemble_size': ensemble_size,
                'individual_results': ensemble_results['all_results'],
                'ensemble_performance': ensemble_performance,
                'training_summary': ensemble_results['training_summary'],
                'timestamp': time.time()
            }
            
            self.logger.info(f"Ensemble training completed: F1={ensemble_performance['f1_score']:.4f}")
            
            return results
            
        except Exception as e:
            self.logger.error(f"Ensemble training error: {str(e)}")
            raise
    
    def _validate_model(self, model) -> Dict[str, Any]:
        """Validate a single model"""
        try:
            # Make predictions
            y_pred = model.predict(self.X_test)
            y_proba = model.predict_proba(self.X_test)
            
            # Calculate metrics
            from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, roc_auc_score
            
            accuracy = accuracy_score(self.y_test, y_pred)
            precision = precision_score(self.y_test, y_pred, average='weighted', zero_division=0)
            recall = recall_score(self.y_test, y_pred, average='weighted', zero_division=0)
            f1 = f1_score(self.y_test, y_pred, average='weighted', zero_division=0)
            
            # AUC for binary classification
            auc = None
            if len(np.unique(self.y_test)) == 2:
                try:
                    auc = roc_auc_score(self.y_test, y_proba[:, 1])
                except Exception:
                    pass
            
            return {
                'accuracy': float(accuracy),
                'precision': float(precision),
                'recall': float(recall),
                'f1_score': float(f1),
                'auc': float(auc) if auc is not None else None,
                'test_samples': len(self.y_test)
            }
            
        except Exception as e:
            self.logger.error(f"Model validation error: {str(e)}")
            return {}
    
    def _validate_ensemble(self) -> Dict[str, Any]:
        """Validate ensemble of models"""
        try:
            if not self.ensemble_models:
                return {}
            
            # Get predictions from all models
            all_predictions = []
            all_probabilities = []
            
            for model_result in self.ensemble_models:
                if 'error' not in model_result:
                    model = self.trained_models.get(model_result['model_key'])
                    if model and model.is_fitted:
                        pred = model.predict(self.X_test)
                        proba = model.predict_proba(self.X_test)
                        all_predictions.append(pred)
                        all_probabilities.append(proba)
            
            if not all_predictions:
                return {}
            
            # Ensemble voting
            ensemble_pred = np.round(np.mean(all_predictions, axis=0)).astype(int)
            ensemble_proba = np.mean(all_probabilities, axis=0)
            
            # Calculate ensemble metrics
            from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score
            
            accuracy = accuracy_score(self.y_test, ensemble_pred)
            precision = precision_score(self.y_test, ensemble_pred, average='weighted', zero_division=0)
            recall = recall_score(self.y_test, ensemble_pred, average='weighted', zero_division=0)
            f1 = f1_score(self.y_test, ensemble_pred, average='weighted', zero_division=0)
            
            return {
                'accuracy': float(accuracy),
                'precision': float(precision),
                'recall': float(recall),
                'f1_score': float(f1),
                'individual_model_count': len(all_predictions),
                'test_samples': len(self.y_test)
            }
            
        except Exception as e:
            self.logger.error(f"Ensemble validation error: {str(e)}")
            return {}
    
    def _generate_ensemble_configs(self, ensemble_size: int) -> List[Dict[str, Any]]:
        """Generate diverse model configurations for ensemble"""
        configs = []
        
        # Kernel variations
        kernels = ['rbf', 'linear', 'poly']
        
        # C values to try
        C_values = [0.1, 1, 10, 100]
        
        # Gamma values for RBF
        gamma_values = ['scale', 'auto', 0.01, 0.1, 1]
        
        for i in range(ensemble_size):
            kernel = kernels[i % len(kernels)]
            
            config = {
                'model_type': 'binary',
                'kernel': kernel,
                'hyperparameters': {}
            }
            
            if kernel == 'rbf':
                config['hyperparameters'] = {
                    'C': C_values[i % len(C_values)],
                    'gamma': gamma_values[i % len(gamma_values)]
                }
            elif kernel == 'linear':
                config['hyperparameters'] = {
                    'C': C_values[i % len(C_values)]
                }
            elif kernel == 'poly':
                config['hyperparameters'] = {
                    'C': C_values[i % len(C_values)],
                    'degree': 2 + (i % 3)  # degrees 2, 3, 4
                }
            
            configs.append(config)
        
        return configs
    
    def _create_training_summary(self, results: Dict[str, Any]) -> Dict[str, Any]:
        """Create training summary"""
        try:
            summary = {
                'total_models': len(results),
                'successful_models': 0,
                'failed_models': 0,
                'best_f1_score': 0.0,
                'avg_training_time': 0.0,
                'kernel_distribution': {},
                'model_type_distribution': {}
            }
            
            training_times = []
            f1_scores = []
            
            for model_key, result in results.items():
                if 'error' not in result:
                    summary['successful_models'] += 1
                    training_times.append(result.get('training_time', 0))
                    
                    val_results = result.get('validation_results', {})
                    f1_score = val_results.get('f1_score', 0)
                    f1_scores.append(f1_score)
                    
                    if f1_score > summary['best_f1_score']:
                        summary['best_f1_score'] = f1_score
                else:
                    summary['failed_models'] += 1
                
                # Count kernels
                kernel = result.get('kernel', 'unknown')
                summary['kernel_distribution'][kernel] = summary['kernel_distribution'].get(kernel, 0) + 1
                
                # Count model types
                model_type = result.get('model_type', 'unknown')
                summary['model_type_distribution'][model_type] = summary['model_type_distribution'].get(model_type, 0) + 1
            
            if training_times:
                summary['avg_training_time'] = np.mean(training_times)
            
            if f1_scores:
                summary['avg_f1_score'] = np.mean(f1_scores)
                summary['f1_score_std'] = np.std(f1_scores)
            
            return summary
            
        except Exception as e:
            self.logger.error(f"Training summary creation error: {str(e)}")
            return {}
    
    def save_training_results(self, output_dir: str):
        """Save all training results"""
        try:
            output_path = Path(output_dir)
            output_path.mkdir(parents=True, exist_ok=True)
            
            # Save training history
            history_file = output_path / 'training_history.json'
            with open(history_file, 'w') as f:
                import json
                json.dump(self.training_history, f, indent=2, default=str)
            
            # Save best model if available
            if self.best_model:
                model_file = output_path / 'best_model.joblib'
                self.best_model.save_model(str(model_file))
            
            # Save ensemble models
            if self.ensemble_models:
                ensemble_file = output_path / 'ensemble_results.json'
                with open(ensemble_file, 'w') as f:
                    import json
                    json.dump(self.ensemble_models, f, indent=2, default=str)
            
            # Save validation results
            validation_file = output_path / 'validation_results.json'
            with open(validation_file, 'w') as f:
                import json
                json.dump(self.validation_results, f, indent=2, default=str)
            
            self.logger.info(f"Training results saved to {output_dir}")
            
        except Exception as e:
            self.logger.error(f"Results saving error: {str(e)}")
    
    def get_training_statistics(self) -> Dict[str, Any]:
        """Get comprehensive training statistics"""
        return {
            'total_models_trained': len(self.trained_models),
            'training_history_length': len(self.training_history),
            'best_model_available': self.best_model is not None,
            'ensemble_size': len(self.ensemble_models),
            'data_info': {
                'train_samples': len(self.y_train) if self.y_train is not None else 0,
                'test_samples': len(self.y_test) if self.y_test is not None else 0,
                'feature_count': len(self.feature_names)
            },
            'best_validation_score': self.validation_results.get('f1_score', 0.0) if self.validation_results else 0.0
        }