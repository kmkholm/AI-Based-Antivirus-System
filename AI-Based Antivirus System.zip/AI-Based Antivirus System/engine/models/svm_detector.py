"""
SVM-based Malware Detector

Uses Support Vector Machine models to detect malware based on extracted features.
Implements detection with confidence scoring and model ensemble capabilities.
"""

import logging
import numpy as np
import time
from typing import Dict, List, Any, Optional, Tuple, Union
from pathlib import Path
import json

from .svm_model import SVMModel, create_svm_model
from ..utils import get_logger


class SVMDetector:
    """
    SVM-based malware detection system
    
    Features:
    - Multiple kernel support (RBF, linear, polynomial, sigmoid)
    - Confidence scoring
    - Model ensemble capabilities
    - Real-time detection
    - Feature importance analysis
    """
    
    def __init__(self, config: Optional[Dict] = None):
        self.logger = get_logger(__name__)
        self.config = config or self._get_default_config()
        
        # Detection models
        self.primary_model = None
        self.ensemble_models = []
        self.model_weights = []
        
        # Detection thresholds
        self.malware_threshold = self.config.get('malware_threshold', 0.7)
        self.confidence_threshold = self.config.get('confidence_threshold', 0.5)
        
        # Statistics
        self.detection_stats = {
            'total_detections': 0,
            'malware_detected': 0,
            'false_positives': 0,
            'avg_confidence': 0.0,
            'detection_times': []
        }
        
        # Initialize with default model
        self._initialize_default_model()
        
        self.logger.info("SVM Detector initialized")
    
    def _get_default_config(self) -> Dict:
        """Get default SVM detector configuration"""
        return {
            'model_type': 'binary',
            'kernel': 'rbf',
            'ensemble_enabled': False,
            'ensemble_size': 3,
            'malware_threshold': 0.7,
            'confidence_threshold': 0.5,
            'enable_feature_importance': True,
            'enable_ensemble': False,
            'auto_threshold_tuning': False,
            'feature_selection': 'variance',
            'kernel_cache_size': 200
        }
    
    def _initialize_default_model(self):
        """Initialize default SVM model"""
        try:
            self.primary_model = create_svm_model(
                model_type=self.config['model_type'],
                kernel=self.config['kernel']
            )
            self.logger.info(f"Default model initialized: {self.config['model_type']} with {self.config['kernel']} kernel")
        except Exception as e:
            self.logger.error(f"Default model initialization error: {str(e)}")
    
    def predict(self, features: Dict[str, Any]) -> Dict[str, Any]:
        """
        Predict malware using SVM model
        
        Args:
            features: Feature dictionary from feature extraction
            
        Returns:
            Detection result with prediction, confidence, and metadata
        """
        start_time = time.time()
        
        try:
            # Convert features to model input format
            feature_vector = self._features_to_vector(features)
            
            if feature_vector.size == 0:
                return self._create_error_result("Empty feature vector")
            
            # Make prediction
            prediction, confidence, probabilities = self._make_prediction(feature_vector)
            
            # Calculate additional metrics
            analysis_time = time.time() - start_time
            feature_importance = self._get_feature_importance() if self.config['enable_feature_importance'] else {}
            
            # Create result
            result = {
                'prediction': int(prediction),
                'is_malicious': bool(prediction == 1),
                'confidence': float(confidence),
                'probabilities': {
                    'benign': float(probabilities[0]) if len(probabilities) > 0 else 0.0,
                    'malicious': float(probabilities[1]) if len(probabilities) > 1 else 0.0
                },
                'threat_level': self._classify_threat_level(confidence),
                'analysis_time': analysis_time,
                'feature_count': len(feature_vector),
                'model_info': self._get_model_info(),
                'feature_importance': feature_importance
            }
            
            # Update statistics
            self._update_stats(result, analysis_time)
            
            self.logger.debug(f"SVM detection completed: {'malicious' if result['is_malicious'] else 'benign'} "
                            f"(confidence: {confidence:.3f})")
            
            return result
            
        except Exception as e:
            self.logger.error(f"SVM detection error: {str(e)}")
            return self._create_error_result(str(e))
    
    def batch_predict(self, features_list: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """Make predictions for multiple samples"""
        results = []
        
        self.logger.info(f"Starting batch prediction for {len(features_list)} samples")
        
        for i, features in enumerate(features_list):
            try:
                result = self.predict(features)
                result['batch_index'] = i
                results.append(result)
            except Exception as e:
                self.logger.error(f"Batch prediction error for sample {i}: {str(e)}")
                results.append(self._create_error_result(str(e)))
        
        self.logger.info(f"Batch prediction completed: {len(results)} results")
        return results
    
    def _features_to_vector(self, features: Dict[str, Any]) -> np.ndarray:
        """Convert feature dictionary to model input vector"""
        try:
            # Extract numerical features
            numerical_features = []
            feature_names = []
            
            for key, value in features.items():
                if key == 'feature_vector' and isinstance(value, list):
                    # Use pre-computed feature vector if available
                    return np.array(value)
                
                if isinstance(value, (int, float)) and not np.isnan(value):
                    numerical_features.append(float(value))
                    feature_names.append(key)
            
            if not numerical_features:
                return np.array([])
            
            return np.array(numerical_features)
            
        except Exception as e:
            self.logger.error(f"Feature vector conversion error: {str(e)}")
            return np.array([])
    
    def _make_prediction(self, feature_vector: np.ndarray) -> Tuple[int, float, np.ndarray]:
        """Make prediction using the trained model"""
        if not self.primary_model.model.is_fitted:
            # Return default prediction for unfitted model
            return 0, 0.5, np.array([0.5, 0.5])
        
        try:
            # Get prediction
            prediction = self.primary_model.predict(feature_vector.reshape(1, -1))[0]
            
            # Get probabilities
            probabilities = self.primary_model.predict_proba(feature_vector.reshape(1, -1))[0]
            
            # Get confidence (max probability)
            confidence = np.max(probabilities)
            
            return int(prediction), float(confidence), probabilities
            
        except Exception as e:
            self.logger.error(f"Prediction error: {str(e)}")
            return 0, 0.5, np.array([0.5, 0.5])
    
    def _classify_threat_level(self, confidence: float) -> str:
        """Classify threat level based on confidence"""
        if confidence >= 0.9:
            return 'critical'
        elif confidence >= 0.8:
            return 'high'
        elif confidence >= 0.6:
            return 'medium'
        elif confidence >= 0.4:
            return 'low'
        else:
            return 'clean'
    
    def _get_feature_importance(self) -> Dict[str, float]:
        """Get feature importance scores"""
        try:
            if not self.primary_model.model.is_fitted:
                return {}
            
            # Get support vectors
            support_vectors = self.primary_model.model.get_support_vectors()
            if support_vectors is None or len(support_vectors) == 0:
                return {}
            
            # Simple feature importance based on support vector analysis
            # In practice, this would use more sophisticated methods
            feature_importance = {}
            
            # For now, return empty dict - would implement actual feature importance
            # based on model coefficients, support vectors, etc.
            
            return feature_importance
            
        except Exception as e:
            self.logger.error(f"Feature importance calculation error: {str(e)}")
            return {}
    
    def _get_model_info(self) -> Dict[str, Any]:
        """Get information about the current model"""
        try:
            if not self.primary_model.model.is_fitted:
                return {'status': 'not_fitted'}
            
            return self.primary_model.get_model_info()
            
        except Exception as e:
            self.logger.error(f"Model info extraction error: {str(e)}")
            return {'status': 'error', 'error': str(e)}
    
    def _create_error_result(self, error_message: str) -> Dict[str, Any]:
        """Create error result"""
        return {
            'prediction': 0,
            'is_malicious': False,
            'confidence': 0.0,
            'probabilities': {'benign': 0.5, 'malicious': 0.5},
            'threat_level': 'error',
            'analysis_time': 0.0,
            'feature_count': 0,
            'model_info': {'status': 'error'},
            'feature_importance': {},
            'error': error_message
        }
    
    def _update_stats(self, result: Dict[str, Any], analysis_time: float):
        """Update detection statistics"""
        self.detection_stats['total_detections'] += 1
        self.detection_stats['detection_times'].append(analysis_time)
        
        if result['is_malicious']:
            self.detection_stats['malware_detected'] += 1
        
        # Update average confidence
        total_conf = self.detection_stats['avg_confidence'] * (self.detection_stats['total_detections'] - 1)
        self.detection_stats['avg_confidence'] = (total_conf + result['confidence']) / self.detection_stats['total_detections']
        
        # Keep only last 1000 detection times for memory efficiency
        if len(self.detection_stats['detection_times']) > 1000:
            self.detection_stats['detection_times'] = self.detection_stats['detection_times'][-1000:]
    
    def train(self, X: np.ndarray, y: np.ndarray, feature_names: Optional[List[str]] = None) -> Dict[str, Any]:
        """
        Train the SVM model
        
        Args:
            X: Training features
            y: Training labels (0=benign, 1=malicious)
            feature_names: List of feature names
            
        Returns:
            Training results and metrics
        """
        try:
            self.logger.info(f"Training SVM model with {X.shape[0]} samples, {X.shape[1]} features")
            
            # Validate data
            if X.size == 0 or y.size == 0:
                raise ValueError("Empty training data")
            
            if X.shape[0] != y.shape[0]:
                raise ValueError("X and y must have same number of samples")
            
            # Train the model
            self.primary_model.fit(X, y, feature_names)
            
            # Calculate training metrics
            predictions = self.primary_model.predict(X)
            probabilities = self.primary_model.predict_proba(X)
            
            # Calculate metrics
            accuracy = float(np.mean(predictions == y))
            precision = float(np.mean([p for p, t in zip(predictions, y) if t == 1]) or 0.0)
            recall = float(np.mean([p for p, t in zip(predictions, y) if t == 1]) or 0.0)
            f1 = 2 * (precision * recall) / (precision + recall) if (precision + recall) > 0 else 0.0
            
            # Get model parameters
            model_params = self.primary_model.get_model_info()
            
            training_results = {
                'accuracy': accuracy,
                'precision': precision,
                'recall': recall,
                'f1_score': f1,
                'training_samples': X.shape[0],
                'feature_count': X.shape[1],
                'model_parameters': model_params,
                'training_timestamp': time.time()
            }
            
            self.logger.info(f"Training completed: accuracy={accuracy:.4f}, F1={f1:.4f}")
            
            return training_results
            
        except Exception as e:
            self.logger.error(f"Training error: {str(e)}")
            raise
    
    def validate(self, X: np.ndarray, y: np.ndarray) -> Dict[str, Any]:
        """
        Validate the model on test data
        
        Args:
            X: Test features
            y: Test labels
            
        Returns:
            Validation metrics
        """
        try:
            if not self.primary_model.model.is_fitted:
                raise ValueError("Model must be trained before validation")
            
            # Make predictions
            predictions = self.primary_model.predict(X)
            probabilities = self.primary_model.predict_proba(X)
            
            # Calculate metrics
            accuracy = accuracy_score(y, predictions)
            precision = precision_score(y, predictions, average='weighted', zero_division=0)
            recall = recall_score(y, predictions, average='weighted', zero_division=0)
            f1 = f1_score(y, predictions, average='weighted', zero_division=0)
            
            # AUC if binary classification
            auc = None
            if len(np.unique(y)) == 2:
                try:
                    auc = roc_auc_score(y, probabilities[:, 1])
                except Exception:
                    pass
            
            validation_results = {
                'accuracy': float(accuracy),
                'precision': float(precision),
                'recall': float(recall),
                'f1_score': float(f1),
                'auc': float(auc) if auc is not None else None,
                'test_samples': X.shape[0],
                'validation_timestamp': time.time()
            }
            
            self.logger.info(f"Validation completed: accuracy={accuracy:.4f}, F1={f1:.4f}")
            
            return validation_results
            
        except Exception as e:
            self.logger.error(f"Validation error: {str(e)}")
            raise
    
    def hyperparameter_tuning(self, X: np.ndarray, y: np.ndarray, cv: int = 5) -> Dict[str, Any]:
        """Perform hyperparameter tuning"""
        try:
            self.logger.info(f"Starting hyperparameter tuning with {cv}-fold CV")
            
            tuning_results = self.primary_model.hyperparameter_tuning(X, y, cv)
            
            self.logger.info("Hyperparameter tuning completed")
            return tuning_results
            
        except Exception as e:
            self.logger.error(f"Hyperparameter tuning error: {str(e)}")
            raise
    
    def save_model(self, filepath: str):
        """Save the trained model"""
        try:
            if not self.primary_model.model.is_fitted:
                raise ValueError("Model must be trained before saving")
            
            self.primary_model.save_model(filepath)
            
            # Save additional configuration
            config_path = Path(filepath).with_suffix('.config.json')
            with open(config_path, 'w') as f:
                json.dump(self.config, f, indent=2)
            
            self.logger.info(f"Model saved to {filepath}")
            
        except Exception as e:
            self.logger.error(f"Model saving error: {str(e)}")
            raise
    
    def load_model(self, filepath: str):
        """Load a trained model"""
        try:
            self.primary_model.load_model(filepath)
            
            # Load configuration
            config_path = Path(filepath).with_suffix('.config.json')
            if config_path.exists():
                with open(config_path, 'r') as f:
                    self.config.update(json.load(f))
            
            self.logger.info(f"Model loaded from {filepath}")
            
        except Exception as e:
            self.logger.error(f"Model loading error: {str(e)}")
            raise
    
    def get_statistics(self) -> Dict[str, Any]:
        """Get detection statistics"""
        stats = self.detection_stats.copy()
        
        # Calculate additional statistics
        if stats['detection_times']:
            stats['avg_detection_time'] = float(np.mean(stats['detection_times']))
            stats['max_detection_time'] = float(np.max(stats['detection_times']))
            stats['min_detection_time'] = float(np.min(stats['detection_times']))
        
        # Calculate malware detection rate
        if stats['total_detections'] > 0:
            stats['malware_detection_rate'] = stats['malware_detected'] / stats['total_detections']
        else:
            stats['malware_detection_rate'] = 0.0
        
        return stats
    
    def reset_statistics(self):
        """Reset detection statistics"""
        self.detection_stats = {
            'total_detections': 0,
            'malware_detected': 0,
            'false_positives': 0,
            'avg_confidence': 0.0,
            'detection_times': []
        }
        self.logger.info("Detection statistics reset")
    
    def update_thresholds(self, malware_threshold: Optional[float] = None, confidence_threshold: Optional[float] = None):
        """Update detection thresholds"""
        if malware_threshold is not None:
            self.malware_threshold = malware_threshold
        if confidence_threshold is not None:
            self.confidence_threshold = confidence_threshold
        
        self.logger.info(f"Thresholds updated: malware={self.malware_threshold}, confidence={self.confidence_threshold}")
    
    def set_model(self, model_type: str, kernel: str):
        """Set a new primary model"""
        try:
            self.primary_model = create_svm_model(model_type=model_type, kernel=kernel)
            self.config['model_type'] = model_type
            self.config['kernel'] = kernel
            
            self.logger.info(f"Primary model changed to: {model_type} with {kernel} kernel")
            
        except Exception as e:
            self.logger.error(f"Model change error: {str(e)}")
            raise