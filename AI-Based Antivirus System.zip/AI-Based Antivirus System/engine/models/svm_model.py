"""
SVM Model Implementation

Implements Support Vector Machine models with multiple kernel support
for malware detection including linear, RBF, polynomial, and sigmoid kernels.
"""

import logging
import numpy as np
from typing import Dict, List, Any, Optional, Tuple, Union
from abc import ABC, abstractmethod
from sklearn.svm import SVC, SVR, OneClassSVM
from sklearn.model_selection import GridSearchCV, cross_val_score
from sklearn.preprocessing import StandardScaler, MinMaxScaler
from sklearn.pipeline import Pipeline
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, roc_auc_score
import joblib
import pickle
from pathlib import Path

from ..utils import get_logger


class BaseSVMModel(ABC):
    """Base class for SVM models"""
    
    def __init__(self, kernel: str = 'rbf', config: Optional[Dict] = None):
        self.kernel = kernel
        self.config = config or {}
        self.model = None
        self.scaler = None
        self.pipeline = None
        self.is_fitted = False
        self.feature_names = []
        
        self.logger = get_logger(self.__class__.__name__)
    
    @abstractmethod
    def create_model(self, **kwargs):
        """Create the underlying SVM model"""
        pass
    
    def build_pipeline(self, C: float = 1.0, gamma: str = 'scale', degree: int = 3, coef0: float = 0.0):
        """Build preprocessing and model pipeline"""
        # Choose scaler based on kernel
        if self.kernel == 'linear':
            scaler = StandardScaler()  # Good for linear kernels
        else:
            scaler = MinMaxScaler()    # Good for non-linear kernels
        
        # Create model
        model = self.create_model(C=C, gamma=gamma, degree=degree, coef0=coef0)
        
        # Build pipeline
        self.pipeline = Pipeline([
            ('scaler', scaler),
            ('svm', model)
        ])
        
        self.scaler = scaler
        self.model = model
        
        return self.pipeline
    
    def fit(self, X: np.ndarray, y: np.ndarray, feature_names: Optional[List[str]] = None):
        """Fit the model"""
        try:
            if feature_names:
                self.feature_names = feature_names
            
            # Validate input
            if X.size == 0 or y.size == 0:
                raise ValueError("Empty training data")
            
            if X.shape[0] != y.shape[0]:
                raise ValueError("X and y must have same number of samples")
            
            # Build pipeline if not exists
            if self.pipeline is None:
                self.build_pipeline()
            
            # Fit the pipeline
            self.pipeline.fit(X, y)
            self.is_fitted = True
            
            self.logger.info(f"SVM model fitted with kernel: {self.kernel}")
            return self
            
        except Exception as e:
            self.logger.error(f"Model fitting error: {str(e)}")
            raise
    
    def predict(self, X: np.ndarray) -> np.ndarray:
        """Make predictions"""
        if not self.is_fitted:
            raise ValueError("Model must be fitted before prediction")
        
        try:
            return self.pipeline.predict(X)
        except Exception as e:
            self.logger.error(f"Prediction error: {str(e)}")
            return np.array([])
    
    def predict_proba(self, X: np.ndarray) -> np.ndarray:
        """Predict class probabilities"""
        if not self.is_fitted:
            raise ValueError("Model must be fitted before prediction")
        
        try:
            if hasattr(self.pipeline.named_steps['svm'], 'predict_proba'):
                return self.pipeline.predict_proba(X)
            else:
                # Return decision function values as pseudo-probabilities
                scores = self.decision_function(X)
                # Convert to pseudo-probabilities
                probabilities = np.zeros((X.shape[0], 2))
                probabilities[:, 1] = 1 / (1 + np.exp(-scores))  # Sigmoid
                probabilities[:, 0] = 1 - probabilities[:, 1]
                return probabilities
        except Exception as e:
            self.logger.error(f"Probability prediction error: {str(e)}")
            return np.array([])
    
    def decision_function(self, X: np.ndarray) -> np.ndarray:
        """Get decision function values"""
        if not self.is_fitted:
            raise ValueError("Model must be fitted before decision function")
        
        try:
            return self.pipeline.decision_function(X)
        except Exception as e:
            self.logger.error(f"Decision function error: {str(e)}")
            return np.array([])
    
    def save_model(self, filepath: str):
        """Save the trained model"""
        try:
            if not self.is_fitted:
                raise ValueError("Model must be fitted before saving")
            
            model_data = {
                'pipeline': self.pipeline,
                'kernel': self.kernel,
                'feature_names': self.feature_names,
                'config': self.config
            }
            
            with open(filepath, 'wb') as f:
                joblib.dump(model_data, f)
            
            self.logger.info(f"Model saved to {filepath}")
            
        except Exception as e:
            self.logger.error(f"Model saving error: {str(e)}")
            raise
    
    def load_model(self, filepath: str):
        """Load a trained model"""
        try:
            with open(filepath, 'rb') as f:
                model_data = joblib.load(f)
            
            self.pipeline = model_data['pipeline']
            self.kernel = model_data.get('kernel', 'rbf')
            self.feature_names = model_data.get('feature_names', [])
            self.config = model_data.get('config', {})
            self.is_fitted = True
            
            self.logger.info(f"Model loaded from {filepath}")
            
        except Exception as e:
            self.logger.error(f"Model loading error: {str(e)}")
            raise
    
    def get_support_vectors(self) -> Optional[np.ndarray]:
        """Get support vectors"""
        if not self.is_fitted:
            return None
        
        try:
            return self.pipeline.named_steps['svm'].support_vectors_
        except Exception as e:
            self.logger.error(f"Support vector extraction error: {str(e)}")
            return None
    
    def get_model_parameters(self) -> Dict[str, Any]:
        """Get model parameters"""
        if not self.is_fitted:
            return {}
        
        try:
            svm_model = self.pipeline.named_steps['svm']
            return {
                'kernel': svm_model.kernel,
                'C': svm_model.C,
                'gamma': svm_model.gamma,
                'degree': svm_model.degree if hasattr(svm_model, 'degree') else None,
                'coef0': svm_model.coef0 if hasattr(svm_model, 'coef0') else None,
                'n_support_vectors': len(svm_model.support_vectors_),
                'support_vector_indices': svm_model.support_
            }
        except Exception as e:
            self.logger.error(f"Parameter extraction error: {str(e)}")
            return {}


class BinarySVMModel(BaseSVMModel):
    """Binary classification SVM model"""
    
    def create_model(self, **kwargs):
        """Create binary classification SVM model"""
        return SVC(
            kernel=self.kernel,
            probability=True,  # Enable probability estimation
            **kwargs
        )


class MulticlassSVMModel(BaseSVMModel):
    """Multi-class classification SVM model"""
    
    def create_model(self, **kwargs):
        """Create multi-class classification SVM model"""
        return SVC(
            kernel=self.kernel,
            decision_function_shape='ovr',  # One-vs-rest for multiclass
            probability=True,
            **kwargs
        )


class RegressionSVMModel(BaseSVMModel):
    """Support Vector Regression model"""
    
    def create_model(self, **kwargs):
        """Create SVR model"""
        return SVR(kernel=self.kernel, **kwargs)
    
    def predict_proba(self, X: np.ndarray) -> np.ndarray:
        """SVR doesn't support predict_proba"""
        raise NotImplementedError("Support Vector Regression does not support probability prediction")


class OneClassSVMModel(BaseSVMModel):
    """One-class SVM for anomaly detection"""
    
    def create_model(self, **kwargs):
        """Create one-class SVM model"""
        return OneClassSVM(kernel=self.kernel, **kwargs)
    
    def predict_proba(self, X: np.ndarray) -> np.ndarray:
        """One-class SVM doesn't support predict_proba"""
        raise NotImplementedError("One-class SVM does not support probability prediction")
    
    def predict(self, X: np.ndarray) -> np.ndarray:
        """One-class SVM predictions: 1 for inlier, -1 for outlier"""
        if not self.is_fitted:
            raise ValueError("Model must be fitted before prediction")
        
        try:
            predictions = self.pipeline.predict(X)
            # Convert -1 (outlier) to 0, 1 (inlier) to 1
            return (predictions + 1) // 2
        except Exception as e:
            self.logger.error(f"One-class prediction error: {str(e)}")
            return np.array([])


class SVMModel:
    """
    Unified SVM model interface with multiple kernel support
    
    Supports different types of SVM models:
    - Binary classification
    - Multi-class classification
    - Regression
    - One-class anomaly detection
    """
    
    def __init__(self, model_type: str = 'binary', kernel: str = 'rbf', config: Optional[Dict] = None):
        self.model_type = model_type
        self.kernel = kernel
        self.config = config or {}
        self.model = None
        
        # Create appropriate model
        if model_type == 'binary':
            self.model = BinarySVMModel(kernel, config)
        elif model_type == 'multiclass':
            self.model = MulticlassSVMModel(kernel, config)
        elif model_type == 'regression':
            self.model = RegressionSVMModel(kernel, config)
        elif model_type == 'oneclass':
            self.model = OneClassSVMModel(kernel, config)
        else:
            raise ValueError(f"Unknown model type: {model_type}")
        
        self.logger = get_logger(__name__)
        self.logger.info(f"SVM model created: {model_type} with {kernel} kernel")
    
    def fit(self, X: np.ndarray, y: np.ndarray, feature_names: Optional[List[str]] = None):
        """Fit the model"""
        return self.model.fit(X, y, feature_names)
    
    def predict(self, X: np.ndarray) -> np.ndarray:
        """Make predictions"""
        return self.model.predict(X)
    
    def predict_proba(self, X: np.ndarray) -> np.ndarray:
        """Predict probabilities"""
        return self.model.predict_proba(X)
    
    def decision_function(self, X: np.ndarray) -> np.ndarray:
        """Get decision function values"""
        return self.model.decision_function(X)
    
    def save_model(self, filepath: str):
        """Save the model"""
        self.model.save_model(filepath)
    
    def load_model(self, filepath: str):
        """Load the model"""
        self.model.load_model(filepath)
    
    def get_model_info(self) -> Dict[str, Any]:
        """Get model information"""
        info = {
            'model_type': self.model_type,
            'kernel': self.kernel,
            'is_fitted': self.model.is_fitted,
            'feature_names': self.model.feature_names
        }
        
        if self.model.is_fitted:
            info.update(self.model.get_model_parameters())
        
        return info
    
    def hyperparameter_tuning(self, X: np.ndarray, y: np.ndarray, cv: int = 5) -> Dict[str, Any]:
        """
        Perform hyperparameter tuning using grid search
        
        Args:
            X: Training features
            y: Training labels
            cv: Cross-validation folds
            
        Returns:
            Best parameters and scores
        """
        try:
            # Define parameter grids for different kernels
            param_grids = {
                'rbf': {
                    'svm__C': [0.1, 1, 10, 100],
                    'svm__gamma': ['scale', 'auto', 0.001, 0.01, 0.1, 1]
                },
                'linear': {
                    'svm__C': [0.1, 1, 10, 100]
                },
                'poly': {
                    'svm__C': [0.1, 1, 10],
                    'svm__gamma': ['scale', 'auto'],
                    'svm__degree': [2, 3, 4]
                },
                'sigmoid': {
                    'svm__C': [0.1, 1, 10],
                    'svm__gamma': ['scale', 'auto'],
                    'svm__coef0': [0.0, 1.0, 2.0]
                }
            }
            
            param_grid = param_grids.get(self.kernel, param_grids['rbf'])
            
            # Create grid search
            grid_search = GridSearchCV(
                self.model.pipeline,
                param_grid,
                cv=cv,
                scoring='accuracy',
                n_jobs=-1,
                verbose=1
            )
            
            # Fit grid search
            grid_search.fit(X, y)
            
            # Update model with best parameters
            self.model.pipeline = grid_search.best_estimator_
            
            self.logger.info(f"Hyperparameter tuning completed. Best score: {grid_search.best_score_:.4f}")
            
            return {
                'best_params': grid_search.best_params_,
                'best_score': grid_search.best_score_,
                'cv_results': grid_search.cv_results_
            }
            
        except Exception as e:
            self.logger.error(f"Hyperparameter tuning error: {str(e)}")
            return {}


def create_svm_model(model_type: str = 'binary', kernel: str = 'rbf', config: Optional[Dict] = None) -> SVMModel:
    """
    Factory function to create SVM models
    
    Args:
        model_type: 'binary', 'multiclass', 'regression', or 'oneclass'
        kernel: 'rbf', 'linear', 'poly', or 'sigmoid'
        config: Model configuration
        
    Returns:
        Configured SVM model
    """
    return SVMModel(model_type=model_type, kernel=kernel, config=config)