"""
Core Antivirus Engine

This package contains the main antivirus detection engine with:
- SVM-based machine learning detection
- Feature extraction modules
- Signature-based detection
- Heuristic analysis
- Threat classification and scoring
"""

from .engine import AntivirusEngine
from .detection import DetectionEngine
from .features import FeatureExtractor
from .models import SVMDetector
from .threat_intel import ThreatIntel
from .scoring import ThreatClassifier

__all__ = [
    'AntivirusEngine',
    'DetectionEngine', 
    'FeatureExtractor',
    'SVMDetector',
    'ThreatIntel',
    'ThreatClassifier'
]

__version__ = '1.0.0'
__author__ = 'Antivirus Development Team'