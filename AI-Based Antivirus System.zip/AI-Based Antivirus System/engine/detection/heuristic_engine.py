"""
Heuristic Engine

Analyzes files for suspicious characteristics and patterns
that may indicate malware presence without requiring exact matches.
"""

import logging
import time
import math
import re
from typing import Dict, List, Any, Optional, Tuple
from pathlib import Path
from collections import Counter
import struct

from ..utils import get_logger


class HeuristicEngine:
    """
    Heuristic-based malware detection system
    
    Analyzes file characteristics, structure, and patterns
    to identify potentially malicious content.
    """
    
    def __init__(self, config: Optional[Dict] = None):
        self.logger = get_logger(__name__)
        self.config = config or self._get_default_config()
        
        # Heuristic rules and thresholds
        self.heuristic_rules = self._initialize_heuristic_rules()
        self.analysis_cache = {}  # Cache for analyzed files
        
        # Statistics
        self.analysis_stats = {
            'total_analyses': 0,
            'suspicious_detected': 0,
            'analysis_time_sum': 0.0,
            'rule_trigger_counts': {}
        }
        
        self.logger.info("Heuristic Engine initialized")
    
    def _get_default_config(self) -> Dict:
        """Get default configuration"""
        return {
            'entropy_threshold': 7.5,  # High entropy threshold
            'string_threshold': 1000,   # Suspicious string count threshold
            'section_threshold': 10,    # Suspicious section count threshold
            'size_anomaly_threshold': 2.0,  # Size anomaly factor
            'packer_indicators': ['UPX', 'ASPack', 'PECompact', 'Themida', 'VMProtect'],
            'suspicious_imports': [
                'CreateProcess', 'WriteFile', 'ReadFile', 'RegSetValue',
                'LoadLibrary', 'GetProcAddress', 'FindWindow', 'GetAsyncKeyState',
                'CreateFileMapping', 'VirtualAlloc', 'WriteProcessMemory'
            ],
            'suspicious_strings': [
                'cmd.exe', 'powershell', 'regsvr32', 'rundll32', 'wmic',
                'CreateProcess', 'WriteFile', 'ReadFile', 'RegSetValue',
                'DownloadFile', 'Execute', 'Run', 'Install', 'Update'
            ],
            'analysis_timeout': 30,  # seconds
            'max_file_size': 100 * 1024 * 1024,  # 100MB
            'confidence_threshold': 0.6
        }
    
    def _initialize_heuristic_rules(self) -> List[Dict[str, Any]]:
        """Initialize heuristic detection rules"""
        return [
            {
                'name': 'High Entropy',
                'description': 'File has unusually high entropy suggesting encryption/packing',
                'weight': 0.15,
                'threshold': self.config['entropy_threshold']
            },
            {
                'name': 'Excessive Sections',
                'description': 'PE file has unusually many sections',
                'weight': 0.10,
                'threshold': self.config['section_threshold']
            },
            {
                'name': 'Suspicious Imports',
                'description': 'File imports potentially dangerous API functions',
                'weight': 0.20,
                'threshold': 3  # At least 3 suspicious imports
            },
            {
                'name': 'Suspicious Strings',
                'description': 'File contains suspicious command strings',
                'weight': 0.12,
                'threshold': 5  # At least 5 suspicious strings
            },
            {
                'name': 'Size Anomaly',
                'description': 'File size is anomalous for its type',
                'weight': 0.08,
                'threshold': self.config['size_anomaly_threshold']
            },
            {
                'name': 'Packer Detection',
                'description': 'File appears to be packed',
                'weight': 0.18,
                'threshold': 0  # Any packer indicator
            },
            {
                'name': 'Anti-Debugging',
                'description': 'File contains anti-debugging techniques',
                'weight': 0.15,
                'threshold': 0
            },
            {
                'name': 'Network Activity',
                'description': 'File references network operations',
                'weight': 0.10,
                'threshold': 0
            }
        ]
    
    def analyze_file(self, file_path: str) -> Dict[str, Any]:
        """
        Perform heuristic analysis on a file
        
        Args:
            file_path: Path to file to analyze
            
        Returns:
            Analysis result with heuristics and confidence
        """
        try:
            start_time = time.time()
            
            self.logger.debug(f"Starting heuristic analysis: {file_path}")
            
            # Validate file
            if not self._validate_file(file_path):
                return {
                    'method': 'heuristic',
                    'confidence': 0.0,
                    'is_malicious': False,
                    'heuristics': [],
                    'analysis_time': 0.0
                }
            
            # Check cache
            if file_path in self.analysis_cache:
                cached_result = self.analysis_cache[file_path].copy()
                cached_result['cached'] = True
                self.logger.debug(f"Heuristic analysis cache hit: {file_path}")
                return cached_result
            
            # Perform analysis
            heuristics_results = []
            total_weight = 0.0
            total_score = 0.0
            
            # 1. Entropy analysis
            entropy_result = self._analyze_entropy(file_path)
            if entropy_result['triggered']:
                heuristics_results.append(entropy_result)
                total_weight += self.heuristic_rules[0]['weight']
                total_score += entropy_result['score'] * self.heuristic_rules[0]['weight']
            
            # 2. Section analysis
            section_result = self._analyze_sections(file_path)
            if section_result['triggered']:
                heuristics_results.append(section_result)
                total_weight += self.heuristic_rules[1]['weight']
                total_score += section_result['score'] * self.heuristic_rules[1]['weight']
            
            # 3. Import analysis
            import_result = self._analyze_imports(file_path)
            if import_result['triggered']:
                heuristics_results.append(import_result)
                total_weight += self.heuristic_rules[2]['weight']
                total_score += import_result['score'] * self.heuristic_rules[2]['weight']
            
            # 4. String analysis
            string_result = self._analyze_strings(file_path)
            if string_result['triggered']:
                heuristics_results.append(string_result)
                total_weight += self.heuristic_rules[3]['weight']
                total_score += string_result['score'] * self.heuristic_rules[3]['weight']
            
            # 5. Size analysis
            size_result = self._analyze_size(file_path)
            if size_result['triggered']:
                heuristics_results.append(size_result)
                total_weight += self.heuristic_rules[4]['weight']
                total_score += size_result['score'] * self.heuristic_rules[4]['weight']
            
            # 6. Packer detection
            packer_result = self._detect_packers(file_path)
            if packer_result['triggered']:
                heuristics_results.append(packer_result)
                total_weight += self.heuristic_rules[5]['weight']
                total_score += packer_result['score'] * self.heuristic_rules[5]['weight']
            
            # 7. Anti-debugging detection
            anti_debug_result = self._detect_anti_debugging(file_path)
            if anti_debug_result['triggered']:
                heuristics_results.append(anti_debug_result)
                total_weight += self.heuristic_rules[6]['weight']
                total_score += anti_debug_result['score'] * self.heuristic_rules[6]['weight']
            
            # 8. Network activity detection
            network_result = self._detect_network_activity(file_path)
            if network_result['triggered']:
                heuristics_results.append(network_result)
                total_weight += self.heuristic_rules[7]['weight']
                total_score += network_result['score'] * self.heuristic_rules[7]['weight']
            
            # Calculate final confidence
            if total_weight > 0:
                confidence = min(total_score / total_weight, 1.0)
            else:
                confidence = 0.0
            
            is_malicious = confidence >= self.config['confidence_threshold']
            
            # Create result
            result = {
                'method': 'heuristic',
                'confidence': confidence,
                'is_malicious': is_malicious,
                'heuristics': heuristics_results,
                'heuristic_names': [h['name'] for h in heuristics_results],
                'analysis_time': time.time() - start_time,
                'threat_level': self._classify_threat_level(confidence),
                'cached': False
            }
            
            # Cache result
            self.analysis_cache[file_path] = result.copy()
            
            # Update statistics
            self._update_stats(result, result['analysis_time'])
            
            self.logger.debug(f"Heuristic analysis completed: {len(heuristics_results)} heuristics, "
                            f"confidence={confidence:.3f}")
            
            return result
            
        except Exception as e:
            self.logger.error(f"Heuristic analysis error: {str(e)}")
            return {
                'method': 'heuristic',
                'confidence': 0.0,
                'is_malicious': False,
                'heuristics': [],
                'analysis_time': 0.0,
                'error': str(e)
            }
    
    def _validate_file(self, file_path: str) -> bool:
        """Validate file before analysis"""
        try:
            path = Path(file_path)
            if not path.exists() or not path.is_file():
                return False
            
            if path.stat().st_size > self.config['max_file_size']:
                self.logger.warning(f"File {file_path} too large for heuristic analysis")
                return False
            
            return True
            
        except Exception as e:
            self.logger.error(f"File validation error: {str(e)}")
            return False
    
    def _analyze_entropy(self, file_path: str) -> Dict[str, Any]:
        """Analyze file entropy"""
        try:
            with open(file_path, 'rb') as f:
                data = f.read()
            
            if not data:
                return {'triggered': False, 'score': 0.0}
            
            # Calculate Shannon entropy
            byte_counts = [0] * 256
            for byte in data:
                byte_counts[byte] += 1
            
            entropy = 0.0
            data_len = len(data)
            
            for count in byte_counts:
                if count > 0:
                    probability = count / data_len
                    entropy -= probability * math.log2(probability)
            
            threshold = self.config['entropy_threshold']
            triggered = entropy > threshold
            score = min(entropy / 8.0, 1.0)  # Normalize to 0-1
            
            return {
                'name': 'High Entropy',
                'triggered': triggered,
                'score': score,
                'value': entropy,
                'threshold': threshold,
                'description': f'Entropy: {entropy:.2f} (threshold: {threshold})'
            }
            
        except Exception as e:
            self.logger.error(f"Entropy analysis error: {str(e)}")
            return {'triggered': False, 'score': 0.0}
    
    def _analyze_sections(self, file_path: str) -> Dict[str, Any]:
        """Analyze PE sections"""
        try:
            with open(file_path, 'rb') as f:
                data = f.read()
            
            # Check for PE signature
            if len(data) < 64 or data[:2] != b'MZ':
                return {'triggered': False, 'score': 0.0}
            
            # Get PE offset
            pe_offset = struct.unpack('<I', data[60:64])[0]
            
            if pe_offset + 24 > len(data) or data[pe_offset:pe_offset+4] != b'PE\x00\x00':
                return {'triggered': False, 'score': 0.0}
            
            # Get number of sections
            num_sections = struct.unpack('<H', data[pe_offset+6:pe_offset+8])[0]
            
            threshold = self.config['section_threshold']
            triggered = num_sections > threshold
            score = min(num_sections / 50.0, 1.0)  # Normalize to 0-1
            
            return {
                'name': 'Excessive Sections',
                'triggered': triggered,
                'score': score,
                'value': num_sections,
                'threshold': threshold,
                'description': f'Number of sections: {num_sections} (threshold: {threshold})'
            }
            
        except Exception as e:
            self.logger.error(f"Section analysis error: {str(e)}")
            return {'triggered': False, 'score': 0.0}
    
    def _analyze_imports(self, file_path: str) -> Dict[str, Any]:
        """Analyze imported functions"""
        try:
            with open(file_path, 'rb') as f:
                data = f.read()
            
            # Look for suspicious imports
            suspicious_imports_found = []
            for api in self.config['suspicious_imports']:
                if api.encode('ascii', errors='ignore') in data:
                    suspicious_imports_found.append(api)
            
            threshold = self.config['heuristic_rules'][2]['threshold']
            triggered = len(suspicious_imports_found) >= threshold
            score = min(len(suspicious_imports_found) / 10.0, 1.0)
            
            return {
                'name': 'Suspicious Imports',
                'triggered': triggered,
                'score': score,
                'value': len(suspicious_imports_found),
                'threshold': threshold,
                'description': f'Suspicious imports: {suspicious_imports_found}',
                'imports_found': suspicious_imports_found
            }
            
        except Exception as e:
            self.logger.error(f"Import analysis error: {str(e)}")
            return {'triggered': False, 'score': 0.0}
    
    def _analyze_strings(self, file_path: str) -> Dict[str, Any]:
        """Analyze suspicious strings"""
        try:
            with open(file_path, 'rb') as f:
                data = f.read()
            
            # Extract strings (4+ ASCII characters)
            ascii_strings = re.findall(b'[ -~]{4,}', data)
            
            # Count suspicious strings
            suspicious_strings_found = []
            for string in ascii_strings:
                string_lower = string.decode('ascii', errors='ignore').lower()
                for suspicious in self.config['suspicious_strings']:
                    if suspicious.lower() in string_lower:
                        suspicious_strings_found.append(suspicious)
                        break
            
            threshold = self.config['heuristic_rules'][3]['threshold']
            triggered = len(suspicious_strings_found) >= threshold
            score = min(len(suspicious_strings_found) / 20.0, 1.0)
            
            return {
                'name': 'Suspicious Strings',
                'triggered': triggered,
                'score': score,
                'value': len(suspicious_strings_found),
                'threshold': threshold,
                'description': f'Suspicious strings found: {len(suspicious_strings_found)}',
                'strings_found': list(set(suspicious_strings_found))
            }
            
        except Exception as e:
            self.logger.error(f"String analysis error: {str(e)}")
            return {'triggered': False, 'score': 0.0}
    
    def _analyze_size(self, file_path: str) -> Dict[str, Any]:
        """Analyze file size anomalies"""
        try:
            path = Path(file_path)
            file_size = path.stat().st_size
            
            # Simple size-based heuristics
            if file_size == 0:
                return {'triggered': True, 'score': 1.0, 'description': 'Empty file'}
            
            # Very small executables are suspicious
            if file_size < 1024 and path.suffix.lower() in ['.exe', '.dll']:
                return {
                    'name': 'Size Anomaly',
                    'triggered': True,
                    'score': 0.8,
                    'value': file_size,
                    'description': f'Very small executable: {file_size} bytes'
                }
            
            # Very large files might be suspicious
            threshold = 50 * 1024 * 1024  # 50MB
            if file_size > threshold:
                return {
                    'name': 'Size Anomaly',
                    'triggered': True,
                    'score': 0.3,
                    'value': file_size,
                    'description': f'Very large file: {file_size} bytes'
                }
            
            return {'triggered': False, 'score': 0.0}
            
        except Exception as e:
            self.logger.error(f"Size analysis error: {str(e)}")
            return {'triggered': False, 'score': 0.0}
    
    def _detect_packers(self, file_path: str) -> Dict[str, Any]:
        """Detect packers and compressors"""
        try:
            with open(file_path, 'rb') as f:
                data = f.read()
            
            packers_found = []
            
            # Check for known packer signatures
            for packer in self.config['packer_indicators']:
                if packer.encode('ascii', errors='ignore') in data:
                    packers_found.append(packer)
            
            # Check for high entropy sections (also indicates packing)
            if len(data) > 1000:
                chunk_size = 1024
                high_entropy_chunks = 0
                
                for i in range(0, len(data) - chunk_size, chunk_size):
                    chunk = data[i:i + chunk_size]
                    chunk_entropy = self._calculate_entropy(chunk)
                    if chunk_entropy > 7.0:
                        high_entropy_chunks += 1
                
                if high_entropy_chunks > len(data) // chunk_size * 0.3:  # 30% of chunks have high entropy
                    packers_found.append('Unknown Packer (High Entropy)')
            
            triggered = len(packers_found) > 0
            score = min(len(packers_found) / 5.0, 1.0)
            
            return {
                'name': 'Packer Detection',
                'triggered': triggered,
                'score': score,
                'value': len(packers_found),
                'description': f'Packer indicators: {packers_found}',
                'packers_found': packers_found
            }
            
        except Exception as e:
            self.logger.error(f"Packer detection error: {str(e)}")
            return {'triggered': False, 'score': 0.0}
    
    def _detect_anti_debugging(self, file_path: str) -> Dict[str, Any]:
        """Detect anti-debugging techniques"""
        try:
            with open(file_path, 'rb') as f:
                data = f.read()
            
            anti_debug_apis = [
                b'IsDebuggerPresent',
                b'CheckRemoteDebuggerPresent',
                b'OutputDebugString',
                b'GetTickCount',
                b'QueryPerformanceCounter'
            ]
            
            anti_debug_found = []
            for api in anti_debug_apis:
                if api in data:
                    anti_debug_found.append(api.decode('ascii', errors='ignore'))
            
            triggered = len(anti_debug_found) > 0
            score = min(len(anti_debug_found) / 3.0, 1.0)
            
            return {
                'name': 'Anti-Debugging',
                'triggered': triggered,
                'score': score,
                'value': len(anti_debug_found),
                'description': f'Anti-debugging techniques: {anti_debug_found}',
                'techniques_found': anti_debug_found
            }
            
        except Exception as e:
            self.logger.error(f"Anti-debugging detection error: {str(e)}")
            return {'triggered': False, 'score': 0.0}
    
    def _detect_network_activity(self, file_path: str) -> Dict[str, Any]:
        """Detect network-related activity"""
        try:
            with open(file_path, 'rb') as f:
                data = f.read()
            
            network_patterns = [
                b'http://',
                b'https://',
                b'ftp://',
                b'socket',
                b'connect',
                b'send',
                b'recv'
            ]
            
            network_indicators = []
            for pattern in network_patterns:
                if pattern in data:
                    network_indicators.append(pattern.decode('ascii', errors='ignore'))
            
            triggered = len(network_indicators) > 0
            score = min(len(network_indicators) / 5.0, 1.0)
            
            return {
                'name': 'Network Activity',
                'triggered': triggered,
                'score': score,
                'value': len(network_indicators),
                'description': f'Network indicators: {network_indicators}',
                'indicators_found': network_indicators
            }
            
        except Exception as e:
            self.logger.error(f"Network activity detection error: {str(e)}")
            return {'triggered': False, 'score': 0.0}
    
    def _calculate_entropy(self, data: bytes) -> float:
        """Calculate Shannon entropy of data"""
        if not data:
            return 0.0
        
        byte_counts = [0] * 256
        for byte in data:
            byte_counts[byte] += 1
        
        entropy = 0.0
        data_len = len(data)
        
        for count in byte_counts:
            if count > 0:
                probability = count / data_len
                entropy -= probability * math.log2(probability)
        
        return entropy
    
    def _classify_threat_level(self, confidence: float) -> str:
        """Classify threat level based on confidence"""
        if confidence >= 0.9:
            return 'critical'
        elif confidence >= 0.8:
            return 'high'
        elif confidence >= 0.6:
            return 'medium'
        elif confidence >= 0.4:
            return 'low'
        else:
            return 'clean'
    
    def _update_stats(self, result: Dict[str, Any], analysis_time: float):
        """Update analysis statistics"""
        self.analysis_stats['total_analyses'] += 1
        self.analysis_stats['analysis_time_sum'] += analysis_time
        
        if result.get('is_malicious', False):
            self.analysis_stats['suspicious_detected'] += 1
        
        # Update rule trigger counts
        for heuristic in result.get('heuristics', []):
            rule_name = heuristic.get('name', 'Unknown')
            self.analysis_stats['rule_trigger_counts'][rule_name] = \
                self.analysis_stats['rule_trigger_counts'].get(rule_name, 0) + 1
    
    def load_rules(self, rules_file: str) -> bool:
        """Load heuristic rules from file"""
        try:
            # In a real implementation, this would load rules from JSON/YAML
            # For now, we'll just return True
            self.logger.info(f"Heuristic rules loaded from {rules_file}")
            return True
            
        except Exception as e:
            self.logger.error(f"Rules loading error: {str(e)}")
            return False
    
    def add_heuristic_rule(self, name: str, description: str, weight: float, 
                          threshold: float, detection_func):
        """Add a new heuristic rule"""
        try:
            new_rule = {
                'name': name,
                'description': description,
                'weight': weight,
                'threshold': threshold,
                'detection_func': detection_func
            }
            
            self.heuristic_rules.append(new_rule)
            self.logger.info(f"Heuristic rule added: {name}")
            
        except Exception as e:
            self.logger.error(f"Heuristic rule addition error: {str(e)}")
    
    def get_heuristic_statistics(self) -> Dict[str, Any]:
        """Get heuristic analysis statistics"""
        stats = self.analysis_stats.copy()
        
        # Calculate additional statistics
        if stats['total_analyses'] > 0:
            stats['suspicious_rate'] = stats['suspicious_detected'] / stats['total_analyses']
            stats['avg_analysis_time'] = stats['analysis_time_sum'] / stats['total_analyses']
        else:
            stats['suspicious_rate'] = 0.0
            stats['avg_analysis_time'] = 0.0
        
        stats['rule_count'] = len(self.heuristic_rules)
        stats['cache_size'] = len(self.analysis_cache)
        
        return stats
    
    def clear_cache(self):
        """Clear analysis cache"""
        self.analysis_cache.clear()
        self.logger.info("Heuristic analysis cache cleared")
    
    def reset_statistics(self):
        """Reset analysis statistics"""
        self.analysis_stats = {
            'total_analyses': 0,
            'suspicious_detected': 0,
            'analysis_time_sum': 0.0,
            'rule_trigger_counts': {}
        }
        self.logger.info("Heuristic analysis statistics reset")