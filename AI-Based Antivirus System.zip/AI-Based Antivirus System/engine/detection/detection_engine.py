"""
Main Detection Engine

Orchestrates signature-based and heuristic detection methods
to provide comprehensive malware detection capabilities.
"""

import logging
import time
import hashlib
from typing import Dict, List, Any, Optional, Tuple, Union
from pathlib import Path
import json

from .signature_detector import SignatureDetector
from .heuristic_engine import HeuristicEngine
from .behavioral_analyzer import BehavioralAnalyzer
from ..utils import get_logger


class DetectionEngine:
    """
    Main detection engine combining multiple detection methods
    
    Features:
    - Signature-based detection
    - Heuristic analysis
    - Behavioral analysis
    - Quorum-based decision making
    """
    
    def __init__(self, config: Optional[Dict] = None):
        self.logger = get_logger(__name__)
        self.config = config or self._get_default_config()
        
        # Initialize detection components
        self.signature_detector = SignatureDetector()
        self.heuristic_engine = HeuristicEngine()
        self.behavioral_analyzer = BehavioralAnalyzer()
        
        # Detection statistics
        self.detection_stats = {
            'total_scans': 0,
            'signature_detections': 0,
            'heuristic_detections': 0,
            'behavioral_detections': 0,
            'false_positives': 0,
            'avg_detection_time': 0.0
        }
        
        self.logger.info("Detection Engine initialized")
    
    def _get_default_config(self) -> Dict:
        """Get default detection configuration"""
        return {
            'signature_enabled': True,
            'heuristic_enabled': True,
            'behavioral_enabled': True,
            'signature_threshold': 0.9,
            'heuristic_threshold': 0.7,
            'behavioral_threshold': 0.6,
            'quorum_required': 2,
            'max_file_size': 100 * 1024 * 1024,  # 100MB
            'supported_types': ['.exe', '.dll', '.bin', '.pdf', '.doc', '.js', '.ps1', '.vbs'],
            'cache_results': True
        }
    
    def signature_scan(self, file_path: str) -> Dict[str, Any]:
        """
        Perform signature-based scan
        
        Args:
            file_path: Path to the file to scan
            
        Returns:
            Detection result
        """
        try:
            start_time = time.time()
            
            self.logger.debug(f"Starting signature scan: {file_path}")
            
            # Validate file
            if not self._validate_file(file_path):
                return {
                    'method': 'signature',
                    'confidence': 0.0,
                    'is_malicious': False,
                    'matches': [],
                    'signatures': [],
                    'scan_time': 0.0
                }
            
            # Perform signature detection
            result = self.signature_detector.scan_file(file_path)
            
            scan_time = time.time() - start_time
            result['scan_time'] = scan_time
            
            # Update statistics
            self.detection_stats['signature_detections'] += 1 if result.get('is_malicious', False) else 0
            
            self.logger.debug(f"Signature scan completed: {file_path} in {scan_time:.3f}s")
            
            return result
            
        except Exception as e:
            self.logger.error(f"Signature scan error: {str(e)}")
            return {
                'method': 'signature',
                'confidence': 0.0,
                'is_malicious': False,
                'matches': [],
                'signatures': [],
                'scan_time': 0.0,
                'error': str(e)
            }
    
    def heuristic_scan(self, file_path: str) -> Dict[str, Any]:
        """
        Perform heuristic analysis scan
        
        Args:
            file_path: Path to the file to scan
            
        Returns:
            Detection result
        """
        try:
            start_time = time.time()
            
            self.logger.debug(f"Starting heuristic scan: {file_path}")
            
            # Validate file
            if not self._validate_file(file_path):
                return {
                    'method': 'heuristic',
                    'confidence': 0.0,
                    'is_malicious': False,
                    'heuristics': [],
                    'scan_time': 0.0
                }
            
            # Perform heuristic analysis
            result = self.heuristic_engine.analyze_file(file_path)
            
            scan_time = time.time() - start_time
            result['scan_time'] = scan_time
            
            # Update statistics
            self.detection_stats['heuristic_detections'] += 1 if result.get('is_malicious', False) else 0
            
            self.logger.debug(f"Heuristic scan completed: {file_path} in {scan_time:.3f}s")
            
            return result
            
        except Exception as e:
            self.logger.error(f"Heuristic scan error: {str(e)}")
            return {
                'method': 'heuristic',
                'confidence': 0.0,
                'is_malicious': False,
                'heuristics': [],
                'scan_time': 0.0,
                'error': str(e)
            }
    
    def behavioral_scan(self, file_path: str) -> Dict[str, Any]:
        """
        Perform behavioral analysis scan
        
        Args:
            file_path: Path to the file to scan
            
        Returns:
            Detection result
        """
        try:
            start_time = time.time()
            
            self.logger.debug(f"Starting behavioral scan: {file_path}")
            
            # Validate file
            if not self._validate_file(file_path):
                return {
                    'method': 'behavioral',
                    'confidence': 0.0,
                    'is_malicious': False,
                    'behaviors': [],
                    'scan_time': 0.0
                }
            
            # Perform behavioral analysis
            result = self.behavioral_analyzer.analyze_file(file_path)
            
            scan_time = time.time() - start_time
            result['scan_time'] = scan_time
            
            # Update statistics
            self.detection_stats['behavioral_detections'] += 1 if result.get('is_malicious', False) else 0
            
            self.logger.debug(f"Behavioral scan completed: {file_path} in {scan_time:.3f}s")
            
            return result
            
        except Exception as e:
            self.logger.error(f"Behavioral scan error: {str(e)}")
            return {
                'method': 'behavioral',
                'confidence': 0.0,
                'is_malicious': False,
                'behaviors': [],
                'scan_time': 0.0,
                'error': str(e)
            }
    
    def comprehensive_scan(self, file_path: str) -> Dict[str, Any]:
        """
        Perform comprehensive scan using all methods
        
        Args:
            file_path: Path to the file to scan
            
        Returns:
            Combined detection result
        """
        try:
            start_time = time.time()
            
            self.logger.info(f"Starting comprehensive scan: {file_path}")
            
            # Run all detection methods
            results = []
            
            if self.config['signature_enabled']:
                sig_result = self.signature_scan(file_path)
                results.append(sig_result)
            
            if self.config['heuristic_enabled']:
                heur_result = self.heuristic_scan(file_path)
                results.append(heur_result)
            
            if self.config['behavioral_enabled']:
                beh_result = self.behavioral_scan(file_path)
                results.append(beh_result)
            
            # Make quorum-based decision
            final_result = self._make_quorum_decision(results)
            
            # Add metadata
            final_result['file_path'] = file_path
            final_result['total_scan_time'] = time.time() - start_time
            final_result['methods_used'] = [r.get('method', 'unknown') for r in results]
            
            # Update statistics
            self._update_stats(final_result, final_result['total_scan_time'])
            
            self.logger.info(f"Comprehensive scan completed: {file_path} - {final_result.get('threat_level', 'clean')}")
            
            return final_result
            
        except Exception as e:
            self.logger.error(f"Comprehensive scan error: {str(e)}")
            return {
                'file_path': file_path,
                'is_malicious': False,
                'confidence': 0.0,
                'threat_level': 'error',
                'error': str(e),
                'total_scan_time': 0.0
            }
    
    def _validate_file(self, file_path: str) -> bool:
        """Validate file before scanning"""
        try:
            path = Path(file_path)
            if not path.exists() or not path.is_file():
                return False
            
            if path.stat().st_size > self.config['max_file_size']:
                self.logger.warning(f"File {file_path} exceeds size limit")
                return False
            
            if self.config['supported_types']:
                if path.suffix.lower() not in self.config['supported_types']:
                    self.logger.warning(f"File type {path.suffix} not supported")
                    return False
            
            return True
            
        except Exception as e:
            self.logger.error(f"File validation error: {str(e)}")
            return False
    
    def _make_quorum_decision(self, results: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Make final decision using quorum-based approach"""
        # Count detections by confidence level
        high_conf_detections = []
        medium_conf_detections = []
        low_conf_detections = []
        
        for result in results:
            confidence = result.get('confidence', 0.0)
            is_malicious = result.get('is_malicious', False)
            
            if confidence >= self.config['signature_threshold']:
                high_conf_detections.append(result)
            elif confidence >= self.config['heuristic_threshold']:
                medium_conf_detections.append(result)
            elif confidence >= self.config['behavioral_threshold']:
                low_conf_detections.append(result)
        
        # Decision logic
        is_malicious = False
        confidence = 0.0
        threat_level = 'clean'
        detection_methods = []
        all_indicators = []
        
        # High confidence detections take precedence
        if high_conf_detections:
            is_malicious = True
            confidence = max(r.get('confidence', 0.0) for r in high_conf_detections)
            threat_level = self._classify_threat_level(confidence)
            detection_methods = [r.get('method', 'unknown') for r in high_conf_detections]
            
            # Collect all indicators
            for result in high_conf_detections:
                all_indicators.extend(result.get('matches', []))
                all_indicators.extend(result.get('heuristics', []))
                all_indicators.extend(result.get('behaviors', []))
        
        # Quorum requirement for medium confidence
        elif len(medium_conf_detections) >= self.config['quorum_required']:
            is_malicious = True
            confidence = sum(r.get('confidence', 0.0) for r in medium_conf_detections) / len(medium_conf_detections)
            threat_level = self._classify_threat_level(confidence)
            detection_methods = [r.get('method', 'unknown') for r in medium_conf_detections]
            
            for result in medium_conf_detections:
                all_indicators.extend(result.get('matches', []))
                all_indicators.extend(result.get('heuristics', []))
                all_indicators.extend(result.get('behaviors', []))
        
        # Additional confirmation for low confidence with multiple methods
        elif len(low_conf_detections) >= self.config['quorum_required'] + 1:
            confidence = sum(r.get('confidence', 0.0) for r in low_conf_detections) / len(low_conf_detections)
            if confidence > 0.5:
                is_malicious = True
                threat_level = self._classify_threat_level(confidence)
                detection_methods = [r.get('method', 'unknown') for r in low_conf_detections]
        
        return {
            'is_malicious': is_malicious,
            'confidence': confidence,
            'threat_level': threat_level,
            'detection_methods': detection_methods,
            'indicators': list(set(all_indicators)),  # Remove duplicates
            'quorum_details': {
                'high_conf_count': len(high_conf_detections),
                'medium_conf_count': len(medium_conf_detections),
                'low_conf_count': len(low_conf_detections),
                'total_methods': len(results)
            }
        }
    
    def _classify_threat_level(self, confidence: float) -> str:
        """Classify threat level based on confidence"""
        if confidence >= 0.95:
            return 'critical'
        elif confidence >= 0.85:
            return 'high'
        elif confidence >= 0.70:
            return 'medium'
        elif confidence >= 0.50:
            return 'low'
        else:
            return 'clean'
    
    def _update_stats(self, result: Dict[str, Any], scan_time: float):
        """Update detection statistics"""
        self.detection_stats['total_scans'] += 1
        
        # Update average scan time
        total_time = self.detection_stats['avg_detection_time'] * (self.detection_stats['total_scans'] - 1)
        self.detection_stats['avg_detection_time'] = (total_time + scan_time) / self.detection_stats['total_scans']
        
        # Count detections by method
        methods = result.get('detection_methods', [])
        for method in methods:
            if method == 'signature':
                self.detection_stats['signature_detections'] += 1
            elif method == 'heuristic':
                self.detection_stats['heuristic_detections'] += 1
            elif method == 'behavioral':
                self.detection_stats['behavioral_detections'] += 1
    
    def batch_scan(self, file_paths: List[str], scan_type: str = 'comprehensive') -> Dict[str, Dict[str, Any]]:
        """
        Perform batch scanning of multiple files
        
        Args:
            file_paths: List of file paths to scan
            scan_type: 'signature', 'heuristic', 'behavioral', or 'comprehensive'
            
        Returns:
            Dictionary mapping file paths to scan results
        """
        try:
            self.logger.info(f"Starting batch scan: {len(file_paths)} files, type: {scan_type}")
            
            results = {}
            
            for file_path in file_paths:
                try:
                    if scan_type == 'signature':
                        result = self.signature_scan(file_path)
                    elif scan_type == 'heuristic':
                        result = self.heuristic_scan(file_path)
                    elif scan_type == 'behavioral':
                        result = self.behavioral_scan(file_path)
                    else:  # comprehensive
                        result = self.comprehensive_scan(file_path)
                    
                    results[file_path] = result
                    
                except Exception as e:
                    self.logger.error(f"Batch scan error for {file_path}: {str(e)}")
                    results[file_path] = {
                        'error': str(e),
                        'is_malicious': False,
                        'confidence': 0.0
                    }
            
            self.logger.info(f"Batch scan completed: {len(results)} results")
            return results
            
        except Exception as e:
            self.logger.error(f"Batch scan error: {str(e)}")
            return {}
    
    def load_signatures(self, signature_file: str) -> bool:
        """Load signature database"""
        try:
            success = self.signature_detector.load_signature_database(signature_file)
            if success:
                self.logger.info(f"Signatures loaded from {signature_file}")
            return success
        except Exception as e:
            self.logger.error(f"Signature loading error: {str(e)}")
            return False
    
    def update_heuristic_rules(self, rules_file: str) -> bool:
        """Update heuristic detection rules"""
        try:
            success = self.heuristic_engine.load_rules(rules_file)
            if success:
                self.logger.info(f"Heuristic rules loaded from {rules_file}")
            return success
        except Exception as e:
            self.logger.error(f"Heuristic rules loading error: {str(e)}")
            return False
    
    def get_detection_statistics(self) -> Dict[str, Any]:
        """Get comprehensive detection statistics"""
        stats = self.detection_stats.copy()
        
        # Calculate additional statistics
        if stats['total_scans'] > 0:
            stats['detection_rate'] = (
                (stats['signature_detections'] + stats['heuristic_detections'] + stats['behavioral_detections']) 
                / stats['total_scans']
            )
            stats['signature_detection_rate'] = stats['signature_detections'] / stats['total_scans']
            stats['heuristic_detection_rate'] = stats['heuristic_detections'] / stats['total_scans']
            stats['behavioral_detection_rate'] = stats['behavioral_detections'] / stats['total_scans']
        else:
            stats['detection_rate'] = 0.0
            stats['signature_detection_rate'] = 0.0
            stats['heuristic_detection_rate'] = 0.0
            stats['behavioral_detection_rate'] = 0.0
        
        return stats
    
    def reset_statistics(self):
        """Reset detection statistics"""
        self.detection_stats = {
            'total_scans': 0,
            'signature_detections': 0,
            'heuristic_detections': 0,
            'behavioral_detections': 0,
            'false_positives': 0,
            'avg_detection_time': 0.0
        }
        self.logger.info("Detection statistics reset")
    
    def update_config(self, new_config: Dict):
        """Update detection engine configuration"""
        self.config.update(new_config)
        self.logger.info("Detection engine configuration updated")
    
    def export_scan_results(self, results: Dict[str, Dict[str, Any]], output_path: str):
        """Export scan results to file"""
        try:
            export_data = {
                'scan_timestamp': time.time(),
                'scan_type': 'batch',
                'total_files': len(results),
                'results': results
            }
            
            with open(output_path, 'w') as f:
                json.dump(export_data, f, indent=2, default=str)
            
            self.logger.info(f"Scan results exported to {output_path}")
            
        except Exception as e:
            self.logger.error(f"Results export error: {str(e)}")