"""
Signature Detector

Implements hash-based and pattern-based signature detection
for known malware identification.
"""

import logging
import hashlib
import re
from typing import Dict, List, Any, Optional, Tuple, Set
from pathlib import Path
import json
import yara

from ..utils import get_logger


class SignatureDetector:
    """
    Signature-based malware detection system
    
    Supports:
    - File hash matching (MD5, SHA1, SHA256)
    - YARA rule matching
    - String pattern detection
    - Magic number verification
    """
    
    def __init__(self, config: Optional[Dict] = None):
        self.logger = get_logger(__name__)
        self.config = config or self._get_default_config()
        
        # Signature databases
        self.hash_database = {}  # {hash_type: {hash_value: {name, threat_level, first_seen}}}
        self.yara_rules = None
        self.pattern_signatures = []  # List of regex patterns
        self.magic_numbers = {}  # File type signatures
        
        # Detection statistics
        self.detection_stats = {
            'hash_matches': 0,
            'yara_matches': 0,
            'pattern_matches': 0,
            'total_scans': 0
        }
        
        # Load default signatures
        self._load_default_signatures()
        
        self.logger.info("Signature Detector initialized")
    
    def _get_default_config(self) -> Dict:
        """Get default configuration"""
        return {
            'hash_types': ['md5', 'sha1', 'sha256'],
            'yara_enabled': True,
            'pattern_enabled': True,
            'magic_number_enabled': True,
            'scan_timeout': 30,  # seconds
            'max_file_size': 50 * 1024 * 1024,  # 50MB for signature scanning
            'confidence_threshold': 0.9
        }
    
    def _load_default_signatures(self):
        """Load default signature patterns and rules"""
        try:
            # Load common malware hashes (example set)
            default_hashes = {
                'sha256': {
                    'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855': {
                        'name': 'Known Malware Sample 1',
                        'threat_level': 'high',
                        'family': 'Trojan'
                    },
                    'd2f6b1a2b3c4d5e6f7a8b9c0d1e2f3a4b5c6d7e8f9a0b1c2d3e4f5a6b7c8d9e0f1a2': {
                        'name': 'Known Malware Sample 2', 
                        'threat_level': 'critical',
                        'family': 'Ransomware'
                    }
                }
            }
            
            self.hash_database.update(default_hashes)
            
            # Load suspicious patterns
            self.pattern_signatures = [
                {
                    'name': 'PowerShell Obfuscation',
                    'pattern': r'(?i)powershell.*-enc',
                    'threat_level': 'medium',
                    'description': 'Encoded PowerShell command'
                },
                {
                    'name': 'Registry Persistence',
                    'pattern': r'(?i)HKLM.*\\Software\\Microsoft\\Windows\\CurrentVersion\\Run',
                    'threat_level': 'high',
                    'description': 'Registry persistence mechanism'
                },
                {
                    'name': 'Network Download',
                    'pattern': r'(?i)(http|https|ftp)://[^\s<>"{}|\\^`\[\]]+',
                    'threat_level': 'medium',
                    'description': 'Network URL pattern'
                },
                {
                    'name': 'File System Traversal',
                    'pattern': r'\.\.[\\/]', 
                    'threat_level': 'medium',
                    'description': 'Directory traversal attempt'
                }
            ]
            
            # Load magic numbers for common file types
            self.magic_numbers = {
                b'MZ': {'type': 'PE Executable', 'threat_level': 'medium'},
                b'PE\x00\x00': {'type': 'PE Executable', 'threat_level': 'low'},
                b'\x7fELF': {'type': 'ELF Executable', 'threat_level': 'low'},
                b'\xfe\xed\xfa': {'type': 'Mach-O Executable', 'threat_level': 'low'},
                b'%PDF': {'type': 'PDF Document', 'threat_level': 'low'},
                b'\xd0\xcf\x11\xe0': {'type': 'Microsoft Office Document', 'threat_level': 'low'},
                b'PK\x03\x04': {'type': 'ZIP Archive', 'threat_level': 'low'},
                b'\x89PNG': {'type': 'PNG Image', 'threat_level': 'low'},
                b'\xff\xd8\xff': {'type': 'JPEG Image', 'threat_level': 'low'}
            }
            
            self.logger.info("Default signatures loaded")
            
        except Exception as e:
            self.logger.error(f"Error loading default signatures: {str(e)}")
    
    def scan_file(self, file_path: str) -> Dict[str, Any]:
        """
        Scan file for signature matches
        
        Args:
            file_path: Path to file to scan
            
        Returns:
            Detection result with matches and confidence
        """
        try:
            start_time = time.time()
            
            self.logger.debug(f"Starting signature scan: {file_path}")
            
            # Validate file
            if not self._validate_file(file_path):
                return {
                    'method': 'signature',
                    'confidence': 0.0,
                    'is_malicious': False,
                    'matches': [],
                    'signatures': [],
                    'scan_time': 0.0
                }
            
            matches = []
            signatures = []
            
            # 1. Hash-based detection
            hash_matches = self._scan_hashes(file_path)
            matches.extend(hash_matches)
            
            # 2. YARA rule detection
            if self.config['yara_enabled'] and self.yara_rules:
                yara_matches = self._scan_yara(file_path)
                matches.extend(yara_matches)
            
            # 3. Pattern detection
            if self.config['pattern_enabled']:
                pattern_matches = self._scan_patterns(file_path)
                matches.extend(pattern_matches)
            
            # 4. Magic number detection
            if self.config['magic_number_enabled']:
                magic_matches = self._scan_magic_numbers(file_path)
                matches.extend(magic_matches)
            
            # Calculate confidence
            confidence = self._calculate_confidence(matches)
            is_malicious = confidence >= self.config['confidence_threshold']
            
            # Create result
            result = {
                'method': 'signature',
                'confidence': confidence,
                'is_malicious': is_malicious,
                'matches': matches,
                'signatures': [m.get('signature_name', 'Unknown') for m in matches],
                'scan_time': time.time() - start_time,
                'threat_level': self._classify_threat_level(confidence)
            }
            
            # Update statistics
            self._update_stats(result)
            
            self.logger.debug(f"Signature scan completed: {len(matches)} matches, confidence={confidence:.3f}")
            
            return result
            
        except Exception as e:
            self.logger.error(f"Signature scan error: {str(e)}")
            return {
                'method': 'signature',
                'confidence': 0.0,
                'is_malicious': False,
                'matches': [],
                'signatures': [],
                'scan_time': 0.0,
                'error': str(e)
            }
    
    def _validate_file(self, file_path: str) -> bool:
        """Validate file before scanning"""
        try:
            path = Path(file_path)
            if not path.exists() or not path.is_file():
                return False
            
            if path.stat().st_size > self.config['max_file_size']:
                self.logger.warning(f"File {file_path} too large for signature scanning")
                return False
            
            return True
            
        except Exception as e:
            self.logger.error(f"File validation error: {str(e)}")
            return False
    
    def _scan_hashes(self, file_path: str) -> List[Dict[str, Any]]:
        """Scan file hashes against known malware database"""
        matches = []
        
        try:
            # Calculate file hashes
            hashes = self._calculate_hashes(file_path)
            
            # Check against database
            for hash_type, hash_value in hashes.items():
                if hash_type in self.hash_database and hash_value in self.hash_database[hash_type]:
                    signature_info = self.hash_database[hash_type][hash_value]
                    
                    matches.append({
                        'type': 'hash',
                        'hash_type': hash_type,
                        'hash_value': hash_value,
                        'signature_name': signature_info['name'],
                        'threat_level': signature_info['threat_level'],
                        'family': signature_info.get('family', 'Unknown'),
                        'confidence': 1.0,  # Perfect match
                        'description': f'Exact hash match for {signature_info["name"]}'
                    })
                    
                    self.logger.info(f"Hash match found: {hash_type}={hash_value}")
        
        except Exception as e:
            self.logger.error(f"Hash scanning error: {str(e)}")
        
        return matches
    
    def _scan_yara(self, file_path: str) -> List[Dict[str, Any]]:
        """Scan file using YARA rules"""
        matches = []
        
        try:
            if not self.yara_rules:
                return matches
            
            # Match YARA rules
            yara_matches = self.yara_rules.match(file_path)
            
            for match in yara_matches:
                matches.append({
                    'type': 'yara',
                    'rule_name': match.rule,
                    'signature_name': f"YARA Rule: {match.rule}",
                    'threat_level': 'medium',
                    'confidence': 0.9,
                    'description': f'YARA rule {match.rule} matched',
                    'matched_strings': [str(s) for s in match.strings]
                })
                
                self.logger.info(f"YARA match: rule={match.rule}")
        
        except Exception as e:
            self.logger.error(f"YARA scanning error: {str(e)}")
        
        return matches
    
    def _scan_patterns(self, file_path: str) -> List[Dict[str, Any]]:
        """Scan file content for suspicious patterns"""
        matches = []
        
        try:
            # Read file content (limited to avoid memory issues)
            with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                content = f.read(1024 * 1024)  # Read first 1MB
            
            # Check patterns
            for pattern_info in self.pattern_signatures:
                try:
                    pattern = pattern_info['pattern']
                    regex = re.compile(pattern)
                    found_matches = regex.findall(content)
                    
                    if found_matches:
                        matches.append({
                            'type': 'pattern',
                            'signature_name': pattern_info['name'],
                            'threat_level': pattern_info['threat_level'],
                            'confidence': 0.7,
                            'description': pattern_info['description'],
                            'match_count': len(found_matches),
                            'sample_matches': found_matches[:3]  # First 3 matches
                        })
                        
                        self.logger.info(f"Pattern match: {pattern_info['name']} ({len(found_matches)} occurrences)")
                
                except re.error as e:
                    self.logger.warning(f"Invalid regex pattern: {pattern_info['name']} - {str(e)}")
        
        except Exception as e:
            self.logger.error(f"Pattern scanning error: {str(e)}")
        
        return matches
    
    def _scan_magic_numbers(self, file_path: str) -> List[Dict[str, Any]]:
        """Scan file for magic numbers/signatures"""
        matches = []
        
        try:
            with open(file_path, 'rb') as f:
                header = f.read(20)  # Read first 20 bytes
            
            # Check magic numbers
            for magic_bytes, file_info in self.magic_numbers.items():
                if header.startswith(magic_bytes):
                    # Only flag as suspicious if it's an executable type
                    if file_info['type'] in ['PE Executable', 'ELF Executable', 'Mach-O Executable']:
                        matches.append({
                            'type': 'magic_number',
                            'signature_name': f"{file_info['type']} Detected",
                            'threat_level': file_info['threat_level'],
                            'confidence': 0.3,  # Low confidence for magic numbers alone
                            'description': f'File type: {file_info["type"]}',
                            'magic_bytes': magic_bytes.hex()
                        })
            
        except Exception as e:
            self.logger.error(f"Magic number scanning error: {str(e)}")
        
        return matches
    
    def _calculate_hashes(self, file_path: str) -> Dict[str, str]:
        """Calculate various hashes for a file"""
        hashes = {}
        
        try:
            with open(file_path, 'rb') as f:
                content = f.read()
            
            # Calculate different hash types
            if 'md5' in self.config['hash_types']:
                hashes['md5'] = hashlib.md5(content).hexdigest()
            
            if 'sha1' in self.config['hash_types']:
                hashes['sha1'] = hashlib.sha1(content).hexdigest()
            
            if 'sha256' in self.config['hash_types']:
                hashes['sha256'] = hashlib.sha256(content).hexdigest()
        
        except Exception as e:
            self.logger.error(f"Hash calculation error: {str(e)}")
        
        return hashes
    
    def _calculate_confidence(self, matches: List[Dict[str, Any]]) -> float:
        """Calculate overall confidence based on matches"""
        if not matches:
            return 0.0
        
        # Weight different match types
        type_weights = {
            'hash': 1.0,        # Perfect match
            'yara': 0.9,        # Very high confidence
            'pattern': 0.7,     # Medium-high confidence
            'magic_number': 0.3  # Low confidence
        }
        
        # Calculate weighted confidence
        total_weight = 0.0
        weighted_confidence = 0.0
        
        for match in matches:
            match_type = match.get('type', 'unknown')
            match_confidence = match.get('confidence', 0.0)
            weight = type_weights.get(match_type, 0.5)
            
            total_weight += weight
            weighted_confidence += match_confidence * weight
        
        if total_weight > 0:
            return min(weighted_confidence / total_weight, 1.0)
        else:
            return 0.0
    
    def _classify_threat_level(self, confidence: float) -> str:
        """Classify threat level based on confidence"""
        if confidence >= 0.95:
            return 'critical'
        elif confidence >= 0.85:
            return 'high'
        elif confidence >= 0.70:
            return 'medium'
        elif confidence >= 0.50:
            return 'low'
        else:
            return 'clean'
    
    def _update_stats(self, result: Dict[str, Any]):
        """Update detection statistics"""
        self.detection_stats['total_scans'] += 1
        
        matches = result.get('matches', [])
        for match in matches:
            match_type = match.get('type', 'unknown')
            if match_type == 'hash':
                self.detection_stats['hash_matches'] += 1
            elif match_type == 'yara':
                self.detection_stats['yara_matches'] += 1
            elif match_type == 'pattern':
                self.detection_stats['pattern_matches'] += 1
    
    def load_signature_database(self, database_path: str) -> bool:
        """
        Load signature database from file
        
        Args:
            database_path: Path to signature database file
            
        Returns:
            Success status
        """
        try:
            with open(database_path, 'r') as f:
                data = json.load(f)
            
            # Update hash database
            if 'hashes' in data:
                for hash_type, hash_dict in data['hashes'].items():
                    if hash_type not in self.hash_database:
                        self.hash_database[hash_type] = {}
                    self.hash_database[hash_type].update(hash_dict)
            
            # Update patterns
            if 'patterns' in data:
                self.pattern_signatures.extend(data['patterns'])
            
            # Update magic numbers
            if 'magic_numbers' in data:
                self.magic_numbers.update(data['magic_numbers'])
            
            self.logger.info(f"Signature database loaded from {database_path}")
            return True
            
        except Exception as e:
            self.logger.error(f"Database loading error: {str(e)}")
            return False
    
    def load_yara_rules(self, rules_path: str) -> bool:
        """
        Load YARA rules from file
        
        Args:
            rules_path: Path to YARA rules file or directory
            
        Returns:
            Success status
        """
        try:
            if Path(rules_path).is_dir():
                # Load all .yar files from directory
                yara_files = list(Path(rules_path).glob('*.yar'))
                if yara_files:
                    self.yara_rules = yara.compile(filepaths={f.stem: str(f) for f in yara_files})
                else:
                    self.logger.warning(f"No YARA files found in {rules_path}")
                    return False
            else:
                # Load single rules file
                self.yara_rules = yara.compile(filepath=rules_path)
            
            self.logger.info(f"YARA rules loaded from {rules_path}")
            return True
            
        except Exception as e:
            self.logger.error(f"YARA rules loading error: {str(e)}")
            return False
    
    def add_hash_signature(self, hash_type: str, hash_value: str, name: str, 
                          threat_level: str = 'medium', family: str = 'Unknown'):
        """Add a new hash signature to the database"""
        try:
            if hash_type not in self.hash_database:
                self.hash_database[hash_type] = {}
            
            self.hash_database[hash_type][hash_value] = {
                'name': name,
                'threat_level': threat_level,
                'family': family,
                'added_time': time.time()
            }
            
            self.logger.info(f"Hash signature added: {hash_type}={hash_value}")
            
        except Exception as e:
            self.logger.error(f"Hash signature addition error: {str(e)}")
    
    def add_pattern_signature(self, name: str, pattern: str, threat_level: str = 'medium', 
                            description: str = ''):
        """Add a new pattern signature"""
        try:
            self.pattern_signatures.append({
                'name': name,
                'pattern': pattern,
                'threat_level': threat_level,
                'description': description
            })
            
            self.logger.info(f"Pattern signature added: {name}")
            
        except Exception as e:
            self.logger.error(f"Pattern signature addition error: {str(e)}")
    
    def get_signature_statistics(self) -> Dict[str, Any]:
        """Get signature detection statistics"""
        return {
            'total_signatures': sum(len(hashes) for hashes in self.hash_database.values()),
            'hash_types': list(self.hash_database.keys()),
            'pattern_count': len(self.pattern_signatures),
            'magic_numbers_count': len(self.magic_numbers),
            'yara_loaded': self.yara_rules is not None,
            'detection_stats': self.detection_stats.copy()
        }
    
    def export_signatures(self, output_path: str):
        """Export current signature database"""
        try:
            export_data = {
                'hashes': self.hash_database,
                'patterns': self.pattern_signatures,
                'magic_numbers': {k.hex(): v for k, v in self.magic_numbers.items()},
                'export_time': time.time()
            }
            
            with open(output_path, 'w') as f:
                json.dump(export_data, f, indent=2, default=str)
            
            self.logger.info(f"Signatures exported to {output_path}")
            
        except Exception as e:
            self.logger.error(f"Signature export error: {str(e)}")
    
    def reset_statistics(self):
        """Reset detection statistics"""
        self.detection_stats = {
            'hash_matches': 0,
            'yara_matches': 0,
            'pattern_matches': 0,
            'total_scans': 0
        }
        self.logger.info("Signature detection statistics reset")


# Import time module
import time