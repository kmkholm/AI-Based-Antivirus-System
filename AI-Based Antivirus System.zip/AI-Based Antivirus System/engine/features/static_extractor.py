"""
Static Feature Extractor

Extracts static features from files including:
- PE headers and sections (Windows executables)
- Import/export tables
- String analysis
- Byte n-grams
- Entropy analysis
- Code patterns
"""

import logging
import re
from typing import Dict, List, Any, Optional
from pathlib import Path
import struct
import hashlib
from collections import Counter

from ..utils import get_logger


class StaticFeatureExtractor:
    """Extracts static features from various file types"""
    
    def __init__(self):
        self.logger = get_logger(__name__)
        
        # Malware-related strings patterns
        self.suspicious_patterns = [
            r'cmd\.exe', r'powershell', r'wmic', r'regsvr32', r'rundll32',
            r'CreateProcess', r'WriteFile', r'ReadFile', r'RegSetValue',
            r'HttpSendRequest', r'InternetOpen', r'WSAStartup', r'connect',
            r'CreateFileMapping', r'VirtualAlloc', r'LoadLibrary', r'GetProcAddress',
            r'FindWindow', r'SetWindowsHook', r'GetAsyncKeyState', r'keylog',
            r'password', r'credential', r'token', r'session', r'login',
            r'C:\\Windows\\System32', r'C:\\Program Files', r'%TEMP%', r'%APPDATA%',
            r'http://', r'https://', r'ftp://', r'\\.*\\.*\\', r'\\\\.*\\.*'
        ]
        
        # PE file signatures and structures
        self.pe_signatures = {
            'MZ': b'MZ',  # DOS header
            'PE': b'PE\x00\x00',  # PE signature
        }
        
        self.logger.info("Static Feature Extractor initialized")
    
    def extract_basic_features(self, file_path: str, file_type: str) -> Dict[str, Any]:
        """Extract basic static features for quick analysis"""
        features = {}
        
        try:
            if file_type == 'pe':
                features.update(self._extract_pe_basic_features(file_path))
            elif file_type in ['script', 'text']:
                features.update(self._extract_script_features(file_path))
            elif file_type == 'document':
                features.update(self._extract_document_features(file_path))
            else:
                features.update(self._extract_generic_features(file_path))
            
            # Common features for all file types
            features.update(self._extract_common_features(file_path))
            
        except Exception as e:
            self.logger.error(f"Basic static feature extraction error: {str(e)}")
        
        return features
    
    def extract_standard_features(self, file_path: str, file_type: str) -> Dict[str, Any]:
        """Extract standard feature set"""
        features = {}
        
        try:
            # Start with basic features
            features.update(self.extract_basic_features(file_path, file_type))
            
            if file_type == 'pe':
                features.update(self._extract_pe_standard_features(file_path))
            elif file_type in ['script', 'text']:
                features.update(self._extract_script_standard_features(file_path))
            
            # String analysis
            features.update(self._extract_string_features(file_path))
            
            # Byte analysis
            features.update(self._extract_byte_features(file_path))
            
        except Exception as e:
            self.logger.error(f"Standard static feature extraction error: {str(e)}")
        
        return features
    
    def extract_full_features(self, file_path: str, file_type: str) -> Dict[str, Any]:
        """Extract complete static feature set"""
        features = {}
        
        try:
            # Start with standard features
            features.update(self.extract_standard_features(file_path, file_type))
            
            if file_type == 'pe':
                features.update(self._extract_pe_full_features(file_path))
            
            # Advanced analysis
            features.update(self._extract_entropy_features(file_path))
            features.update(self._extract_ngram_features(file_path))
            features.update(self._extract_code_patterns(file_path))
            
        except Exception as e:
            self.logger.error(f"Full static feature extraction error: {str(e)}")
        
        return features
    
    def _extract_pe_basic_features(self, file_path: str) -> Dict[str, Any]:
        """Extract basic PE file features"""
        features = {}
        
        try:
            with open(file_path, 'rb') as f:
                data = f.read()
            
            if len(data) < 64:
                return features
            
            # DOS header
            dos_header = data[:64]
            if dos_header[:2] != b'MZ':
                return features
            
            # PE header offset
            pe_offset = struct.unpack('<I', data[60:64])[0]
            
            if pe_offset + 24 > len(data):
                return features
            
            # PE signature
            pe_sig = data[pe_offset:pe_offset+4]
            if pe_sig != b'PE\x00\x00':
                return features
            
            # COFF header
            machine = struct.unpack('<H', data[pe_offset+4:pe_offset+6])[0]
            num_sections = struct.unpack('<H', data[pe_offset+6:pe_offset+8])[0]
            timestamp = struct.unpack('<I', data[pe_offset+8:pe_offset+12])[0]
            
            features.update({
                'is_pe': True,
                'machine_type': machine,
                'num_sections': num_sections,
                'timestamp': timestamp,
                'pe_size': len(data)
            })
            
        except Exception as e:
            self.logger.error(f"PE basic feature extraction error: {str(e)}")
        
        return features
    
    def _extract_pe_standard_features(self, file_path: str) -> Dict[str, Any]:
        """Extract standard PE features"""
        features = {}
        
        try:
            pe_info = self._parse_pe_file(file_path)
            if not pe_info:
                return features
            
            features.update({
                'subsystem': pe_info.get('subsystem', 0),
                'dll_characteristics': pe_info.get('dll_characteristics', 0),
                'magic': pe_info.get('magic', 0),
                'major_linker_version': pe_info.get('major_linker_version', 0),
                'minor_linker_version': pe_info.get('minor_linker_version', 0),
                'size_of_code': pe_info.get('size_of_code', 0),
                'size_of_initialized_data': pe_info.get('size_of_initialized_data', 0),
                'size_of_uninitialized_data': pe_info.get('size_of_uninitialized_data', 0),
                'entry_point': pe_info.get('entry_point', 0),
            })
            
            # Section information
            if 'sections' in pe_info:
                features['sections'] = []
                for section in pe_info['sections']:
                    features['sections'].append({
                        'name': section.get('name', ''),
                        'virtual_size': section.get('virtual_size', 0),
                        'virtual_address': section.get('virtual_address', 0),
                        'raw_size': section.get('raw_size', 0),
                        'raw_address': section.get('raw_address', 0),
                        'characteristics': section.get('characteristics', 0)
                    })
            
        except Exception as e:
            self.logger.error(f"PE standard feature extraction error: {str(e)}")
        
        return features
    
    def _extract_pe_full_features(self, file_path: str) -> Dict[str, Any]:
        """Extract full PE feature set"""
        features = {}
        
        try:
            # Import table
            imports = self._extract_imports(file_path)
            if imports:
                features['imports'] = imports
            
            # Export table
            exports = self._extract_exports(file_path)
            if exports:
                features['exports'] = exports
            
            # Resource information
            resources = self._extract_resources(file_path)
            if resources:
                features['resources'] = resources
            
            # Security directory
            security = self._extract_security_info(file_path)
            if security:
                features['security'] = security
            
        except Exception as e:
            self.logger.error(f"PE full feature extraction error: {str(e)}")
        
        return features
    
    def _extract_script_features(self, file_path: str) -> Dict[str, Any]:
        """Extract features from script files"""
        features = {}
        
        try:
            with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                content = f.read()
            
            # Basic statistics
            features.update({
                'line_count': len(content.splitlines()),
                'char_count': len(content),
                'word_count': len(content.split()),
                'is_obfuscated': self._detect_obfuscation(content),
            })
            
            # Suspicious patterns
            suspicious_matches = 0
            for pattern in self.suspicious_patterns:
                matches = re.findall(pattern, content, re.IGNORECASE)
                suspicious_matches += len(matches)
            
            features['suspicious_pattern_count'] = suspicious_matches
            
        except Exception as e:
            self.logger.error(f"Script feature extraction error: {str(e)}")
        
        return features
    
    def _extract_document_features(self, file_path: str) -> Dict[str, Any]:
        """Extract features from document files"""
        features = {}
        
        try:
            # For now, treat as generic file
            features.update(self._extract_generic_features(file_path))
            
            # Document-specific features can be added here
            # (e.g., PDF metadata, Office document properties)
            
        except Exception as e:
            self.logger.error(f"Document feature extraction error: {str(e)}")
        
        return features
    
    def _extract_generic_features(self, file_path: str) -> Dict[str, Any]:
        """Extract features from generic files"""
        features = {}
        
        try:
            path = Path(file_path)
            
            # File properties
            features.update({
                'extension': path.suffix.lower(),
                'name_length': len(path.name),
                'has_spaces': ' ' in path.name,
                'has_dots': '.' in path.name,
                'is_hidden': path.name.startswith('.'),
            })
            
        except Exception as e:
            self.logger.error(f"Generic feature extraction error: {str(e)}")
        
        return features
    
    def _extract_common_features(self, file_path: str) -> Dict[str, Any]:
        """Extract common features for all file types"""
        features = {}
        
        try:
            with open(file_path, 'rb') as f:
                data = f.read()
            
            # File size categories
            size = len(data)
            if size < 1024:
                features['size_category'] = 'tiny'
            elif size < 10240:
                features['size_category'] = 'small'
            elif size < 102400:
                features['size_category'] = 'medium'
            elif size < 1024000:
                features['size_category'] = 'large'
            else:
                features['size_category'] = 'huge'
            
            # Byte distribution
            if data:
                byte_counts = Counter(data)
                most_common_byte = byte_counts.most_common(1)[0] if byte_counts else (0, 0)
                features['most_common_byte'] = most_common_byte[0]
                features['most_common_byte_count'] = most_common_byte[1]
                features['unique_byte_count'] = len(byte_counts)
            
            # Magic number detection
            features['magic_number'] = data[:8].hex() if data else ''
            
        except Exception as e:
            self.logger.error(f"Common feature extraction error: {str(e)}")
        
        return features
    
    def _extract_string_features(self, file_path: str) -> Dict[str, Any]:
        """Extract string-based features"""
        features = {}
        
        try:
            with open(file_path, 'rb') as f:
                data = f.read()
            
            # Extract ASCII strings (4+ characters)
            ascii_strings = re.findall(b'[ -~]{4,}', data)
            features['ascii_string_count'] = len(ascii_strings)
            features['avg_ascii_string_length'] = sum(len(s) for s in ascii_strings) / len(ascii_strings) if ascii_strings else 0
            
            # Extract URLs
            url_pattern = rb'https?://[^\s<>"{}|\\^`\[\]]+'
            urls = re.findall(url_pattern, data)
            features['url_count'] = len(urls)
            
            # Extract file paths
            path_pattern = rb'[A-Za-z]:\\[^\x00]*'
            paths = re.findall(path_pattern, data)
            features['windows_path_count'] = len(paths)
            
            # Suspicious string patterns
            suspicious_strings = 0
            for pattern in self.suspicious_patterns:
                matches = re.findall(pattern.encode(), data, re.IGNORECASE)
                suspicious_strings += len(matches)
            
            features['suspicious_string_count'] = suspicious_strings
            
        except Exception as e:
            self.logger.error(f"String feature extraction error: {str(e)}")
        
        return features
    
    def _extract_byte_features(self, file_path: str) -> Dict[str, Any]:
        """Extract byte-level features"""
        features = {}
        
        try:
            with open(file_path, 'rb') as f:
                data = f.read()
            
            if not data:
                return features
            
            # Byte frequency analysis
            byte_counts = [0] * 256
            for byte in data:
                byte_counts[byte] += 1
            
            # Statistical measures
            import numpy as np
            byte_array = np.array(byte_counts, dtype=float)
            
            if byte_array.sum() > 0:
                byte_array = byte_array / byte_array.sum()
                
                features.update({
                    'byte_mean': float(np.mean(byte_array)),
                    'byte_std': float(np.std(byte_array)),
                    'byte_min': float(np.min(byte_array)),
                    'byte_max': float(np.max(byte_array)),
                    'byte_entropy': self._calculate_entropy(byte_array),
                })
            
            # High-entropy regions (potential encryption/packing)
            high_entropy_regions = self._find_high_entropy_regions(data)
            features['high_entropy_region_count'] = len(high_entropy_regions)
            features['high_entropy_regions'] = high_entropy_regions
            
        except Exception as e:
            self.logger.error(f"Byte feature extraction error: {str(e)}")
        
        return features
    
    def _extract_entropy_features(self, file_path: str) -> Dict[str, Any]:
        """Extract entropy-based features"""
        features = {}
        
        try:
            with open(file_path, 'rb') as f:
                data = f.read()
            
            if not data:
                return features
            
            # Overall file entropy
            features['file_entropy'] = self._calculate_shannon_entropy(data)
            
            # Section-by-section entropy for PE files
            section_entropies = self._calculate_section_entropies(file_path)
            if section_entropies:
                features['section_entropies'] = section_entropies
                features['max_section_entropy'] = max(section_entropies) if section_entropies else 0
            
            # Entropy-based packer detection
            features['is_likely_packed'] = features.get('file_entropy', 0) > 7.5
            
        except Exception as e:
            self.logger.error(f"Entropy feature extraction error: {str(e)}")
        
        return features
    
    def _extract_ngram_features(self, file_path: str) -> Dict[str, Any]:
        """Extract n-gram features"""
        features = {}
        
        try:
            with open(file_path, 'rb') as f:
                data = f.read()
            
            if len(data) < 256:
                return features
            
            # 1-grams (byte frequency)
            byte_freq = {}
            for byte in data[:10000]:  # Limit to first 10KB for performance
                byte_freq[byte] = byte_freq.get(byte, 0) + 1
            
            features['byte_frequency_top10'] = dict(sorted(byte_freq.items(), key=lambda x: x[1], reverse=True)[:10])
            
            # 2-grams (byte pairs)
            if len(data) >= 2:
                bigram_freq = {}
                for i in range(len(data) - 1):
                    bigram = (data[i], data[i + 1])
                    bigram_freq[bigram] = bigram_freq.get(bigram, 0) + 1
                
                features['bigram_frequency_top10'] = dict(sorted(bigram_freq.items(), key=lambda x: x[1], reverse=True)[:10])
            
        except Exception as e:
            self.logger.error(f"N-gram feature extraction error: {str(e)}")
        
        return features
    
    def _extract_code_patterns(self, file_path: str) -> Dict[str, Any]:
        """Extract code pattern features"""
        features = {}
        
        try:
            # This would typically involve disassembly, which requires external tools
            # For now, we'll use basic pattern matching on bytes
            
            with open(file_path, 'rb') as f:
                data = f.read()
            
            # Common assembly patterns (in bytes)
            patterns = {
                'push_pop_sequence': b'\x50\x58',  # push eax / pop eax
                'jmp_instruction': b'\xE9',       # near jmp
                'call_instruction': b'\xE8',      # near call
                'ret_instruction': b'\xC3',       # ret
                'xor_eax_eax': b'\x33\xC0',       # xor eax, eax
                'mov_eax_imm': b'\xB8',           # mov eax, immediate
            }
            
            for pattern_name, pattern_bytes in patterns.items():
                count = data.count(pattern_bytes)
                features[f'{pattern_name}_count'] = count
            
        except Exception as e:
            self.logger.error(f"Code pattern extraction error: {str(e)}")
        
        return features
    
    def _parse_pe_file(self, file_path: str) -> Optional[Dict]:
        """Parse PE file structure"""
        try:
            with open(file_path, 'rb') as f:
                data = f.read()
            
            if len(data) < 64:
                return None
            
            # DOS header
            if data[:2] != b'MZ':
                return None
            
            # PE header offset
            pe_offset = struct.unpack('<I', data[60:64])[0]
            
            if pe_offset + 24 > len(data):
                return None
            
            # PE signature
            if data[pe_offset:pe_offset+4] != b'PE\x00\x00':
                return None
            
            pe_info = {}
            
            # COFF header
            machine = struct.unpack('<H', data[pe_offset+4:pe_offset+6])[0]
            num_sections = struct.unpack('<H', data[pe_offset+6:pe_offset+8])[0]
            timestamp = struct.unpack('<I', data[pe_offset+8:pe_offset+12])[0]
            opt_hdr_size = struct.unpack('<H', data[pe_offset+20:pe_offset+22])[0]
            
            pe_info.update({
                'machine': machine,
                'num_sections': num_sections,
                'timestamp': timestamp,
                'opt_hdr_size': opt_hdr_size
            })
            
            # Optional header
            if pe_offset + 24 + opt_hdr_size <= len(data):
                opt_hdr_start = pe_offset + 24
                magic = struct.unpack('<H', data[opt_hdr_start:opt_hdr_start+2])[0]
                
                pe_info['magic'] = magic
                
                if magic == 0x10b:  # PE32
                    subsystem = struct.unpack('<H', data[opt_hdr_start+68:opt_hdr_start+70])[0]
                    dll_characteristics = struct.unpack('<H', data[opt_hdr_start+70:opt_hdr_start+72])[0]
                    pe_info.update({
                        'subsystem': subsystem,
                        'dll_characteristics': dll_characteristics
                    })
            
            return pe_info
            
        except Exception as e:
            self.logger.error(f"PE parsing error: {str(e)}")
            return None
    
    def _extract_imports(self, file_path: str) -> Optional[List[str]]:
        """Extract imported functions (simplified)"""
        # This is a simplified version - full PE parsing would be needed for accurate results
        try:
            with open(file_path, 'rb') as f:
                data = f.read()
            
            # Look for common Windows API function names
            common_apis = [
                b'CreateProcess', b'WriteFile', b'ReadFile', b'RegSetValue',
                b'LoadLibrary', b'GetProcAddress', b'FindWindow', b'CreateFile',
                b'DeleteFile', b'CopyFile', b'MoveFile', b'GetWindowsDirectory'
            ]
            
            imports = []
            for api in common_apis:
                if api in data:
                    imports.append(api.decode('ascii', errors='ignore'))
            
            return imports if imports else None
            
        except Exception as e:
            self.logger.error(f"Import extraction error: {str(e)}")
            return None
    
    def _extract_exports(self, file_path: str) -> Optional[List[str]]:
        """Extract exported functions (simplified)"""
        # Simplified version
        return None
    
    def _extract_resources(self, file_path: str) -> Optional[Dict]:
        """Extract resource information (simplified)"""
        # Simplified version
        return None
    
    def _extract_security_info(self, file_path: str) -> Optional[Dict]:
        """Extract security directory information (simplified)"""
        # Simplified version
        return None
    
    def _detect_obfuscation(self, content: str) -> bool:
        """Detect if script content appears obfuscated"""
        try:
            # Simple heuristics for obfuscation
            long_identifier_ratio = len(re.findall(r'[a-zA-Z]{20,}', content)) / len(content.split()) if content.split() else 0
            unusual_char_ratio = len(re.findall(r'[^a-zA-Z0-9\s]', content)) / len(content) if content else 0
            compressed_ratio = len(re.findall(r'[A-Za-z0-9+/]{100,}={0,2}', content)) / len(content) if content else 0
            
            return (long_identifier_ratio > 0.1 or 
                   unusual_char_ratio > 0.1 or 
                   compressed_ratio > 0.1)
            
        except Exception:
            return False
    
    def _calculate_entropy(self, byte_array) -> float:
        """Calculate entropy of byte array"""
        import math
        
        entropy = 0.0
        for p in byte_array:
            if p > 0:
                entropy -= p * math.log2(p)
        return entropy
    
    def _calculate_shannon_entropy(self, data: bytes) -> float:
        """Calculate Shannon entropy of byte data"""
        if not data:
            return 0.0
        
        # Calculate byte frequencies
        byte_counts = [0] * 256
        for byte in data:
            byte_counts[byte] += 1
        
        # Calculate entropy
        import math
        entropy = 0.0
        data_len = len(data)
        
        for count in byte_counts:
            if count > 0:
                probability = count / data_len
                entropy -= probability * math.log2(probability)
        
        return entropy
    
    def _find_high_entropy_regions(self, data: bytes, threshold: float = 7.0) -> List[Dict]:
        """Find regions with high entropy (potential encrypted/packed sections)"""
        import math
        
        high_entropy_regions = []
        window_size = 256
        
        for i in range(0, len(data) - window_size, window_size // 2):
            window = data[i:i + window_size]
            entropy = self._calculate_shannon_entropy(window)
            
            if entropy > threshold:
                high_entropy_regions.append({
                    'start': i,
                    'end': i + len(window),
                    'entropy': entropy
                })
        
        return high_entropy_regions
    
    def _calculate_section_entropies(self, file_path: str) -> List[float]:
        """Calculate entropy of PE sections"""
        # Simplified version - would need full PE parsing
        return []
    
    def get_basic_feature_names(self) -> List[str]:
        """Get list of basic feature names"""
        return [
            'is_pe', 'machine_type', 'num_sections', 'timestamp', 'pe_size',
            'line_count', 'char_count', 'word_count', 'is_obfuscated',
            'suspicious_pattern_count', 'size_category', 'magic_number'
        ]
    
    def get_standard_feature_names(self) -> List[str]:
        """Get list of standard feature names"""
        return (self.get_basic_feature_names() + [
            'subsystem', 'dll_characteristics', 'magic', 'entry_point',
            'ascii_string_count', 'url_count', 'windows_path_count',
            'suspicious_string_count', 'byte_mean', 'byte_std', 'byte_entropy'
        ])
    
    def get_full_feature_names(self) -> List[str]:
        """Get list of full feature names"""
        return (self.get_standard_feature_names() + [
            'imports', 'exports', 'resources', 'security',
            'file_entropy', 'high_entropy_region_count', 'is_likely_packed',
            'byte_frequency_top10', 'bigram_frequency_top10',
            'push_pop_sequence_count', 'jmp_instruction_count', 'call_instruction_count'
        ])