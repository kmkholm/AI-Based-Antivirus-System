"""
Hybrid Feature Extractor

Combines static and dynamic features to create hybrid representations
that leverage the strengths of both approaches for better malware detection.
"""

import logging
import numpy as np
from typing import Dict, List, Any, Optional, Tuple
from sklearn.preprocessing import StandardScaler, MinMaxScaler
from sklearn.feature_selection import SelectKBest, f_classif

from ..utils import get_logger


class HybridFeatureExtractor:
    """Combines static and dynamic features for enhanced detection"""
    
    def __init__(self):
        self.logger = get_logger(__name__)
        
        # Feature importance weights (static vs dynamic)
        self.feature_weights = {
            'static_dominant': {
                'entropy_features': 0.8,
                'structural_features': 0.9,
                'string_features': 0.7,
                'byte_features': 0.8
            },
            'dynamic_dominant': {
                'behavior_features': 0.9,
                'api_features': 0.8,
                'network_features': 0.7,
                'pattern_features': 0.8
            },
            'hybrid_balanced': {
                'combined_features': 0.6
            }
        }
        
        self.logger.info("Hybrid Feature Extractor initialized")
    
    def extract_hybrid_features(self, file_path: str, static_features: Dict, dynamic_features: Dict) -> Dict[str, Any]:
        """Extract hybrid features combining static and dynamic analysis"""
        hybrid_features = {}
        
        try:
            # Create composite features
            hybrid_features.update(self._create_composite_features(static_features, dynamic_features))
            
            # Create interaction features
            hybrid_features.update(self._create_interaction_features(static_features, dynamic_features))
            
            # Create normalized features
            hybrid_features.update(self._create_normalized_features(static_features, dynamic_features))
            
            # Create feature ensembles
            hybrid_features.update(self._create_feature_ensembles(static_features, dynamic_features))
            
            # Calculate hybrid scores
            hybrid_features.update(self._calculate_hybrid_scores(static_features, dynamic_features, hybrid_features))
            
        except Exception as e:
            self.logger.error(f"Hybrid feature extraction error: {str(e)}")
        
        return hybrid_features
    
    def _create_composite_features(self, static_features: Dict, dynamic_features: Dict) -> Dict[str, Any]:
        """Create features that combine static and dynamic information"""
        composite = {}
        
        try:
            # Risk score combination
            static_risk = self._calculate_static_risk(static_features)
            dynamic_risk = self._calculate_dynamic_risk(dynamic_features)
            
            composite['static_risk_score'] = static_risk
            composite['dynamic_risk_score'] = dynamic_risk
            composite['combined_risk_score'] = (static_risk * 0.4) + (dynamic_risk * 0.6)
            
            # Feature density analysis
            static_density = self._calculate_feature_density(static_features)
            dynamic_density = self._calculate_feature_density(dynamic_features)
            
            composite['static_feature_density'] = static_density
            composite['dynamic_feature_density'] = dynamic_density
            composite['hybrid_feature_density'] = (static_density + dynamic_density) / 2
            
            # Suspicion correlation
            static_suspicion = static_features.get('suspicious_string_count', 0) + static_features.get('high_entropy_region_count', 0)
            dynamic_suspicion = dynamic_features.get('behavior_suspicion_score', 0)
            
            composite['static_suspicion_level'] = static_suspicion
            composite['dynamic_suspicion_level'] = dynamic_suspicion
            composite['total_suspicion_score'] = static_suspicion + dynamic_suspicion
            
        except Exception as e:
            self.logger.error(f"Composite feature creation error: {str(e)}")
        
        return composite
    
    def _create_interaction_features(self, static_features: Dict, dynamic_features: Dict) -> Dict[str, Any]:
        """Create features that represent interactions between static and dynamic properties"""
        interactions = {}
        
        try:
            # File type vs behavior correlation
            file_type = static_features.get('file_type', 'unknown')
            behavior_malicious = dynamic_features.get('is_behavior_malicious', False)
            
            interactions[f'{file_type}_malicious_behavior'] = 1 if behavior_malicious else 0
            
            # Size vs execution correlation
            file_size = static_features.get('file_info', {}).get('size', 0)
            execution_successful = dynamic_features.get('execution_successful', False)
            
            # Small files that execute successfully might be suspicious
            if file_size < 10240 and execution_successful:  # < 10KB
                interactions['small_executable_risk'] = 1
            else:
                interactions['small_executable_risk'] = 0
            
            # Entropy vs packing correlation
            file_entropy = static_features.get('file_entropy', 0)
            memory_operations = dynamic_features.get('total_memory_operations', 0)
            
            # High entropy with memory operations might indicate unpacking
            interactions['entropy_memory_correlation'] = file_entropy * min(memory_operations / 10, 1)
            
            # API complexity vs static complexity
            api_count = dynamic_features.get('unique_api_calls', 0)
            static_complexity = len([k for k in static_features.keys() if 'feature' in k.lower() or 'count' in k.lower()])
            
            interactions['api_static_complexity_ratio'] = api_count / max(static_complexity, 1)
            
            # Network activity vs suspicious strings
            network_ops = dynamic_features.get('total_network_operations', 0)
            suspicious_strings = static_features.get('suspicious_string_count', 0)
            
            interactions['network_string_correlation'] = network_ops * suspicious_strings
            
        except Exception as e:
            self.logger.error(f"Interaction feature creation error: {str(e)}")
        
        return interactions
    
    def _create_normalized_features(self, static_features: Dict, dynamic_features: Dict) -> Dict[str, Any]:
        """Create normalized versions of features for better ML performance"""
        normalized = {}
        
        try:
            # Combine all numerical features
            numerical_features = self._extract_numerical_features(static_features, dynamic_features)
            
            if not numerical_features:
                return normalized
            
            # Z-score normalization
            values = list(numerical_features.values())
            if len(values) > 1:
                mean_val = np.mean(values)
                std_val = np.std(values)
                
                if std_val > 0:
                    for key, value in numerical_features.items():
                        normalized[f'{key}_zscore'] = (value - mean_val) / std_val
                else:
                    for key in numerical_features:
                        normalized[f'{key}_zscore'] = 0.0
            
            # Min-max normalization
            if len(values) > 1:
                min_val = min(values)
                max_val = max(values)
                
                if max_val > min_val:
                    for key, value in numerical_features.items():
                        normalized[f'{key}_minmax'] = (value - min_val) / (max_val - min_val)
                else:
                    for key in numerical_features:
                        normalized[f'{key}_minmax'] = 0.0
            
            # Binarization for categorical features
            categorical_features = self._extract_categorical_features(static_features, dynamic_features)
            for key, value in categorical_features.items():
                normalized[f'{key}_binary'] = 1 if value else 0
            
        except Exception as e:
            self.logger.error(f"Normalized feature creation error: {str(e)}")
        
        return normalized
    
    def _create_feature_ensembles(self, static_features: Dict, dynamic_features: Dict) -> Dict[str, Any]:
        """Create ensemble features by combining similar feature types"""
        ensembles = {}
        
        try:
            # Security-related features ensemble
            security_static = self._get_security_related_static_features(static_features)
            security_dynamic = self._get_security_related_dynamic_features(dynamic_features)
            
            ensembles['security_features_count'] = len(security_static) + len(security_dynamic)
            ensembles['security_risk_aggregate'] = (sum(security_static.values()) + sum(security_dynamic.values())) / max(len(security_static) + len(security_dynamic), 1)
            
            # I/O features ensemble
            io_static = static_features.get('total_file_operations', 0)
            io_dynamic = dynamic_features.get('total_file_operations', 0)
            
            ensembles['total_io_operations'] = io_static + io_dynamic
            ensembles['io_complexity_score'] = (io_static * 0.3) + (io_dynamic * 0.7)
            
            # Network features ensemble
            network_static = static_features.get('url_count', 0)
            network_dynamic = dynamic_features.get('total_network_operations', 0)
            
            ensembles['network_activity_score'] = (network_static * 0.2) + (network_dynamic * 0.8)
            ensembles['network_suspicion_level'] = min(network_static + network_dynamic, 1.0)
            
            # Persistence features ensemble
            persistence_static = static_features.get('persistence_indicators', 0)
            persistence_dynamic = dynamic_features.get('persistence_indicators', 0)
            
            ensembles['persistence_indicators_total'] = persistence_static + persistence_dynamic
            ensembles['is_persistence_suspicious'] = 1 if (persistence_static + persistence_dynamic) > 0 else 0
            
        except Exception as e:
            self.logger.error(f"Ensemble feature creation error: {str(e)}")
        
        return ensembles
    
    def _calculate_hybrid_scores(self, static_features: Dict, dynamic_features: Dict, hybrid_features: Dict) -> Dict[str, Any]:
        """Calculate hybrid detection scores"""
        scores = {}
        
        try:
            # Multi-modal confidence score
            static_confidence = self._calculate_static_confidence(static_features)
            dynamic_confidence = dynamic_features.get('behavior_confidence', 0.0)
            hybrid_confidence = hybrid_features.get('combined_risk_score', 0.0)
            
            # Weighted combination
            total_confidence = (static_confidence * 0.3) + (dynamic_confidence * 0.4) + (hybrid_confidence * 0.3)
            scores['multimodal_confidence'] = total_confidence
            
            # Threat level prediction
            threat_level = self._predict_threat_level(static_features, dynamic_features, hybrid_features)
            scores['predicted_threat_level'] = threat_level
            scores['threat_level_score'] = self._threat_level_to_score(threat_level)
            
            # Malware family probability (simplified)
            family_probs = self._predict_malware_family(static_features, dynamic_features)
            scores['family_probabilities'] = family_probs
            scores['most_likely_family'] = max(family_probs, key=family_probs.get) if family_probs else 'unknown'
            
        except Exception as e:
            self.logger.error(f"Hybrid score calculation error: {str(e)}")
        
        return scores
    
    def _calculate_static_risk(self, static_features: Dict) -> float:
        """Calculate risk score based on static features"""
        risk_factors = [
            static_features.get('suspicious_string_count', 0) * 0.1,
            static_features.get('high_entropy_region_count', 0) * 0.2,
            1.0 if static_features.get('is_likely_packed', False) else 0.0,
            static_features.get('entropy', 0.0) * 0.05,
            min(static_features.get('suspicious_pattern_count', 0) * 0.1, 1.0)
        ]
        
        return min(sum(risk_factors), 1.0)
    
    def _calculate_dynamic_risk(self, dynamic_features: Dict) -> float:
        """Calculate risk score based on dynamic features"""
        risk_factors = [
            dynamic_features.get('behavior_confidence', 0.0),
            dynamic_features.get('api_suspicion_score', 0) * 0.02,
            dynamic_features.get('anti_analysis_score', 0) * 0.1,
            1.0 if dynamic_features.get('is_behavior_malicious', False) else 0.0
        ]
        
        return min(sum(risk_factors), 1.0)
    
    def _calculate_feature_density(self, features: Dict) -> float:
        """Calculate feature density (number of non-zero features)"""
        if not features:
            return 0.0
        
        non_zero_count = 0
        total_count = 0
        
        for key, value in features.items():
            total_count += 1
            if isinstance(value, (int, float)) and value != 0:
                non_zero_count += 1
            elif isinstance(value, (str, list, dict)) and value:
                non_zero_count += 1
        
        return non_zero_count / max(total_count, 1)
    
    def _extract_numerical_features(self, static_features: Dict, dynamic_features: Dict) -> Dict[str, float]:
        """Extract numerical features for normalization"""
        numerical = {}
        
        # Extract from static features
        for key, value in static_features.items():
            if isinstance(value, (int, float)) and not np.isnan(value):
                numerical[f'static_{key}'] = float(value)
        
        # Extract from dynamic features
        for key, value in dynamic_features.items():
            if isinstance(value, (int, float)) and not np.isnan(value):
                numerical[f'dynamic_{key}'] = float(value)
        
        return numerical
    
    def _extract_categorical_features(self, static_features: Dict, dynamic_features: Dict) -> Dict[str, Any]:
        """Extract categorical features for binarization"""
        categorical = {}
        
        # Extract from static features
        for key, value in static_features.items():
            if not isinstance(value, (int, float)):
                categorical[f'static_{key}'] = bool(value)
        
        # Extract from dynamic features
        for key, value in dynamic_features.items():
            if not isinstance(value, (int, float)):
                categorical[f'dynamic_{key}'] = bool(value)
        
        return categorical
    
    def _get_security_related_static_features(self, static_features: Dict) -> Dict[str, float]:
        """Extract security-related static features"""
        security_features = {}
        
        security_indicators = [
            'suspicious_string_count', 'high_entropy_region_count', 'is_likely_packed',
            'jmp_instruction_count', 'call_instruction_count', 'xor_eax_eax_count'
        ]
        
        for indicator in security_indicators:
            if indicator in static_features:
                value = static_features[indicator]
                if isinstance(value, (int, float)):
                    security_features[indicator] = float(value)
        
        return security_features
    
    def _get_security_related_dynamic_features(self, dynamic_features: Dict) -> Dict[str, float]:
        """Extract security-related dynamic features"""
        security_features = {}
        
        security_indicators = [
            'api_suspicion_score', 'anti_analysis_score', 'behavior_suspicion_score',
            'privilege_escalation_attempts', 'persistence_indicators', 'suspicious_processes'
        ]
        
        for indicator in security_indicators:
            if indicator in dynamic_features:
                value = dynamic_features[indicator]
                if isinstance(value, (int, float)):
                    security_features[indicator] = float(value)
        
        return security_features
    
    def _calculate_static_confidence(self, static_features: Dict) -> float:
        """Calculate confidence in static analysis results"""
        confidence_factors = []
        
        # File entropy confidence
        entropy = static_features.get('file_entropy', 0.0)
        if entropy > 7.5:  # High entropy
            confidence_factors.append(0.8)
        elif entropy < 3.0:  # Low entropy
            confidence_factors.append(0.3)
        else:
            confidence_factors.append(0.6)
        
        # File type confidence
        file_type = static_features.get('file_type', 'unknown')
        if file_type == 'pe':
            confidence_factors.append(0.9)  # High confidence for PE files
        elif file_type in ['script', 'document']:
            confidence_factors.append(0.7)  # Medium confidence
        else:
            confidence_factors.append(0.4)  # Lower confidence
        
        # Feature completeness
        feature_count = len([k for k, v in static_features.items() if v is not None])
        if feature_count > 20:
            confidence_factors.append(0.8)
        elif feature_count > 10:
            confidence_factors.append(0.6)
        else:
            confidence_factors.append(0.3)
        
        return np.mean(confidence_factors) if confidence_factors else 0.0
    
    def _predict_threat_level(self, static_features: Dict, dynamic_features: Dict, hybrid_features: Dict) -> str:
        """Predict threat level based on all features"""
        combined_score = (
            static_features.get('suspicious_string_count', 0) * 0.1 +
            dynamic_features.get('behavior_confidence', 0.0) * 0.5 +
            hybrid_features.get('combined_risk_score', 0.0) * 0.4
        )
        
        if combined_score >= 0.8:
            return 'critical'
        elif combined_score >= 0.6:
            return 'high'
        elif combined_score >= 0.4:
            return 'medium'
        elif combined_score >= 0.2:
            return 'low'
        else:
            return 'clean'
    
    def _threat_level_to_score(self, threat_level: str) -> float:
        """Convert threat level to numerical score"""
        level_scores = {
            'clean': 0.0,
            'low': 0.25,
            'medium': 0.5,
            'high': 0.75,
            'critical': 1.0
        }
        return level_scores.get(threat_level, 0.0)
    
    def _predict_malware_family(self, static_features: Dict, dynamic_features: Dict) -> Dict[str, float]:
        """Predict malware family probabilities (simplified implementation)"""
        families = {
            'trojan': 0.0,
            'worm': 0.0,
            'virus': 0.0,
            'ransomware': 0.0,
            'spyware': 0.0,
            'adware': 0.0,
            'rootkit': 0.0
        }
        
        try:
            # Simple rule-based family classification
            api_calls = dynamic_features.get('api_categories', {})
            file_ops = dynamic_features.get('total_file_operations', 0)
            network_ops = dynamic_features.get('total_network_operations', 0)
            persistence = dynamic_features.get('persistence_indicators', 0)
            
            # Trojan indicators
            if 'process_operations' in api_calls and persistence > 0:
                families['trojan'] = 0.6
            
            # Worm indicators
            if network_ops > 5 and 'file_operations' in api_calls:
                families['worm'] = 0.7
            
            # Ransomware indicators
            file_modifications = dynamic_features.get('file_modifications', 0)
            if file_modifications > 10 and 'registry_operations' in api_calls:
                families['ransomware'] = 0.8
            
            # Spyware indicators
            if 'security_operations' in api_calls and 'anti_analysis' in api_calls:
                families['spyware'] = 0.6
            
            # Normalize probabilities
            total_score = sum(families.values())
            if total_score > 0:
                for family in families:
                    families[family] /= total_score
            
        except Exception as e:
            self.logger.error(f"Family prediction error: {str(e)}")
        
        return families
    
    def get_hybrid_feature_names(self) -> List[str]:
        """Get list of hybrid feature names"""
        return [
            'static_risk_score', 'dynamic_risk_score', 'combined_risk_score',
            'static_feature_density', 'dynamic_feature_density', 'hybrid_feature_density',
            'static_suspicion_level', 'dynamic_suspicion_level', 'total_suspicion_score',
            'small_executable_risk', 'entropy_memory_correlation', 'api_static_complexity_ratio',
            'network_string_correlation', 'security_features_count', 'security_risk_aggregate',
            'total_io_operations', 'io_complexity_score', 'network_activity_score',
            'network_suspicion_level', 'persistence_indicators_total', 'is_persistence_suspicious',
            'multimodal_confidence', 'predicted_threat_level', 'threat_level_score',
            'most_likely_family'
        ]