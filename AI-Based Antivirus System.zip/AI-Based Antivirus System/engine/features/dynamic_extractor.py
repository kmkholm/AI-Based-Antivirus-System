"""
Dynamic Feature Extractor

Extracts dynamic features from file execution including:
- API call sequences
- File system operations
- Registry modifications
- Network activity
- Process behavior
- Memory operations
"""

import logging
import time
import json
from typing import Dict, List, Any, Optional
from pathlib import Path
from collections import defaultdict

from ..utils import get_logger


class DynamicFeatureExtractor:
    """Extracts dynamic features from file execution behavior"""
    
    def __init__(self):
        self.logger = get_logger(__name__)
        
        # Suspicious API calls mapped to behavior categories
        self.suspicious_apis = {
            'file_operations': [
                'CreateFile', 'WriteFile', 'ReadFile', 'DeleteFile', 'CopyFile',
                'MoveFile', 'FindFirstFile', 'FindNextFile', 'GetFileAttributes',
                'SetFileAttributes', 'CreateDirectory', 'RemoveDirectory'
            ],
            'registry_operations': [
                'RegOpenKey', 'RegSetValue', 'RegDeleteValue', 'RegCreateKey',
                'RegCloseKey', 'RegQueryValue', 'RegEnumKey', 'RegEnumValue'
            ],
            'process_operations': [
                'CreateProcess', 'OpenProcess', 'TerminateProcess', 'GetExitCodeProcess',
                'CreateToolhelp32Snapshot', 'Process32First', 'Process32Next',
                'Thread32First', 'Thread32Next', 'CreateRemoteThread'
            ],
            'memory_operations': [
                'VirtualAlloc', 'VirtualAllocEx', 'VirtualFree', 'VirtualProtect',
                'CreateFileMapping', 'MapViewOfFile', 'UnmapViewOfFile',
                'WriteProcessMemory', 'ReadProcessMemory'
            ],
            'network_operations': [
                'socket', 'connect', 'send', 'recv', 'WSAStartup', 'WSACleanup',
                'InternetOpen', 'InternetConnect', 'HttpOpenRequest', 'HttpSendRequest',
                'FtpOpenFile', 'FtpGetFile', 'FtpPutFile'
            ],
            'security_operations': [
                'LookupPrivilegeValue', 'AdjustTokenPrivileges', 'OpenProcessToken',
                'GetTokenInformation', 'SetTokenInformation', 'ImpersonateLoggedOnUser',
                'LogonUser', 'NetUserEnum', 'NetServerEnum'
            ],
            'anti_analysis': [
                'IsDebuggerPresent', 'CheckRemoteDebuggerPresent', 'OutputDebugString',
                'GetTickCount', 'QueryPerformanceCounter', 'GetSystemTime',
                'FindWindow', 'GetForegroundWindow', 'GetWindowText'
            ]
        }
        
        # Behavior patterns
        self.malware_patterns = {
            'keylogging': [
                ('GetAsyncKeyState', 'SetWindowsHookEx'),
                ('GetForegroundWindow', 'GetWindowText'),
                ('CallNextHookEx', 'UnhookWindowsHookEx')
            ],
            'persistence': [
                ('RegSetValue', 'HKLM\\Software\\Microsoft\\Windows\\CurrentVersion\\Run'),
                ('RegSetValue', 'HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Run'),
                ('CopyFile', 'Start Menu\\Programs\\Startup')
            ],
            'downloader': [
                ('URLDownloadToFile', 'WinExec'),
                ('InternetOpen', 'InternetConnect', 'FtpGetFile'),
                ('shell', 'curl', 'wget')
            ],
            'dll_injection': [
                ('OpenProcess', 'VirtualAllocEx', 'WriteProcessMemory', 'CreateRemoteThread'),
                ('CreateProcess', 'WriteProcessMemory'),
                ('GetProcAddress', 'LoadLibrary')
            ]
        }
        
        self.logger.info("Dynamic Feature Extractor initialized")
    
    def extract_basic_features(self, file_path: str) -> Dict[str, Any]:
        """Extract basic dynamic features"""
        features = {}
        
        try:
            # Simulate dynamic analysis (in real implementation, this would use sandboxing)
            behavior_data = self._simulate_execution(file_path)
            
            features.update({
                'execution_successful': behavior_data.get('success', False),
                'execution_time': behavior_data.get('execution_time', 0.0),
                'process_created': behavior_data.get('process_created', False),
                'network_activity': behavior_data.get('network_activity', False),
                'file_modifications': behavior_data.get('file_modifications', 0),
                'registry_modifications': behavior_data.get('registry_modifications', 0)
            })
            
        except Exception as e:
            self.logger.error(f"Basic dynamic feature extraction error: {str(e)}")
        
        return features
    
    def extract_full_features(self, file_path: str) -> Dict[str, Any]:
        """Extract complete dynamic feature set"""
        features = {}
        
        try:
            # Simulate full dynamic analysis
            behavior_data = self._simulate_execution(file_path, full_analysis=True)
            
            # API call analysis
            features.update(self._analyze_api_calls(behavior_data.get('api_calls', [])))
            
            # File system behavior
            features.update(self._analyze_file_behavior(behavior_data.get('file_operations', [])))
            
            # Registry behavior
            features.update(self._analyze_registry_behavior(behavior_data.get('registry_operations', [])))
            
            # Network behavior
            features.update(self._analyze_network_behavior(behavior_data.get('network_operations', [])))
            
            # Process behavior
            features.update(self._analyze_process_behavior(behavior_data.get('process_operations', [])))
            
            # Memory behavior
            features.update(self._analyze_memory_behavior(behavior_data.get('memory_operations', [])))
            
            # Security behavior
            features.update(self._analyze_security_behavior(behavior_data.get('security_operations', [])))
            
            # Anti-analysis detection
            features.update(self._detect_anti_analysis(behavior_data.get('anti_analysis', [])))
            
            # Malware pattern detection
            features.update(self._detect_malware_patterns(behavior_data))
            
            # Overall behavior score
            features.update(self._calculate_behavior_score(features))
            
        except Exception as e:
            self.logger.error(f"Full dynamic feature extraction error: {str(e)}")
        
        return features
    
    def _simulate_execution(self, file_path: str, full_analysis: bool = False) -> Dict[str, Any]:
        """
        Simulate dynamic analysis execution
        
        In a real implementation, this would:
        1. Execute the file in a sandboxed environment
        2. Monitor API calls, file operations, etc.
        3. Capture network traffic
        4. Analyze process behavior
        """
        try:
            # This is a simulation - replace with actual sandbox integration
            behavior_data = {
                'success': True,
                'execution_time': 2.5,
                'api_calls': [],
                'file_operations': [],
                'registry_operations': [],
                'network_operations': [],
                'process_operations': [],
                'memory_operations': [],
                'security_operations': [],
                'anti_analysis': [],
                'suspicious_behaviors': []
            }
            
            # Simulate based on file type
            path = Path(file_path)
            file_type = path.suffix.lower()
            
            if file_type in ['.exe', '.dll']:
                behavior_data.update(self._simulate_executable_behavior(file_path))
            elif file_type in ['.js', '.vbs', '.ps1']:
                behavior_data.update(self._simulate_script_behavior(file_path))
            elif file_type in ['.doc', '.pdf']:
                behavior_data.update(self._simulate_document_behavior(file_path))
            
            if full_analysis:
                # Add more detailed simulation for full analysis
                behavior_data.update(self._simulate_detailed_behavior(file_path))
            
            return behavior_data
            
        except Exception as e:
            self.logger.error(f"Execution simulation error: {str(e)}")
            return {'success': False, 'execution_time': 0.0}
    
    def _simulate_executable_behavior(self, file_path: str) -> Dict[str, Any]:
        """Simulate behavior of executable files"""
        return {
            'api_calls': [
                'CreateFile', 'ReadFile', 'GetFileSize', 'CreateProcess',
                'LoadLibrary', 'GetProcAddress', 'VirtualAlloc', 'WriteFile'
            ],
            'file_operations': [
                {'operation': 'read', 'path': 'C:\\Windows\\System32\\kernel32.dll', 'success': True},
                {'operation': 'create', 'path': 'temp_file.tmp', 'success': True},
                {'operation': 'write', 'path': 'config.ini', 'success': True}
            ],
            'registry_operations': [
                {'operation': 'query', 'key': 'HKLM\\Software\\Microsoft\\Windows\\CurrentVersion', 'success': True},
                {'operation': 'set', 'key': 'HKCU\\Software\\Test', 'value': 'test_data', 'success': True}
            ],
            'process_operations': [
                {'operation': 'create', 'process': 'notepad.exe', 'success': True}
            ]
        }
    
    def _simulate_script_behavior(self, file_path: str) -> Dict[str, Any]:
        """Simulate behavior of script files"""
        return {
            'api_calls': [
                'WScript.Shell', 'CreateObject', 'GetObject', 'RegRead', 'RegWrite',
                'FileSystemObject', 'Network', 'WScript.Network'
            ],
            'file_operations': [
                {'operation': 'read', 'path': 'script_file.js', 'success': True},
                {'operation': 'create', 'path': 'output.txt', 'success': True}
            ],
            'network_operations': [
                {'operation': 'http_get', 'url': 'http://example.com', 'success': True}
            ]
        }
    
    def _simulate_document_behavior(self, file_path: str) -> Dict[str, Any]:
        """Simulate behavior of document files"""
        return {
            'api_calls': [
                'CoCreateInstance', 'Document.Open', 'Application.Visible'
            ],
            'file_operations': [
                {'operation': 'read', 'path': file_path, 'success': True}
            ],
            'process_operations': [
                {'operation': 'create', 'process': 'winword.exe', 'success': True}
            ]
        }
    
    def _simulate_detailed_behavior(self, file_path: str) -> Dict[str, Any]:
        """Simulate detailed behavior for full analysis"""
        return {
            'memory_operations': [
                {'operation': 'VirtualAlloc', 'size': 4096, 'success': True},
                {'operation': 'WriteProcessMemory', 'size': 1024, 'success': True}
            ],
            'security_operations': [
                {'operation': 'OpenProcessToken', 'success': False}
            ],
            'anti_analysis': [
                {'operation': 'IsDebuggerPresent', 'result': False},
                {'operation': 'GetTickCount', 'result': 12345}
            ],
            'network_operations': [
                {'operation': 'socket', 'protocol': 'TCP', 'success': True},
                {'operation': 'connect', 'ip': '192.168.1.1', 'port': 80, 'success': True}
            ]
        }
    
    def _analyze_api_calls(self, api_calls: List[str]) -> Dict[str, Any]:
        """Analyze API call patterns"""
        features = {
            'total_api_calls': len(api_calls),
            'unique_api_calls': len(set(api_calls)),
            'api_categories': defaultdict(int)
        }
        
        # Categorize API calls
        for api_call in api_calls:
            categorized = False
            for category, apis in self.suspicious_apis.items():
                if any(api in api_call for api in apis):
                    features['api_categories'][category] += 1
                    categorized = True
                    break
            
            if not categorized:
                features['api_categories']['other'] += 1
        
        # Convert to regular dict for JSON serialization
        features['api_categories'] = dict(features['api_categories'])
        
        # Calculate suspicion scores
        suspicion_score = 0
        for category, count in features['api_categories'].items():
            if category in ['file_operations', 'registry_operations', 'process_operations', 'memory_operations']:
                suspicion_score += count * 2
            elif category in ['security_operations', 'anti_analysis']:
                suspicion_score += count * 3
            else:
                suspicion_score += count
        
        features['api_suspicion_score'] = suspicion_score
        features['is_api_suspicious'] = suspicion_score > 10
        
        return features
    
    def _analyze_file_behavior(self, file_operations: List[Dict]) -> Dict[str, Any]:
        """Analyze file system behavior"""
        features = {
            'total_file_operations': len(file_operations),
            'successful_operations': 0,
            'failed_operations': 0,
            'operation_types': defaultdict(int),
            'accessed_paths': [],
            'suspicious_paths': []
        }
        
        for operation in file_operations:
            if operation.get('success', False):
                features['successful_operations'] += 1
            else:
                features['failed_operations'] += 1
            
            features['operation_types'][operation.get('operation', 'unknown')] += 1
            
            path = operation.get('path', '')
            if path:
                features['accessed_paths'].append(path)
                
                # Check for suspicious paths
                suspicious_indicators = ['temp', 'startup', 'system32', 'appdata', 'program files']
                if any(indicator in path.lower() for indicator in suspicious_indicators):
                    features['suspicious_paths'].append(path)
        
        features['operation_types'] = dict(features['operation_types'])
        features['unique_paths_accessed'] = len(set(features['accessed_paths']))
        features['suspicious_path_count'] = len(features['suspicious_paths'])
        
        return features
    
    def _analyze_registry_behavior(self, registry_operations: List[Dict]) -> Dict[str, Any]:
        """Analyze registry modification behavior"""
        features = {
            'total_registry_operations': len(registry_operations),
            'registry_keys_accessed': [],
            'persistence_indicators': 0,
            'security_settings_modified': 0
        }
        
        for operation in registry_operations:
            key = operation.get('key', '')
            if key:
                features['registry_keys_accessed'].append(key)
                
                # Check for persistence indicators
                if 'run' in key.lower() or 'startup' in key.lower():
                    features['persistence_indicators'] += 1
                
                # Check for security settings
                if any(sec in key.lower() for sec in ['security', 'policy', 'audit']):
                    features['security_settings_modified'] += 1
        
        features['unique_registry_keys'] = len(set(features['registry_keys_accessed']))
        features['is_registry_suspicious'] = features['persistence_indicators'] > 0
        
        return features
    
    def _analyze_network_behavior(self, network_operations: List[Dict]) -> Dict[str, Any]:
        """Analyze network behavior"""
        features = {
            'total_network_operations': len(network_operations),
            'successful_connections': 0,
            'failed_connections': 0,
            'protocols_used': set(),
            'destinations': [],
            'suspicious_domains': []
        }
        
        for operation in network_operations:
            if operation.get('success', False):
                features['successful_connections'] += 1
            else:
                features['failed_connections'] += 1
            
            protocol = operation.get('protocol', '')
            if protocol:
                features['protocols_used'].add(protocol)
            
            # Extract destination
            ip = operation.get('ip', '')
            url = operation.get('url', '')
            domain = operation.get('domain', '')
            
            destination = ip or url or domain
            if destination:
                features['destinations'].append(destination)
                
                # Check for suspicious domains
                if self._is_suspicious_domain(destination):
                    features['suspicious_domains'].append(destination)
        
        features['protocols_used'] = list(features['protocols_used'])
        features['unique_destinations'] = len(set(features['destinations']))
        features['suspicious_domain_count'] = len(features['suspicious_domains'])
        
        return features
    
    def _analyze_process_behavior(self, process_operations: List[Dict]) -> Dict[str, Any]:
        """Analyze process creation/manipulation behavior"""
        features = {
            'total_process_operations': len(process_operations),
            'processes_created': 0,
            'processes_injected': 0,
            'suspicious_processes': []
        }
        
        for operation in process_operations:
            op_type = operation.get('operation', '')
            
            if op_type == 'create':
                features['processes_created'] += 1
            elif op_type == 'inject':
                features['processes_injected'] += 1
            
            # Check for suspicious process names
            process_name = operation.get('process', '')
            suspicious_names = ['cmd.exe', 'powershell', 'wscript', 'cscript', 'regsvr32', 'rundll32']
            if any(name in process_name.lower() for name in suspicious_names):
                features['suspicious_processes'].append(process_name)
        
        return features
    
    def _analyze_memory_behavior(self, memory_operations: List[Dict]) -> Dict[str, Any]:
        """Analyze memory manipulation behavior"""
        features = {
            'total_memory_operations': len(memory_operations),
            'memory_allocated': 0,
            'memory_written': 0,
            'suspicious_allocations': 0
        }
        
        for operation in memory_operations:
            op_type = operation.get('operation', '')
            size = operation.get('size', 0)
            
            if 'alloc' in op_type.lower():
                features['memory_allocated'] += size
                
                # Check for large allocations (suspicious)
                if size > 1024 * 1024:  # 1MB
                    features['suspicious_allocations'] += 1
            
            elif 'write' in op_type.lower():
                features['memory_written'] += size
        
        return features
    
    def _analyze_security_behavior(self, security_operations: List[Dict]) -> Dict[str, Any]:
        """Analyze security-related behavior"""
        features = {
            'total_security_operations': len(security_operations),
            'privilege_escalation_attempts': 0,
            'token_manipulation': 0,
            'authentication_attempts': 0
        }
        
        for operation in security_operations:
            op_type = operation.get('operation', '')
            
            if 'privilege' in op_type.lower() and not operation.get('success', True):
                features['privilege_escalation_attempts'] += 1
            elif 'token' in op_type.lower():
                features['token_manipulation'] += 1
            elif 'logon' in op_type.lower():
                features['authentication_attempts'] += 1
        
        return features
    
    def _detect_anti_analysis(self, anti_analysis_ops: List[Dict]) -> Dict[str, Any]:
        """Detect anti-analysis techniques"""
        features = {
            'anti_analysis_detected': False,
            'debugger_check': False,
            'timing_checks': False,
            'environment_checks': False,
            'anti_analysis_score': 0
        }
        
        for operation in anti_analysis_ops:
            op_type = operation.get('operation', '')
            
            if 'debugger' in op_type.lower():
                features['debugger_check'] = True
                features['anti_analysis_score'] += 2
            
            elif any(timing in op_type.lower() for timing in ['tick', 'performance', 'time']):
                features['timing_checks'] = True
                features['anti_analysis_score'] += 1
            
            elif any(env in op_type.lower() for env in ['window', 'process', 'module']):
                features['environment_checks'] = True
                features['anti_analysis_score'] += 1
        
        features['anti_analysis_detected'] = features['anti_analysis_score'] > 2
        
        return features
    
    def _detect_malware_patterns(self, behavior_data: Dict) -> Dict[str, Any]:
        """Detect known malware behavior patterns"""
        features = {
            'detected_patterns': [],
            'pattern_scores': {},
            'overall_pattern_score': 0
        }
        
        api_calls = behavior_data.get('api_calls', [])
        file_ops = behavior_data.get('file_operations', [])
        registry_ops = behavior_data.get('registry_operations', [])
        network_ops = behavior_data.get('network_operations', [])
        
        # Check for keylogging pattern
        keylogging_apis = ['GetAsyncKeyState', 'SetWindowsHookEx', 'GetForegroundWindow']
        if all(api in api_calls for api in keylogging_apis):
            features['detected_patterns'].append('keylogging')
            features['pattern_scores']['keylogging'] = 3
        
        # Check for persistence pattern
        persistence_keys = ['HKLM\\Software\\Microsoft\\Windows\\CurrentVersion\\Run',
                          'HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Run']
        persistence_apis = ['RegSetValue', 'CopyFile']
        
        has_persistence_key = any(key in str(registry_ops) for key in persistence_keys)
        has_persistence_api = any(api in api_calls for api in persistence_apis)
        
        if has_persistence_key and has_persistence_api:
            features['detected_patterns'].append('persistence')
            features['pattern_scores']['persistence'] = 3
        
        # Check for downloader pattern
        downloader_apis = ['URLDownloadToFile', 'WinExec', 'InternetOpen']
        has_downloader_apis = any(api in api_calls for api in downloader_apis)
        
        if has_downloader_apis:
            features['detected_patterns'].append('downloader')
            features['pattern_scores']['downloader'] = 2
        
        # Check for DLL injection pattern
        injection_apis = ['OpenProcess', 'VirtualAllocEx', 'WriteProcessMemory', 'CreateRemoteThread']
        if all(api in api_calls for api in injection_apis):
            features['detected_patterns'].append('dll_injection')
            features['pattern_scores']['dll_injection'] = 4
        
        # Calculate overall score
        features['overall_pattern_score'] = sum(features['pattern_scores'].values())
        
        return features
    
    def _calculate_behavior_score(self, features: Dict[str, Any]) -> Dict[str, Any]:
        """Calculate overall behavior suspicion score"""
        score = 0
        max_score = 100
        
        # API call score
        api_score = min(features.get('api_suspicion_score', 0), 20)
        score += api_score
        
        # File operation score
        file_score = min(features.get('suspicious_path_count', 0) * 5, 20)
        score += file_score
        
        # Registry score
        registry_score = min(features.get('persistence_indicators', 0) * 10, 20)
        score += registry_score
        
        # Network score
        network_score = min(features.get('suspicious_domain_count', 0) * 5, 15)
        score += network_score
        
        # Anti-analysis score
        anti_analysis_score = features.get('anti_analysis_score', 0) * 3
        score += min(anti_analysis_score, 15)
        
        # Pattern score
        pattern_score = min(features.get('overall_pattern_score', 0) * 2, 10)
        score += pattern_score
        
        # Normalize to 0-1
        normalized_score = min(score / max_score, 1.0)
        
        return {
            'behavior_suspicion_score': score,
            'behavior_confidence': normalized_score,
            'is_behavior_malicious': normalized_score > 0.7
        }
    
    def _is_suspicious_domain(self, destination: str) -> bool:
        """Check if a domain/IP is suspicious"""
        try:
            # Simple heuristics for suspicious domains
            suspicious_indicators = [
                '.tk', '.ml', '.ga', '.cf',  # Free TLDs often used by malware
                'bit.ly', 'tinyurl', 't.co',  # URL shorteners
                'tor2web', 'onion',  # Tor-related
                'Dynamic DNS', 'no-ip'  # Dynamic DNS services
            ]
            
            return any(indicator in destination.lower() for indicator in suspicious_indicators)
            
        except Exception:
            return False
    
    def get_basic_feature_names(self) -> List[str]:
        """Get list of basic dynamic feature names"""
        return [
            'execution_successful', 'execution_time', 'process_created',
            'network_activity', 'file_modifications', 'registry_modifications'
        ]
    
    def get_full_feature_names(self) -> List[str]:
        """Get list of full dynamic feature names"""
        return (self.get_basic_feature_names() + [
            'total_api_calls', 'unique_api_calls', 'api_categories', 'api_suspicion_score',
            'total_file_operations', 'successful_operations', 'operation_types',
            'unique_paths_accessed', 'suspicious_path_count',
            'total_registry_operations', 'unique_registry_keys', 'persistence_indicators',
            'total_network_operations', 'unique_destinations', 'suspicious_domain_count',
            'total_process_operations', 'processes_created', 'suspicious_processes',
            'total_memory_operations', 'memory_allocated', 'suspicious_allocations',
            'total_security_operations', 'privilege_escalation_attempts', 'token_manipulation',
            'anti_analysis_detected', 'debugger_check', 'timing_checks', 'anti_analysis_score',
            'detected_patterns', 'overall_pattern_score', 'behavior_suspicion_score',
            'behavior_confidence', 'is_behavior_malicious'
        ])