"""
Feature Processor

Handles feature preprocessing, normalization, selection, and transformation
for machine learning models in the antivirus engine.
"""

import logging
import numpy as np
import pandas as pd
from typing import Dict, List, Any, Optional, Tuple, Union
from sklearn.preprocessing import StandardScaler, MinMaxScaler, RobustScaler, LabelEncoder
from sklearn.feature_selection import SelectKBest, f_classif, mutual_info_classif, RFE
from sklearn.decomposition import PCA
from sklearn.impute import SimpleImputer

from ..utils import get_logger


class FeatureProcessor:
    """
    Processes and transforms features for machine learning models
    
    Handles:
    - Feature normalization and scaling
    - Missing value imputation
    - Feature selection
    - Dimensionality reduction
    - Categorical encoding
    """
    
    def __init__(self, config: Optional[Dict] = None):
        self.logger = get_logger(__name__)
        self.config = config or {}
        
        # Preprocessing components
        self.scalers = {
            'standard': StandardScaler(),
            'minmax': MinMaxScaler(),
            'robust': RobustScaler()
        }
        
        self.imputer = SimpleImputer(strategy='mean')
        self.label_encoder = LabelEncoder()
        self.pca = None
        
        # Feature selection components
        self.feature_selector = None
        self.selected_features = []
        
        # Processing statistics
        self.feature_stats = {}
        self.processing_history = []
        
        self.logger.info("Feature Processor initialized")
    
    def process_features(self, features: Dict[str, Any], analysis_depth: str = 'full') -> Dict[str, Any]:
        """
        Process features for ML model consumption
        
        Args:
            features: Raw feature dictionary
            analysis_depth: Analysis depth level
            
        Returns:
            Processed feature dictionary
        """
        try:
            self.logger.debug(f"Processing features for depth: {analysis_depth}")
            
            processed = features.copy()
            
            # Step 1: Feature cleaning and validation
            processed = self._clean_features(processed)
            
            # Step 2: Handle missing values
            processed = self._impute_missing_values(processed)
            
            # Step 3: Encode categorical features
            processed = self._encode_categorical_features(processed)
            
            # Step 4: Normalize numerical features
            processed = self._normalize_features(processed, analysis_depth)
            
            # Step 5: Feature selection (if configured)
            if analysis_depth in ['standard', 'full']:
                processed = self._select_features(processed)
            
            # Step 6: Create feature vectors
            feature_vector = self._create_feature_vector(processed)
            
            # Step 7: Add processing metadata
            processed['feature_vector'] = feature_vector
            processed['processing_info'] = {
                'analysis_depth': analysis_depth,
                'feature_count': len(feature_vector),
                'timestamp': pd.Timestamp.now().isoformat(),
                'processing_steps': self.processing_history
            }
            
            # Clear processing history for next batch
            self.processing_history.clear()
            
            self.logger.debug(f"Feature processing completed: {len(feature_vector)} features")
            return processed
            
        except Exception as e:
            self.logger.error(f"Feature processing error: {str(e)}")
            return features
    
    def _clean_features(self, features: Dict[str, Any]) -> Dict[str, Any]:
        """Clean and validate features"""
        cleaned = {}
        self.processing_history.append('cleaning')
        
        for key, value in features.items():
            try:
                # Skip None values
                if value is None:
                    continue
                
                # Convert to appropriate type
                cleaned[key] = self._convert_feature_type(key, value)
                
                # Validate numerical features
                if isinstance(cleaned[key], (int, float)):
                    if np.isnan(cleaned[key]) or np.isinf(cleaned[key]):
                        self.logger.warning(f"Invalid numerical value for {key}: {value}")
                        continue
                    
                    # Clip extreme values
                    if abs(cleaned[key]) > 1e10:
                        self.logger.warning(f"Extreme value for {key}: {value}")
                        cleaned[key] = np.sign(cleaned[key]) * 1e10
                
            except Exception as e:
                self.logger.warning(f"Error cleaning feature {key}: {str(e)}")
                continue
        
        return cleaned
    
    def _convert_feature_type(self, key: str, value: Any) -> Any:
        """Convert feature to appropriate type"""
        # Handle specific feature types
        if 'count' in key.lower() or 'number' in key.lower():
            try:
                return int(value) if value is not None else 0
            except (ValueError, TypeError):
                return 0
        
        elif any(word in key.lower() for word in ['size', 'time', 'entropy', 'score', 'confidence']):
            try:
                return float(value) if value is not None else 0.0
            except (ValueError, TypeError):
                return 0.0
        
        elif 'is_' in key.lower() or 'has_' in key.lower() or 'contains_' in key.lower():
            return bool(value) if value is not None else False
        
        elif isinstance(value, str):
            return value.strip() if value else ''
        
        else:
            return value
    
    def _impute_missing_values(self, features: Dict[str, Any]) -> Dict[str, Any]:
        """Handle missing or invalid values"""
        self.processing_history.append('imputation')
        
        # Separate numerical and categorical features
        numerical_features = {}
        categorical_features = {}
        
        for key, value in features.items():
            if isinstance(value, (int, float)) and not np.isnan(value):
                numerical_features[key] = value
            else:
                categorical_features[key] = value
        
        # Impute numerical features
        if numerical_features:
            try:
                values_array = np.array(list(numerical_features.values())).reshape(-1, 1)
                imputed_array = self.imputer.fit_transform(values_array)
                
                for i, key in enumerate(numerical_features.keys()):
                    numerical_features[key] = float(imputed_array[i][0])
            except Exception as e:
                self.logger.warning(f"Numerical imputation error: {str(e)}")
        
        # Combine features
        return {**numerical_features, **categorical_features}
    
    def _encode_categorical_features(self, features: Dict[str, Any]) -> Dict[str, Any]:
        """Encode categorical features"""
        self.processing_history.append('encoding')
        encoded = {}
        
        categorical_features = [
            'file_type', 'machine_type', 'subsystem', 'size_category',
            'predicted_threat_level', 'most_likely_family', 'magic_number'
        ]
        
        for key, value in features.items():
            if key in categorical_features or not isinstance(value, (int, float)):
                # One-hot encode or label encode
                if isinstance(value, bool):
                    encoded[key] = int(value)
                elif isinstance(value, str):
                    # Simple hash encoding for strings
                    encoded[key] = hash(value) % 1000
                else:
                    encoded[key] = value
            else:
                encoded[key] = value
        
        return encoded
    
    def _normalize_features(self, features: Dict[str, Any], analysis_depth: str) -> Dict[str, Any]:
        """Normalize numerical features"""
        self.processing_history.append('normalization')
        
        if analysis_depth == 'quick':
            return features  # Skip normalization for quick analysis
        
        # Extract numerical features
        numerical_features = {}
        for key, value in features.items():
            if isinstance(value, (int, float)) and key != 'feature_vector':
                numerical_features[key] = value
        
        if not numerical_features:
            return features
        
        try:
            # Choose scaler based on config
            scaler_name = self.config.get('scaler', 'standard')
            scaler = self.scalers.get(scaler_name, self.scalers['standard'])
            
            # Fit and transform
            values_array = np.array(list(numerical_features.values())).reshape(-1, 1)
            normalized_array = scaler.fit_transform(values_array)
            
            # Create normalized features
            normalized = {}
            for i, key in enumerate(numerical_features.keys()):
                normalized[f'{key}_normalized'] = float(normalized_array[i][0])
            
            # Keep original features for reference
            normalized.update(features)
            
            return normalized
            
        except Exception as e:
            self.logger.warning(f"Feature normalization error: {str(e)}")
            return features
    
    def _select_features(self, features: Dict[str, Any]) -> Dict[str, Any]:
        """Select most relevant features"""
        self.processing_history.append('selection')
        
        # For now, use simple feature selection based on variance
        # In practice, this would be based on trained models
        
        if 'feature_vector' in features:
            feature_vector = features['feature_vector']
            if isinstance(feature_vector, (list, np.ndarray)) and len(feature_vector) > 50:
                # Select top features by variance
                variance_scores = self._calculate_feature_variance(features)
                top_features = sorted(variance_scores.items(), key=lambda x: x[1], reverse=True)[:30]
                
                selected_features = dict(top_features)
                features['selected_features'] = selected_features
                self.selected_features = list(selected_features.keys())
        
        return features
    
    def _calculate_feature_variance(self, features: Dict[str, Any]) -> Dict[str, float]:
        """Calculate variance for feature selection"""
        variance_scores = {}
        
        for key, value in features.items():
            if isinstance(value, (int, float)) and key != 'feature_vector':
                # Simple variance approximation based on feature type
                if 'count' in key.lower() or 'number' in key.lower():
                    variance_scores[key] = min(float(value), 1000.0)  # Cap at 1000
                elif 'score' in key.lower() or 'confidence' in key.lower():
                    variance_scores[key] = abs(float(value))
                else:
                    variance_scores[key] = min(abs(float(value)), 100.0)  # Cap at 100
        
        return variance_scores
    
    def _create_feature_vector(self, features: Dict[str, Any]) -> List[float]:
        """Create numerical feature vector for ML models"""
        feature_vector = []
        
        # Collect all numerical features
        for key, value in features.items():
            if key != 'feature_vector' and isinstance(value, (int, float)):
                feature_vector.append(float(value))
        
        return feature_vector
    
    def transform_features(self, features: Dict[str, Any]) -> np.ndarray:
        """Transform features using fitted processors"""
        try:
            if 'feature_vector' in features:
                feature_vector = features['feature_vector']
                if isinstance(feature_vector, list):
                    return np.array(feature_vector)
            return np.array([])
        except Exception as e:
            self.logger.error(f"Feature transformation error: {str(e)}")
            return np.array([])
    
    def fit_scaler(self, features_list: List[Dict[str, Any]], scaler_type: str = 'standard'):
        """Fit scaler on multiple feature sets"""
        try:
            scaler = self.scalers.get(scaler_type, self.scalers['standard'])
            all_values = []
            
            for features in features_list:
                numerical_features = []
                for key, value in features.items():
                    if isinstance(value, (int, float)) and not np.isnan(value):
                        numerical_features.append(float(value))
                
                if numerical_features:
                    all_values.extend(numerical_features)
            
            if all_values:
                scaler.fit(np.array(all_values).reshape(-1, 1))
                self.logger.info(f"Scaler fitted with {len(all_values)} values")
            
        except Exception as e:
            self.logger.error(f"Scaler fitting error: {str(e)}")
    
    def apply_pca(self, features: np.ndarray, n_components: int = 0.95):
        """Apply PCA for dimensionality reduction"""
        try:
            if features.size == 0:
                return features
            
            if self.pca is None:
                self.pca = PCA(n_components=n_components)
                self.pca.fit(features)
            
            return self.pca.transform(features)
            
        except Exception as e:
            self.logger.error(f"PCA transformation error: {str(e)}")
            return features
    
    def get_feature_importance(self, features: np.ndarray, labels: np.ndarray) -> Dict[str, float]:
        """Calculate feature importance scores"""
        try:
            if features.size == 0 or labels.size == 0:
                return {}
            
            # Use mutual information for feature importance
            importance_scores = mutual_info_classif(features.reshape(1, -1), labels, random_state=42)
            return {f'feature_{i}': score for i, score in enumerate(importance_scores[0])}
            
        except Exception as e:
            self.logger.error(f"Feature importance calculation error: {str(e)}")
            return {}
    
    def create_feature_matrix(self, features_list: List[Dict[str, Any]]) -> Tuple[np.ndarray, List[str]]:
        """Create feature matrix from list of feature dictionaries"""
        try:
            if not features_list:
                return np.array([]), []
            
            # Get all feature names
            all_feature_names = set()
            for features in features_list:
                for key in features.keys():
                    if key != 'feature_vector' and isinstance(features[key], (int, float)):
                        all_feature_names.add(key)
            
            feature_names = sorted(list(all_feature_names))
            
            # Create matrix
            feature_matrix = []
            for features in features_list:
                row = []
                for feature_name in feature_names:
                    value = features.get(feature_name, 0.0)
                    if isinstance(value, (int, float)) and not np.isnan(value):
                        row.append(float(value))
                    else:
                        row.append(0.0)
                feature_matrix.append(row)
            
            return np.array(feature_matrix), feature_names
            
        except Exception as e:
            self.logger.error(f"Feature matrix creation error: {str(e)}")
            return np.array([]), []
    
    def export_processing_config(self, output_path: str):
        """Export feature processing configuration"""
        try:
            config_data = {
                'feature_stats': self.feature_stats,
                'selected_features': self.selected_features,
                'scaler_type': self.config.get('scaler', 'standard'),
                'processing_steps': self.processing_history,
                'export_timestamp': pd.Timestamp.now().isoformat()
            }
            
            import json
            with open(output_path, 'w') as f:
                json.dump(config_data, f, indent=2, default=str)
            
            self.logger.info(f"Processing config exported to {output_path}")
            
        except Exception as e:
            self.logger.error(f"Config export error: {str(e)}")
    
    def load_processing_config(self, config_path: str):
        """Load feature processing configuration"""
        try:
            import json
            with open(config_path, 'r') as f:
                config_data = json.load(f)
            
            self.feature_stats = config_data.get('feature_stats', {})
            self.selected_features = config_data.get('selected_features', [])
            self.config['scaler'] = config_data.get('scaler_type', 'standard')
            
            self.logger.info(f"Processing config loaded from {config_path}")
            
        except Exception as e:
            self.logger.error(f"Config loading error: {str(e)}")
    
    def get_feature_statistics(self, features: Dict[str, Any]) -> Dict[str, Any]:
        """Get statistics about processed features"""
        stats = {
            'total_features': 0,
            'numerical_features': 0,
            'categorical_features': 0,
            'missing_values': 0,
            'feature_types': {},
            'value_ranges': {}
        }
        
        for key, value in features.items():
            if key == 'feature_vector':
                continue
            
            stats['total_features'] += 1
            
            if isinstance(value, (int, float)):
                stats['numerical_features'] += 1
                stats['value_ranges'][key] = {'min': value, 'max': value}
            else:
                stats['categorical_features'] += 1
            
            if value is None or (isinstance(value, (int, float)) and np.isnan(value)):
                stats['missing_values'] += 1
            
            # Track feature types
            feature_type = type(value).__name__
            stats['feature_types'][feature_type] = stats['feature_types'].get(feature_type, 0) + 1
        
        return stats
    
    def validate_features(self, features: Dict[str, Any], expected_types: Dict[str, type]) -> Tuple[bool, List[str]]:
        """Validate features have expected types and ranges"""
        errors = []
        
        for feature_name, expected_type in expected_types.items():
            if feature_name not in features:
                errors.append(f"Missing feature: {feature_name}")
                continue
            
            actual_value = features[feature_name]
            if actual_value is None:
                errors.append(f"Null value for feature: {feature_name}")
                continue
            
            if not isinstance(actual_value, expected_type):
                errors.append(f"Type mismatch for {feature_name}: expected {expected_type}, got {type(actual_value)}")
                continue
            
            # Additional validation for numerical features
            if expected_type in (int, float) and isinstance(actual_value, (int, float)):
                if np.isnan(actual_value) or np.isinf(actual_value):
                    errors.append(f"Invalid numerical value for {feature_name}: {actual_value}")
        
        is_valid = len(errors) == 0
        return is_valid, errors