"""
Feature Extractor

Main feature extraction interface that coordinates static, dynamic, and hybrid
feature extraction based on file type and analysis depth.
"""

import logging
from typing import Dict, List, Optional, Any
from pathlib import Path
import hashlib
import json
from abc import ABC, abstractmethod

from .static_extractor import StaticFeatureExtractor
from .dynamic_extractor import DynamicFeatureExtractor
from .hybrid_extractor import HybridFeatureExtractor
from .feature_processor import FeatureProcessor
from ..utils import get_logger, FileTypeDetector


class FeatureExtractor:
    """
    Main feature extraction class that orchestrates different extraction methods
    
    Supports multiple analysis depths:
    - quick: Basic static features only
    - standard: Static + basic dynamic features
    - full: Complete hybrid feature set
    """
    
    def __init__(self, config: Optional[Dict] = None):
        """Initialize feature extractor with all extractors"""
        self.logger = get_logger(__name__)
        self.config = config or {}
        
        # Initialize extractors
        self.static_extractor = StaticFeatureExtractor()
        self.dynamic_extractor = DynamicFeatureExtractor()
        self.hybrid_extractor = HybridFeatureExtractor()
        self.feature_processor = FeatureProcessor()
        self.file_type_detector = FileTypeDetector()
        
        self.logger.info("Feature Extractor initialized")
    
    def extract_features(self, file_path: str, analysis_depth: str = 'full') -> Dict[str, Any]:
        """
        Extract features from a file based on analysis depth
        
        Args:
            file_path: Path to the file
            analysis_depth: 'quick', 'standard', or 'full'
            
        Returns:
            Dictionary of extracted features
        """
        try:
            self.logger.debug(f"Extracting features from {file_path} (depth: {analysis_depth})")
            
            # Basic file information
            file_info = self._get_file_info(file_path)
            if not file_info:
                return {}
            
            # Detect file type
            file_type = self.file_type_detector.detect_type(file_path)
            features = {'file_info': file_info, 'file_type': file_type}
            
            # Extract based on depth
            if analysis_depth == 'quick':
                features.update(self._extract_quick_features(file_path, file_type))
            elif analysis_depth == 'standard':
                features.update(self._extract_standard_features(file_path, file_type))
            else:  # full
                features.update(self._extract_full_features(file_path, file_type))
            
            # Process and normalize features
            processed_features = self.feature_processor.process_features(features, analysis_depth)
            
            self.logger.debug(f"Extracted {len(processed_features)} features from {file_path}")
            return processed_features
            
        except Exception as e:
            self.logger.error(f"Feature extraction error for {file_path}: {str(e)}")
            return {}
    
    def _get_file_info(self, file_path: str) -> Optional[Dict]:
        """Get basic file information"""
        try:
            path = Path(file_path)
            if not path.exists():
                return None
            
            stat = path.stat()
            
            # Calculate file hash
            file_hash = self._calculate_file_hash(file_path)
            
            return {
                'path': str(path.absolute()),
                'name': path.name,
                'size': stat.st_size,
                'extension': path.suffix.lower(),
                'created_time': stat.st_ctime,
                'modified_time': stat.st_mtime,
                'hash_sha256': file_hash,
                'is_executable': self._is_executable(path),
            }
            
        except Exception as e:
            self.logger.error(f"Error getting file info: {str(e)}")
            return None
    
    def _calculate_file_hash(self, file_path: str) -> str:
        """Calculate SHA256 hash of file"""
        try:
            sha256_hash = hashlib.sha256()
            with open(file_path, "rb") as f:
                for byte_block in iter(lambda: f.read(4096), b""):
                    sha256_hash.update(byte_block)
            return sha256_hash.hexdigest()
        except Exception:
            return ""
    
    def _is_executable(self, path: Path) -> bool:
        """Check if file is executable"""
        try:
            # Check extension
            executable_extensions = {'.exe', '.dll', '.sys', '.scr', '.bat', '.cmd', '.com'}
            if path.suffix.lower() in executable_extensions:
                return True
            
            # Check file permissions (Unix-like systems)
            if hasattr(path, 'stat'):
                mode = path.stat().st_mode
                return bool(mode & 0o111)
            
            return False
            
        except Exception:
            return False
    
    def _extract_quick_features(self, file_path: str, file_type: str) -> Dict[str, Any]:
        """Extract basic static features for quick analysis"""
        features = {}
        
        try:
            # Static features for all file types
            static_features = self.static_extractor.extract_basic_features(file_path, file_type)
            features.update(static_features)
            
            # File entropy (quick malware indicator)
            entropy = self._calculate_file_entropy(file_path)
            if entropy is not None:
                features['entropy'] = entropy
            
            self.logger.debug(f"Quick features extracted: {len(static_features)} static")
            
        except Exception as e:
            self.logger.error(f"Quick feature extraction error: {str(e)}")
        
        return features
    
    def _extract_standard_features(self, file_path: str, file_type: str) -> Dict[str, Any]:
        """Extract standard feature set"""
        features = {}
        
        try:
            # Static features
            static_features = self.static_extractor.extract_standard_features(file_path, file_type)
            features.update(static_features)
            
            # Basic dynamic features if file is executable
            if self._is_executable(Path(file_path)):
                dynamic_features = self.dynamic_extractor.extract_basic_features(file_path)
                features.update(dynamic_features)
            
            self.logger.debug(f"Standard features extracted: {len(static_features)} static, "
                            f"{len(features.get('dynamic_features', {}))} dynamic")
            
        except Exception as e:
            self.logger.error(f"Standard feature extraction error: {str(e)}")
        
        return features
    
    def _extract_full_features(self, file_path: str, file_type: str) -> Dict[str, Any]:
        """Extract complete feature set for full analysis"""
        features = {}
        
        try:
            # Static features
            static_features = self.static_extractor.extract_full_features(file_path, file_type)
            features.update(static_features)
            
            # Dynamic features
            if self._is_executable(Path(file_path)):
                dynamic_features = self.dynamic_extractor.extract_full_features(file_path)
                features.update(dynamic_features)
            
            # Hybrid features
            hybrid_features = self.hybrid_extractor.extract_hybrid_features(
                file_path, static_features, features.get('dynamic_features', {})
            )
            features.update(hybrid_features)
            
            self.logger.debug(f"Full features extracted: {len(static_features)} static, "
                            f"{len(features.get('dynamic_features', {}))} dynamic, "
                            f"{len(hybrid_features)} hybrid")
            
        except Exception as e:
            self.logger.error(f"Full feature extraction error: {str(e)}")
        
        return features
    
    def _calculate_file_entropy(self, file_path: str) -> Optional[float]:
        """Calculate Shannon entropy of file content"""
        try:
            with open(file_path, 'rb') as f:
                data = f.read()
            
            if not data:
                return 0.0
            
            # Calculate byte frequency
            byte_counts = [0] * 256
            for byte in data:
                byte_counts[byte] += 1
            
            # Calculate entropy
            import math
            entropy = 0.0
            data_len = len(data)
            
            for count in byte_counts:
                if count > 0:
                    probability = count / data_len
                    entropy -= probability * math.log2(probability)
            
            return entropy
            
        except Exception as e:
            self.logger.error(f"Entropy calculation error: {str(e)}")
            return None
    
    def get_feature_names(self, analysis_depth: str) -> List[str]:
        """Get list of feature names for a given analysis depth"""
        if analysis_depth == 'quick':
            return self.static_extractor.get_basic_feature_names()
        elif analysis_depth == 'standard':
            return (self.static_extractor.get_standard_feature_names() + 
                   self.dynamic_extractor.get_basic_feature_names())
        else:  # full
            return (self.static_extractor.get_full_feature_names() + 
                   self.dynamic_extractor.get_full_feature_names() + 
                   self.hybrid_extractor.get_hybrid_feature_names())
    
    def validate_features(self, features: Dict[str, Any], expected_types: Dict[str, type]) -> bool:
        """Validate extracted features have expected types and values"""
        try:
            for feature_name, expected_type in expected_types.items():
                if feature_name not in features:
                    self.logger.warning(f"Missing feature: {feature_name}")
                    return False
                
                if not isinstance(features[feature_name], expected_type):
                    self.logger.warning(f"Invalid type for {feature_name}: "
                                      f"expected {expected_type}, got {type(features[feature_name])}")
                    return False
            
            return True
            
        except Exception as e:
            self.logger.error(f"Feature validation error: {str(e)}")
            return False
    
    def export_features(self, features: Dict[str, Any], output_path: str):
        """Export features to JSON file"""
        try:
            # Add metadata
            export_data = {
                'metadata': {
                    'extraction_timestamp': __import__('time').time(),
                    'feature_count': len(features),
                    'python_version': __import__('sys').version
                },
                'features': features
            }
            
            with open(output_path, 'w') as f:
                json.dump(export_data, f, indent=2, default=str)
            
            self.logger.info(f"Features exported to {output_path}")
            
        except Exception as e:
            self.logger.error(f"Feature export error: {str(e)}")
    
    def batch_extract_features(self, file_paths: List[str], analysis_depth: str = 'full') -> Dict[str, Dict[str, Any]]:
        """Extract features from multiple files"""
        results = {}
        
        self.logger.info(f"Starting batch extraction for {len(file_paths)} files")
        
        for file_path in file_paths:
            try:
                features = self.extract_features(file_path, analysis_depth)
                results[file_path] = features
            except Exception as e:
                self.logger.error(f"Batch extraction error for {file_path}: {str(e)}")
                results[file_path] = {}
        
        self.logger.info(f"Batch extraction completed: {len(results)} files processed")
        return results