"""
Main Antivirus Engine

Orchestrates all detection engines including SVM, signature-based, and heuristic detection.
Provides unified interface for malware detection and threat classification.
"""

import logging
import time
from typing import Dict, List, Optional, Tuple, Any
from dataclasses import dataclass
from pathlib import Path
import json

from .detection import DetectionEngine
from .features import FeatureExtractor
from .models import SVMDetector
from .threat_intel import ThreatIntel
from .scoring import ThreatClassifier
from .utils import get_logger, FileAnalyzer, CachingManager


@dataclass
class ScanResult:
    """Result of a malware scan"""
    file_path: str
    is_malicious: bool
    confidence: float
    threat_level: str
    detection_methods: List[str]
    features_used: List[str]
    analysis_time: float
    additional_info: Dict[str, Any]


class AntivirusEngine:
    """
    Main antivirus engine that coordinates all detection methods
    
    This engine implements a multi-layered detection approach:
    1. Signature-based detection (fast, precise for known threats)
    2. SVM-based ML detection (for unknown/variant threats) 
    3. Heuristic analysis (behavioral patterns)
    4. Threat intelligence enrichment
    5. Quorum-based final decision
    """
    
    def __init__(self, config: Optional[Dict] = None):
        """Initialize the antivirus engine with all components"""
        self.logger = get_logger(__name__)
        self.config = config or self._get_default_config()
        
        # Initialize components
        self.cache_manager = CachingManager()
        self.feature_extractor = FeatureExtractor()
        self.svm_detector = SVMDetector()
        self.detection_engine = DetectionEngine()
        self.threat_intel = ThreatIntel()
        self.threat_classifier = ThreatClassifier()
        
        # Performance tracking
        self.stats = {
            'total_scans': 0,
            'malware_detected': 0,
            'false_positives': 0,
            'avg_scan_time': 0.0,
            'cache_hits': 0
        }
        
        self.logger.info("Antivirus Engine initialized successfully")
    
    def _get_default_config(self) -> Dict:
        """Get default engine configuration"""
        return {
            'cache_enabled': True,
            'cache_size': 10000,
            'svm_threshold': 0.7,
            'heuristic_threshold': 0.6,
            'signature_timeout': 1.0,  # seconds
            'svm_timeout': 5.0,  # seconds
            'heuristic_timeout': 2.0,  # seconds
            'enable_quorum': True,
            'min_detectors': 2,
            'enable_threat_intel': True,
            'max_file_size': 100 * 1024 * 1024,  # 100MB
            'supported_types': ['.exe', '.dll', '.bin', '.pdf', '.doc', '.js', '.ps1']
        }
    
    def scan_file(self, file_path: str, analysis_depth: str = 'full') -> ScanResult:
        """
        Scan a file for malware using multi-layer detection
        
        Args:
            file_path: Path to the file to scan
            analysis_depth: 'quick', 'standard', or 'full'
            
        Returns:
            ScanResult with detection results
        """
        start_time = time.time()
        
        try:
            self.logger.info(f"Starting scan of {file_path}")
            
            # Check cache first
            if self.config['cache_enabled']:
                cached_result = self.cache_manager.get(str(file_path))
                if cached_result:
                    self.stats['cache_hits'] += 1
                    self.logger.info(f"Cache hit for {file_path}")
                    return cached_result
            
            # Validate file
            if not self._validate_file(file_path):
                return ScanResult(
                    file_path=file_path,
                    is_malicious=False,
                    confidence=0.0,
                    threat_level='clean',
                    detection_methods=[],
                    features_used=[],
                    analysis_time=time.time() - start_time,
                    additional_info={'error': 'File validation failed'}
                )
            
            # Multi-stage detection
            detection_results = []
            
            # Stage 1: Signature-based detection (fast)
            sig_result = self._run_signature_detection(file_path, analysis_depth)
            detection_results.append(sig_result)
            
            # Stage 2: Heuristic analysis (if needed)
            heur_result = self._run_heuristic_analysis(file_path, analysis_depth)
            if heur_result['confidence'] > 0:
                detection_results.append(heur_result)
            
            # Stage 3: SVM-based ML detection (if needed)
            svm_result = self._run_svm_detection(file_path, analysis_depth)
            if svm_result['confidence'] > 0:
                detection_results.append(svm_result)
            
            # Stage 4: Threat intelligence enrichment
            ti_result = self._enrich_with_threat_intel(file_path, analysis_depth)
            if ti_result['matches']:
                detection_results.append(ti_result)
            
            # Quorum-based final decision
            final_result = self._make_final_decision(
                file_path, detection_results, analysis_depth
            )
            
            # Cache result
            if self.config['cache_enabled']:
                self.cache_manager.set(str(file_path), final_result)
            
            # Update statistics
            self._update_stats(final_result, time.time() - start_time)
            
            self.logger.info(f"Scan completed for {file_path}: {final_result.threat_level}")
            return final_result
            
        except Exception as e:
            self.logger.error(f"Error scanning {file_path}: {str(e)}")
            return ScanResult(
                file_path=file_path,
                is_malicious=False,
                confidence=0.0,
                threat_level='error',
                detection_methods=[],
                features_used=[],
                analysis_time=time.time() - start_time,
                additional_info={'error': str(e)}
            )
    
    def _validate_file(self, file_path: str) -> bool:
        """Validate file before scanning"""
        try:
            path = Path(file_path)
            if not path.exists() or not path.is_file():
                return False
            
            if path.stat().st_size > self.config['max_file_size']:
                self.logger.warning(f"File {file_path} exceeds size limit")
                return False
            
            if self.config['supported_types']:
                if path.suffix.lower() not in self.config['supported_types']:
                    self.logger.warning(f"File type {path.suffix} not supported")
                    return False
            
            return True
            
        except Exception as e:
            self.logger.error(f"File validation error: {str(e)}")
            return False
    
    def _run_signature_detection(self, file_path: str, depth: str) -> Dict:
        """Run signature-based detection"""
        try:
            start_time = time.time()
            result = self.detection_engine.signature_scan(file_path)
            
            return {
                'method': 'signature',
                'confidence': result.get('confidence', 0.0),
                'features': result.get('signatures', []),
                'time': time.time() - start_time,
                'matches': result.get('matches', [])
            }
        except Exception as e:
            self.logger.error(f"Signature detection error: {str(e)}")
            return {'method': 'signature', 'confidence': 0.0, 'features': [], 'time': 0}
    
    def _run_heuristic_analysis(self, file_path: str, depth: str) -> Dict:
        """Run heuristic analysis"""
        try:
            start_time = time.time()
            result = self.detection_engine.heuristic_scan(file_path)
            
            return {
                'method': 'heuristic',
                'confidence': result.get('confidence', 0.0),
                'features': result.get('heuristics', []),
                'time': time.time() - start_time
            }
        except Exception as e:
            self.logger.error(f"Heuristic analysis error: {str(e)}")
            return {'method': 'heuristic', 'confidence': 0.0, 'features': [], 'time': 0}
    
    def _run_svm_detection(self, file_path: str, depth: str) -> Dict:
        """Run SVM-based ML detection"""
        try:
            start_time = time.time()
            
            # Extract features
            features = self.feature_extractor.extract_features(file_path, depth)
            if not features:
                return {'method': 'svm', 'confidence': 0.0, 'features': [], 'time': 0}
            
            # Run SVM detection
            result = self.svm_detector.predict(features)
            
            return {
                'method': 'svm',
                'confidence': result.get('confidence', 0.0),
                'features': list(features.keys()) if features else [],
                'time': time.time() - start_time,
                'prediction': result.get('prediction', 0),
                'probabilities': result.get('probabilities', {})
            }
        except Exception as e:
            self.logger.error(f"SVM detection error: {str(e)}")
            return {'method': 'svm', 'confidence': 0.0, 'features': [], 'time': 0}
    
    def _enrich_with_threat_intel(self, file_path: str, depth: str) -> Dict:
        """Enrich detection with threat intelligence"""
        try:
            if not self.config['enable_threat_intel']:
                return {'method': 'threat_intel', 'confidence': 0.0, 'features': [], 'matches': []}
            
            start_time = time.time()
            result = self.threat_intel.lookup_file(file_path)
            
            return {
                'method': 'threat_intel',
                'confidence': result.get('confidence', 0.0),
                'features': ['hash', 'reputation'],
                'time': time.time() - start_time,
                'matches': result.get('matches', [])
            }
        except Exception as e:
            self.logger.error(f"Threat intelligence error: {str(e)}")
            return {'method': 'threat_intel', 'confidence': 0.0, 'features': [], 'matches': []}
    
    def _make_final_decision(self, file_path: str, results: List[Dict], depth: str) -> ScanResult:
        """Make final decision using quorum-based approach"""
        # Count detections by method
        high_conf_detections = []
        low_conf_detections = []
        
        for result in results:
            if result['confidence'] > 0.8:
                high_conf_detections.append(result)
            elif result['confidence'] > 0.3:
                low_conf_detections.append(result)
        
        # Decision logic
        is_malicious = False
        confidence = 0.0
        threat_level = 'clean'
        detection_methods = []
        all_features = []
        
        # High confidence detections take precedence
        if high_conf_detections:
            is_malicious = True
            confidence = max(r['confidence'] for r in high_conf_detections)
            detection_methods = [r['method'] for r in high_conf_detections]
            for r in high_conf_detections:
                all_features.extend(r.get('features', []))
        
        # Quorum requirement for lower confidence
        elif len(low_conf_detections) >= self.config['min_detectors']:
            # Weighted decision based on method reliability
            weighted_score = 0.0
            total_weight = 0.0
            
            for result in low_conf_detections:
                weight = self._get_method_weight(result['method'])
                weighted_score += result['confidence'] * weight
                total_weight += weight
                detection_methods.append(result['method'])
                all_features.extend(result.get('features', []))
            
            if total_weight > 0:
                confidence = weighted_score / total_weight
                is_malicious = confidence > self.config['svm_threshold']
        
        # Classify threat level
        threat_level = self.threat_classifier.classify_threat(
            is_malicious, confidence, detection_methods
        )
        
        return ScanResult(
            file_path=file_path,
            is_malicious=is_malicious,
            confidence=confidence,
            threat_level=threat_level,
            detection_methods=detection_methods,
            features_used=list(set(all_features)),
            analysis_time=0.0,  # Will be set by caller
            additional_info={'detection_breakdown': results}
        )
    
    def _get_method_weight(self, method: str) -> float:
        """Get reliability weight for detection method"""
        weights = {
            'signature': 1.0,      # High reliability for known patterns
            'threat_intel': 0.9,   # High reliability for known IOCs
            'svm': 0.7,            # Good reliability for ML detection
            'heuristic': 0.6       # Lower reliability for heuristics
        }
        return weights.get(method, 0.5)
    
    def _update_stats(self, result: ScanResult, scan_time: float):
        """Update engine statistics"""
        self.stats['total_scans'] += 1
        
        if result.is_malicious:
            self.stats['malware_detected'] += 1
        
        # Update average scan time
        total_time = self.stats['avg_scan_time'] * (self.stats['total_scans'] - 1)
        self.stats['avg_scan_time'] = (total_time + scan_time) / self.stats['total_scans']
    
    def get_statistics(self) -> Dict:
        """Get engine performance statistics"""
        return self.stats.copy()
    
    def update_config(self, new_config: Dict):
        """Update engine configuration"""
        self.config.update(new_config)
        self.logger.info("Engine configuration updated")
    
    def load_models(self, model_path: str):
        """Load trained models"""
        try:
            self.svm_detector.load_model(model_path)
            self.logger.info(f"Models loaded from {model_path}")
        except Exception as e:
            self.logger.error(f"Error loading models: {str(e)}")
    
    def export_scan_results(self, results: List[ScanResult], output_path: str):
        """Export scan results to file"""
        try:
            export_data = []
            for result in results:
                export_data.append({
                    'file_path': result.file_path,
                    'is_malicious': result.is_malicious,
                    'confidence': result.confidence,
                    'threat_level': result.threat_level,
                    'detection_methods': result.detection_methods,
                    'features_used': result.features_used,
                    'analysis_time': result.analysis_time,
                    'timestamp': time.time()
                })
            
            with open(output_path, 'w') as f:
                json.dump(export_data, f, indent=2)
            
            self.logger.info(f"Scan results exported to {output_path}")
            
        except Exception as e:
            self.logger.error(f"Error exporting results: {str(e)}")