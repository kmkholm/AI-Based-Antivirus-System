"""
Test script to validate the AI Antivirus application
"""

import os
import sys
import json
from pathlib import Path

# Add current directory to path
current_dir = Path(__file__).parent
sys.path.insert(0, str(current_dir))

def test_imports():
    """Test that all components can be imported"""
    print("Testing component imports...")
    
    components = [
        'engine',
        'scanner', 
        'monitor',
        'database',
        'web_interface',
        'integration'
    ]
    
    for component in components:
        try:
            __import__(component)
            print(f"✓ {component} imported successfully")
        except ImportError as e:
            print(f"✗ {component} import failed: {e}")
            return False
    
    return True

def test_database():
    """Test database functionality"""
    print("\nTesting database functionality...")
    
    try:
        from database.threat_database import ThreatDatabase
        
        # Create test database
        db = ThreatDatabase(':memory:')  # In-memory database for testing
        
        # Test adding a threat
        threat_data = {
            'hash': 'test123',
            'file_path': '/test/file.exe',
            'threat_type': 'malware',
            'threat_family': 'TestFamily',
            'severity': 5,
            'confidence': 0.95,
            'detection_method': 'AI-SVM'
        }
        
        threat_id = db.add_threat(threat_data)
        print(f"✓ Threat added with ID: {threat_id}")
        
        # Test retrieving threat
        retrieved = db.get_threat('test123')
        if retrieved:
            print(f"✓ Threat retrieved: {retrieved['threat_type']}")
        else:
            print("✗ Threat not retrieved")
            return False
        
        # Test statistics
        stats = db.get_statistics()
        print(f"✓ Database statistics: {len(stats)} categories")
        
        db.close()
        return True
        
    except Exception as e:
        print(f"✗ Database test failed: {e}")
        return False

def test_scanner():
    """Test scanner functionality"""
    print("\nTesting scanner functionality...")
    
    try:
        from scanner.scanner_engine import FileScanner
        from scanner.scan_config import ScanConfig
        
        # Create test config
        config = ScanConfig()
        
        # Test scanner creation
        scanner = FileScanner(config)
        print("✓ Scanner created successfully")
        
        # Test file type detection
        from scanner.file_detector import FileTypeDetector
        detector = FileTypeDetector()
        
        # Create a test file
        test_file = current_dir / "test_file.txt"
        test_file.write_text("This is a test file")
        
        file_type = detector.detect_file_type(str(test_file))
        print(f"✓ File type detection: {file_type}")
        
        # Clean up
        test_file.unlink()
        
        return True
        
    except Exception as e:
        print(f"✗ Scanner test failed: {e}")
        return False

def test_ai_engine():
    """Test AI engine functionality"""
    print("\nTesting AI engine functionality...")
    
    try:
        from engine.features.feature_extractor import FeatureExtractor
        from engine.models.svm_model import SVMModel
        
        # Test feature extractor
        extractor = FeatureExtractor()
        print("✓ Feature extractor created")
        
        # Test SVM model
        model = SVMModel()
        print("✓ SVM model created")
        
        return True
        
    except Exception as e:
        print(f"✗ AI engine test failed: {e}")
        return False

def test_web_interface():
    """Test web interface"""
    print("\nTesting web interface...")
    
    try:
        # Check if Flask is available
        import flask
        print("✓ Flask is available")
        
        # Try to import our web app
        try:
            from web_interface.app import app
            print("✓ Web interface app imported")
        except ImportError:
            print("! Web interface not available (missing dependencies)")
        
        return True
        
    except ImportError:
        print("! Flask not installed (web interface unavailable)")
        return True  # Not a critical failure

def test_integration():
    """Test system integration"""
    print("\nTesting system integration...")
    
    try:
        from integration.abstraction.platform_adapter import PlatformAdapter
        
        adapter = PlatformAdapter()
        print("✓ Platform adapter created")
        
        return True
        
    except Exception as e:
        print(f"✗ Integration test failed: {e}")
        return False

def test_main_application():
    """Test main application"""
    print("\nTesting main application...")
    
    try:
        from main import AntivirusApplication
        
        # Create application instance
        app = AntivirusApplication()
        print("✓ Main application created")
        
        # Test configuration
        config = app.config
        print(f"✓ Configuration loaded: {config['app_name']} v{config['version']}")
        
        # Test status
        status = app.get_status()
        print(f"✓ Status check: {status['status']}")
        
        return True
        
    except Exception as e:
        print(f"✗ Main application test failed: {e}")
        return False

def create_sample_test_file():
    """Create a sample test file for scanning"""
    test_content = b"""
    This is a test file for antivirus scanning.
    It contains no actual malware.
    X5O!P%@AP[4\\PZX54(P^)7CC)7}$EICAR-STANDARD-ANTIVIRUS-TEST-FILE!$H+H*
    """
    
    test_file = current_dir / "EICAR_test.txt"
    test_file.write_bytes(test_content)
    return str(test_file)

def test_full_scan():
    """Test a full scan operation"""
    print("\nTesting full scan operation...")
    
    try:
        # Create test file
        test_file = create_sample_test_file()
        
        # Test with main application
        from main import AntivirusApplication
        app = AntivirusApplication()
        
        # Perform scan
        results = app.scan_path(str(current_dir), "test")
        print(f"✓ Scan completed: {results.get('threats_found', 0)} threats found")
        
        # Clean up
        Path(test_file).unlink()
        
        return True
        
    except Exception as e:
        print(f"✗ Full scan test failed: {e}")
        return False

def main():
    """Run all tests"""
    print("AI Antivirus Application Test Suite")
    print("=" * 50)
    
    tests = [
        ("Component Imports", test_imports),
        ("Database Functionality", test_database),
        ("Scanner Functionality", test_scanner),
        ("AI Engine", test_ai_engine),
        ("Web Interface", test_web_interface),
        ("System Integration", test_integration),
        ("Main Application", test_main_application),
        ("Full Scan Operation", test_full_scan)
    ]
    
    results = []
    for test_name, test_func in tests:
        try:
            result = test_func()
            results.append((test_name, result))
        except Exception as e:
            print(f"✗ {test_name} failed with exception: {e}")
            results.append((test_name, False))
    
    # Summary
    print("\n" + "=" * 50)
    print("TEST SUMMARY")
    print("=" * 50)
    
    passed = 0
    total = len(results)
    
    for test_name, result in results:
        status = "PASS" if result else "FAIL"
        print(f"{test_name:<25} {status}")
        if result:
            passed += 1
    
    print(f"\nResults: {passed}/{total} tests passed")
    
    if passed == total:
        print("🎉 All tests passed! The AI Antivirus application is ready to use.")
        return 0
    else:
        print(f"⚠️  {total - passed} test(s) failed. Please check the issues above.")
        return 1

if __name__ == "__main__":
    sys.exit(main())