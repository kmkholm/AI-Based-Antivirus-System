"""
Platform adapter for cross-platform compatibility.

Provides unified interface for platform-specific operations:
- System information detection
- Platform-specific optimizations
- OS-level API abstractions
- Cross-platform compatibility layer

Supports Linux, Windows, and macOS with optimized implementations
for each platform.
"""

import os
import sys
import platform
import subprocess
import threading
from typing import Dict, List, Optional, Any, Tuple
from dataclasses import dataclass
from enum import Enum

from ..core.config import MonitorConfig


class PlatformType(Enum):
    """Supported platform types."""
    LINUX = "linux"
    WINDOWS = "windows"
    MACOS = "darwin"
    UNKNOWN = "unknown"


@dataclass
class PlatformInfo:
    """Platform information structure."""
    type: PlatformType
    name: str
    version: str
    architecture: str
    kernel_version: str
    supports_syscall_monitoring: bool
    supports_file_monitoring: bool
    supports_network_monitoring: bool
    requires_privileges: Dict[str, bool]
    api_capabilities: Dict[str, List[str]]


class SystemInfoProvider:
    """Provides system information for the current platform."""
    
    @staticmethod
    def get_platform_info() -> PlatformInfo:
        """Get comprehensive platform information."""
        system = platform.system().lower()
        
        if system == 'linux':
            return SystemInfoProvider._get_linux_info()
        elif system == 'windows':
            return SystemInfoProvider._get_windows_info()
        elif system == 'darwin':
            return SystemInfoProvider._get_macos_info()
        else:
            return SystemInfoProvider._get_unknown_info()
    
    @staticmethod
    def _get_linux_info() -> PlatformInfo:
        """Get Linux-specific platform information."""
        try:
            with open('/etc/os-release', 'r') as f:
                os_release = f.read()
            
            # Parse os-release
            os_name = "Unknown"
            os_version = "Unknown"
            
            for line in os_release.split('\n'):
                if line.startswith('PRETTY_NAME='):
                    os_name = line.split('=')[1].strip('"')
                elif line.startswith('VERSION_ID='):
                    os_version = line.split('=')[1].strip('"')
        except Exception:
            os_name = platform.platform()
            os_version = platform.release()
        
        # Check capabilities
        try:
            # Check for inotify support
            with open('/proc/sys/fs/inotify/max_user_watches', 'r') as f:
                inotify_support = True
        except Exception:
            inotify_support = False
        
        try:
            # Check for eBPF support
            result = subprocess.run(['which', 'bpftool'], capture_output=True)
            ebpf_support = result.returncode == 0
        except Exception:
            ebpf_support = False
        
        return PlatformInfo(
            type=PlatformType.LINUX,
            name=os_name,
            version=os_version,
            architecture=platform.machine(),
            kernel_version=platform.release(),
            supports_syscall_monitoring=ebpf_support,
            supports_file_monitoring=inotify_support,
            supports_network_monitoring=True,
            requires_privileges={
                'syscall_monitoring': ebpf_support,
                'file_monitoring': inotify_support,
                'network_monitoring': True
            },
            api_capabilities={
                'file_monitoring': ['inotify', 'fanotify'],
                'process_monitoring': ['procfs', 'psutil'],
                'syscall_monitoring': ['ebpf', 'ptrace', 'audit'],
                'network_monitoring': ['packet_socket', 'netlink', 'psutil']
            }
        )
    
    @staticmethod
    def _get_windows_info() -> PlatformInfo:
        """Get Windows-specific platform information."""
        try:
            import winreg
        except ImportError:
            winreg = None
        
        # Get Windows version info
        try:
            import sys
            if hasattr(sys, 'getwindowsversion'):
                win_version = sys.getwindowsversion()
                os_version = f"{win_version.major}.{win_version.minor}.{win_version.build}"
            else:
                os_version = platform.version()
        except Exception:
            os_version = platform.version()
        
        # Check capabilities
        etw_support = SystemInfoProvider._check_windows_etw()
        wfp_support = SystemInfoProvider._check_windows_wfp()
        
        return PlatformInfo(
            type=PlatformType.WINDOWS,
            name=platform.platform(),
            version=os_version,
            architecture=platform.machine(),
            kernel_version=platform.release(),
            supports_syscall_monitoring=etw_support,
            supports_file_monitoring=True,
            supports_network_monitoring=wfp_support,
            requires_privileges={
                'syscall_monitoring': etw_support,
                'file_monitoring': False,
                'network_monitoring': wfp_support
            },
            api_capabilities={
                'file_monitoring': ['ReadDirectoryChangesW', 'FindFirstChangeNotification'],
                'process_monitoring': ['psutil', 'wmi'],
                'syscall_monitoring': ['etw', 'wfp'],
                'network_monitoring': ['wfp', 'pcap']
            }
        )
    
    @staticmethod
    def _get_macos_info() -> PlatformInfo:
        """Get macOS-specific platform information."""
        # Check for macOS capabilities
        endpoint_security_support = SystemInfoProvider._check_macos_endpoint_security()
        kqueue_support = True  # Always supported on macOS
        
        return PlatformInfo(
            type=PlatformType.MACOS,
            name=platform.platform(),
            version=platform.mac_ver()[0],
            architecture=platform.machine(),
            kernel_version=platform.release(),
            supports_syscall_monitoring=endpoint_security_support,
            supports_file_monitoring=kqueue_support,
            supports_network_monitoring=True,
            requires_privileges={
                'syscall_monitoring': endpoint_security_support,
                'file_monitoring': False,
                'network_monitoring': False
            },
            api_capabilities={
                'file_monitoring': ['kqueue'],
                'process_monitoring': ['psutil'],
                'syscall_monitoring': ['endpoint_security'],
                'network_monitoring': ['pcap', 'socket']
            }
        )
    
    @staticmethod
    def _get_unknown_info() -> PlatformInfo:
        """Get information for unknown platform."""
        return PlatformInfo(
            type=PlatformType.UNKNOWN,
            name=platform.platform(),
            version=platform.release(),
            architecture=platform.machine(),
            kernel_version=platform.release(),
            supports_syscall_monitoring=False,
            supports_file_monitoring=False,
            supports_network_monitoring=False,
            requires_privileges={},
            api_capabilities={}
        )
    
    @staticmethod
    def _check_windows_etw() -> bool:
        """Check if Windows ETW is available."""
        try:
            import ctypes
            from ctypes import wintypes
            
            # Try to load ETW DLL
            etw_dll = ctypes.windll.LoadLibrary("advapi32.dll")
            return True
        except Exception:
            return False
    
    @staticmethod
    def _check_windows_wfp() -> bool:
        """Check if Windows WFP is available."""
        try:
            import ctypes
            from ctypes import wintypes
            
            # Try to load WFP DLL
            wfp_dll = ctypes.windll.LoadLibrary("fwpuclnt.dll")
            return True
        except Exception:
            return False
    
    @staticmethod
    def _check_macos_endpoint_security() -> bool:
        """Check if macOS Endpoint Security is available."""
        try:
            # Check if endpoint security framework is available
            result = subprocess.run(['kextstat'], capture_output=True)
            return 'com.apple.endpointsecurity' in result.stdout.decode()
        except Exception:
            return False


class ProcessProvider:
    """Provides process information across platforms."""
    
    @staticmethod
    def get_current_process_info() -> Dict[str, Any]:
        """Get current process information."""
        try:
            import psutil
            process = psutil.Process()
            
            return {
                'pid': process.pid,
                'name': process.name(),
                'cmdline': process.cmdline(),
                'create_time': process.create_time(),
                'cpu_percent': process.cpu_percent(),
                'memory_percent': process.memory_percent(),
                'status': process.status(),
                'username': process.username() if hasattr(process, 'username') else None
            }
        except Exception as e:
            return {
                'pid': os.getpid(),
                'name': 'python',
                'error': str(e)
            }
    
    @staticmethod
    def get_process_tree() -> Dict[str, Any]:
        """Get process tree information."""
        try:
            import psutil
            
            root_processes = []
            for proc in psutil.process_iter(['pid', 'name', 'ppid']):
                try:
                    if proc.info['ppid'] == 0 or proc.info['ppid'] == 1:
                        root_processes.append({
                            'pid': proc.info['pid'],
                            'name': proc.info['name'],
                            'children': ProcessProvider._get_process_children(proc.info['pid'])
                        })
                except (psutil.NoSuchProcess, psutil.AccessDenied):
                    continue
            
            return {'root_processes': root_processes}
        except Exception as e:
            return {'error': str(e), 'root_processes': []}
    
    @staticmethod
    def _get_process_children(parent_pid: int) -> List[Dict[str, Any]]:
        """Get child processes of a parent process."""
        try:
            import psutil
            
            children = []
            for proc in psutil.process_iter(['pid', 'name', 'ppid']):
                try:
                    if proc.info['ppid'] == parent_pid:
                        children.append({
                            'pid': proc.info['pid'],
                            'name': proc.info['name']
                        })
                except (psutil.NoSuchProcess, psutil.AccessDenied):
                    continue
            
            return children
        except Exception:
            return []


class NetworkProvider:
    """Provides network information across platforms."""
    
    @staticmethod
    def get_network_interfaces() -> List[Dict[str, Any]]:
        """Get network interface information."""
        try:
            import psutil
            
            interfaces = []
            for name, addrs in psutil.net_if_addrs().items():
                interface_info = {
                    'name': name,
                    'addresses': []
                }
                
                for addr in addrs:
                    interface_info['addresses'].append({
                        'family': str(addr.family),
                        'address': addr.address,
                        'netmask': addr.netmask,
                        'broadcast': addr.broadcast
                    })
                
                interfaces.append(interface_info)
            
            return interfaces
        except Exception as e:
            return [{'error': str(e)}]
    
    @staticmethod
    def get_active_connections() -> List[Dict[str, Any]]:
        """Get active network connections."""
        try:
            import psutil
            
            connections = []
            for conn in psutil.net_connections():
                try:
                    connections.append({
                        'family': str(conn.family),
                        'type': str(conn.type),
                        'local_address': f"{conn.laddr.ip}:{conn.laddr.port}" if conn.laddr else None,
                        'remote_address': f"{conn.raddr.ip}:{conn.raddr.port}" if conn.raddr else None,
                        'status': conn.status,
                        'pid': conn.pid
                    })
                except (psutil.NoSuchProcess, psutil.AccessDenied):
                    continue
            
            return connections
        except Exception as e:
            return [{'error': str(e)}]


class PlatformAdapter:
    """Main platform adapter providing unified interface."""
    
    def __init__(self, config: MonitorConfig):
        self.config = config
        self.platform_info = SystemInfoProvider.get_platform_info()
        self._lock = threading.RLock()
        
    def is_supported(self, capability: str) -> bool:
        """Check if platform supports a specific capability."""
        capability_map = {
            'syscall_monitoring': self.platform_info.supports_syscall_monitoring,
            'file_monitoring': self.platform_info.supports_file_monitoring,
            'network_monitoring': self.platform_info.supports_network_monitoring
        }
        
        return capability_map.get(capability, False)
    
    def get_recommended_config(self) -> Dict[str, Any]:
        """Get platform-recommended configuration."""
        recommendations = {
            'platform': self.platform_info.type.value,
            'optimizations': []
        }
        
        if self.platform_info.type == PlatformType.LINUX:
            recommendations['optimizations'] = [
                'use_inotify_for_file_monitoring',
                'enable_ebpf_for_syscall_monitoring',
                'use_psutil_for_process_monitoring',
                'use_packet_socket_for_network_monitoring'
            ]
        elif self.platform_info.type == PlatformType.WINDOWS:
            recommendations['optimizations'] = [
                'use_etw_for_syscall_monitoring',
                'use_wfp_for_network_monitoring',
                'use_readdirectorychangesw_for_file_monitoring',
                'use_psutil_for_process_monitoring'
            ]
        elif self.platform_info.type == PlatformType.MACOS:
            recommendations['optimizations'] = [
                'use_endpoint_security_for_syscall_monitoring',
                'use_kqueue_for_file_monitoring',
                'use_psutil_for_process_monitoring'
            ]
        
        return recommendations
    
    def check_privileges(self) -> Dict[str, bool]:
        """Check current privileges for various operations."""
        privileges = {}
        
        if self.platform_info.type == PlatformType.LINUX:
            # Check if running as root
            privileges['root_access'] = os.geteuid() == 0
            
            # Check for specific capabilities (simplified)
            privileges['network_capture'] = privileges['root_access']
            privileges['syscall_monitoring'] = privileges['root_access']
            
        elif self.platform_info.type == PlatformType.WINDOWS:
            # Check if running as administrator
            try:
                import ctypes
                privileges['admin_access'] = ctypes.windll.shell32.IsUserAnAdmin()
            except Exception:
                privileges['admin_access'] = False
            
            privileges['network_capture'] = privileges['admin_access']
            privileges['syscall_monitoring'] = privileges['admin_access']
            
        elif self.platform_info.type == PlatformType.MACOS:
            # Check for root access
            privileges['root_access'] = os.geteuid() == 0
            privileges['network_capture'] = privileges['root_access']
            privileges['syscall_monitoring'] = privileges['root_access']
        
        return privileges
    
    def optimize_for_platform(self) -> bool:
        """Apply platform-specific optimizations."""
        try:
            if self.platform_info.type == PlatformType.LINUX:
                return self._optimize_linux()
            elif self.platform_info.type == PlatformType.WINDOWS:
                return self._optimize_windows()
            elif self.platform_info.type == PlatformType.MACOS:
                return self._optimize_macos()
            return False
        except Exception as e:
            print(f"Error optimizing for platform: {e}")
            return False
    
    def _optimize_linux(self) -> bool:
        """Apply Linux-specific optimizations."""
        try:
            # Increase inotify watches limit
            with open('/proc/sys/fs/inotify/max_user_watches', 'r') as f:
                current_limit = int(f.read().strip())
            
            if current_limit < 100000:
                print(f"Recommendation: Increase inotify watches limit (current: {current_limit}, recommended: 100000)")
            
            # Check for optimized kernel
            kernel_version = platform.release()
            print(f"Running on Linux kernel: {kernel_version}")
            
            return True
        except Exception as e:
            print(f"Error optimizing Linux: {e}")
            return False
    
    def _optimize_windows(self) -> bool:
        """Apply Windows-specific optimizations."""
        try:
            import platform
            windows_version = platform.platform()
            print(f"Running on: {windows_version}")
            
            # Check for Windows Defender exclusions
            print("Recommendation: Add antivirus process to Windows Defender exclusions")
            
            return True
        except Exception as e:
            print(f"Error optimizing Windows: {e}")
            return False
    
    def _optimize_macos(self) -> bool:
        """Apply macOS-specific optimizations."""
        try:
            macos_version = platform.mac_ver()[0]
            print(f"Running on macOS: {macos_version}")
            
            # Check for system integrity protection
            try:
                result = subprocess.run(['csrutil', 'status'], capture_output=True, text=True)
                if 'enabled' in result.stdout.lower():
                    print("Note: System Integrity Protection is enabled - some monitoring may be limited")
            except Exception:
                pass
            
            return True
        except Exception as e:
            print(f"Error optimizing macOS: {e}")
            return False
    
    def get_platform_stats(self) -> Dict[str, Any]:
        """Get comprehensive platform statistics."""
        stats = {
            'platform_info': {
                'type': self.platform_info.type.value,
                'name': self.platform_info.name,
                'version': self.platform_info.version,
                'architecture': self.platform_info.architecture,
                'kernel_version': self.platform_info.kernel_version
            },
            'capabilities': {
                'syscall_monitoring': self.platform_info.supports_syscall_monitoring,
                'file_monitoring': self.platform_info.supports_file_monitoring,
                'network_monitoring': self.platform_info.supports_network_monitoring
            },
            'privileges': self.check_privileges(),
            'recommendations': self.get_recommended_config(),
            'process_info': ProcessProvider.get_current_process_info(),
            'network_interfaces': NetworkProvider.get_network_interfaces()
        }
        
        return stats
    
    def __str__(self) -> str:
        return f"PlatformAdapter({self.platform_info.type.value} - {self.platform_info.name})"