"""
Behavior analysis engine for real-time threat detection.

Analyzes patterns across file, process, system call, and network events
to detect sophisticated multi-stage attacks and behavioral anomalies.

Features:
- Cross-event correlation and analysis
- Machine learning-based behavior classification
- Sequence pattern detection
- Anomaly scoring and threat assessment
- Real-time behavioral profiling
- Performance-optimized for high-throughput analysis

Based on behavioral analysis research for detecting advanced persistent threats.
"""

import os
import time
import threading
import json
import numpy as np
from typing import Dict, List, Set, Optional, Tuple, Any
from dataclasses import dataclass, field
from collections import defaultdict, deque
from concurrent.futures import ThreadPoolExecutor
from enum import Enum

from ..core.event_system import EventSystem, EventType, EventPriority, get_event_system
from ..core.config import MonitorConfig


class ThreatLevel(Enum):
    """Threat level enumeration."""
    BENIGN = "benign"
    SUSPICIOUS = "suspicious"
    MALICIOUS = "malicious"
    CRITICAL = "critical"


@dataclass
class BehaviorProfile:
    """Behavior profile for entities (processes, users, etc.)."""
    entity_id: str  # Process ID, user ID, or other identifier
    entity_type: str  # process, user, system
    created_time: float
    last_update: float
    event_count: int = 0
    file_operations: int = 0
    network_connections: int = 0
    system_calls: int = 0
    privilege_operations: int = 0
    suspicious_operations: int = 0
    behavior_score: float = 0.0
    threat_level: ThreatLevel = ThreatLevel.BENIGN
    indicators: List[str] = field(default_factory=list)
    sequence_patterns: Dict[str, int] = field(default_factory=dict)
    feature_vector: List[float] = field(default_factory=list)


@dataclass
class ThreatAssessment:
    """Threat assessment result."""
    threat_level: ThreatLevel
    confidence: float
    indicators: List[str]
    affected_entities: List[str]
    recommended_actions: List[str]
    analysis_time: float
    correlation_id: str


class BehaviorClassifier:
    """Machine learning-based behavior classifier."""
    
    def __init__(self, config: MLConfig):
        self.config = config
        self._feature_weights = {
            'file_operations': 0.15,
            'network_connections': 0.20,
            'system_calls': 0.25,
            'privilege_operations': 0.30,
            'suspicious_patterns': 0.35
        }
        
        # Simplified scoring thresholds
        self._thresholds = {
            'suspicious': 0.4,
            'malicious': 0.6,
            'critical': 0.8
        }
    
    def extract_features(self, profile: BehaviorProfile) -> List[float]:
        """Extract features for machine learning analysis."""
        if not profile.feature_vector:
            # Create feature vector from profile data
            features = [
                min(profile.file_operations / 100.0, 1.0),  # Normalize to 0-1
                min(profile.network_connections / 50.0, 1.0),
                min(profile.system_calls / 1000.0, 1.0),
                min(profile.privilege_operations / 10.0, 1.0),
                min(profile.suspicious_operations / 20.0, 1.0),
                profile.event_count / 1000.0,  # Recent activity
                len(profile.indicators) / 10.0,  # Number of indicators
                len(profile.sequence_patterns) / 20.0  # Pattern diversity
            ]
            
            profile.feature_vector = features
        
        return profile.feature_vector
    
    def classify_behavior(self, profile: BehaviorProfile) -> Tuple[ThreatLevel, float]:
        """Classify behavior and return threat level with confidence."""
        features = self.extract_features(profile)
        
        # Simple weighted scoring
        score = 0.0
        for i, (feature_name, weight) in enumerate(self._feature_weights.items()):
            if i < len(features):
                score += features[i] * weight
        
        # Normalize score
        score = min(score, 1.0)
        
        # Determine threat level
        if score >= self._thresholds['critical']:
            threat_level = ThreatLevel.CRITICAL
        elif score >= self._thresholds['malicious']:
            threat_level = ThreatLevel.MALICIOUS
        elif score >= self._thresholds['suspicious']:
            threat_level = ThreatLevel.SUSPICIOUS
        else:
            threat_level = ThreatLevel.BENIGN
        
        return threat_level, score


class SequenceAnalyzer:
    """Analyzes event sequences for behavioral patterns."""
    
    def __init__(self):
        self._known_malicious_sequences = [
            # File-based attack sequence
            ['file.create', 'file.modify', 'process.create', 'network.connect'],
            # Privilege escalation sequence
            ['process.create', 'syscall.privesc', 'process.create', 'file.modify'],
            # Data exfiltration sequence
            ['process.create', 'network.connect', 'file.access', 'network.exfiltration'],
            # Process injection sequence
            ['process.create', 'syscall.inject', 'process.create', 'process.terminate'],
            # Persistence sequence
            ['file.create', 'file.modify', 'syscall.privesc', 'file.create']
        ]
        
        self._sequence_frequencies: Dict[str, Dict[str, int]] = defaultdict(lambda: defaultdict(int))
    
    def analyze_sequence(self, events: List[Dict]) -> List[str]:
        """Analyze event sequence for malicious patterns."""
        indicators = []
        
        if len(events) < 2:
            return indicators
        
        # Extract event types
        event_types = [event.get('type', '').replace('file.', '').replace('process.', '').replace('syscall.', '').replace('network.', '') for event in events]
        
        # Check for known malicious sequences
        for i, malicious_seq in enumerate(self._known_malicious_sequences):
            if self._matches_sequence(event_types, malicious_seq):
                indicators.append(f"malicious_sequence_{i}")
        
        # Check for custom patterns
        for seq_type, frequencies in self._sequence_frequencies.items():
            if self._sequence_matches_frequent_pattern(event_types, frequencies):
                indicators.append(f"frequent_pattern_{seq_type}")
        
        return indicators
    
    def _matches_sequence(self, event_types: List[str], pattern: List[str]) -> bool:
        """Check if event types match a given pattern."""
        if len(event_types) < len(pattern):
            return False
        
        # Use sliding window to find pattern
        for i in range(len(event_types) - len(pattern) + 1):
            if event_types[i:i+len(pattern)] == pattern:
                return True
        
        return False
    
    def _sequence_matches_frequent_pattern(self, event_types: List[str], frequencies: Dict[str, int]) -> bool:
        """Check if sequence matches frequent patterns."""
        if not event_types:
            return False
        
        # Simple check for high-frequency individual events
        for event_type in event_types:
            if frequencies.get(event_type, 0) > 5:  # Threshold for frequency
                return True
        
        return False


class CorrelationEngine:
    """Correlates events across different monitoring components."""
    
    def __init__(self, config: MonitorConfig):
        self.config = config
        self._correlation_window = config.alert_config.correlation_window
        self._event_cache: List[Dict] = []
        self._entity_profiles: Dict[str, BehaviorProfile] = {}
        self._correlation_lock = threading.RLock()
    
    def correlate_events(self, events: List[Dict]) -> ThreatAssessment:
        """Correlate events and assess threat level."""
        if not events:
            return ThreatAssessment(
                threat_level=ThreatLevel.BENIGN,
                confidence=0.0,
                indicators=[],
                affected_entities=[],
                recommended_actions=[],
                analysis_time=0.0,
                correlation_id=""
            )
        
        start_time = time.time()
        correlation_id = f"corr_{int(start_time)}"
        
        # Group events by entity
        entity_events = defaultdict(list)
        for event in events:
            entity_id = self._extract_entity_id(event)
            if entity_id:
                entity_events[entity_id].append(event)
        
        # Analyze each entity
        all_indicators = []
        affected_entities = []
        
        for entity_id, entity_events_list in entity_events.items():
            # Update behavior profile
            profile = self._update_profile(entity_id, entity_events_list)
            
            # Analyze patterns
            sequence_indicators = self._analyze_patterns(entity_events_list)
            all_indicators.extend(sequence_indicators)
            
            if profile.threat_level != ThreatLevel.BENIGN:
                affected_entities.append(entity_id)
                all_indicators.extend(profile.indicators)
        
        # Overall threat assessment
        threat_level, confidence = self._assess_overall_threat(entity_events, all_indicators)
        
        analysis_time = time.time() - start_time
        
        return ThreatAssessment(
            threat_level=threat_level,
            confidence=confidence,
            indicators=list(set(all_indicators)),
            affected_entities=affected_entities,
            recommended_actions=self._generate_recommendations(threat_level, all_indicators),
            analysis_time=analysis_time,
            correlation_id=correlation_id
        )
    
    def _extract_entity_id(self, event: Dict) -> Optional[str]:
        """Extract entity ID from event."""
        data = event.get('data', {})
        
        # Try different entity identifiers
        if 'pid' in data:
            return f"process_{data['pid']}"
        elif 'user' in data:
            return f"user_{data['user']}"
        else:
            return event.get('source', 'unknown')
    
    def _update_profile(self, entity_id: str, events: List[Dict]) -> BehaviorProfile:
        """Update behavior profile for an entity."""
        with self._correlation_lock:
            if entity_id not in self._entity_profiles:
                self._entity_profiles[entity_id] = BehaviorProfile(
                    entity_id=entity_id,
                    entity_type=self._determine_entity_type(events[0]) if events else "unknown",
                    created_time=time.time(),
                    last_update=time.time()
                )
            
            profile = self._entity_profiles[entity_id]
            profile.last_update = time.time()
            profile.event_count += len(events)
            
            # Update counters based on event types
            for event in events:
                event_type = event.get('type', '')
                
                if event_type.startswith('file.'):
                    profile.file_operations += 1
                elif event_type.startswith('process.'):
                    profile.network_connections += 1
                elif event_type.startswith('syscall.'):
                    profile.system_calls += 1
                elif event_type.startswith('network.'):
                    profile.network_connections += 1
                
                # Check for suspicious indicators
                data = event.get('data', {})
                if 'suspicious_score' in data and data['suspicious_score'] > 0.5:
                    profile.suspicious_operations += 1
                    profile.indicators.append(f"suspicious_{event_type}")
                
                # Check for privilege operations
                if self._is_privilege_operation(event):
                    profile.privilege_operations += 1
            
            return profile
    
    def _determine_entity_type(self, event: Dict) -> str:
        """Determine entity type from event."""
        event_type = event.get('type', '')
        if event_type.startswith('process.'):
            return 'process'
        elif event_type.startswith('file.'):
            return 'file'
        elif event_type.startswith('network.'):
            return 'network'
        else:
            return 'unknown'
    
    def _is_privilege_operation(self, event: Dict) -> bool:
        """Check if event represents a privilege operation."""
        event_type = event.get('type', '')
        data = event.get('data', {})
        
        privilege_indicators = [
            'privesc', 'privilege', 'setuid', 'setgid', 'sudo', 'admin'
        ]
        
        return any(indicator in event_type.lower() or 
                  any(indicator in str(value).lower() for value in data.values()) 
                  for indicator in privilege_indicators)
    
    def _analyze_patterns(self, events: List[Dict]) -> List[str]:
        """Analyze event patterns for suspicious behavior."""
        # Use sequence analyzer
        analyzer = SequenceAnalyzer()
        return analyzer.analyze_sequence(events)
    
    def _assess_overall_threat(self, entity_events: Dict[str, List[Dict]], indicators: List[str]) -> Tuple[ThreatLevel, float]:
        """Assess overall threat level from correlated events."""
        if not entity_events:
            return ThreatLevel.BENIGN, 0.0
        
        # Count threat indicators
        threat_score = 0.0
        
        # High-risk indicators
        critical_indicators = [
            'malicious_sequence', 'process_injection', 'privilege_escalation',
            'data_exfiltration', 'beaconing'
        ]
        
        high_indicators = [
            'suspicious_process', 'suspicious_network', 'suspicious_file'
        ]
        
        for indicator in indicators:
            if any(critical in indicator for critical in critical_indicators):
                threat_score += 0.3
            elif any(high in indicator for high in high_indicators):
                threat_score += 0.2
            else:
                threat_score += 0.1
        
        # Factor in number of affected entities
        entity_factor = min(len(entity_events) / 10.0, 1.0)
        threat_score *= (1 + entity_factor)
        
        # Normalize score
        threat_score = min(threat_score, 1.0)
        
        # Determine threat level
        if threat_score >= 0.8:
            threat_level = ThreatLevel.CRITICAL
        elif threat_score >= 0.6:
            threat_level = ThreatLevel.MALICIOUS
        elif threat_score >= 0.4:
            threat_level = ThreatLevel.SUSPICIOUS
        else:
            threat_level = ThreatLevel.BENIGN
        
        return threat_level, threat_score
    
    def _generate_recommendations(self, threat_level: ThreatLevel, indicators: List[str]) -> List[str]:
        """Generate recommended actions based on threat assessment."""
        recommendations = []
        
        if threat_level == ThreatLevel.CRITICAL:
            recommendations.extend([
                "Immediately isolate affected systems",
                "Block network connections to suspicious IPs",
                "Terminate suspicious processes",
                "Alert security team immediately"
            ])
        elif threat_level == ThreatLevel.MALICIOUS:
            recommendations.extend([
                "Quarantine affected systems",
                "Investigate attack vectors",
                "Update security policies",
                "Monitor for lateral movement"
            ])
        elif threat_level == ThreatLevel.SUSPICIOUS:
            recommendations.extend([
                "Increase monitoring frequency",
                "Review system logs",
                "Validate with additional tools"
            ])
        
        return recommendations


class BehaviorEngine:
    """Main behavior analysis engine."""
    
    def __init__(self, config: MonitorConfig):
        self.config = config
        self.event_system = get_event_system()
        self._classifier = BehaviorClassifier(config.ml)
        self._correlation_engine = CorrelationEngine(config)
        self._running = False
        self._analysis_queue = deque(maxlen=1000)
        self._analysis_thread = None
        self._stats = {
            'events_analyzed': 0,
            'threats_detected': 0,
            'profiles_created': 0
        }
        
        # Subscribe to events
        self._setup_event_subscriptions()
    
    def start(self) -> None:
        """Start the behavior analysis engine."""
        if not self.config.ml.enabled:
            return
        
        self._running = True
        self._analysis_thread = threading.Thread(target=self._analysis_loop, daemon=True)
        self._analysis_thread.start()
    
    def stop(self) -> None:
        """Stop the behavior analysis engine."""
        self._running = False
        
        if self._analysis_thread:
            self._analysis_thread.join(timeout=5)
    
    def _setup_event_subscriptions(self) -> None:
        """Setup event subscriptions for behavior analysis."""
        # Subscribe to all event types for comprehensive analysis
        event_types = [
            EventType.FILE_CREATE, EventType.FILE_MODIFY, EventType.FILE_DELETE,
            EventType.PROCESS_CREATE, EventType.PROCESS_SUSPICIOUS, EventType.PROCESS_TERMINATE,
            EventType.SYSCALL_ANOMALY, EventType.SYSCALL_SEQUENCE,
            EventType.NETWORK_CONNECT, EventType.NETWORK_SUSPICIOUS, EventType.NETWORK_EXFILTRATION
        ]
        
        def event_handler(event):
            # Add to analysis queue
            with threading.Lock():
                if len(self._analysis_queue) < self._analysis_queue.maxlen:
                    self._analysis_queue.append(event)
                else:
                    # Remove oldest and add new
                    self._analysis_queue.popleft()
                    self._analysis_queue.append(event)
        
        self.event_system.subscribe("behavior_engine", event_types, event_handler)
    
    def _analysis_loop(self) -> None:
        """Main analysis loop."""
        while self._running:
            try:
                # Get events for analysis
                events_to_analyze = []
                
                with threading.Lock():
                    if self._analysis_queue:
                        # Process up to 10 events at a time
                        batch_size = min(10, len(self._analysis_queue))
                        for _ in range(batch_size):
                            if self._analysis_queue:
                                events_to_analyze.append(self._analysis_queue.popleft())
                
                if events_to_analyze:
                    # Convert events to dictionaries
                    event_dicts = [event.to_dict() for event in events_to_analyze]
                    
                    # Perform correlation analysis
                    assessment = self._correlation_engine.correlate_events(event_dicts)
                    
                    # Update stats
                    self._stats['events_analyzed'] += len(events_to_analyze)
                    if assessment.threat_level != ThreatLevel.BENIGN:
                        self._stats['threats_detected'] += 1
                    
                    # Publish behavior analysis event
                    if assessment.threat_level != ThreatLevel.BENIGN:
                        self._publish_behavior_event(assessment)
                
                # Sleep briefly to prevent CPU spinning
                time.sleep(0.1)
                
            except Exception as e:
                if self._running:
                    print(f"Error in behavior analysis: {e}")
    
    def _publish_behavior_event(self, assessment: ThreatAssessment) -> None:
        """Publish behavior analysis event."""
        # Map threat level to event type
        event_type_map = {
            ThreatLevel.CRITICAL: EventType.ALERT_CRITICAL,
            ThreatLevel.MALICIOUS: EventType.ALERT_HIGH,
            ThreatLevel.SUSPICIOUS: EventType.ALERT_MEDIUM
        }
        
        event_type = event_type_map.get(assessment.threat_level, EventType.ALERT_LOW)
        
        # Determine priority
        priority_map = {
            ThreatLevel.CRITICAL: EventPriority.CRITICAL,
            ThreatLevel.MALICIOUS: EventPriority.HIGH,
            ThreatLevel.SUSPICIOUS: EventPriority.MEDIUM
        }
        
        priority = priority_map.get(assessment.threat_level, EventPriority.NORMAL)
        
        # Create event data
        data = {
            'threat_level': assessment.threat_level.value,
            'confidence': assessment.confidence,
            'indicators': assessment.indicators,
            'affected_entities': assessment.affected_entities,
            'recommended_actions': assessment.recommended_actions,
            'analysis_time': assessment.analysis_time,
            'correlation_id': assessment.correlation_id
        }
        
        # Create and publish event
        behavior_event = self.event_system.create_event(
            event_type=event_type,
            source="behavior_engine",
            data=data,
            priority=priority
        )
        
        self.event_system.publish_event(behavior_event)
    
    def get_stats(self) -> Dict:
        """Get behavior engine statistics."""
        return {
            **self._stats,
            'running': self._running,
            'queue_size': len(self._analysis_queue),
            'profiles_created': len(self._correlation_engine._entity_profiles)
        }