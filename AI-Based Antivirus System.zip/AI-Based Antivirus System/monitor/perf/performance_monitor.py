"""
Performance monitoring and optimization system.

Monitors and optimizes the real-time monitoring system for minimal
system impact while maintaining high detection accuracy.

Features:
- Real-time performance metrics collection
- Adaptive resource management
- Dynamic threshold adjustment
- Performance bottleneck detection
- System resource monitoring
- Load balancing and optimization

Based on performance optimization research for real-time security systems.
"""

import os
import time
import psutil
import threading
import json
from typing import Dict, List, Optional, Tuple, Any
from dataclasses import dataclass, field
from collections import deque, defaultdict
from concurrent.futures import ThreadPoolExecutor
import statistics

from ..core.config import MonitorConfig
from ..core.event_system import get_event_system


@dataclass
class PerformanceMetrics:
    """Performance metrics data structure."""
    timestamp: float
    cpu_percent: float
    memory_usage_mb: float
    memory_percent: float
    disk_io_read: float  # MB/s
    disk_io_write: float  # MB/s
    network_io_sent: float  # MB/s
    network_io_recv: float  # MB/s
    event_queue_sizes: Dict[str, int]
    processing_latency_ms: float
    events_per_second: float
    active_threads: int
    active_connections: int


@dataclass
class ResourceThresholds:
    """Resource usage thresholds for adaptive control."""
    cpu_warning: float = 50.0
    cpu_critical: float = 80.0
    memory_warning: float = 60.0
    memory_critical: float = 85.0
    disk_io_warning: float = 100.0  # MB/s
    disk_io_critical: float = 200.0  # MB/s
    queue_size_warning: int = 5000
    queue_size_critical: int = 8000
    latency_warning_ms: float = 100.0
    latency_critical_ms: float = 500.0


class PerformanceOptimizer:
    """Optimizes monitoring system performance based on real-time metrics."""
    
    def __init__(self, config: MonitorConfig):
        self.config = config.performance
        self.thresholds = ResourceThresholds()
        self._optimization_history: List[Dict] = []
        self._current_optimizations: List[str] = []
        self._lock = threading.RLock()
        
    def should_optimize(self, metrics: PerformanceMetrics) -> List[str]:
        """Determine optimization actions based on current metrics."""
        optimizations = []
        
        # CPU optimization
        if metrics.cpu_percent > self.thresholds.cpu_critical:
            optimizations.extend([
                'reduce_event_batch_size',
                'decrease_monitoring_frequency',
                'enable_aggressive_caching'
            ])
        elif metrics.cpu_percent > self.thresholds.cpu_warning:
            optimizations.extend([
                'reduce_event_batch_size',
                'enable_caching'
            ])
        
        # Memory optimization
        if metrics.memory_percent > self.thresholds.memory_critical:
            optimizations.extend([
                'clear_event_cache',
                'reduce_cache_sizes',
                'enable_memory_compression'
            ])
        elif metrics.memory_percent > self.thresholds.memory_warning:
            optimizations.append('enable_caching')
        
        # Queue optimization
        if any(size > self.thresholds.queue_size_critical for size in metrics.event_queue_sizes.values()):
            optimizations.extend([
                'increase_processing_threads',
                'drop_low_priority_events',
                'enable_emergency_mode'
            ])
        elif any(size > self.thresholds.queue_size_warning for size in metrics.event_queue_sizes.values()):
            optimizations.append('increase_processing_threads')
        
        # Latency optimization
        if metrics.processing_latency_ms > self.thresholds.latency_critical_ms:
            optimizations.extend([
                'reduce_processing_complexity',
                'enable_fast_path_processing'
            ])
        elif metrics.processing_latency_ms > self.thresholds.latency_warning_ms:
            optimizations.append('enable_fast_path_processing')
        
        return list(set(optimizations))  # Remove duplicates
    
    def apply_optimizations(self, optimizations: List[str]) -> bool:
        """Apply performance optimizations."""
        applied = []
        
        with self._lock:
            for optimization in optimizations:
                if optimization in self._current_optimizations:
                    continue  # Already applied
                
                if self._apply_single_optimization(optimization):
                    applied.append(optimization)
                    self._current_optimizations.append(optimization)
        
        if applied:
            self._optimization_history.append({
                'timestamp': time.time(),
                'optimizations': applied,
                'metrics': self._get_current_system_state()
            })
        
        return len(applied) > 0
    
    def _apply_single_optimization(self, optimization: str) -> bool:
        """Apply a single optimization."""
        try:
            if optimization == 'reduce_event_batch_size':
                self.config.batch_timeout_ms = max(50, self.config.batch_timeout_ms // 2)
                return True
                
            elif optimization == 'decrease_monitoring_frequency':
                # This would need to be applied to individual monitors
                # For now, we'll just log it
                print("Optimization: Decreasing monitoring frequency")
                return True
                
            elif optimization == 'enable_caching':
                self.config.caching_enabled = True
                return True
                
            elif optimization == 'enable_aggressive_caching':
                self.config.caching_enabled = True
                # Increase cache sizes
                for queue_name in self.config.queue_sizes:
                    self.config.queue_sizes[queue_name] = min(
                        self.config.queue_sizes[queue_name] * 2, 10000
                    )
                return True
                
            elif optimization == 'clear_event_cache':
                # This would need to be implemented in individual components
                print("Optimization: Clearing event cache")
                return True
                
            elif optimization == 'reduce_cache_sizes':
                for queue_name in self.config.queue_sizes:
                    self.config.queue_sizes[queue_name] = max(
                        self.config.queue_sizes[queue_name] // 2, 100
                    )
                return True
                
            elif optimization == 'enable_memory_compression':
                self.config.compression_enabled = True
                return True
                
            elif optimization == 'increase_processing_threads':
                self.config.processing_threads = min(
                    self.config.processing_threads + 1, 8
                )
                return True
                
            elif optimization == 'drop_low_priority_events':
                print("Optimization: Dropping low priority events")
                return True
                
            elif optimization == 'enable_emergency_mode':
                print("Optimization: Enabling emergency mode")
                return True
                
            elif optimization == 'reduce_processing_complexity':
                print("Optimization: Reducing processing complexity")
                return True
                
            elif optimization == 'enable_fast_path_processing':
                print("Optimization: Enabling fast path processing")
                return True
                
        except Exception as e:
            print(f"Error applying optimization {optimization}: {e}")
        
        return False
    
    def _get_current_system_state(self) -> Dict:
        """Get current system state for optimization tracking."""
        return {
            'cpu_percent': psutil.cpu_percent(),
            'memory_percent': psutil.virtual_memory().percent,
            'active_threads': threading.active_count(),
            'process_count': len(psutil.pids())
        }


class ResourceMonitor:
    """Monitors system resources and performance metrics."""
    
    def __init__(self, config: MonitorConfig):
        self.config = config
        self._metrics_history: deque = deque(maxlen=360)  # Last hour (assuming 10s intervals)
        self._running = False
        self._monitor_thread = None
        self._optimizer = PerformanceOptimizer(config)
        self._last_disk_io = psutil.disk_io_counters()
        self._last_network_io = psutil.net_io_counters()
        self._last_timestamp = time.time()
        
    def start(self) -> None:
        """Start resource monitoring."""
        self._running = True
        self._monitor_thread = threading.Thread(target=self._monitor_loop, daemon=True)
        self._monitor_thread.start()
    
    def stop(self) -> None:
        """Stop resource monitoring."""
        self._running = False
        
        if self._monitor_thread:
            self._monitor_thread.join(timeout=5)
    
    def _monitor_loop(self) -> None:
        """Main monitoring loop."""
        while self._running:
            try:
                # Collect metrics
                metrics = self._collect_metrics()
                
                # Add to history
                self._metrics_history.append(metrics)
                
                # Check if optimization is needed
                optimizations = self._optimizer.should_optimize(metrics)
                if optimizations:
                    self._optimizer.apply_optimizations(optimizations)
                
                # Sleep for next measurement
                time.sleep(10)  # Collect every 10 seconds
                
            except Exception as e:
                if self._running:
                    print(f"Error in resource monitoring: {e}")
    
    def _collect_metrics(self) -> PerformanceMetrics:
        """Collect current performance metrics."""
        current_time = time.time()
        current_disk_io = psutil.disk_io_counters()
        current_network_io = psutil.net_io_counters()
        
        # Calculate rates
        time_diff = current_time - self._last_timestamp
        disk_read_rate = 0.0
        disk_write_rate = 0.0
        network_sent_rate = 0.0
        network_recv_rate = 0.0
        
        if self._last_disk_io and time_diff > 0:
            disk_read_rate = (current_disk_io.read_bytes - self._last_disk_io.read_bytes) / time_diff / 1024 / 1024
            disk_write_rate = (current_disk_io.write_bytes - self._last_disk_io.write_bytes) / time_diff / 1024 / 1024
        
        if self._last_network_io and time_diff > 0:
            network_sent_rate = (current_network_io.bytes_sent - self._last_network_io.bytes_sent) / time_diff / 1024 / 1024
            network_recv_rate = (current_network_io.bytes_recv - self._last_network_io.bytes_recv) / time_diff / 1024 / 1024
        
        # Update last values
        self._last_disk_io = current_disk_io
        self._last_network_io = current_network_io
        self._last_timestamp = current_time
        
        # Get system metrics
        cpu_percent = psutil.cpu_percent()
        memory = psutil.virtual_memory()
        
        # Get event queue sizes from event system
        event_system = get_event_system()
        event_stats = event_system.get_stats() if event_system else {}
        
        return PerformanceMetrics(
            timestamp=current_time,
            cpu_percent=cpu_percent,
            memory_usage_mb=memory.used / 1024 / 1024,
            memory_percent=memory.percent,
            disk_io_read=disk_read_rate,
            disk_io_write=disk_write_rate,
            network_io_sent=network_sent_rate,
            network_io_recv=network_recv_rate,
            event_queue_sizes=event_stats.get('event_bus', {}).get('queue_size', 0),
            processing_latency_ms=self._calculate_processing_latency(),
            events_per_second=self._calculate_events_per_second(),
            active_threads=threading.active_count(),
            active_connections=len(psutil.net_connections())
        )
    
    def _calculate_processing_latency(self) -> float:
        """Calculate average processing latency."""
        if len(self._metrics_history) < 2:
            return 0.0
        
        # Simple latency calculation based on queue sizes and processing rate
        recent_metrics = list(self._metrics_history)[-10:]  # Last 10 samples
        queue_sizes = [m.event_queue_sizes for m in recent_metrics if hasattr(m, 'event_queue_sizes')]
        
        if not queue_sizes:
            return 0.0
        
        # Calculate average queue size
        avg_queue_size = statistics.mean(
            sum(queue_dict.values()) for queue_dict in queue_sizes
        )
        
        # Estimate latency based on queue size (simplified model)
        return min(avg_queue_size * 0.1, 1000.0)  # Max 1 second
    
    def _calculate_events_per_second(self) -> float:
        """Calculate events per second processing rate."""
        if len(self._metrics_history) < 2:
            return 0.0
        
        # Calculate rate based on recent metrics
        recent_metrics = list(self._metrics_history)[-5:]  # Last 5 samples
        time_span = recent_metrics[-1].timestamp - recent_metrics[0].timestamp
        
        if time_span > 0:
            return len(recent_metrics) / time_span
        
        return 0.0
    
    def get_performance_summary(self) -> Dict:
        """Get performance summary statistics."""
        if not self._metrics_history:
            return {}
        
        recent_metrics = list(self._metrics_history)[-60:]  # Last 10 minutes
        
        return {
            'avg_cpu_percent': statistics.mean(m.cpu_percent for m in recent_metrics),
            'max_cpu_percent': max(m.cpu_percent for m in recent_metrics),
            'avg_memory_percent': statistics.mean(m.memory_percent for m in recent_metrics),
            'max_memory_percent': max(m.memory_percent for m in recent_metrics),
            'avg_events_per_second': statistics.mean(m.events_per_second for m in recent_metrics),
            'max_events_per_second': max(m.events_per_second for m in recent_metrics),
            'avg_processing_latency_ms': statistics.mean(m.processing_latency_ms for m in recent_metrics),
            'optimizations_applied': len(self._optimizer._current_optimizations),
            'current_optimizations': self._optimizer._current_optimizations.copy()
        }
    
    def get_current_metrics(self) -> Optional[PerformanceMetrics]:
        """Get latest performance metrics."""
        if self._metrics_history:
            return self._metrics_history[-1]
        return None
    
    def get_metrics_history(self, minutes: int = 60) -> List[PerformanceMetrics]:
        """Get metrics history for specified time period."""
        cutoff_time = time.time() - (minutes * 60)
        return [m for m in self._metrics_history if m.timestamp > cutoff_time]


class PerformanceMonitor:
    """Main performance monitoring system."""
    
    def __init__(self, config: MonitorConfig):
        self.config = config
        self._resource_monitor = ResourceMonitor(config)
        self._running = False
        
    def start(self) -> None:
        """Start performance monitoring."""
        if not self.config.performance.caching_enabled:
            return
        
        self._resource_monitor.start()
        self._running = True
    
    def stop(self) -> None:
        """Stop performance monitoring."""
        self._resource_monitor.stop()
        self._running = False
    
    def get_stats(self) -> Dict:
        """Get performance monitor statistics."""
        return {
            'running': self._running,
            'current_metrics': self._resource_monitor.get_current_metrics().__dict__ if self._resource_monitor.get_current_metrics() else None,
            'performance_summary': self._resource_monitor.get_performance_summary()
        }
    
    def get_optimization_recommendations(self) -> List[str]:
        """Get performance optimization recommendations."""
        current_metrics = self._resource_monitor.get_current_metrics()
        if not current_metrics:
            return []
        
        return self._resource_monitor._optimizer.should_optimize(current_metrics)