"""
Alert and notification system for real-time monitoring.

Provides comprehensive alert management with:
- Severity-based alert classification
- Event correlation and aggregation
- Multiple notification channels (email, webhook, etc.)
- Alert suppression and deduplication
- Response action orchestration
- Performance monitoring and metrics

Based on SIEM and security operations best practices.
"""

import os
import time
import json
import smtplib
import threading
import requests
from email.mime.text import MimeText
from email.mime.multipart import MimeMultipart
from typing import Dict, List, Set, Optional, Callable, Any
from dataclasses import dataclass, field
from collections import defaultdict, deque
from concurrent.futures import ThreadPoolExecutor
from enum import Enum

from ..core.event_system import EventSystem, EventType, EventPriority, get_event_system
from ..core.config import MonitorConfig


class AlertSeverity(Enum):
    """Alert severity levels."""
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"


class AlertStatus(Enum):
    """Alert status states."""
    NEW = "new"
    ACKNOWLEDGED = "acknowledged"
    RESOLVED = "resolved"
    SUPPRESSED = "suppressed"
    ESCALATED = "escalated"


@dataclass
class Alert:
    """Alert data structure."""
    id: str
    title: str
    description: str
    severity: AlertSeverity
    status: AlertStatus
    source: str
    timestamp: float
    correlation_id: str
    affected_entities: List[str]
    indicators: List[str]
    recommended_actions: List[str]
    confidence: float
    event_count: int = 1
    suppression_count: int = 0
    escalation_level: int = 0
    response_actions: List[str] = field(default_factory=list)


class AlertAggregator:
    """Aggregates and correlates alerts to reduce noise."""
    
    def __init__(self, config: AlertConfig):
        self.config = config
        self._alert_cache: Dict[str, Alert] = {}
        self._aggregation_window = config.aggregation_interval
        self._suppression_window = config.suppression_window
        self._max_alerts_per_minute = config.max_alerts_per_minute
        self._alert_counts: Dict[str, deque] = defaultdict(lambda: deque(maxlen=60))
        self._lock = threading.RLock()
        
    def should_suppress_alert(self, alert: Alert) -> Tuple[bool, Optional[Alert]]:
        """Check if alert should be suppressed based on aggregation rules."""
        with self._lock:
            # Check for similar alerts within suppression window
            current_time = time.time()
            cutoff_time = current_time - self._suppression_window
            
            for cached_alert in self._alert_cache.values():
                if self._is_similar_alert(alert, cached_alert):
                    # Check if cached alert is still within suppression window
                    if cached_alert.timestamp > cutoff_time:
                        # Update suppression count
                        cached_alert.suppression_count += 1
                        cached_alert.event_count += 1
                        return True, cached_alert
            
            return False, None
    
    def _is_similar_alert(self, alert1: Alert, alert2: Alert) -> bool:
        """Check if two alerts are similar enough to be aggregated."""
        # Check severity
        if alert1.severity != alert2.severity:
            return False
        
        # Check source
        if alert1.source != alert2.source:
            return False
        
        # Check title similarity (simple string matching)
        if alert1.title != alert2.title:
            return False
        
        # Check if they affect similar entities
        common_entities = set(alert1.affected_entities) & set(alert2.affected_entities)
        if len(common_entities) > 0:
            return True
        
        return False
    
    def should_rate_limit(self, source: str) -> bool:
        """Check if alerts from source should be rate limited."""
        with self._lock:
            current_time = time.time()
            self._alert_counts[source].append(current_time)
            
            # Count alerts in the last minute
            cutoff_time = current_time - 60
            recent_alerts = [t for t in self._alert_counts[source] if t > cutoff_time]
            
            return len(recent_alerts) > self._max_alerts_per_minute


class NotificationChannel:
    """Base class for notification channels."""
    
    def __init__(self, name: str, config: Dict[str, Any]):
        self.name = name
        self.config = config
        self.enabled = config.get('enabled', True)
    
    def send_notification(self, alert: Alert) -> bool:
        """Send notification for an alert."""
        raise NotImplementedError


class EmailChannel(NotificationChannel):
    """Email notification channel."""
    
    def __init__(self, config: Dict[str, Any]):
        super().__init__("email", config)
        self.smtp_server = config.get('smtp_server', 'localhost')
        self.smtp_port = config.get('smtp_port', 587)
        self.username = config.get('username', '')
        self.password = config.get('password', '')
        self.from_address = config.get('from_address', 'antivirus@localhost')
        self.to_addresses = config.get('to_addresses', [])
    
    def send_notification(self, alert: Alert) -> bool:
        """Send email notification."""
        if not self.enabled or not self.to_addresses:
            return False
        
        try:
            # Create email message
            msg = MimeMultipart()
            msg['From'] = self.from_address
            msg['To'] = ', '.join(self.to_addresses)
            msg['Subject'] = f"[{alert.severity.value.upper()}] {alert.title}"
            
            # Create email body
            body = self._format_alert_email(alert)
            msg.attach(MimeText(body, 'html'))
            
            # Send email
            if self.smtp_server and self.username and self.password:
                server = smtplib.SMTP(self.smtp_server, self.smtp_port)
                server.starttls()
                server.login(self.username, self.password)
                server.send_message(msg)
                server.quit()
            else:
                # Use local sendmail
                server = smtplib.SMTP('localhost')
                server.send_message(msg)
                server.quit()
            
            return True
            
        except Exception as e:
            print(f"Error sending email notification: {e}")
            return False
    
    def _format_alert_email(self, alert: Alert) -> str:
        """Format alert for email notification."""
        return f"""
        <html>
        <body>
        <h2>Antivirus Alert - {alert.severity.value.upper()}</h2>
        
        <h3>Alert Details</h3>
        <p><strong>Title:</strong> {alert.title}</p>
        <p><strong>Description:</strong> {alert.description}</p>
        <p><strong>Source:</strong> {alert.source}</p>
        <p><strong>Confidence:</strong> {alert.confidence:.2%}</p>
        <p><strong>Time:</strong> {time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(alert.timestamp))}</p>
        
        <h3>Affected Entities</h3>
        <ul>
        {''.join(f'<li>{entity}</li>' for entity in alert.affected_entities)}
        </ul>
        
        <h3>Indicators</h3>
        <ul>
        {''.join(f'<li>{indicator}</li>' for indicator in alert.indicators)}
        </ul>
        
        <h3>Recommended Actions</h3>
        <ul>
        {''.join(f'<li>{action}</li>' for action in alert.recommended_actions)}
        </ul>
        
        <p><em>This alert was generated by the AI Antivirus Real-Time Monitoring System.</em></p>
        </body>
        </html>
        """


class WebhookChannel(NotificationChannel):
    """Webhook notification channel."""
    
    def __init__(self, config: Dict[str, Any]):
        super().__init__("webhook", config)
        self.url = config.get('url', '')
        self.headers = config.get('headers', {})
        self.timeout = config.get('timeout', 10)
    
    def send_notification(self, alert: Alert) -> bool:
        """Send webhook notification."""
        if not self.enabled or not self.url:
            return False
        
        try:
            payload = {
                'alert': {
                    'id': alert.id,
                    'title': alert.title,
                    'description': alert.description,
                    'severity': alert.severity.value,
                    'source': alert.source,
                    'timestamp': alert.timestamp,
                    'confidence': alert.confidence,
                    'affected_entities': alert.affected_entities,
                    'indicators': alert.indicators,
                    'recommended_actions': alert.recommended_actions
                }
            }
            
            response = requests.post(
                self.url,
                json=payload,
                headers=self.headers,
                timeout=self.timeout
            )
            
            return response.status_code == 200
            
        except Exception as e:
            print(f"Error sending webhook notification: {e}")
            return False


class AlertSystem:
    """Main alert and notification system."""
    
    def __init__(self, config: MonitorConfig):
        self.config = config.alert_config
        self.event_system = get_event_system()
        self._alert_store: Dict[str, Alert] = {}
        self._alert_aggregator = AlertAggregator(self.config)
        self._notification_channels: List[NotificationChannel] = []
        self._running = False
        self._stats = {
            'alerts_created': 0,
            'alerts_suppressed': 0,
            'notifications_sent': 0,
            'alerts_resolved': 0
        }
        self._lock = threading.RLock()
        
        # Initialize notification channels
        self._setup_notification_channels()
        
        # Setup event subscriptions
        self._setup_event_subscriptions()
    
    def start(self) -> None:
        """Start the alert system."""
        if not self.config.enabled:
            return
        
        self._running = True
        
        # Start background tasks
        threading.Thread(target=self._cleanup_loop, daemon=True).start()
    
    def stop(self) -> None:
        """Stop the alert system."""
        self._running = False
    
    def _setup_notification_channels(self) -> None:
        """Setup notification channels from configuration."""
        # Email notifications
        if self.config.escalation_rules.get('high', {}).get('email', False):
            email_config = {
                'enabled': True,
                'smtp_server': os.getenv('SMTP_SERVER', 'localhost'),
                'smtp_port': int(os.getenv('SMTP_PORT', '587')),
                'username': os.getenv('SMTP_USERNAME', ''),
                'password': os.getenv('SMTP_PASSWORD', ''),
                'from_address': os.getenv('ALERT_FROM_EMAIL', 'antivirus@localhost'),
                'to_addresses': os.getenv('ALERT_TO_EMAILS', '').split(',')
            }
            self._notification_channels.append(EmailChannel(email_config))
        
        # Webhook notifications
        webhook_url = os.getenv('ALERT_WEBHOOK_URL', '')
        if webhook_url and self.config.escalation_rules.get('high', {}).get('webhook', False):
            webhook_config = {
                'enabled': True,
                'url': webhook_url,
                'headers': {'Content-Type': 'application/json'},
                'timeout': 10
            }
            self._notification_channels.append(WebhookChannel(webhook_config))
    
    def _setup_event_subscriptions(self) -> None:
        """Setup event subscriptions for alert processing."""
        alert_event_types = [
            EventType.ALERT_LOW, EventType.ALERT_MEDIUM, 
            EventType.ALERT_HIGH, EventType.ALERT_CRITICAL,
            EventType.ALERT_CORRELATED
        ]
        
        def alert_handler(event):
            self._process_alert_event(event)
        
        self.event_system.subscribe("alert_system", alert_event_types, alert_handler)
    
    def _process_alert_event(self, event) -> None:
        """Process alert event and create notifications."""
        data = event.data
        source = event.source
        
        # Create alert
        alert = Alert(
            id=f"alert_{int(time.time())}_{hash(source) % 10000}",
            title=data.get('title', 'Security Alert'),
            description=data.get('description', 'No description available'),
            severity=self._map_event_type_to_severity(event.type),
            status=AlertStatus.NEW,
            source=source,
            timestamp=event.timestamp,
            correlation_id=event.correlation_id or "",
            affected_entities=data.get('affected_entities', []),
            indicators=data.get('indicators', []),
            recommended_actions=data.get('recommended_actions', []),
            confidence=data.get('confidence', 0.0)
        )
        
        # Check for suppression
        should_suppress, existing_alert = self._alert_aggregator.should_suppress_alert(alert)
        
        if should_suppress and existing_alert:
            # Increment suppression count
            with self._lock:
                self._stats['alerts_suppressed'] += 1
            return
        
        # Check rate limiting
        if self._alert_aggregator.should_rate_limit(source):
            print(f"Rate limiting alerts from source: {source}")
            return
        
        # Store alert
        with self._lock:
            self._alert_store[alert.id] = alert
            self._stats['alerts_created'] += 1
        
        # Send notifications based on severity
        if alert.severity in [AlertSeverity.HIGH, AlertSeverity.CRITICAL]:
            self._send_notifications(alert)
        
        # Auto-escalate if needed
        if alert.severity == AlertSeverity.CRITICAL:
            self._escalate_alert(alert)
    
    def _map_event_type_to_severity(self, event_type: EventType) -> AlertSeverity:
        """Map event type to alert severity."""
        severity_map = {
            EventType.ALERT_CRITICAL: AlertSeverity.CRITICAL,
            EventType.ALERT_HIGH: AlertSeverity.HIGH,
            EventType.ALERT_MEDIUM: AlertSeverity.MEDIUM,
            EventType.ALERT_LOW: AlertSeverity.LOW,
            EventType.ALERT_CORRELATED: AlertSeverity.HIGH
        }
        
        return severity_map.get(event_type, AlertSeverity.LOW)
    
    def _send_notifications(self, alert: Alert) -> None:
        """Send notifications for alert."""
        with ThreadPoolExecutor(max_workers=3) as executor:
            futures = []
            
            for channel in self._notification_channels:
                if channel.enabled:
                    future = executor.submit(channel.send_notification, alert)
                    futures.append(future)
            
            # Wait for all notifications to complete
            success_count = 0
            for future in futures:
                try:
                    if future.result(timeout=30):
                        success_count += 1
                except Exception as e:
                    print(f"Notification failed: {e}")
            
            with self._lock:
                if success_count > 0:
                    self._stats['notifications_sent'] += 1
    
    def _escalate_alert(self, alert: Alert) -> None:
        """Escalate critical alert."""
        alert.escalation_level += 1
        alert.status = AlertStatus.ESCALATED
        
        # Send immediate notifications
        for channel in self._notification_channels:
            if hasattr(channel, 'enabled') and channel.enabled:
                try:
                    channel.send_notification(alert)
                except Exception as e:
                    print(f"Error escalating alert: {e}")
    
    def _cleanup_loop(self) -> None:
        """Background cleanup loop."""
        while self._running:
            try:
                # Clean up old alerts
                current_time = time.time()
                cutoff_time = current_time - 24 * 3600  # 24 hours
                
                with self._lock:
                    expired_alerts = [
                        alert_id for alert_id, alert in self._alert_store.items()
                        if alert.timestamp < cutoff_time and alert.status == AlertStatus.RESOLVED
                    ]
                    
                    for alert_id in expired_alerts:
                        del self._alert_store[alert_id]
                
                # Clean up alert count history
                current_minute = int(current_time / 60)
                for source in list(self._alert_aggregator._alert_counts.keys()):
                    # Remove old timestamps
                    cutoff_timestamp = (current_minute - 60) * 60
                    self._alert_aggregator._alert_counts[source] = deque(
                        [t for t in self._alert_aggregator._alert_counts[source] if t > cutoff_timestamp],
                        maxlen=60
                    )
                
                time.sleep(300)  # Clean up every 5 minutes
                
            except Exception as e:
                if self._running:
                    print(f"Error in alert cleanup: {e}")
    
    def get_alert_summary(self) -> Dict:
        """Get alert summary statistics."""
        with self._lock:
            return {
                'total_alerts': len(self._alert_store),
                'active_alerts': len([a for a in self._alert_store.values() if a.status == AlertStatus.NEW]),
                'escalated_alerts': len([a for a in self._alert_store.values() if a.status == AlertStatus.ESCALATED]),
                'resolved_alerts': len([a for a in self._alert_store.values() if a.status == AlertStatus.RESOLVED]),
                'severity_breakdown': {
                    'low': len([a for a in self._alert_store.values() if a.severity == AlertSeverity.LOW]),
                    'medium': len([a for a in self._alert_store.values() if a.severity == AlertSeverity.MEDIUM]),
                    'high': len([a for a in self._alert_store.values() if a.severity == AlertSeverity.HIGH]),
                    'critical': len([a for a in self._alert_store.values() if a.severity == AlertSeverity.CRITICAL])
                }
            }
    
    def get_stats(self) -> Dict:
        """Get alert system statistics."""
        with self._lock:
            return {
                **self._stats,
                'running': self._running,
                'notification_channels': len(self._notification_channels),
                'alert_summary': self.get_alert_summary()
            }