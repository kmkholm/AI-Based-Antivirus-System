"""
Network traffic monitoring and analysis for real-time threat detection.

Provides comprehensive network monitoring capabilities including:
- Real-time network traffic capture and analysis
- DNS monitoring and suspicious domain detection
- Connection pattern analysis
- Data exfiltration detection
- C2 communication pattern detection
- Performance-optimized for high-throughput environments

Based on network behavior analysis research for detecting malicious network activities.
"""

import os
import time
import socket
import threading
import platform
import ipaddress
from typing import Dict, List, Set, Optional, Tuple, Any
from dataclasses import dataclass, field
from collections import defaultdict, deque
from concurrent.futures import ThreadPoolExecutor
import json
import hashlib

# Optional imports for packet capture
try:
    import scapy.all as scapy
    SCAPY_AVAILABLE = True
except ImportError:
    SCAPY_AVAILABLE = False

from ..core.event_system import EventSystem, EventType, EventPriority, get_event_system
from ..core.config import MonitorConfig


@dataclass
class NetworkConnection:
    """Network connection data."""
    protocol: str  # tcp, udp, icmp
    local_address: str
    local_port: int
    remote_address: str
    remote_port: int
    state: str  # established, listening, closed, etc.
    pid: Optional[int] = None
    process_name: str = ""
    user_id: int = 0
    first_seen: float = field(default_factory=time.time)
    last_seen: float = field(default_factory=time.time)
    bytes_sent: int = 0
    bytes_received: int = 0
    packets_sent: int = 0
    packets_received: int = 0
    suspicious_score: float = 0.0
    dns_queries: List[str] = field(default_factory=list)
    user_agent: str = ""


@dataclass
class DNSEvent:
    """DNS query event."""
    domain: str
    query_type: str  # A, AAAA, CNAME, MX, etc.
    response_ip: Optional[str] = None
    timestamp: float = field(default_factory=time.time)
    pid: Optional[int] = None
    process_name: str = ""


class NetworkAnalyzer:
    """Analyzes network traffic for suspicious patterns."""
    
    def __init__(self, config: NetworkMonitorConfig):
        self.config = config
        self._connection_patterns: Dict[str, List[NetworkConnection]] = defaultdict(list)
        self._dns_patterns: Dict[str, List[DNSEvent]] = defaultdict(list)
        self._suspicious_domains = set(config.suspicious_domains)
        self._dns_suspicious_patterns = set(config.dns_suspicious_patterns)
        self._known_c2_ports = {8080, 8443, 443, 80, 53, 22, 25, 110, 143, 993, 995}
        
        # Known malicious IP ranges (simplified)
        self._malicious_ips = set()
        
        # Domains to monitor
        self._monitored_domains = set()
    
    def analyze_connection(self, connection: NetworkConnection) -> Tuple[float, List[str]]:
        """Analyze network connection for suspicious patterns."""
        score = 0.0
        indicators = []
        
        # Check for suspicious ports
        if self._is_suspicious_port(connection.remote_port):
            score += 0.3
            indicators.append(f"suspicious_port:{connection.remote_port}")
        
        # Check for known C2 ports
        if connection.remote_port in self._known_c2_ports:
            score += 0.2
            indicators.append("c2_port")
        
        # Check for suspicious process
        if self._is_suspicious_process(connection.process_name):
            score += 0.4
            indicators.append("suspicious_process")
        
        # Check connection frequency
        if self._is_high_frequency_connection(connection):
            score += 0.3
            indicators.append("high_frequency_connection")
        
        # Check for data exfiltration patterns
        if self._is_data_exfiltration(connection):
            score += 0.5
            indicators.append("data_exfiltration")
        
        # Check for beaconing patterns
        if self._is_beaconing_pattern(connection):
            score += 0.4
            indicators.append("beaconing")
        
        # Check for port scanning
        if self._is_port_scanning(connection):
            score += 0.4
            indicators.append("port_scanning")
        
        return min(1.0, score), indicators
    
    def _is_suspicious_port(self, port: int) -> bool:
        """Check if port number is suspicious."""
        suspicious_ports = {
            1337, 31337, 4444, 5555, 6666, 7777, 8888, 9999,
            1234, 4321, 12345, 54321,
            4443, 6667, 8080, 8443
        }
        
        return port in suspicious_ports or port < 1024
    
    def _is_suspicious_process(self, process_name: str) -> bool:
        """Check if process name is suspicious."""
        suspicious_processes = {
            'cmd.exe', 'powershell.exe', 'wscript.exe', 'cscript.exe',
            'rundll32.exe', 'regsvr32.exe', 'mshta.exe', 'wmic.exe',
            'bitsadmin.exe', 'certutil.exe', 'curl.exe', 'wget.exe',
            'nc.exe', 'netcat.exe', 'ncat.exe', 'telnet.exe'
        }
        
        return process_name.lower() in suspicious_processes
    
    def _is_high_frequency_connection(self, connection: NetworkConnection) -> bool:
        """Check for high-frequency connection patterns."""
        # Check if same process connects to many different IPs
        connections_from_process = [
            conn for conn in self._connection_patterns[connection.process_name]
            if conn.pid == connection.pid
        ]
        
        unique_ips = set(conn.remote_address for conn in connections_from_process)
        
        # More than 10 unique IPs in short time could indicate scanning
        if len(unique_ips) > 10:
            return True
        
        return False
    
    def _is_data_exfiltration(self, connection: NetworkConnection) -> bool:
        """Check for data exfiltration patterns."""
        # Check if outbound data is much higher than inbound
        total_sent = connection.bytes_sent
        total_received = connection.bytes_received
        
        if total_sent > self.config.data_exfiltration_threshold_mb * 1024 * 1024:
            ratio = total_sent / max(total_received, 1)
            if ratio > 10:  # Sent 10x more than received
                return True
        
        return False
    
    def _is_beaconing_pattern(self, connection: NetworkConnection) -> bool:
        """Check for periodic beaconing patterns."""
        connections = self._connection_patterns.get(connection.process_name, [])
        
        # Look for regular intervals between connections to same IP
        same_ip_connections = [
            conn for conn in connections
            if conn.remote_address == connection.remote_address
        ]
        
        if len(same_ip_connections) >= 3:
            intervals = []
            for i in range(1, len(same_ip_connections)):
                interval = same_ip_connections[i].last_seen - same_ip_connections[i-1].last_seen
                intervals.append(interval)
            
            # Check if intervals are consistent (within 20% variance)
            if len(intervals) > 0:
                avg_interval = sum(intervals) / len(intervals)
                consistent_intervals = sum(
                    1 for interval in intervals
                    if abs(interval - avg_interval) < avg_interval * 0.2
                )
                
                if consistent_intervals / len(intervals) > 0.7:
                    return True
        
        return False
    
    def _is_port_scanning(self, connection: NetworkConnection) -> bool:
        """Check for port scanning patterns."""
        connections = self._connection_patterns.get(connection.process_name, [])
        
        # Check if one process tries to connect to many different ports
        same_ip_connections = [
            conn for conn in connections
            if conn.remote_address == connection.remote_address
        ]
        
        unique_ports = set(conn.remote_port for conn in same_ip_connections)
        
        # More than 20 different ports to same IP could indicate scanning
        if len(unique_ports) > 20:
            return True
        
        return False
    
    def analyze_dns(self, dns_event: DNSEvent) -> Tuple[float, List[str]]:
        """Analyze DNS query for suspicious patterns."""
        score = 0.0
        indicators = []
        
        # Check for suspicious domain patterns
        if self._is_suspicious_domain(dns_event.domain):
            score += 0.5
            indicators.append("suspicious_domain")
        
        # Check for DGA (Domain Generation Algorithm) patterns
        if self._is_dga_domain(dns_event.domain):
            score += 0.6
            indicators.append("dga_domain")
        
        # Check for subdomain patterns
        if self._is_suspicious_subdomain(dns_event.domain):
            score += 0.3
            indicators.append("suspicious_subdomain")
        
        # Check for IP-based domains
        if self._is_ip_based_domain(dns_event.domain):
            score += 0.4
            indicators.append("ip_based_domain")
        
        return min(1.0, score), indicators
    
    def _is_suspicious_domain(self, domain: str) -> bool:
        """Check if domain is suspicious."""
        # Check against known suspicious domains
        for suspicious_domain in self._suspicious_domains:
            if suspicious_domain.endswith('*'):
                # Wildcard matching
                pattern = suspicious_domain[:-1]
                if domain.endswith(pattern) or pattern in domain:
                    return True
            elif suspicious_domain in domain:
                return True
        
        # Check for suspicious TLDs
        suspicious_tlds = {'.onion', '.tor', '.i2p', '.bit', '.sil'}
        domain_lower = domain.lower()
        
        return any(domain_lower.endswith(tld) for tld in suspicious_tlds)
    
    def _is_dga_domain(self, domain: str) -> bool:
        """Check for Domain Generation Algorithm patterns."""
        # Simple heuristics for DGA detection
        parts = domain.split('.')
        
        for part in parts[:-1]:  # Exclude TLD
            # Check for random-looking strings
            if len(part) > 10 and part.isalnum():
                # Check character distribution
                if len(set(part)) > len(part) * 0.6:  # High entropy
                    # Check for mix of letters and numbers
                    if any(c.isalpha() for c in part) and any(c.isdigit() for c in part):
                        return True
        
        return False
    
    def _is_suspicious_subdomain(self, domain: str) -> bool:
        """Check for suspicious subdomain patterns."""
        parts = domain.split('.')
        
        if len(parts) < 3:
            return False
        
        # Check for long subdomains
        for part in parts[:-2]:  # Exclude main domain and TLD
            if len(part) > 15:
                return True
        
        # Check for many subdomains
        if len(parts) > 4:
            return True
        
        return False
    
    def _is_ip_based_domain(self, domain: str) -> bool:
        """Check if domain is IP-based instead of domain-based."""
        # Check if it looks like an IP address
        try:
            ipaddress.ip_address(domain)
            return True
        except ValueError:
            pass
        
        # Check for numeric domains
        if domain.replace('.', '').isdigit():
            return True
        
        return False


class PlatformNetworkMonitor:
    """Base class for platform-specific network monitors."""
    
    def __init__(self, config: NetworkMonitorConfig, event_system: EventSystem):
        self.config = config
        self.event_system = event_system
        self._running = False
        self._connections: Dict[str, NetworkConnection] = {}
        self._dns_cache: List[DNSEvent] = []
        self._analyzer = NetworkAnalyzer(config)
        self._capture_thread = None
        self._stats = {
            'packets_captured': 0,
            'connections_tracked': 0,
            'dns_queries': 0
        }
    
    def start(self) -> bool:
        """Start network monitoring."""
        raise NotImplementedError
    
    def stop(self) -> None:
        """Stop network monitoring."""
        self._running = False
    
    def _get_current_connections(self) -> List[NetworkConnection]:
        """Get current network connections using system APIs."""
        connections = []
        
        try:
            import psutil
            
            for conn in psutil.net_connections():
                if conn.status == 'ESTABLISHED' and conn.raddr:
                    connection = NetworkConnection(
                        protocol='tcp' if conn.family == socket.AF_INET else 'tcp',
                        local_address=str(conn.laddr.ip),
                        local_port=conn.laddr.port,
                        remote_address=str(conn.raddr.ip),
                        remote_port=conn.raddr.port,
                        state=conn.status,
                        pid=conn.pid
                    )
                    connections.append(connection)
                    
        except Exception:
            pass
        
        return connections
    
    def _track_connection(self, connection: NetworkConnection) -> None:
        """Track network connection."""
        # Find process information
        try:
            import psutil
            if connection.pid:
                process = psutil.Process(connection.pid)
                connection.process_name = process.name()
        except (psutil.NoSuchProcess, psutil.AccessDenied):
            pass
        
        # Analyze connection
        suspicious_score, indicators = self._analyzer.analyze_connection(connection)
        connection.suspicious_score = suspicious_score
        
        # Update stats
        self._stats['connections_tracked'] += 1
        
        # Publish event if suspicious
        if suspicious_score > 0.3:
            self._publish_network_event(connection, indicators)
    
    def _publish_network_event(self, connection: NetworkConnection, indicators: List[str]) -> None:
        """Publish network connection event."""
        # Determine event type based on indicators
        if any('exfiltration' in indicator for indicator in indicators):
            event_type = EventType.NETWORK_EXFILTRATION
            priority = EventPriority.HIGH
        elif any('beaconing' in indicator for indicator in indicators):
            event_type = EventType.NETWORK_SUSPICIOUS
            priority = EventPriority.MEDIUM
        else:
            event_type = EventType.NETWORK_CONNECT
            priority = EventPriority.NORMAL
        
        # Create event data
        data = {
            'protocol': connection.protocol,
            'local_address': connection.local_address,
            'local_port': connection.local_port,
            'remote_address': connection.remote_address,
            'remote_port': connection.remote_port,
            'state': connection.state,
            'pid': connection.pid,
            'process_name': connection.process_name,
            'suspicious_score': connection.suspicious_score,
            'indicators': indicators,
            'bytes_sent': connection.bytes_sent,
            'bytes_received': connection.bytes_received
        }
        
        # Create and publish event
        network_event = self.event_system.create_event(
            event_type=event_type,
            source="network_monitor",
            data=data,
            priority=priority
        )
        
        self.event_system.publish_event(network_event)


class LinuxNetworkMonitor(PlatformNetworkMonitor):
    """Linux-specific network monitor."""
    
    def __init__(self, config: NetworkMonitorConfig, event_system: EventSystem):
        super().__init__(config, event_system)
        self._packet_socket = None
    
    def start(self) -> bool:
        """Start Linux network monitoring."""
        try:
            # Check if we can use packet capture
            if not SCAPY_AVAILABLE:
                print("Scapy not available for packet capture")
                return False
            
            # Try to create packet socket
            try:
                self._packet_socket = socket.socket(socket.AF_PACKET, socket.SOCK_RAW, socket.ntohs(0x0003))
                self._packet_socket.setsockopt(socket.SOL_SOCKET, socket.SO_RCVBUF, 2*1024*1024)  # 2MB buffer
            except PermissionError:
                print("Permission denied for packet capture - running without packet-level monitoring")
            
            self._running = True
            
            # Start monitoring threads
            self._capture_thread = threading.Thread(target=self._capture_loop, daemon=True)
            self._capture_thread.start()
            
            return True
            
        except Exception as e:
            print(f"Error starting Linux network monitor: {e}")
            return False
    
    def _capture_loop(self) -> None:
        """Packet capture loop."""
        while self._running:
            try:
                if self._packet_socket:
                    # Simplified packet capture
                    # In practice, you'd use scapy to parse packets
                    data, addr = self._packet_socket.recvfrom(65535)
                    self._stats['packets_captured'] += 1
                
                # Also monitor connections periodically
                connections = self._get_current_connections()
                for conn in connections:
                    self._track_connection(conn)
                
                time.sleep(1)  # Check every second
                
            except Exception as e:
                if self._running:
                    print(f"Error in network capture: {e}")


class WindowsNetworkMonitor(PlatformNetworkMonitor):
    """Windows-specific network monitor."""
    
    def start(self) -> bool:
        """Start Windows network monitoring."""
        try:
            self._running = True
            
            # Start monitoring thread
            self._capture_thread = threading.Thread(target=self._monitor_loop, daemon=True)
            self._capture_thread.start()
            
            return True
            
        except Exception as e:
            print(f"Error starting Windows network monitor: {e}")
            return False
    
    def _monitor_loop(self) -> None:
        """Network monitoring loop."""
        while self._running:
            try:
                # Monitor connections
                connections = self._get_current_connections()
                for conn in connections:
                    self._track_connection(conn)
                
                time.sleep(1)  # Check every second
                
            except Exception as e:
                if self._running:
                    print(f"Error in Windows network monitoring: {e}")


class NetworkMonitor:
    """Main network monitoring system."""
    
    def __init__(self, config: MonitorConfig):
        self.config = config.network_monitor
        self.event_system = get_event_system()
        self._monitor: Optional[PlatformNetworkMonitor] = None
        self._running = False
        self._dns_thread = None
        self._dns_cache = []
    
    def start(self) -> bool:
        """Start network monitoring."""
        if not self.config.enabled:
            return False
        
        # Create platform-specific monitor
        system = platform.system().lower()
        
        if system == 'linux':
            self._monitor = LinuxNetworkMonitor(self.config, self.event_system)
        elif system == 'windows':
            self._monitor = WindowsNetworkMonitor(self.config, self.event_system)
        else:
            print(f"Network monitoring not supported on {system}")
            return False
        
        # Start the monitor
        if self._monitor.start():
            self._running = True
            
            # Start DNS monitoring thread
            if self.config.dns_monitoring:
                self._dns_thread = threading.Thread(target=self._dns_monitor_loop, daemon=True)
                self._dns_thread.start()
            
            return True
        
        return False
    
    def stop(self) -> None:
        """Stop network monitoring."""
        self._running = False
        
        if self._monitor:
            self._monitor.stop()
        
        if self._dns_thread:
            self._dns_thread.join(timeout=5)
    
    def _dns_monitor_loop(self) -> None:
        """DNS monitoring loop."""
        while self._running:
            try:
                # Simulate DNS monitoring
                # In practice, you'd monitor DNS queries
                time.sleep(1)
                
            except Exception as e:
                if self._running:
                    print(f"Error in DNS monitoring: {e}")
    
    def get_stats(self) -> Dict:
        """Get network monitor statistics."""
        stats = {
            'running': self._running,
            'platform': platform.system().lower()
        }
        
        if self._monitor:
            stats.update(self._monitor._stats)
        
        return stats