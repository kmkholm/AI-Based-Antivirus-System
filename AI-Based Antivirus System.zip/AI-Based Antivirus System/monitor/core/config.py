"""
Configuration system for real-time monitoring components.

Handles all configuration parameters for:
- File system monitoring
- Process monitoring  
- System call interception
- Network monitoring
- Alert thresholds
- Performance optimization settings
"""

import json
import os
from typing import Dict, List, Optional, Union
from dataclasses import dataclass, field, asdict
from pathlib import Path


@dataclass
class FileMonitorConfig:
    """Configuration for file system monitoring."""
    enabled: bool = True
    watch_paths: List[str] = field(default_factory=lambda: ["/", "/tmp", "/var/log"])
    recursive: bool = True
    event_types: List[str] = field(default_factory=lambda: [
        'create', 'modify', 'delete', 'access', 'move', 'rename'
    ])
    exclude_patterns: List[str] = field(default_factory=lambda: [
        '*.tmp', '*.swp', '*~', '.git/*', '__pycache__/*'
    ])
    scan_threshold_mb: int = 100  # Skip scanning files larger than this
    cache_size: int = 1000  # Number of file checksums to cache
    batch_size: int = 50  # Process events in batches for performance


@dataclass
class ProcessMonitorConfig:
    """Configuration for process monitoring and behavioral analysis."""
    enabled: bool = True
    scan_interval_ms: int = 100  # Process scanning frequency
    behavior_window_size: int = 10  # Number of recent actions to analyze
    suspicious_processes: List[str] = field(default_factory=lambda: [
        'cmd.exe', 'powershell.exe', 'wmic', 'reg', 'net', 'whoami'
    ])
    parent_child_monitoring: bool = True
    command_line_monitoring: bool = True
    environment_monitoring: bool = True
    privilege_escalation_detection: bool = True
    process_injection_patterns: List[str] = field(default_factory=lambda: [
        'VirtualAllocEx', 'WriteProcessMemory', 'CreateRemoteThread'
    ])


@dataclass
class SyscallMonitorConfig:
    """Configuration for system call monitoring."""
    enabled: bool = True
    platform: str = "auto"  # auto, linux, windows, macos
    syscall_patterns: List[str] = field(default_factory=lambda: [
        'open', 'execve', 'fork', 'clone', 'mmap', 'mprotect', 'prctl',
        'CreateProcess', 'VirtualAlloc', 'CreateFile', 'WriteFile', 'SetWindowsHook'
    ])
    sequence_analysis: bool = True
    time_window_ms: int = 5000  # Time window for sequence analysis
    anomaly_threshold: float = 0.7  # Threshold for anomaly detection
    ignore_benign_patterns: bool = True


@dataclass
class NetworkMonitorConfig:
    """Configuration for network traffic monitoring."""
    enabled: bool = True
    interface: str = "auto"  # auto-detect or specific interface
    capture_packets: bool = True
    protocol_filter: List[str] = field(default_factory=lambda: ['tcp', 'udp', 'icmp'])
    suspicious_domains: List[str] = field(default_factory=lambda: [
        '*.onion', '*.tor', '*.i2p', 'malware-domains.txt'
    ])
    dns_monitoring: bool = True
    dns_suspicious_patterns: List[str] = field(default_factory=lambda: [
        'dga-*', 'malware-*', 'c2-*'
    ])
    connection_timeout: int = 30  # seconds
    data_exfiltration_threshold_mb: int = 100


@dataclass
class AlertConfig:
    """Configuration for alert and notification system."""
    enabled: bool = True
    severity_levels: List[str] = field(default_factory=lambda: [
        'low', 'medium', 'high', 'critical'
    ])
    correlation_window: int = 60  # seconds
    aggregation_interval: int = 10  # seconds
    max_alerts_per_minute: int = 100
    escalation_rules: Dict[str, Dict] = field(default_factory=lambda: {
        'high': {'email': True, 'webhook': True},
        'critical': {'email': True, 'webhook': True, 'sms': True}
    })
    suppression_window: int = 300  # seconds


@dataclass
class PerformanceConfig:
    """Configuration for performance optimization."""
    max_cpu_percent: int = 10  # Maximum CPU usage percentage
    max_memory_mb: int = 256   # Maximum memory usage in MB
    event_buffer_size: int = 10000
    processing_threads: int = 4
    queue_sizes: Dict[str, int] = field(default_factory=lambda: {
        'file_events': 1000,
        'process_events': 500,
        'syscall_events': 2000,
        'network_events': 2000
    })
    batch_processing: bool = True
    batch_timeout_ms: int = 100
    caching_enabled: bool = True
    compression_enabled: bool = True


@dataclass
class MLConfig:
    """Configuration for machine learning components."""
    enabled: bool = True
    model_path: str = "/opt/antivirus/models"
    feature_extraction: bool = True
    anomaly_detection: bool = True
    behavior_classification: bool = True
    similarity_hashing: bool = True
    model_update_interval: int = 3600  # seconds
    confidence_threshold: float = 0.8
    explainability_enabled: bool = True


class MonitorConfig:
    """Main configuration class for the real-time monitoring system."""
    
    def __init__(self, config_path: Optional[str] = None):
        self.config_path = config_path or "/etc/antivirus/monitor.json"
        self.file_monitor = FileMonitorConfig()
        self.process_monitor = ProcessMonitorConfig()
        self.syscall_monitor = SyscallMonitorConfig()
        self.network_monitor = NetworkMonitorConfig()
        self.alert_config = AlertConfig()
        self.performance = PerformanceConfig()
        self.ml = MLConfig()
        
        # Load configuration if file exists
        if os.path.exists(self.config_path):
            self.load_config()
        
        # Create default directories
        self._create_directories()
    
    def load_config(self) -> None:
        """Load configuration from JSON file."""
        try:
            with open(self.config_path, 'r') as f:
                data = json.load(f)
            
            # Update configurations from loaded data
            if 'file_monitor' in data:
                self._update_dataclass(self.file_monitor, data['file_monitor'])
            if 'process_monitor' in data:
                self._update_dataclass(self.process_monitor, data['process_monitor'])
            if 'syscall_monitor' in data:
                self._update_dataclass(self.syscall_monitor, data['syscall_monitor'])
            if 'network_monitor' in data:
                self._update_dataclass(self.network_monitor, data['network_monitor'])
            if 'alert_config' in data:
                self._update_dataclass(self.alert_config, data['alert_config'])
            if 'performance' in data:
                self._update_dataclass(self.performance, data['performance'])
            if 'ml' in data:
                self._update_dataclass(self.ml, data['ml'])
                
        except Exception as e:
            print(f"Warning: Could not load config from {self.config_path}: {e}")
    
    def save_config(self) -> None:
        """Save current configuration to JSON file."""
        config_dict = {
            'file_monitor': asdict(self.file_monitor),
            'process_monitor': asdict(self.process_monitor),
            'syscall_monitor': asdict(self.syscall_monitor),
            'network_monitor': asdict(self.network_monitor),
            'alert_config': asdict(self.alert_config),
            'performance': asdict(self.performance),
            'ml': asdict(self.ml)
        }
        
        # Create directory if it doesn't exist
        os.makedirs(os.path.dirname(self.config_path), exist_ok=True)
        
        with open(self.config_path, 'w') as f:
            json.dump(config_dict, f, indent=2)
    
    def _update_dataclass(self, instance, data: Dict) -> None:
        """Update dataclass instance with data from dictionary."""
        for key, value in data.items():
            if hasattr(instance, key):
                setattr(instance, key, value)
    
    def _create_directories(self) -> None:
        """Create necessary directories for the monitoring system."""
        directories = [
            "/var/log/antivirus",
            "/var/lib/antivirus/cache",
            "/var/lib/antivirus/models",
            "/tmp/antivirus/events"
        ]
        
        for directory in directories:
            os.makedirs(directory, exist_ok=True)
    
    def get_platform_config(self) -> Dict:
        """Get platform-specific configuration."""
        import platform
        system = platform.system().lower()
        
        platform_configs = {
            'linux': {
                'syscall_monitor': {
                    'mechanisms': ['fanotify', 'inotify', 'seccomp'],
                    'supported': True
                },
                'network_monitor': {
                    'mechanisms': ['pcap', 'socket'],
                    'requires_root': True
                }
            },
            'windows': {
                'syscall_monitor': {
                    'mechanisms': ['etw', 'wfp', 'minifilter'],
                    'supported': True
                },
                'network_monitor': {
                    'mechanisms': ['wfp', 'pcap'],
                    'requires_admin': True
                }
            },
            'darwin': {  # macOS
                'syscall_monitor': {
                    'mechanisms': ['kqueue', 'endpoint_security'],
                    'supported': True
                },
                'network_monitor': {
                    'mechanisms': ['pcap'],
                    'requires_root': True
                }
            }
        }
        
        return platform_configs.get(system, {})
    
    def validate_config(self) -> bool:
        """Validate configuration parameters."""
        try:
            # Validate performance settings
            if self.performance.max_cpu_percent < 0 or self.performance.max_cpu_percent > 100:
                return False
            
            if self.performance.max_memory_mb < 0:
                return False
            
            # Validate alert settings
            if self.alert_config.max_alerts_per_minute < 0:
                return False
            
            # Validate monitor intervals
            if self.process_monitor.scan_interval_ms < 10:
                return False
            
            # Validate ML settings
            if self.ml.confidence_threshold < 0 or self.ml.confidence_threshold > 1:
                return False
            
            return True
            
        except Exception:
            return False
    
    def optimize_for_platform(self) -> None:
        """Optimize configuration based on current platform."""
        import platform
        system = platform.system().lower()
        
        if system == 'linux':
            # Linux optimizations
            self.syscall_monitor.platform = 'linux'
            self.performance.processing_threads = min(8, os.cpu_count() or 4)
            
        elif system == 'windows':
            # Windows optimizations
            self.syscall_monitor.platform = 'windows'
            self.performance.event_buffer_size = 15000
            
        elif system == 'darwin':
            # macOS optimizations
            self.syscall_monitor.platform = 'macos'
            self.performance.processing_threads = min(4, os.cpu_count() or 2)
    
    def get_queue_config(self, queue_name: str) -> Dict:
        """Get configuration for a specific queue."""
        default_size = self.performance.queue_sizes.get(queue_name, 1000)
        
        return {
            'max_size': default_size,
            'batch_size': self.performance.batch_timeout_ms,
            'batch_processing': self.performance.batch_processing
        }