"""
System call monitoring and analysis for real-time threat detection.

Provides platform-specific system call interception and behavioral analysis
for detecting malicious activities at the kernel level.

Features:
- Cross-platform system call monitoring
- Sequence analysis for behavior patterns
- Anomaly detection for unusual system call patterns
- Performance-optimized for minimal system impact
- Real-time analysis with configurable thresholds

Based on research in system call analysis for behavioral malware detection.
"""

import os
import time
import threading
import platform
import json
import re
from typing import Dict, List, Set, Optional, Tuple, Any
from dataclasses import dataclass, field
from collections import deque, defaultdict
from concurrent.futures import ThreadPoolExecutor
import subprocess

from ..core.event_system import EventSystem, EventType, EventPriority, get_event_system
from ..core.config import MonitorConfig


@dataclass
class SyscallEvent:
    """System call event data."""
    pid: int
    syscall_name: str
    timestamp: float
    arguments: List[Any] = field(default_factory=list)
    return_value: Any = None
    duration: float = 0.0
    thread_id: int = 0
    process_name: str = ""
    user_id: int = 0
    parent_pid: int = 0
    correlation_id: str = None


@dataclass
class SyscallPattern:
    """System call pattern for sequence analysis."""
    sequence: List[str]
    frequency: int
    last_seen: float
    confidence: float
    is_malicious: bool = False
    category: str = ""  # e.g., "file_access", "network", "process_mgmt"


class SyscallAnalyzer:
    """Analyzes system call patterns for suspicious behavior."""
    
    def __init__(self, config: SyscallMonitorConfig):
        self.config = config
        self._patterns: Dict[str, SyscallPattern] = {}
        self._sequence_cache: Dict[int, deque] = defaultdict(lambda: deque(maxlen=50))
        self._anomaly_threshold = config.anomaly_threshold
        self._sequence_window = config.time_window_ms / 1000.0  # Convert to seconds
        
        # Define known malicious system call sequences
        self._malicious_patterns = [
            ['open', 'read', 'mmap', 'mprotect', 'mprotect'],  # Memory protection bypass
            ['clone', 'execve', 'prctl', 'setuid'],  # Privilege escalation
            ['socket', 'connect', 'recv', 'send'],  # Network communication
            ['open', 'mmap', 'mprotect', 'mprotect', 'mprotect'],  # W^X bypass
            ['fork', 'execve', 'ptrace'],  # Process injection
            ['chmod', 'chown', 'setuid'],  # Permission manipulation
            ['mount', 'umount', 'pivot_root'],  # Filesystem manipulation
        ]
        
        # Initialize patterns
        self._initialize_patterns()
    
    def _initialize_patterns(self) -> None:
        """Initialize known system call patterns."""
        for i, pattern in enumerate(self._malicious_patterns):
            pattern_id = f"malicious_{i}"
            self._patterns[pattern_id] = SyscallPattern(
                sequence=pattern,
                frequency=0,
                last_seen=0.0,
                confidence=0.8,
                is_malicious=True,
                category="malicious"
            )
    
    def analyze_syscall(self, event: SyscallEvent) -> Tuple[float, List[str]]:
        """Analyze a system call event and return suspicious score and indicators."""
        score = 0.0
        indicators = []
        
        # Add to sequence cache
        self._sequence_cache[event.pid].append(event.syscall_name)
        
        # Check for individual suspicious syscalls
        if self._is_suspicious_syscall(event.syscall_name):
            score += 0.3
            indicators.append(f"suspicious_syscall:{event.syscall_name}")
        
        # Analyze sequence patterns
        sequence_score = self._analyze_sequence(event.pid)
        score += sequence_score
        
        # Check for privilege escalation patterns
        if self._check_privilege_escalation(event):
            score += 0.4
            indicators.append("privilege_escalation")
        
        # Check for anti-debugging patterns
        if self._check_anti_debugging(event):
            score += 0.3
            indicators.append("anti_debugging")
        
        # Check for file manipulation patterns
        if self._check_file_manipulation(event):
            score += 0.2
            indicators.append("file_manipulation")
        
        return min(1.0, score), indicators
    
    def _is_suspicious_syscall(self, syscall_name: str) -> bool:
        """Check if a system call is suspicious."""
        suspicious_syscalls = {
            'prctl', 'ptrace', 'mprotect', 'madvise', 'mincore',
            'setuid', 'setgid', 'setreuid', 'setregid',
            'chroot', 'pivot_root', 'unshare',
            'open', 'openat', 'creat',
            'ptrace', 'process_vm_readv', 'process_vm_writev'
        }
        
        return syscall_name.lower() in suspicious_syscalls
    
    def _analyze_sequence(self, pid: int) -> float:
        """Analyze system call sequence for patterns."""
        if pid not in self._sequence_cache:
            return 0.0
        
        sequence = list(self._sequence_cache[pid])
        
        if len(sequence) < 2:
            return 0.0
        
        score = 0.0
        
        # Check for malicious patterns
        for pattern_id, pattern in self._patterns.items():
            if pattern.is_malicious and self._matches_pattern(sequence, pattern.sequence):
                score += pattern.confidence
                pattern.frequency += 1
                pattern.last_seen = time.time()
        
        # Check for unusual sequence characteristics
        unique_syscalls = set(sequence)
        if len(unique_syscalls) > 20:  # Too many different syscalls
            score += 0.2
        
        # Check for rapid syscall bursts
        recent_sequences = []
        current_time = time.time()
        for event_seq in self._sequence_cache[pid]:
            # This is a simplified check - in practice, you'd track timing
            recent_sequences.append(event_seq)
        
        if len(recent_sequences) > 30:  # Too many syscalls in window
            score += 0.3
        
        return score
    
    def _matches_pattern(self, sequence: List[str], pattern: List[str]) -> bool:
        """Check if a sequence matches a pattern."""
        if len(sequence) < len(pattern):
            return False
        
        # Use sliding window to find pattern
        for i in range(len(sequence) - len(pattern) + 1):
            if sequence[i:i+len(pattern)] == pattern:
                return True
        
        return False
    
    def _check_privilege_escalation(self, event: SyscallEvent) -> bool:
        """Check for privilege escalation indicators."""
        privilege_escalation_syscalls = [
            'setuid', 'setgid', 'setreuid', 'setregid', 'setresuid', 'setresgid',
            'prctl', 'capset', 'chroot', 'pivot_root'
        ]
        
        return event.syscall_name in privilege_escalation_syscalls
    
    def _check_anti_debugging(self, event: SyscallEvent) -> bool:
        """Check for anti-debugging patterns."""
        anti_debugging_syscalls = [
            'ptrace', 'prctl', 'gettimeofday', 'clock_gettime'
        ]
        
        return event.syscall_name in anti_debugging_syscalls
    
    def _check_file_manipulation(self, event: SyscallEvent) -> bool:
        """Check for suspicious file manipulation patterns."""
        file_syscalls = ['open', 'openat', 'creat', 'unlink', 'rename']
        
        if event.syscall_name in file_syscalls:
            # Check for suspicious file paths in arguments
            if event.arguments:
                for arg in event.arguments:
                    if isinstance(arg, str) and self._is_suspicious_path(arg):
                        return True
        
        return False
    
    def _is_suspicious_path(self, path: str) -> bool:
        """Check if a file path is suspicious."""
        suspicious_patterns = [
            '/tmp/', '/var/tmp/', '/dev/shm/', '/proc/', '/sys/',
            'C:\\Windows\\Temp\\', 'C:\\Users\\*\\AppData\\Local\\Temp\\'
        ]
        
        path_lower = path.lower()
        return any(pattern in path_lower for pattern in suspicious_patterns)


class PlatformSyscallMonitor:
    """Base class for platform-specific system call monitors."""
    
    def __init__(self, config: SyscallMonitorConfig, event_system: EventSystem):
        self.config = config
        self.event_system = event_system
        self._running = False
        self._syscalls_captured = 0
        self._analyzer = SyscallAnalyzer(config)
        
    def start(self) -> bool:
        """Start the system call monitor."""
        raise NotImplementedError
    
    def stop(self) -> None:
        """Stop the system call monitor."""
        self._running = False
    
    def capture_syscall(self, pid: int, syscall_name: str, 
                       arguments: List[Any], return_value: Any) -> None:
        """Capture and analyze a system call."""
        if not self._running:
            return
        
        syscall_event = SyscallEvent(
            pid=pid,
            syscall_name=syscall_name,
            timestamp=time.time(),
            arguments=arguments,
            return_value=return_value
        )
        
        # Analyze the syscall
        suspicious_score, indicators = self._analyzer.analyze_syscall(syscall_event)
        
        if suspicious_score > 0.3:  # Threshold for publishing events
            self._publish_syscall_event(syscall_event, suspicious_score, indicators)
        
        self._syscalls_captured += 1
    
    def _publish_syscall_event(self, event: SyscallEvent, score: float, indicators: List[str]) -> None:
        """Publish a system call event."""
        # Determine event type
        if score > 0.8:
            event_type = EventType.SYSCALL_ANOMALY
            priority = EventPriority.CRITICAL
        elif score > 0.6:
            event_type = EventType.SYSCALL_ANOMALY
            priority = EventPriority.HIGH
        else:
            event_type = EventType.SYSCALL_SEQUENCE
            priority = EventPriority.MEDIUM
        
        # Create event data
        data = {
            'pid': event.pid,
            'syscall': event.syscall_name,
            'arguments': event.arguments,
            'return_value': event.return_value,
            'suspicious_score': score,
            'indicators': indicators,
            'timestamp': event.timestamp
        }
        
        # Create and publish event
        syscall_event = self.event_system.create_event(
            event_type=event_type,
            source="syscall_monitor",
            data=data,
            priority=priority
        )
        
        self.event_system.publish_event(syscall_event)


class LinuxSyscallMonitor(PlatformSyscallMonitor):
    """Linux-specific system call monitor using eBPF/ftrace."""
    
    def __init__(self, config: SyscallMonitorConfig, event_system: EventSystem):
        super().__init__(config, event_system)
        self._bpf_program = None
        self._monitoring_thread = None
    
    def start(self) -> bool:
        """Start Linux system call monitoring."""
        try:
            # Try to use eBPF for efficient monitoring
            if self._start_ebpf_monitor():
                return True
            
            # Fall back to strace-based monitoring
            return self._start_strace_monitor()
            
        except Exception as e:
            print(f"Error starting Linux syscall monitor: {e}")
            return False
    
    def _start_ebpf_monitor(self) -> bool:
        """Start eBPF-based system call monitoring."""
        try:
            # This is a simplified eBPF implementation
            # In practice, you'd use libraries like BCC or libbpf
            
            self._running = True
            self._monitoring_thread = threading.Thread(target=self._ebpf_loop, daemon=True)
            self._monitoring_thread.start()
            
            return True
            
        except Exception:
            return False
    
    def _ebpf_loop(self) -> None:
        """eBPF monitoring loop."""
        while self._running:
            try:
                # In a real implementation, this would read from eBPF maps
                # For now, we'll simulate some system call capture
                time.sleep(0.1)
                
            except Exception as e:
                if self._running:
                    print(f"Error in eBPF monitoring: {e}")
    
    def _start_strace_monitor(self) -> bool:
        """Start strace-based system call monitoring."""
        try:
            # Check if strace is available
            result = subprocess.run(['which', 'strace'], capture_output=True)
            if result.returncode != 0:
                print("strace not available")
                return False
            
            self._running = True
            self._monitoring_thread = threading.Thread(target=self._strace_loop, daemon=True)
            self._monitoring_thread.start()
            
            return True
            
        except Exception as e:
            print(f"Error starting strace monitor: {e}")
            return False
    
    def _strace_loop(self) -> None:
        """strace monitoring loop."""
        try:
            # Monitor specific processes or system-wide
            cmd = ['strace', '-f', '-e', 'trace=open,read,write,execve,clone,fork,mmap,mprotect,prctl,setuid', '-p', '1']
            
            process = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
            
            while self._running:
                line = process.stdout.readline()
                if not line:
                    break
                
                self._parse_strace_line(line)
                
        except Exception as e:
            if self._running:
                print(f"Error in strace monitoring: {e}")
    
    def _parse_strace_line(self, line: str) -> None:
        """Parse a strace output line."""
        try:
            # Simple parsing of strace output
            # Format: PID SYSCALL(args) = return_value
            
            if ' = ' in line and '(' in line:
                parts = line.split('(', 1)
                if len(parts) == 2:
                    syscall_part = parts[0].strip()
                    if ' ' in syscall_part:
                        parts2 = syscall_part.rsplit(' ', 1)
                        if len(parts2) == 2:
                            pid = int(parts2[0])
                            syscall_name = parts2[1]
                            
                            # Extract arguments
                            args_part = parts[1].split(')', 1)[0] if ')' in parts[1] else ""
                            arguments = [arg.strip().strip('"') for arg in args_part.split(',')]
                            
                            # Extract return value
                            return_value = None
                            if ' = ' in parts[1]:
                                return_part = parts[1].split(' = ', 1)[1].strip()
                                try:
                                    return_value = int(return_part)
                                except ValueError:
                                    return_value = return_part
                            
                            self.capture_syscall(pid, syscall_name, arguments, return_value)
                            
        except Exception as e:
            # Silently ignore parsing errors
            pass


class WindowsSyscallMonitor(PlatformSyscallMonitor):
    """Windows-specific system call monitor using ETW."""
    
    def __init__(self, config: SyscallMonitorConfig, event_system: EventSystem):
        super().__init__(config, event_system)
        self._etw_session = None
    
    def start(self) -> bool:
        """Start Windows system call monitoring."""
        try:
            # Check if we can use ETW
            import ctypes
            from ctypes import wintypes
            
            # This is a simplified Windows implementation
            # In practice, you'd use libraries like pyeventtrace or implement directly
            
            self._running = True
            self._monitoring_thread = threading.Thread(target=self._etw_loop, daemon=True)
            self._monitoring_thread.start()
            
            return True
            
        except Exception as e:
            print(f"Error starting Windows syscall monitor: {e}")
            return False
    
    def _etw_loop(self) -> None:
        """ETW monitoring loop."""
        while self._running:
            try:
                # Simulate Windows system call monitoring
                # In practice, this would read from ETW events
                time.sleep(0.1)
                
            except Exception as e:
                if self._running:
                    print(f"Error in ETW monitoring: {e}")


class SyscallMonitor:
    """Main system call monitoring system."""
    
    def __init__(self, config: MonitorConfig):
        self.config = config.syscall_monitor
        self.event_system = get_event_system()
        self._monitor: Optional[PlatformSyscallMonitor] = None
        self._running = False
        
    def start(self) -> bool:
        """Start system call monitoring."""
        if not self.config.enabled:
            return False
        
        # Create platform-specific monitor
        system = platform.system().lower()
        
        if system == 'linux':
            self._monitor = LinuxSyscallMonitor(self.config, self.event_system)
        elif system == 'windows':
            self._monitor = WindowsSyscallMonitor(self.config, self.event_system)
        else:
            print(f"System call monitoring not supported on {system}")
            return False
        
        # Start the monitor
        if self._monitor.start():
            self._running = True
            return True
        
        return False
    
    def stop(self) -> None:
        """Stop system call monitoring."""
        self._running = False
        
        if self._monitor:
            self._monitor.stop()
    
    def get_stats(self) -> Dict:
        """Get system call monitor statistics."""
        stats = {
            'running': self._running,
            'platform': platform.system().lower()
        }
        
        if self._monitor:
            stats.update({
                'syscalls_captured': self._monitor._syscalls_captured,
                'monitor_type': type(self._monitor).__name__
            })
        
        return stats