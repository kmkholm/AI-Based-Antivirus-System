"""
Event system for real-time monitoring components.

Provides a high-performance event-driven architecture for:
- File system events
- Process monitoring events
- System call events
- Network traffic events
- Alert and notification events

Implements publisher/subscriber pattern with efficient batching
and queuing for minimal system impact.
"""

import time
import queue
import threading
import json
import uuid
from typing import Dict, List, Callable, Optional, Any, Set
from dataclasses import dataclass, asdict
from enum import Enum
from concurrent.futures import ThreadPoolExecutor
import weakref


class EventType(Enum):
    """Enumeration of event types."""
    FILE_CREATE = "file.create"
    FILE_MODIFY = "file.modify"
    FILE_DELETE = "file.delete"
    FILE_ACCESS = "file.access"
    FILE_MOVE = "file.move"
    FILE_RENAME = "file.rename"
    
    PROCESS_CREATE = "process.create"
    PROCESS_TERMINATE = "process.terminate"
    PROCESS_INJECT = "process.inject"
    PROCESS_SUSPICIOUS = "process.suspicious"
    
    SYSCALL_ANOMALY = "syscall.anomaly"
    SYSCALL_SEQUENCE = "syscall.sequence"
    SYSCALL_PRIVILEGE_ESCALATION = "syscall.privesc"
    
    NETWORK_CONNECT = "network.connect"
    NETWORK_DISCONNECT = "network.disconnect"
    NETWORK_DNS = "network.dns"
    NETWORK_SUSPICIOUS = "network.suspicious"
    NETWORK_EXFILTRATION = "network.exfiltration"
    
    BEHAVIOR_ANOMALY = "behavior.anomaly"
    BEHAVIOR_MALICIOUS = "behavior.malicious"
    BEHAVIOR_SEQUENCE = "behavior.sequence"
    
    ALERT_LOW = "alert.low"
    ALERT_MEDIUM = "alert.medium"
    ALERT_HIGH = "alert.high"
    ALERT_CRITICAL = "alert.critical"
    ALERT_CORRELATED = "alert.correlated"
    
    SYSTEM_START = "system.start"
    SYSTEM_STOP = "system.stop"
    SYSTEM_ERROR = "system.error"
    SYSTEM_PERFORMANCE = "system.performance"


class EventPriority(Enum):
    """Event priority levels."""
    LOW = 1
    NORMAL = 2
    HIGH = 3
    CRITICAL = 4


@dataclass
class Event:
    """Base event class."""
    id: str
    type: EventType
    timestamp: float
    priority: EventPriority
    source: str
    data: Dict[str, Any]
    metadata: Dict[str, Any] = None
    correlation_id: str = None
    parent_id: str = None
    
    def __post_init__(self):
        if self.metadata is None:
            self.metadata = {}
    
    def to_dict(self) -> Dict:
        """Convert event to dictionary for serialization."""
        return {
            'id': self.id,
            'type': self.type.value,
            'timestamp': self.timestamp,
            'priority': self.priority.value,
            'source': self.source,
            'data': self.data,
            'metadata': self.metadata,
            'correlation_id': self.correlation_id,
            'parent_id': self.parent_id
        }
    
    @classmethod
    def from_dict(cls, data: Dict) -> 'Event':
        """Create event from dictionary."""
        return cls(
            id=data['id'],
            type=EventType(data['type']),
            timestamp=data['timestamp'],
            priority=EventPriority(data['priority']),
            source=data['source'],
            data=data['data'],
            metadata=data.get('metadata', {}),
            correlation_id=data.get('correlation_id'),
            parent_id=data.get('parent_id')
        )


class EventSubscriber:
    """Event subscriber interface."""
    
    def __init__(self, name: str, event_types: List[EventType]):
        self.name = name
        self.event_types = event_types
        self.enabled = True
        self._callback: Optional[Callable] = None
    
    def set_callback(self, callback: Callable[[Event], None]) -> None:
        """Set event callback function."""
        self._callback = callback
    
    def handle_event(self, event: Event) -> None:
        """Handle incoming event."""
        if not self.enabled or self._callback is None:
            return
        
        if event.type in self.event_types:
            try:
                self._callback(event)
            except Exception as e:
                print(f"Error in event handler {self.name}: {e}")


class EventBus:
    """High-performance event bus for publisher/subscriber pattern."""
    
    def __init__(self, max_queue_size: int = 10000, batch_size: int = 50):
        self.max_queue_size = max_queue_size
        self.batch_size = batch_size
        self._subscribers: Dict[EventType, List[EventSubscriber]] = {}
        self._event_queue = queue.PriorityQueue(maxsize=max_queue_size)
        self._running = False
        self._thread_pool = ThreadPoolExecutor(max_workers=4)
        self._stats = {
            'events_processed': 0,
            'events_dropped': 0,
            'subscribers_count': 0,
            'batches_processed': 0
        }
        self._lock = threading.RLock()
    
    def start(self) -> None:
        """Start the event bus."""
        if not self._running:
            self._running = True
            self._thread_pool.submit(self._process_events)
    
    def stop(self) -> None:
        """Stop the event bus."""
        self._running = False
        self._thread_pool.shutdown(wait=True)
    
    def subscribe(self, subscriber: EventSubscriber) -> None:
        """Subscribe to event types."""
        with self._lock:
            for event_type in subscriber.event_types:
                if event_type not in self._subscribers:
                    self._subscribers[event_type] = []
                self._subscribers[event_type].append(subscriber)
            
            self._stats['subscribers_count'] = sum(
                len(subs) for subs in self._subscribers.values()
            )
    
    def unsubscribe(self, name: str) -> None:
        """Unsubscribe a subscriber by name."""
        with self._lock:
            for event_type, subscribers in self._subscribers.items():
                self._subscribers[event_type] = [
                    sub for sub in subscribers if sub.name != name
                ]
            
            self._stats['subscribers_count'] = sum(
                len(subs) for subs in self._subscribers.values()
            )
    
    def publish(self, event: Event) -> bool:
        """Publish an event."""
        if not self._running:
            return False
        
        try:
            # Use negative priority for max-heap (PriorityQueue is min-heap)
            priority = -event.priority.value
            self._event_queue.put((priority, event), timeout=0.1)
            return True
        except queue.Full:
            with self._lock:
                self._stats['events_dropped'] += 1
            return False
    
    def publish_batch(self, events: List[Event]) -> int:
        """Publish multiple events efficiently."""
        if not self._running or not events:
            return 0
        
        published = 0
        for event in events:
            if self.publish(event):
                published += 1
        
        return published
    
    def _process_events(self) -> None:
        """Process events from the queue in batches."""
        batch = []
        
        while self._running:
            try:
                # Collect events in batch
                timeout = 0.1 if batch else 1.0
                priority, event = self._event_queue.get(timeout=timeout)
                
                batch.append(event)
                
                # Process batch if full or timeout
                if len(batch) >= self.batch_size:
                    self._process_batch(batch)
                    batch.clear()
                    
            except queue.Empty:
                # Process remaining batch
                if batch:
                    self._process_batch(batch)
                    batch.clear()
    
    def _process_batch(self, events: List[Event]) -> None:
        """Process a batch of events."""
        if not events:
            return
        
        with self._lock:
            self._stats['events_processed'] += len(events)
            self._stats['batches_processed'] += 1
        
        # Group events by type for efficient delivery
        events_by_type: Dict[EventType, List[Event]] = {}
        for event in events:
            events_by_type.setdefault(event.type, []).append(event)
        
        # Deliver events to subscribers
        for event_type, typed_events in events_by_type.items():
            with self._lock:
                subscribers = self._subscribers.get(event_type, []).copy()
            
            for subscriber in subscribers:
                if subscriber.enabled:
                    for event in typed_events:
                        self._thread_pool.submit(subscriber.handle_event, event)
    
    def get_stats(self) -> Dict:
        """Get event bus statistics."""
        with self._lock:
            return {
                **self._stats,
                'queue_size': self._event_queue.qsize(),
                'running': self._running
            }


class EventSystem:
    """Central event system manager."""
    
    def __init__(self, config):
        self.config = config
        self.event_bus = EventBus(
            max_queue_size=config.performance.event_buffer_size,
            batch_size=50
        )
        self._correlation_cache: Dict[str, List[Event]] = {}
        self._correlation_lock = threading.RLock()
        self.correlation_window = config.alert_config.correlation_window
    
    def start(self) -> None:
        """Start the event system."""
        self.event_bus.start()
    
    def stop(self) -> None:
        """Stop the event system."""
        self.event_bus.stop()
    
    def create_event(self, 
                    event_type: EventType,
                    source: str,
                    data: Dict[str, Any],
                    priority: EventPriority = EventPriority.NORMAL,
                    correlation_id: str = None) -> Event:
        """Create a new event."""
        return Event(
            id=str(uuid.uuid4()),
            type=event_type,
            timestamp=time.time(),
            priority=priority,
            source=source,
            data=data,
            correlation_id=correlation_id or str(uuid.uuid4())
        )
    
    def publish_event(self, event: Event) -> bool:
        """Publish an event."""
        # Store for correlation analysis
        if event.correlation_id:
            with self._correlation_lock:
                if event.correlation_id not in self._correlation_cache:
                    self._correlation_cache[event.correlation_id] = []
                self._correlation_cache[event.correlation_id].append(event)
        
        return self.event_bus.publish(event)
    
    def subscribe(self, name: str, event_types: List[EventType], 
                 callback: Callable[[Event], None]) -> EventSubscriber:
        """Create and register a subscriber."""
        subscriber = EventSubscriber(name, event_types)
        subscriber.set_callback(callback)
        self.event_bus.subscribe(subscriber)
        return subscriber
    
    def correlate_events(self, correlation_id: str) -> List[Event]:
        """Get correlated events within the correlation window."""
        with self._correlation_lock:
            events = self._correlation_cache.get(correlation_id, [])
            
        # Filter events within correlation window
        current_time = time.time()
        cutoff_time = current_time - self.correlation_window
        
        return [
            event for event in events 
            if event.timestamp >= cutoff_time
        ]
    
    def get_correlation_analysis(self, correlation_id: str) -> Dict:
        """Analyze correlated events for patterns."""
        events = self.correlate_events(correlation_id)
        
        if len(events) < 2:
            return {'correlation_strength': 0, 'patterns': []}
        
        # Analyze event patterns
        patterns = {
            'event_sequence': [event.type.value for event in sorted(events, key=lambda e: e.timestamp)],
            'event_sources': list(set(event.source for event in events)),
            'time_span': events[-1].timestamp - events[0].timestamp,
            'event_count': len(events),
            'priority_distribution': {}
        }
        
        # Calculate priority distribution
        for event in events:
            priority = event.priority.name
            patterns['priority_distribution'][priority] = patterns['priority_distribution'].get(priority, 0) + 1
        
        # Calculate correlation strength
        correlation_strength = min(1.0, len(events) / 10)  # Normalize to 0-1
        
        return {
            'correlation_strength': correlation_strength,
            'patterns': patterns,
            'suspicious_indicators': self._detect_suspicious_patterns(events)
        }
    
    def _detect_suspicious_patterns(self, events: List[Event]) -> List[str]:
        """Detect suspicious patterns in correlated events."""
        indicators = []
        
        # Check for rapid-fire events (potential DoS)
        if len(events) > 5:
            time_span = events[-1].timestamp - events[0].timestamp
            if time_span < 1.0:  # More than 5 events in 1 second
                indicators.append("rapid_event_sequence")
        
        # Check for process injection pattern
        process_events = [e for e in events if e.type.value.startswith('process')]
        if any('inject' in e.type.value for e in process_events):
            indicators.append("process_injection_detected")
        
        # Check for privilege escalation
        syscall_events = [e for e in events if e.type.value.startswith('syscall')]
        if any('privesc' in e.type.value for e in syscall_events):
            indicators.append("privilege_escalation")
        
        # Check for network exfiltration pattern
        network_events = [e for e in events if e.type.value.startswith('network')]
        if any('exfiltration' in e.type.value for e in network_events):
            indicators.append("data_exfiltration")
        
        return indicators
    
    def cleanup_correlation_cache(self) -> None:
        """Clean up old correlation data."""
        current_time = time.time()
        cutoff_time = current_time - (self.correlation_window * 2)
        
        with self._correlation_lock:
            expired_keys = []
            for correlation_id, events in self._correlation_cache.items():
                if all(event.timestamp < cutoff_time for event in events):
                    expired_keys.append(correlation_id)
            
            for key in expired_keys:
                del self._correlation_cache[key]
    
    def get_stats(self) -> Dict:
        """Get system statistics."""
        return {
            'event_bus': self.event_bus.get_stats(),
            'correlation_cache_size': len(self._correlation_cache),
            'correlation_window': self.correlation_window
        }


# Global event system instance
_event_system: Optional[EventSystem] = None


def get_event_system() -> EventSystem:
    """Get the global event system instance."""
    global _event_system
    if _event_system is None:
        from .config import MonitorConfig
        config = MonitorConfig()
        _event_system = EventSystem(config)
    return _event_system