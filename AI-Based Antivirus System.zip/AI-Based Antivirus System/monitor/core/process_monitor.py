"""
Process monitoring and behavioral analysis system.

Monitors process creation, execution patterns, and behavioral anomalies
for real-time threat detection with minimal system impact.

Features:
- Real-time process monitoring
- Parent-child relationship analysis
- Command line monitoring
- Process injection detection
- Privilege escalation detection
- Behavioral pattern analysis
- Cross-platform compatibility

Based on behavioral analysis research for detecting process-based attacks.
"""

import os
import time
import psutil
import threading
import platform
from typing import Dict, List, Set, Optional, Tuple
from dataclasses import dataclass, field
from collections import deque
from concurrent.futures import ThreadPoolExecutor
import json

from ..core.event_system import EventSystem, EventType, EventPriority, get_event_system
from ..core.config import MonitorConfig


@dataclass
class ProcessInfo:
    """Process information structure."""
    pid: int
    name: str
    cmdline: List[str]
    cwd: str
    parent_pid: int
    user_id: int
    user_name: str
    create_time: float
    cpu_percent: float
    memory_info: Dict
    open_files: List[str]
    network_connections: List[Dict]
    environment: Dict[str, str]
    suspicious_score: float = 0.0
    last_update: float = field(default_factory=time.time)


@dataclass
class ProcessEvent:
    """Process event data."""
    event_type: str
    process: ProcessInfo
    timestamp: float
    related_processes: List[ProcessInfo] = field(default_factory=list)
    correlation_id: str = None


class ProcessAnalyzer:
    """Analyzes process behavior for suspicious patterns."""
    
    def __init__(self, config: ProcessMonitorConfig):
        self.config = config
        self._suspicious_processes = set(config.suspicious_processes)
        self._injection_patterns = set(config.process_injection_patterns)
        self._behavior_cache: Dict[int, deque] = {}
        self._max_cache_size = config.behavior_window_size
        
    def analyze_process(self, process: ProcessInfo) -> float:
        """Analyze process and return suspicious score (0.0-1.0)."""
        score = 0.0
        
        # Check process name
        if self._is_suspicious_process_name(process.name):
            score += 0.3
        
        # Analyze command line
        score += self._analyze_command_line(process)
        
        # Check for privilege escalation
        if self.config.privilege_escalation_detection:
            score += self._check_privilege_escalation(process)
        
        # Analyze parent-child relationships
        if self.config.parent_child_monitoring:
            score += self._analyze_parent_child(process)
        
        # Check for process injection patterns
        score += self._check_injection_patterns(process)
        
        # Analyze environment variables
        if self.config.environment_monitoring:
            score += self._analyze_environment(process)
        
        # Normalize score to 0.0-1.0 range
        return min(1.0, score)
    
    def _is_suspicious_process_name(self, name: str) -> bool:
        """Check if process name is suspicious."""
        name_lower = name.lower()
        
        # Check against known suspicious process names
        for suspicious in self._suspicious_processes:
            if suspicious.lower() in name_lower:
                return True
        
        # Check for random/encrypted names
        if len(name) > 10 and all(c in '0123456789abcdef' for c in name):
            return True
        
        return False
    
    def _analyze_command_line(self, process: ProcessInfo) -> float:
        """Analyze command line for suspicious patterns."""
        cmdline = ' '.join(process.cmdline).lower()
        score = 0.0
        
        # Suspicious command line patterns
        suspicious_patterns = [
            'powershell -enc',  # Encoded PowerShell
            'cmd /c',           # Command execution
            'curl ', 'wget ',  # Download tools
            'reg add', 'reg delete',  # Registry manipulation
            'net user', 'net localgroup',  # User management
            'whoami', 'ipconfig', 'systeminfo',  # Reconnaissance
            '-windowstyle hidden',  # Hidden execution
            'bypass', 'encodedcommand',  # Obfuscation
        ]
        
        for pattern in suspicious_patterns:
            if pattern in cmdline:
                score += 0.2
        
        # Check for base64 encoded content
        if any(segment.isalnum() and len(segment) > 50 for segment in process.cmdline):
            score += 0.3
        
        return score
    
    def _check_privilege_escalation(self, process: ProcessInfo) -> float:
        """Check for privilege escalation indicators."""
        score = 0.0
        
        # Check if process is running with elevated privileges
        try:
            # Check parent process privileges
            if process.parent_pid != 0:
                parent = psutil.Process(process.parent_pid)
                parent_privilege = parent.username()
                current_privilege = psutil.Process().username()
                
                # Simple check - would need more sophisticated privilege analysis
                if parent_privilege != current_privilege:
                    score += 0.4
        except (psutil.NoSuchProcess, psutil.AccessDenied):
            pass
        
        # Check for known privilege escalation tools in command line
        cmdline_str = ' '.join(process.cmdline).lower()
        privilege_tools = [
            'sudo', 'su', 'runas', 'psexec', 'getprivs', 'winpeas', 'linpeas'
        ]
        
        for tool in privilege_tools:
            if tool in cmdline_str:
                score += 0.3
        
        return score
    
    def _analyze_parent_child(self, process: ProcessInfo) -> float:
        """Analyze parent-child process relationships."""
        score = 0.0
        
        if process.parent_pid == 0:
            return score  # Init process, probably normal
        
        try:
            parent = psutil.Process(process.parent_pid)
            parent_info = self._get_process_info(parent)
            
            # Suspicious parent-child patterns
            suspicious_combinations = [
                ('cmd.exe', 'powershell.exe'),
                ('explorer.exe', 'cmd.exe'),
                ('services.exe', 'svchost.exe'),
                ('rundll32.exe', 'powershell.exe'),
                ('wmiprvse.exe', 'cmd.exe'),
            ]
            
            parent_name = parent_info.name.lower()
            child_name = process.name.lower()
            
            for parent_pat, child_pat in suspicious_combinations:
                if parent_pat in parent_name and child_pat in child_name:
                    score += 0.3
            
            # Unusual parent process
            unusual_parents = ['svchost.exe', 'services.exe', 'rundll32.exe']
            if any(parent_pat in parent_name for parent_pat in unusual_parents):
                if process.name not in ['svchost.exe', 'services.exe']:
                    score += 0.2
                    
        except (psutil.NoSuchProcess, psutil.AccessDenied):
            pass
        
        return score
    
    def _check_injection_patterns(self, process: ProcessInfo) -> float:
        """Check for process injection patterns."""
        score = 0.0
        
        cmdline_str = ' '.join(process.cmdline).lower()
        
        # Check for injection-related API calls in command line or process details
        for pattern in self._injection_patterns:
            if pattern.lower() in cmdline_str:
                score += 0.5
        
        # Check for injection tools
        injection_tools = [
            'mimikatz', 'procmon', 'processhacker', 'x64dbg', 'ollydbg'
        ]
        
        for tool in injection_tools:
            if tool in cmdline_str:
                score += 0.4
        
        return score
    
    def _analyze_environment(self, process: ProcessInfo) -> float:
        """Analyze environment variables for suspicious patterns."""
        score = 0.0
        
        # Check for suspicious environment variables
        suspicious_env_vars = [
            'TEMP', 'TMP', 'APPDATA', 'LOCALAPPDATA'
        ]
        
        for var_name, var_value in process.environment.items():
            var_lower = var_name.lower()
            
            # Check for suspicious temp paths
            if any(sus_var.lower() in var_lower for sus_var in suspicious_env_vars):
                if any(suspect_path in var_value.lower() for suspect_path in ['temp', 'tmp']):
                    score += 0.1
            
            # Check for encoded variables
            if var_value.isalnum() and len(var_value) > 100:
                score += 0.3
        
        return score
    
    def update_behavior_cache(self, process: ProcessInfo) -> None:
        """Update behavior cache for sequence analysis."""
        pid = process.pid
        
        if pid not in self._behavior_cache:
            self._behavior_cache[pid] = deque(maxlen=self._max_cache_size)
        
        behavior_data = {
            'timestamp': time.time(),
            'cpu_percent': process.cpu_percent,
            'memory_mb': process.memory_info.get('rss', 0) / 1024 / 1024,
            'open_files_count': len(process.open_files),
            'network_connections_count': len(process.network_connections)
        }
        
        self._behavior_cache[pid].append(behavior_data)
    
    def analyze_behavior_sequence(self, pid: int) -> float:
        """Analyze process behavior sequence for anomalies."""
        if pid not in self._behavior_cache:
            return 0.0
        
        behavior_data = list(self._behavior_cache[pid])
        
        if len(behavior_data) < 3:
            return 0.0
        
        # Check for unusual CPU usage patterns
        cpu_values = [data['cpu_percent'] for data in behavior_data]
        if max(cpu_values) - min(cpu_values) > 50:  # High variance
            return 0.3
        
        # Check for sudden spikes in resource usage
        for i in range(1, len(cpu_values)):
            if cpu_values[i] > cpu_values[i-1] * 3 and cpu_values[i] > 30:
                return 0.4
        
        # Check for suspicious file access patterns
        file_counts = [data['open_files_count'] for data in behavior_data]
        if max(file_counts) > 100:  # Too many open files
            return 0.3
        
        return 0.0


class PlatformProcessMonitor:
    """Base class for platform-specific process monitors."""
    
    def __init__(self, config: ProcessMonitorConfig, event_system: EventSystem):
        self.config = config
        self.event_system = event_system
        self._running = False
        self._processes: Dict[int, ProcessInfo] = {}
        self._analyzer = ProcessAnalyzer(config)
        self._scan_lock = threading.RLock()
    
    def get_process_info(self, process: psutil.Process) -> Optional[ProcessInfo]:
        """Get detailed process information."""
        try:
            # Get basic information
            create_time = process.create_time()
            cpu_percent = process.cpu_percent(interval=0.1)
            memory_info = process.memory_info()
            cmdline = process.cmdline()
            
            # Get additional information
            try:
                cwd = process.cwd()
            except (psutil.AccessDenied, psutil.NoSuchProcess):
                cwd = ""
            
            try:
                parent = process.parent()
                parent_pid = parent.pid if parent else 0
            except (psutil.AccessDenied, psutil.NoSuchProcess):
                parent_pid = 0
            
            # Get user information
            try:
                user_name = process.username()
                user_id = os.getuid() if hasattr(os, 'getuid') else 0
            except (psutil.AccessDenied, psutil.NoSuchProcess):
                user_name = "unknown"
                user_id = 0
            
            # Get open files
            try:
                open_files = [f.path for f in process.open_files()]
            except (psutil.AccessDenied, psutil.NoSuchProcess):
                open_files = []
            
            # Get network connections
            try:
                network_connections = []
                for conn in process.connections():
                    network_connections.append({
                        'family': conn.family,
                        'type': conn.type,
                        'local_address': str(conn.laddr) if conn.laddr else None,
                        'remote_address': str(conn.raddr) if conn.raddr else None,
                        'status': conn.status
                    })
            except (psutil.AccessDenied, psutil.NoSuchProcess):
                network_connections = []
            
            # Get environment variables (if accessible)
            try:
                environment = dict(process.environ())
            except (psutil.AccessDenied, psutil.NoSuchProcess, AttributeError):
                environment = {}
            
            return ProcessInfo(
                pid=process.pid,
                name=process.name(),
                cmdline=cmdline,
                cwd=cwd,
                parent_pid=parent_pid,
                user_id=user_id,
                user_name=user_name,
                create_time=create_time,
                cpu_percent=cpu_percent,
                memory_info={
                    'rss': memory_info.rss,
                    'vms': memory_info.vms,
                    'percent': process.memory_percent()
                },
                open_files=open_files,
                network_connections=network_connections,
                environment=environment
            )
            
        except (psutil.NoSuchProcess, psutil.AccessDenied):
            return None
    
    def scan_processes(self) -> List[ProcessEvent]:
        """Scan for process changes and return events."""
        events = []
        
        with self._scan_lock:
            current_pids = set(psutil.pids())
            known_pids = set(self._processes.keys())
            
            # Find new processes
            new_pids = current_pids - known_pids
            for pid in new_pids:
                try:
                    process = psutil.Process(pid)
                    process_info = self.get_process_info(process)
                    
                    if process_info:
                        # Analyze the process
                        suspicious_score = self._analyzer.analyze_process(process_info)
                        process_info.suspicious_score = suspicious_score
                        
                        # Update behavior cache
                        self._analyzer.update_behavior_cache(process_info)
                        
                        self._processes[pid] = process_info
                        
                        # Create event
                        event = ProcessEvent(
                            event_type="create",
                            process=process_info,
                            timestamp=time.time()
                        )
                        events.append(event)
                        
                except (psutil.NoSuchProcess, psutil.AccessDenied):
                    continue
            
            # Find terminated processes
            terminated_pids = known_pids - current_pids
            for pid in terminated_pids:
                if pid in self._processes:
                    process_info = self._processes[pid]
                    del self._processes[pid]
                    
                    event = ProcessEvent(
                        event_type="terminate",
                        process=process_info,
                        timestamp=time.time()
                    )
                    events.append(event)
            
            # Check for changes in existing processes
            for pid in current_pids & known_pids:
                if pid in self._processes:
                    try:
                        process = psutil.Process(pid)
                        old_info = self._processes[pid]
                        new_info = self.get_process_info(process)
                        
                        if new_info and self._has_process_changed(old_info, new_info):
                            # Re-analyze for changes
                            suspicious_score = self._analyzer.analyze_process(new_info)
                            new_info.suspicious_score = suspicious_score
                            
                            # Update behavior cache
                            self._analyzer.update_behavior_cache(new_info)
                            
                            self._processes[pid] = new_info
                            
                            event = ProcessEvent(
                                event_type="modify",
                                process=new_info,
                                timestamp=time.time()
                            )
                            events.append(event)
                            
                    except (psutil.NoSuchProcess, psutil.AccessDenied):
                        # Process terminated during scan
                        if pid in self._processes:
                            del self._processes[pid]
        
        return events
    
    def _has_process_changed(self, old_info: ProcessInfo, new_info: ProcessInfo) -> bool:
        """Check if process information has changed significantly."""
        # Check for command line changes
        if old_info.cmdline != new_info.cmdline:
            return True
        
        # Check for significant resource usage changes
        cpu_change = abs(new_info.cpu_percent - old_info.cpu_percent)
        memory_change = abs(new_info.memory_info['rss'] - old_info.memory_info['rss'])
        
        if cpu_change > 5.0:  # 5% CPU change
            return True
        
        if memory_change > 10 * 1024 * 1024:  # 10MB memory change
            return True
        
        # Check for new network connections
        if len(new_info.network_connections) != len(old_info.network_connections):
            return True
        
        return False


class ProcessMonitor:
    """Main process monitoring system."""
    
    def __init__(self, config: MonitorConfig):
        self.config = config.process_monitor
        self.event_system = get_event_system()
        self._monitor = PlatformProcessMonitor(self.config, self.event_system)
        self._running = False
        self._scan_thread = None
        self._last_scan_time = 0
        
    def start(self) -> bool:
        """Start process monitoring."""
        if not self.config.enabled:
            return False
        
        self._running = True
        
        # Start scanning thread
        self._scan_thread = threading.Thread(target=self._scan_loop, daemon=True)
        self._scan_thread.start()
        
        return True
    
    def stop(self) -> None:
        """Stop process monitoring."""
        self._running = False
        
        if self._scan_thread:
            self._scan_thread.join(timeout=5)
    
    def _scan_loop(self) -> None:
        """Main scanning loop."""
        while self._running:
            try:
                current_time = time.time()
                
                # Check if it's time to scan
                if current_time - self._last_scan_time >= (self.config.scan_interval_ms / 1000):
                    events = self._monitor.scan_processes()
                    
                    for event in self._process_process_event(event):
                        pass  # Events are published in _process_process_event
                    
                    self._last_scan_time = current_time
                
                # Sleep for a short time to prevent CPU spinning
                time.sleep(0.1)
                
            except Exception as e:
                if self._running:
                    print(f"Error in process monitoring: {e}")
    
    def _process_process_event(self, event: ProcessEvent) -> None:
        """Process a process event and publish to event system."""
        # Map to event system types
        event_type_map = {
            'create': EventType.PROCESS_CREATE,
            'modify': EventType.PROCESS_SUSPICIOUS,
            'terminate': EventType.PROCESS_TERMINATE
        }
        
        event_type = event_type_map.get(event.event_type)
        if not event_type:
            return
        
        # Determine priority based on suspicious score
        priority = EventPriority.NORMAL
        if event.process.suspicious_score > 0.7:
            priority = EventPriority.HIGH
        elif event.process.suspicious_score > 0.4:
            priority = EventPriority.MEDIUM
        
        # Create event data
        data = {
            'pid': event.process.pid,
            'name': event.process.name,
            'cmdline': event.process.cmdline,
            'user': event.process.user_name,
            'parent_pid': event.process.parent_pid,
            'suspicious_score': event.process.suspicious_score,
            'cpu_percent': event.process.cpu_percent,
            'memory_mb': event.process.memory_info['rss'] / 1024 / 1024,
            'open_files_count': len(event.process.open_files),
            'network_connections_count': len(event.process.network_connections)
        }
        
        # Create and publish event
        monitor_event = self.event_system.create_event(
            event_type=event_type,
            source="process_monitor",
            data=data,
            priority=priority
        )
        
        self.event_system.publish_event(monitor_event)
    
    def get_stats(self) -> Dict:
        """Get process monitor statistics."""
        return {
            'running': self._running,
            'monitored_processes': len(self._monitor._processes),
            'scan_interval_ms': self.config.scan_interval_ms,
            'last_scan_time': self._last_scan_time
        }