"""
Real-time monitoring system orchestrator.

Main entry point that coordinates all monitoring components:
- File system monitoring
- Process monitoring
- System call monitoring
- Network monitoring
- Behavior analysis
- Alert management
- Performance optimization

Provides unified interface for starting, stopping, and managing
the entire real-time monitoring system.
"""

import os
import time
import signal
import threading
import json
import logging
from typing import Dict, List, Optional, Any
from concurrent.futures import ThreadPoolExecutor

from .core.config import MonitorConfig
from .core.event_system import EventSystem, get_event_system
from .core.file_watcher import FileSystemWatcher
from .core.process_monitor import ProcessMonitor
from .core.syscall_monitor import SyscallMonitor
from .network.network_monitor import NetworkMonitor
from .behaviors.behavior_engine import BehaviorEngine
from .alerts.alert_system import AlertSystem
from .perf.performance_monitor import PerformanceMonitor
from .platforms.platform_adapter import PlatformAdapter


class RealTimeMonitor:
    """Main real-time monitoring system orchestrator."""
    
    def __init__(self, config_path: Optional[str] = None):
        """Initialize the real-time monitor."""
        # Load configuration
        self.config = MonitorConfig(config_path)
        self.config.optimize_for_platform()
        
        # Setup logging
        self._setup_logging()
        
        # Initialize components
        self.event_system = get_event_system()
        self.platform_adapter = PlatformAdapter(self.config)
        
        # Initialize monitoring components
        self.file_monitor = None
        self.process_monitor = None
        self.syscall_monitor = None
        self.network_monitor = None
        self.behavior_engine = None
        self.alert_system = None
        self.performance_monitor = None
        
        # State management
        self._running = False
        self._components_started = False
        self._shutdown_event = threading.Event()
        
        # Statistics
        self._start_time = None
        self._component_status = {}
        
        # Setup signal handlers for graceful shutdown
        self._setup_signal_handlers()
    
    def _setup_logging(self) -> None:
        """Setup logging configuration."""
        log_dir = "/var/log/antivirus"
        os.makedirs(log_dir, exist_ok=True)
        
        log_file = os.path.join(log_dir, "monitor.log")
        
        logging.basicConfig(
            level=logging.INFO,
            format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
            handlers=[
                logging.FileHandler(log_file),
                logging.StreamHandler()
            ]
        )
        
        self.logger = logging.getLogger(__name__)
        self.logger.info("Real-time monitor initialized")
    
    def _setup_signal_handlers(self) -> None:
        """Setup signal handlers for graceful shutdown."""
        def signal_handler(signum, frame):
            self.logger.info(f"Received signal {signum}, initiating graceful shutdown...")
            self.stop()
        
        signal.signal(signal.SIGINT, signal_handler)
        signal.signal(signal.SIGTERM, signal_handler)
    
    def start(self) -> bool:
        """Start the real-time monitoring system."""
        if self._running:
            self.logger.warning("Monitor is already running")
            return False
        
        self.logger.info("Starting real-time monitoring system...")
        self._start_time = time.time()
        
        try:
            # Start event system first
            self.event_system.start()
            self.logger.info("Event system started")
            
            # Initialize and start monitoring components
            self._initialize_components()
            
            # Start components
            self._start_components()
            
            self._running = True
            self._components_started = True
            
            self.logger.info("Real-time monitoring system started successfully")
            return True
            
        except Exception as e:
            self.logger.error(f"Error starting monitoring system: {e}")
            self.stop()
            return False
    
    def stop(self) -> None:
        """Stop the real-time monitoring system."""
        if not self._running:
            return
        
        self.logger.info("Stopping real-time monitoring system...")
        
        try:
            # Signal shutdown to all components
            self._shutdown_event.set()
            
            # Stop components in reverse order
            components = [
                ('performance_monitor', self.performance_monitor),
                ('behavior_engine', self.behavior_engine),
                ('alert_system', self.alert_system),
                ('network_monitor', self.network_monitor),
                ('syscall_monitor', self.syscall_monitor),
                ('process_monitor', self.process_monitor),
                ('file_monitor', self.file_monitor)
            ]
            
            for name, component in components:
                if component:
                    try:
                        self.logger.info(f"Stopping {name}...")
                        component.stop()
                        self._component_status[name] = 'stopped'
                    except Exception as e:
                        self.logger.error(f"Error stopping {name}: {e}")
                        self._component_status[name] = 'error'
            
            # Stop event system
            self.event_system.stop()
            
            self._running = False
            self._components_started = False
            
            if self._start_time:
                runtime = time.time() - self._start_time
                self.logger.info(f"Monitor stopped after {runtime:.2f} seconds")
            
        except Exception as e:
            self.logger.error(f"Error during shutdown: {e}")
    
    def _initialize_components(self) -> None:
        """Initialize all monitoring components."""
        self.logger.info("Initializing monitoring components...")
        
        # Check platform support and capabilities
        platform_stats = self.platform_adapter.get_platform_stats()
        self.logger.info(f"Platform: {platform_stats['platform_info']['name']}")
        
        # Initialize file monitor
        if self.config.file_monitor.enabled and self.platform_adapter.is_supported('file_monitoring'):
            self.file_monitor = FileSystemWatcher(self.config)
            self._component_status['file_monitor'] = 'initialized'
        
        # Initialize process monitor
        if self.config.process_monitor.enabled:
            self.process_monitor = ProcessMonitor(self.config)
            self._component_status['process_monitor'] = 'initialized'
        
        # Initialize syscall monitor
        if self.config.syscall_monitor.enabled and self.platform_adapter.is_supported('syscall_monitoring'):
            self.syscall_monitor = SyscallMonitor(self.config)
            self._component_status['syscall_monitor'] = 'initialized'
        
        # Initialize network monitor
        if self.config.network_monitor.enabled and self.platform_adapter.is_supported('network_monitoring'):
            self.network_monitor = NetworkMonitor(self.config)
            self._component_status['network_monitor'] = 'initialized'
        
        # Initialize behavior engine
        if self.config.ml.enabled:
            self.behavior_engine = BehaviorEngine(self.config)
            self._component_status['behavior_engine'] = 'initialized'
        
        # Initialize alert system
        if self.config.alert_config.enabled:
            self.alert_system = AlertSystem(self.config)
            self._component_status['alert_system'] = 'initialized'
        
        # Initialize performance monitor
        if self.config.performance.caching_enabled:
            self.performance_monitor = PerformanceMonitor(self.config)
            self._component_status['performance_monitor'] = 'initialized'
    
    def _start_components(self) -> None:
        """Start all initialized components."""
        self.logger.info("Starting monitoring components...")
        
        components = [
            ('file_monitor', self.file_monitor),
            ('process_monitor', self.process_monitor),
            ('syscall_monitor', self.syscall_monitor),
            ('network_monitor', self.network_monitor),
            ('behavior_engine', self.behavior_engine),
            ('alert_system', self.alert_system),
            ('performance_monitor', self.performance_monitor)
        ]
        
        failed_components = []
        
        for name, component in components:
            if component:
                try:
                    self.logger.info(f"Starting {name}...")
                    if name == 'performance_monitor':
                        component.start()
                    else:
                        if hasattr(component, 'start'):
                            result = component.start()
                            if not result:
                                failed_components.append(name)
                                continue
                    
                    self._component_status[name] = 'running'
                    self.logger.info(f"{name} started successfully")
                    
                except Exception as e:
                    self.logger.error(f"Error starting {name}: {e}")
                    failed_components.append(name)
                    self._component_status[name] = 'error'
        
        if failed_components:
            self.logger.warning(f"Failed to start components: {failed_components}")
            # Continue with other components
    
    def get_status(self) -> Dict[str, Any]:
        """Get current status of the monitoring system."""
        uptime = time.time() - self._start_time if self._start_time else 0
        
        # Get component statistics
        component_stats = {}
        components = [
            ('file_monitor', self.file_monitor),
            ('process_monitor', self.process_monitor),
            ('syscall_monitor', self.syscall_monitor),
            ('network_monitor', self.network_monitor),
            ('behavior_engine', self.behavior_engine),
            ('alert_system', self.alert_system),
            ('performance_monitor', self.performance_monitor)
        ]
        
        for name, component in components:
            if component and hasattr(component, 'get_stats'):
                try:
                    component_stats[name] = component.get_stats()
                except Exception as e:
                    component_stats[name] = {'error': str(e)}
        
        # Get event system stats
        event_stats = self.event_system.get_stats() if self.event_system else {}
        
        return {
            'running': self._running,
            'uptime_seconds': uptime,
            'components': self._component_status,
            'component_stats': component_stats,
            'event_system': event_stats,
            'platform': self.platform_adapter.get_platform_stats(),
            'config': {
                'file_monitoring': self.config.file_monitor.enabled,
                'process_monitoring': self.config.process_monitor.enabled,
                'syscall_monitoring': self.config.syscall_monitor.enabled,
                'network_monitoring': self.config.network_monitor.enabled,
                'behavior_analysis': self.config.ml.enabled,
                'alert_system': self.config.alert_config.enabled,
                'performance_monitoring': self.config.performance.caching_enabled
            }
        }
    
    def get_summary(self) -> str:
        """Get human-readable status summary."""
        status = self.get_status()
        
        summary = []
        summary.append("=== Real-Time Monitor Status ===")
        summary.append(f"Status: {'Running' if status['running'] else 'Stopped'}")
        summary.append(f"Uptime: {status['uptime_seconds']:.1f} seconds")
        summary.append("")
        
        summary.append("Components:")
        for component, component_status in status['components'].items():
            summary.append(f"  {component}: {component_status}")
        summary.append("")
        
        # Event system stats
        event_stats = status.get('event_system', {})
        if event_stats:
            summary.append("Event System:")
            summary.append(f"  Events processed: {event_stats.get('event_bus', {}).get('events_processed', 0)}")
            summary.append(f"  Events dropped: {event_stats.get('event_bus', {}).get('events_dropped', 0)}")
            summary.append(f"  Active subscribers: {event_stats.get('event_bus', {}).get('subscribers_count', 0)}")
            summary.append("")
        
        # Platform info
        platform_info = status.get('platform', {})
        if platform_info:
            summary.append("Platform:")
            platform_data = platform_info.get('platform_info', {})
            summary.append(f"  Type: {platform_data.get('type', 'Unknown')}")
            summary.append(f"  Name: {platform_data.get('name', 'Unknown')}")
            summary.append(f"  Architecture: {platform_data.get('architecture', 'Unknown')}")
            summary.append("")
        
        return "\n".join(summary)
    
    def save_config(self) -> bool:
        """Save current configuration to file."""
        try:
            self.config.save_config()
            self.logger.info(f"Configuration saved to {self.config.config_path}")
            return True
        except Exception as e:
            self.logger.error(f"Error saving configuration: {e}")
            return False
    
    def reload_config(self) -> bool:
        """Reload configuration from file."""
        try:
            old_config = self.config
            self.config = MonitorConfig(self.config.config_path)
            self.logger.info("Configuration reloaded")
            return True
        except Exception as e:
            self.logger.error(f"Error reloading configuration: {e}")
            return False
    
    def __enter__(self):
        """Context manager entry."""
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        """Context manager exit."""
        self.stop()


# Global monitor instance
_monitor_instance: Optional[RealTimeMonitor] = None


def get_monitor() -> RealTimeMonitor:
    """Get the global monitor instance."""
    global _monitor_instance
    if _monitor_instance is None:
        _monitor_instance = RealTimeMonitor()
    return _monitor_instance


def main():
    """Main entry point for command line usage."""
    import argparse
    
    parser = argparse.ArgumentParser(description="AI Antivirus Real-Time Monitor")
    parser.add_argument('--config', help='Configuration file path')
    parser.add_argument('--daemon', action='store_true', help='Run as daemon')
    parser.add_argument('--status', action='store_true', help='Show status and exit')
    parser.add_argument('--save-config', help='Save current config to file')
    
    args = parser.parse_args()
    
    # Create monitor
    monitor = RealTimeMonitor(args.config)
    
    if args.status:
        print(monitor.get_summary())
        return
    
    if args.save_config:
        monitor.save_config()
        print(f"Configuration saved to {args.save_config}")
        return
    
    try:
        if args.daemon:
            # Daemon mode
            import daemon
            with daemon.DaemonContext():
                monitor.start()
                
                # Keep running
                while monitor._running:
                    time.sleep(1)
        else:
            # Interactive mode
            monitor.start()
            
            print("Real-time monitoring system started.")
            print("Press Ctrl+C to stop.")
            
            # Keep running
            while monitor._running:
                time.sleep(1)
                
    except KeyboardInterrupt:
        print("\nShutting down...")
    finally:
        monitor.stop()
        print("Monitor stopped.")


if __name__ == "__main__":
    main()