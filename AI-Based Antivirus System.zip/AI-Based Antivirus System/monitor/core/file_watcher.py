"""
File system watcher for real-time file access monitoring.

Provides platform-optimized file system monitoring with:
- Real-time file access tracking
- Behavioral pattern analysis
- Hash-based caching for performance
- Batch processing for minimal system impact
- Cross-platform compatibility (Linux, Windows, macOS)

Based on research from behavioral analysis for detecting file-based threats
in real-time with minimal performance overhead.
"""

import os
import time
import hashlib
import threading
import queue
import platform
from typing import Dict, List, Set, Optional, Callable, Tuple
from pathlib import Path
from dataclasses import dataclass
from concurrent.futures import ThreadPoolExecutor
import fnmatch

from ..core.event_system import EventSystem, EventType, EventPriority, get_event_system
from ..core.config import MonitorConfig


@dataclass
class FileEvent:
    """File system event data."""
    event_type: str
    file_path: str
    file_size: int
    file_hash: Optional[str]
    timestamp: float
    process_id: Optional[int] = None
    process_name: Optional[str] = None
    user_id: Optional[int] = None
    metadata: Dict = None
    
    def __post_init__(self):
        if self.metadata is None:
            self.metadata = {}


class FileHasher:
    """Efficient file hashing with caching."""
    
    def __init__(self, cache_size: int = 1000):
        self.cache_size = cache_size
        self._cache: Dict[str, str] = {}
        self._cache_order: List[str] = []
        self._lock = threading.RLock()
    
    def get_file_hash(self, file_path: str, use_cache: bool = True) -> Optional[str]:
        """Get file hash with optional caching."""
        if not os.path.exists(file_path):
            return None
        
        # Check cache first
        if use_cache:
            with self._lock:
                if file_path in self._cache:
                    # Move to end (LRU)
                    self._cache_order.remove(file_path)
                    self._cache_order.append(file_path)
                    return self._cache[file_path]
        
        # Calculate hash
        try:
            hash_obj = hashlib.sha256()
            with open(file_path, 'rb') as f:
                # Read in chunks to handle large files efficiently
                for chunk in iter(lambda: f.read(4096), b''):
                    hash_obj.update(chunk)
            
            file_hash = hash_obj.hexdigest()
            
            # Cache the result
            if use_cache:
                with self._lock:
                    self._cache[file_path] = file_hash
                    self._cache_order.append(file_path)
                    
                    # Evict old entries if cache is full
                    while len(self._cache) > self.cache_size:
                        oldest = self._cache_order.pop(0)
                        del self._cache[oldest]
            
            return file_hash
            
        except (IOError, OSError, PermissionError):
            return None
    
    def clear_cache(self) -> None:
        """Clear the hash cache."""
        with self._lock:
            self._cache.clear()
            self._cache_order.clear()


class PlatformFileWatcher:
    """Base class for platform-specific file watchers."""
    
    def __init__(self, config: FileMonitorConfig, event_system: EventSystem):
        self.config = config
        self.event_system = event_system
        self._running = False
        self._watchers = {}
        self._excluded_patterns = set(config.exclude_patterns)
    
    def start(self) -> bool:
        """Start the file watcher."""
        raise NotImplementedError
    
    def stop(self) -> None:
        """Stop the file watcher."""
        self._running = False
    
    def _should_exclude(self, file_path: str) -> bool:
        """Check if file should be excluded based on patterns."""
        path = Path(file_path)
        
        for pattern in self._excluded_patterns:
            if fnmatch.fnmatch(str(path), pattern) or fnmatch.fnmatch(path.name, pattern):
                return True
        
        return False
    
    def _create_file_event(self, event_type: str, file_path: str, 
                          process_info: Dict = None) -> FileEvent:
        """Create a file event."""
        file_size = 0
        file_hash = None
        
        try:
            if os.path.exists(file_path):
                file_size = os.path.getsize(file_path)
                
                # Only hash small files to avoid performance impact
                if file_size < self.config.scan_threshold_mb * 1024 * 1024:
                    file_hasher = FileHasher(self.config.cache_size)
                    file_hash = file_hasher.get_file_hash(file_path, use_cache=True)
        except (OSError, PermissionError):
            pass
        
        return FileEvent(
            event_type=event_type,
            file_path=file_path,
            file_size=file_size,
            file_hash=file_hash,
            timestamp=time.time(),
            process_id=process_info.get('pid') if process_info else None,
            process_name=process_info.get('name') if process_info else None,
            user_id=process_info.get('uid') if process_info else None
        )


class LinuxFileWatcher(PlatformFileWatcher):
    """Linux-specific file watcher using inotify/fanotify."""
    
    def __init__(self, config: FileMonitorConfig, event_system: EventSystem):
        super().__init__(config, event_system)
        self._inotify_events = {
            'create': 0x00000100,  # IN_CREATE
            'modify': 0x00000002,  # IN_MODIFY
            'delete': 0x00000200,  # IN_DELETE
            'access': 0x00000020,  # IN_ACCESS
            'move': 0x00000080,    # IN_MOVED_FROM | IN_MOVED_TO
        }
    
    def start(self) -> bool:
        """Start the Linux file watcher."""
        try:
            import inotify.adapters
            
            self._inotify = inotify.adapters.Inotify()
            self._running = True
            
            # Add watches for configured paths
            for watch_path in self.config.watch_paths:
                if os.path.exists(watch_path):
                    self._inotify.add_watch(watch_path)
            
            # Start monitoring thread
            monitor_thread = threading.Thread(target=self._monitor_loop, daemon=True)
            monitor_thread.start()
            
            return True
            
        except ImportError:
            print("Warning: inotify not available. File monitoring will be limited.")
            return False
        except Exception as e:
            print(f"Error starting Linux file watcher: {e}")
            return False
    
    def _monitor_loop(self) -> None:
        """Main monitoring loop."""
        while self._running:
            try:
                events = self._inotify.event_gen(timeout=1)
                
                for event in events:
                    if not event or not self._running:
                        break
                    
                    # Parse inotify event
                    event_mask = event[1]
                    event_name = event[3] if len(event) > 3 else ""
                    
                    # Map inotify events to our event types
                    file_path = os.path.join(event[2], event_name)
                    
                    if self._should_exclude(file_path):
                        continue
                    
                    # Get process information
                    process_info = self._get_process_info()
                    
                    # Determine event type
                    event_type = "unknown"
                    if event_mask & 0x00000100:  # IN_CREATE
                        event_type = "create"
                    elif event_mask & 0x00000002:  # IN_MODIFY
                        event_type = "modify"
                    elif event_mask & 0x00000200:  # IN_DELETE
                        event_type = "delete"
                    elif event_mask & 0x00000020:  # IN_ACCESS
                        event_type = "access"
                    
                    if event_type != "unknown":
                        file_event = self._create_file_event(event_type, file_path, process_info)
                        self._process_file_event(file_event)
                        
            except Exception as e:
                if self._running:
                    print(f"Error in file monitoring: {e}")
    
    def _get_process_info(self) -> Dict:
        """Get current process information."""
        try:
            return {
                'pid': os.getpid(),
                'name': 'monitor',
                'uid': os.getuid() if hasattr(os, 'getuid') else None
            }
        except Exception:
            return {}
    
    def _process_file_event(self, file_event: FileEvent) -> None:
        """Process a file event."""
        # Determine event type for the event system
        event_type_map = {
            'create': EventType.FILE_CREATE,
            'modify': EventType.FILE_MODIFY,
            'delete': EventType.FILE_DELETE,
            'access': EventType.FILE_ACCESS
        }
        
        event_type = event_type_map.get(file_event.event_type)
        if not event_type:
            return
        
        # Create event
        event = self.event_system.create_event(
            event_type=event_type,
            source="file_monitor",
            data={
                'file_path': file_event.file_path,
                'file_size': file_event.file_size,
                'file_hash': file_event.file_hash,
                'process_id': file_event.process_id,
                'process_name': file_event.process_name
            },
            priority=EventPriority.NORMAL
        )
        
        # Publish event
        self.event_system.publish_event(event)


class WindowsFileWatcher(PlatformFileWatcher):
    """Windows-specific file watcher using ReadDirectoryChangesW."""
    
    def start(self) -> bool:
        """Start the Windows file watcher."""
        try:
            import win32file
            import pywintypes
            
            self._running = True
            
            # Start monitoring thread
            monitor_thread = threading.Thread(target=self._monitor_loop, daemon=True)
            monitor_thread.start()
            
            return True
            
        except ImportError:
            print("Warning: pywin32 not available. File monitoring will be limited.")
            return False
        except Exception as e:
            print(f"Error starting Windows file watcher: {e}")
            return False
    
    def _monitor_loop(self) -> None:
        """Main monitoring loop."""
        try:
            import win32file
            import pywintypes
            
            # Create file monitoring handles
            handles = []
            for watch_path in self.config.watch_paths:
                if os.path.exists(watch_path):
                    try:
                        handle = win32file.FindFirstChangeNotification(
                            watch_path, 
                            self.config.recursive,
                            win32file.FILE_NOTIFY_CHANGE_FILE_NAME | 
                            win32file.FILE_NOTIFY_CHANGE_LAST_WRITE |
                            win32file.FILE_NOTIFY_CHANGE_SIZE
                        )
                        handles.append((handle, watch_path))
                    except pywintypes.error:
                        continue
            
            while self._running and handles:
                # Wait for file system changes
                results = win32file.MsgWaitForMultipleObjects(
                    handles, 
                    False, 
                    1000,  # 1 second timeout
                    win32file.QS_ALLINPUT
                )
                
                if 0 <= results < len(handles):
                    handle, watch_path = handles[results]
                    
                    # Reset notification
                    win32file.FindNextChangeNotification(handle)
                    
                    # Get process information
                    process_info = self._get_process_info()
                    
                    # Scan for changes (simplified)
                    self._scan_directory_changes(watch_path, process_info)
                    
        except Exception as e:
            if self._running:
                print(f"Error in Windows file monitoring: {e}")
    
    def _get_process_info(self) -> Dict:
        """Get current process information."""
        try:
            import win32api
            return {
                'pid': win32api.GetCurrentProcessId(),
                'name': 'monitor',
                'uid': None  # Windows doesn't have user IDs like Unix
            }
        except Exception:
            return {}
    
    def _scan_directory_changes(self, directory: str, process_info: Dict) -> None:
        """Scan directory for file changes."""
        try:
            for root, dirs, files in os.walk(directory):
                for file_name in files:
                    file_path = os.path.join(root, file_name)
                    
                    if self._should_exclude(file_path):
                        continue
                    
                    # Create file event
                    file_event = self._create_file_event("modify", file_path, process_info)
                    self._process_file_event(file_event)
                    
                # Don't recurse into excluded directories
                dirs[:] = [d for d in dirs if not self._should_exclude(os.path.join(root, d))]
                
        except Exception as e:
            print(f"Error scanning directory {directory}: {e}")
    
    def _process_file_event(self, file_event: FileEvent) -> None:
        """Process a file event."""
        # Similar to Linux implementation
        event_type_map = {
            'create': EventType.FILE_CREATE,
            'modify': EventType.FILE_MODIFY,
            'delete': EventType.FILE_DELETE,
            'access': EventType.FILE_ACCESS
        }
        
        event_type = event_type_map.get(file_event.event_type)
        if not event_type:
            return
        
        event = self.event_system.create_event(
            event_type=event_type,
            source="file_monitor",
            data={
                'file_path': file_event.file_path,
                'file_size': file_event.file_size,
                'file_hash': file_event.file_hash,
                'process_id': file_event.process_id,
                'process_name': file_event.process_name
            },
            priority=EventPriority.NORMAL
        )
        
        self.event_system.publish_event(event)


class FileSystemWatcher:
    """Main file system watcher with platform-specific implementations."""
    
    def __init__(self, config: MonitorConfig):
        self.config = config.file_monitor
        self.event_system = get_event_system()
        self._watcher: Optional[PlatformFileWatcher] = None
        self._file_hasher = FileHasher(config.file_monitor.cache_size)
        self._processed_files: Set[str] = set()
        self._batch_queue = queue.Queue(maxsize=config.performance.queue_sizes['file_events'])
        self._batch_thread = None
        self._running = False
        
    def start(self) -> bool:
        """Start the file system watcher."""
        if not self.config.enabled:
            return False
        
        # Create platform-specific watcher
        system = platform.system().lower()
        
        if system == 'linux':
            self._watcher = LinuxFileWatcher(self.config, self.event_system)
        elif system == 'windows':
            self._watcher = WindowsFileWatcher(self.config, self.event_system)
        else:
            # Fallback to basic monitoring
            self._watcher = LinuxFileWatcher(self.config, self.event_system)
        
        # Start the watcher
        if self._watcher.start():
            self._running = True
            
            # Start batch processing thread
            if self.config.batch_size > 1:
                self._batch_thread = threading.Thread(
                    target=self._batch_processor, 
                    daemon=True
                )
                self._batch_thread.start()
            
            return True
        
        return False
    
    def stop(self) -> None:
        """Stop the file system watcher."""
        self._running = False
        
        if self._watcher:
            self._watcher.stop()
        
        if self._batch_thread:
            self._batch_thread.join(timeout=5)
    
    def _batch_processor(self) -> None:
        """Process file events in batches for performance."""
        batch = []
        
        while self._running:
            try:
                # Collect events in batch
                try:
                    file_event = self._batch_queue.get(timeout=1)
                    batch.append(file_event)
                except queue.Empty:
                    pass
                
                # Process batch if full or timeout
                if len(batch) >= self.config.batch_size or (batch and time.time() % 1 < 0.1):
                    self._process_batch(batch)
                    batch.clear()
                    
            except Exception as e:
                print(f"Error in batch processing: {e}")
        
        # Process remaining batch
        if batch:
            self._process_batch(batch)
    
    def _process_batch(self, batch: List[FileEvent]) -> None:
        """Process a batch of file events."""
        # Batch hash calculation
        file_hashes = {}
        for file_event in batch:
            if file_event.file_path not in self._processed_files:
                file_hash = self._file_hasher.get_file_hash(file_event.file_path)
                file_hashes[file_event.file_path] = file_hash
        
        # Publish events
        for file_event in batch:
            if file_event.file_path in file_hashes:
                file_event.file_hash = file_hashes[file_event.file_path]
                self._processed_files.add(file_event.file_path)
            
            # Create and publish event
            self._create_and_publish_event(file_event)
    
    def _create_and_publish_event(self, file_event: FileEvent) -> None:
        """Create and publish a file event."""
        # Map to event system types
        event_type_map = {
            'create': EventType.FILE_CREATE,
            'modify': EventType.FILE_MODIFY,
            'delete': EventType.FILE_DELETE,
            'access': EventType.FILE_ACCESS,
            'move': EventType.FILE_MOVE,
            'rename': EventType.FILE_RENAME
        }
        
        event_type = event_type_map.get(file_event.event_type)
        if not event_type:
            return
        
        # Determine priority based on file type
        priority = EventPriority.NORMAL
        if self._is_suspicious_file(file_event.file_path):
            priority = EventPriority.HIGH
        
        # Create event
        event = self.event_system.create_event(
            event_type=event_type,
            source="file_monitor",
            data={
                'file_path': file_event.file_path,
                'file_size': file_event.file_size,
                'file_hash': file_event.file_hash,
                'process_id': file_event.process_id,
                'process_name': file_event.process_name,
                'user_id': file_event.user_id
            },
            priority=priority
        )
        
        self.event_system.publish_event(event)
    
    def _is_suspicious_file(self, file_path: str) -> bool:
        """Check if file is suspicious based on name, location, or characteristics."""
        # Check file extension
        suspicious_extensions = ['.exe', '.bat', '.cmd', '.ps1', '.vbs', '.js', '.jar']
        if any(file_path.lower().endswith(ext) for ext in suspicious_extensions):
            return True
        
        # Check path patterns
        suspicious_paths = ['/tmp/', '/var/tmp/', 'C:\\temp\\', 'C:\\appdata\\']
        if any(suspect_path in file_path for suspect_path in suspicious_paths):
            return True
        
        return False
    
    def get_stats(self) -> Dict:
        """Get file watcher statistics."""
        return {
            'running': self._running,
            'watcher_type': type(self._watcher).__name__ if self._watcher else None,
            'watch_paths': self.config.watch_paths,
            'processed_files': len(self._processed_files),
            'queue_size': self._batch_queue.qsize(),
            'cache_size': len(self._file_hasher._cache)
        }