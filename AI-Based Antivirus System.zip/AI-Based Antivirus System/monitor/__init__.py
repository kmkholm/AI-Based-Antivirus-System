"""
Real-Time Monitoring System for AI-Based Antivirus

A comprehensive behavioral analysis and real-time monitoring system that provides:
- File system monitoring for real-time file access analysis
- Process monitoring and behavioral pattern detection
- System call interception with platform-specific optimizations
- Network traffic monitoring integration
- Event-driven alert system with correlation
- Performance-optimized for minimal system impact

Based on behavioral analysis research from docs/behavioral_analysis.md
"""

from .core.monitor import RealTimeMonitor
from .core.config import MonitorConfig
from .core.event_system import EventSystem
from .behaviors.behavior_engine import BehaviorEngine
from .platforms.platform_adapter import PlatformAdapter

__version__ = "1.0.0"
__all__ = [
    "RealTimeMonitor",
    "MonitorConfig", 
    "EventSystem",
    "BehaviorEngine",
    "PlatformAdapter"
]

__author__ = "AI Antivirus Development Team"