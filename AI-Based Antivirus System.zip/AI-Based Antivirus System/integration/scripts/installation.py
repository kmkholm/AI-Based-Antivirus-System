"""
Installation and Deployment Scripts
==================================

Cross-platform installation and deployment system for antivirus components:
- Platform-specific installation logic
- Service registration and management
- Configuration deployment
- Dependency management
- Security hardening
- Rollback capabilities

Supports Windows (MSI, PowerShell), Linux (deb/rpm, systemd), and macOS (PKG, launchd).
"""

import os
import sys
import platform
import subprocess
import logging
import shutil
import tempfile
import json
import stat
from pathlib import Path
from typing import Dict, List, Optional, Any
from dataclasses import dataclass
from enum import Enum
import argparse

logger = logging.getLogger(__name__)


class InstallType(Enum):
    """Installation types."""
    SERVICE = "service"
    APPLICATION = "application"
    LIBRARY = "library"
    ALL = "all"


class InstallMode(Enum):
    """Installation modes."""
    INTERACTIVE = "interactive"
    SILENT = "silent"
    UNATTENDED = "unattended"


@dataclass
class InstallationConfig:
    """Installation configuration."""
    install_type: InstallType
    install_mode: InstallMode
    target_directory: str
    config_directory: str
    log_directory: str
    data_directory: str
    service_name: str
    service_description: str
    user: Optional[str] = None
    group: Optional[str] = None
    privileges: str = "user"
    auto_start: bool = True
    enable_firewall: bool = True
    enable_logging: bool = True
    install_dependencies: bool = True
    verify_signature: bool = True


class BaseInstaller:
    """Base installer class."""
    
    def __init__(self, config: InstallationConfig):
        self.config = config
        self.system = platform.system().lower()
        self.architecture = platform.machine().lower()
        self.source_dir = Path(__file__).parent.parent
        self.temp_dir = Path(tempfile.gettempdir()) / "antivirus_install"
        
    def install(self) -> bool:
        """Perform installation."""
        try:
            logger.info(f"Starting {self.config.install_type.value} installation")
            
            # Pre-installation checks
            if not self._pre_install_checks():
                return False
                
            # Create directories
            self._create_directories()
            
            # Install files
            if not self._install_files():
                return False
                
            # Install dependencies
            if self.config.install_dependencies:
                if not self._install_dependencies():
                    return False
                    
            # Create configuration
            if not self._create_configuration():
                return False
                
            # Install as service
            if self.config.install_type in [InstallType.SERVICE, InstallType.ALL]:
                if not self._install_service():
                    return False
                    
            # Post-installation setup
            if not self._post_install():
                return False
                
            logger.info("Installation completed successfully")
            return True
            
        except Exception as e:
            logger.error(f"Installation failed: {e}")
            return False
            
    def uninstall(self) -> bool:
        """Perform uninstallation."""
        try:
            logger.info(f"Starting {self.config.install_type.value} uninstallation")
            
            # Stop service if running
            if self.config.install_type in [InstallType.SERVICE, InstallType.ALL]:
                self._uninstall_service()
                
            # Remove files
            self._remove_files()
            
            # Remove directories
            self._remove_directories()
            
            # Clean up configuration
            self._cleanup_configuration()
            
            logger.info("Uninstallation completed successfully")
            return True
            
        except Exception as e:
            logger.error(f"Uninstallation failed: {e}")
            return False
            
    def verify(self) -> bool:
        """Verify installation."""
        try:
            logger.info("Verifying installation")
            
            # Check directories
            if not self._verify_directories():
                return False
                
            # Check files
            if not self._verify_files():
                return False
                
            # Check service
            if self.config.install_type in [InstallType.SERVICE, InstallType.ALL]:
                if not self._verify_service():
                    return False
                    
            logger.info("Verification completed successfully")
            return True
            
        except Exception as e:
            logger.error(f"Verification failed: {e}")
            return False
            
    def _pre_install_checks(self) -> bool:
        """Pre-installation checks."""
        try:
            # Check available disk space
            target_path = Path(self.config.target_directory)
            if not target_path.parent.exists():
                logger.error(f"Target directory parent does not exist: {target_path.parent}")
                return False
                
            # Check permissions
            if self.system != 'windows':
                import pwd
                import grp
                
                try:
                    if self.config.user:
                        pwd.getpwnam(self.config.user)
                    if self.config.group:
                        grp.getgrnam(self.config.group)
                except KeyError as e:
                    logger.error(f"User or group does not exist: {e}")
                    return False
                    
            return True
            
        except Exception as e:
            logger.error(f"Pre-installation check failed: {e}")
            return False
            
    def _create_directories(self) -> None:
        """Create installation directories."""
        directories = [
            self.config.target_directory,
            self.config.config_directory,
            self.config.log_directory,
            self.config.data_directory
        ]
        
        for directory in directories:
            path = Path(directory)
            path.mkdir(parents=True, exist_ok=True)
            
    def _install_files(self) -> bool:
        """Install application files."""
        try:
            target_path = Path(self.config.target_directory)
            
            # Copy main application files
            src_files = [
                'abstraction',
                'platforms',
                'services',
                'config',
                'monitoring'
            ]
            
            for src_dir in src_files:
                src_path = self.source_dir / src_dir
                if src_path.exists():
                    dst_path = target_path / src_dir
                    shutil.copytree(src_path, dst_path, dirs_exist_ok=True)
                    
            # Copy scripts
            scripts_dir = target_path / 'scripts'
            if scripts_dir.exists():
                shutil.rmtree(scripts_dir)
            shutil.copytree(self.source_dir / 'scripts', scripts_dir)
            
            # Set permissions
            if self.system != 'windows':
                self._set_file_permissions(target_path)
                
            return True
            
        except Exception as e:
            logger.error(f"File installation failed: {e}")
            return False
            
    def _set_file_permissions(self, target_path: Path) -> None:
        """Set file permissions."""
        try:
            # Make scripts executable
            for script_file in target_path.rglob('*.sh'):
                script_file.chmod(0o755)
                
            for script_file in target_path.rglob('*.py'):
                script_file.chmod(0o755)
                
        except Exception as e:
            logger.error(f"Setting permissions failed: {e}")
            
    def _install_dependencies(self) -> bool:
        """Install system dependencies."""
        try:
            if self.system == 'linux':
                return self._install_linux_dependencies()
            elif self.system == 'darwin':
                return self._install_macos_dependencies()
            elif self.system == 'windows':
                return self._install_windows_dependencies()
            else:
                logger.warning(f"Dependencies installation not supported for {self.system}")
                return True
                
        except Exception as e:
            logger.error(f"Dependencies installation failed: {e}")
            return False
            
    def _install_linux_dependencies(self) -> bool:
        """Install Linux dependencies."""
        try:
            # Check package manager
            if shutil.which('apt'):
                return self._install_apt_dependencies()
            elif shutil.which('yum'):
                return self._install_yum_dependencies()
            elif shutil.which('dnf'):
                return self._install_dnf_dependencies()
            else:
                logger.warning("No supported package manager found")
                return True
                
        except Exception as e:
            logger.error(f"Linux dependencies installation failed: {e}")
            return False
            
    def _install_apt_dependencies(self) -> bool:
        """Install apt dependencies."""
        try:
            packages = [
                'python3',
                'python3-pip',
                'python3-venv',
                'clamav',
                'clamav-daemon',
                'clamav-freshclam',
                'systemd',
            ]
            
            cmd = ['sudo', 'apt', 'update']
            subprocess.run(cmd, check=False)
            
            for package in packages:
                cmd = ['sudo', 'apt', 'install', '-y', package]
                result = subprocess.run(cmd, capture_output=True)
                if result.returncode != 0:
                    logger.warning(f"Failed to install {package}: {result.stderr.decode()}")
                    
            return True
            
        except Exception as e:
            logger.error(f"APT dependencies installation failed: {e}")
            return False
            
    def _install_yum_dependencies(self) -> bool:
        """Install yum dependencies."""
        try:
            packages = [
                'python3',
                'python3-pip',
                'clamav',
                'clamav-update',
                'systemd'
            ]
            
            for package in packages:
                cmd = ['sudo', 'yum', 'install', '-y', package]
                result = subprocess.run(cmd, capture_output=True)
                if result.returncode != 0:
                    logger.warning(f"Failed to install {package}: {result.stderr.decode()}")
                    
            return True
            
        except Exception as e:
            logger.error(f"YUM dependencies installation failed: {e}")
            return False
            
    def _install_dnf_dependencies(self) -> bool:
        """Install dnf dependencies."""
        try:
            packages = [
                'python3',
                'python3-pip',
                'clamav',
                'clamav-update',
                'systemd'
            ]
            
            for package in packages:
                cmd = ['sudo', 'dnf', 'install', '-y', package]
                result = subprocess.run(cmd, capture_output=True)
                if result.returncode != 0:
                    logger.warning(f"Failed to install {package}: {result.stderr.decode()}")
                    
            return True
            
        except Exception as e:
            logger.error(f"DNF dependencies installation failed: {e}")
            return False
            
    def _install_macos_dependencies(self) -> bool:
        """Install macOS dependencies."""
        try:
            if not shutil.which('brew'):
                logger.warning("Homebrew not found, skipping dependencies")
                return True
                
            packages = [
                'python@3.9',
                'clamav'
            ]
            
            for package in packages:
                cmd = ['brew', 'install', package]
                result = subprocess.run(cmd, capture_output=True)
                if result.returncode != 0:
                    logger.warning(f"Failed to install {package}: {result.stderr.decode()}")
                    
            return True
            
        except Exception as e:
            logger.error(f"macOS dependencies installation failed: {e}")
            return False
            
    def _install_windows_dependencies(self) -> bool:
        """Install Windows dependencies."""
        try:
            # Check for Python
            if not shutil.which('python'):
                logger.warning("Python not found in PATH")
                
            # Check for required Python packages
            try:
                import ctypes
                import cryptography
                import psutil
            except ImportError as e:
                logger.warning(f"Python dependency missing: {e}")
                
            return True
            
        except Exception as e:
            logger.error(f"Windows dependencies installation failed: {e}")
            return False
            
    def _create_configuration(self) -> bool:
        """Create configuration files."""
        try:
            config_dir = Path(self.config.config_directory)
            config_dir.mkdir(parents=True, exist_ok=True)
            
            # Create default configuration
            default_config = {
                "version": "1.0.0",
                "install_type": self.config.install_type.value,
                "target_directory": self.config.target_directory,
                "log_directory": self.config.log_directory,
                "data_directory": self.config.data_directory,
                "services": {
                    "file_scanner": {
                        "enabled": True,
                        "monitored_paths": ["/tmp", "/var/tmp", "/Downloads"]
                    },
                    "real_time_monitor": {
                        "enabled": True
                    },
                    "ai_detection": {
                        "enabled": True,
                        "model_path": f"{self.config.data_directory}/models"
                    },
                    "threat_intelligence": {
                        "enabled": True,
                        "update_interval": 3600
                    }
                }
            }
            
            config_file = config_dir / 'antivirus.json'
            with open(config_file, 'w') as f:
                json.dump(default_config, f, indent=2)
                
            return True
            
        except Exception as e:
            logger.error(f"Configuration creation failed: {e}")
            return False
            
    def _install_service(self) -> bool:
        """Install system service."""
        try:
            if self.system == 'linux':
                return self._install_linux_service()
            elif self.system == 'darwin':
                return self._install_macos_service()
            elif self.system == 'windows':
                return self._install_windows_service()
            else:
                logger.warning(f"Service installation not supported for {self.system}")
                return True
                
        except Exception as e:
            logger.error(f"Service installation failed: {e}")
            return False
            
    def _install_linux_service(self) -> bool:
        """Install Linux systemd service."""
        try:
            service_content = f"""[Unit]
Description={self.config.service_description}
After=network.target

[Service]
Type=simple
ExecStart={self.config.target_directory}/services/__init__.py --start
WorkingDirectory={self.config.target_directory}
Restart=always
RestartSec=10
User={self.config.user or 'antivirus'}
Group={self.config.group or 'antivirus'}

[Install]
WantedBy=multi-user.target
"""
            
            service_file = Path(f"/etc/systemd/system/{self.config.service_name}.service")
            with open(service_file, 'w') as f:
                f.write(service_content)
                
            # Create antivirus user if needed
            if not self._user_exists(self.config.user or 'antivirus'):
                subprocess.run(['sudo', 'useradd', '-r', '-s', '/bin/false', 'antivirus'], check=False)
                
            # Reload systemd
            subprocess.run(['sudo', 'systemctl', 'daemon-reload'], check=True)
            
            # Enable service
            if self.config.auto_start:
                subprocess.run(['sudo', 'systemctl', 'enable', self.config.service_name], check=True)
                
            return True
            
        except Exception as e:
            logger.error(f"Linux service installation failed: {e}")
            return False
            
    def _install_macos_service(self) -> bool:
        """Install macOS launchd service."""
        try:
            import plistlib
            
            plist_content = {
                "Label": f"com.antivirus.{self.config.service_name}",
                "ProgramArguments": [
                    f"{self.config.target_directory}/services/__init__.py",
                    "--start"
                ],
                "WorkingDirectory": self.config.target_directory,
                "RunAtLoad": self.config.auto_start,
                "KeepAlive": True,
                "StandardOutPath": f"{self.config.log_directory}/service.out.log",
                "StandardErrorPath": f"{self.config.log_directory}/service.err.log"
            }
            
            plist_file = Path(f"/Library/LaunchDaemons/com.antivirus.{self.config.service_name}.plist")
            with open(plist_file, 'wb') as f:
                plistlib.dump(plist_content, f)
                
            return True
            
        except Exception as e:
            logger.error(f"macOS service installation failed: {e}")
            return False
            
    def _install_windows_service(self) -> bool:
        """Install Windows service."""
        try:
            # Create Windows service using sc.exe
            service_name = self.config.service_name
            executable_path = f"{self.config.target_directory}\\services\\__init__.py"
            
            cmd = [
                'sc', 'create', service_name,
                f'binPath= "{executable_path}"',
                'DisplayName= Antivirus System Service',
                'Start= auto'
            ]
            
            result = subprocess.run(cmd, capture_output=True, text=True)
            return result.returncode == 0
            
        except Exception as e:
            logger.error(f"Windows service installation failed: {e}")
            return False
            
    def _user_exists(self, username: str) -> bool:
        """Check if user exists."""
        try:
            import pwd
            pwd.getpwnam(username)
            return True
        except KeyError:
            return False
            
    def _post_install(self) -> bool:
        """Post-installation setup."""
        try:
            # Set up logging
            if self.config.enable_logging:
                self._setup_logging()
                
            # Configure firewall
            if self.config.enable_firewall:
                self._configure_firewall()
                
            return True
            
        except Exception as e:
            logger.error(f"Post-installation setup failed: {e}")
            return False
            
    def _setup_logging(self) -> None:
        """Set up logging configuration."""
        try:
            log_dir = Path(self.config.log_directory)
            log_dir.mkdir(parents=True, exist_ok=True)
            
            # Create log configuration
            log_config = f"""[formatters]
simple
format = %(asctime)s - %(name)s - %(levelname)s - %(message)s

[handlers]
console
file

[handler_console]
class = StreamHandler
level = INFO
formatter = simple
args = (sys.stdout,)

[handler_file]
class = FileHandler
level = DEBUG
formatter = simple
args = ('{log_dir}/antivirus.log',)

[loggers]
root
antivirus

[logger_root]
level = INFO
handlers = console,file

[logger_antivirus]
level = DEBUG
handlers = console,file
qualname = antivirus
propagate = 0
"""
            
            config_file = Path(self.config.config_directory) / 'logging.conf'
            with open(config_file, 'w') as f:
                f.write(log_config)
                
        except Exception as e:
            logger.error(f"Logging setup failed: {e}")
            
    def _configure_firewall(self) -> None:
        """Configure system firewall."""
        try:
            if self.system == 'linux':
                # Configure UFW
                if shutil.which('ufw'):
                    subprocess.run(['sudo', 'ufw', '--force', 'enable'], check=False)
                    
            elif self.system == 'darwin':
                # macOS firewall configuration
                subprocess.run([
                    'sudo', 'defaults', 'write', '/Library/Preferences/com.Apple.sharing.firewall',
                    'FirewallState', '-int', '1'
                ], check=False)
                
        except Exception as e:
            logger.error(f"Firewall configuration failed: {e}")
            
    def _verify_directories(self) -> bool:
        """Verify installation directories."""
        directories = [
            self.config.target_directory,
            self.config.config_directory,
            self.config.log_directory,
            self.config.data_directory
        ]
        
        for directory in directories:
            if not Path(directory).exists():
                logger.error(f"Directory does not exist: {directory}")
                return False
                
        return True
        
    def _verify_files(self) -> bool:
        """Verify installation files."""
        required_files = [
            'abstraction/__init__.py',
            'platforms/__init__.py',
            'services/__init__.py'
        ]
        
        for file_rel_path in required_files:
            file_path = Path(self.config.target_directory) / file_rel_path
            if not file_path.exists():
                logger.error(f"Required file does not exist: {file_path}")
                return False
                
        return True
        
    def _verify_service(self) -> bool:
        """Verify service installation."""
        if self.system == 'linux':
            result = subprocess.run(['systemctl', 'list-unit-files', '--type=service'], 
                                  capture_output=True, text=True)
            return self.config.service_name in result.stdout
        elif self.system == 'darwin':
            result = subprocess.run(['launchctl', 'list'], capture_output=True, text=True)
            return f"com.antivirus.{self.config.service_name}" in result.stdout
        elif self.system == 'windows':
            result = subprocess.run(['sc', 'query', self.config.service_name], 
                                  capture_output=True, text=True)
            return 'RUNNING' in result.stdout or 'STOPPED' in result.stdout
        else:
            return True
            
    def _uninstall_service(self) -> None:
        """Uninstall system service."""
        try:
            if self.system == 'linux':
                subprocess.run(['sudo', 'systemctl', 'stop', self.config.service_name], 
                             check=False, capture_output=True)
                subprocess.run(['sudo', 'systemctl', 'disable', self.config.service_name], 
                             check=False, capture_output=True)
                service_file = Path(f"/etc/systemd/system/{self.config.service_name}.service")
                if service_file.exists():
                    service_file.unlink()
                subprocess.run(['sudo', 'systemctl', 'daemon-reload'], check=False)
                
            elif self.system == 'darwin':
                subprocess.run(['sudo', 'launchctl', 'unload', 
                              f'/Library/LaunchDaemons/com.antivirus.{self.config.service_name}.plist'], 
                             check=False, capture_output=True)
                plist_file = Path(f"/Library/LaunchDaemons/com.antivirus.{self.config.service_name}.plist")
                if plist_file.exists():
                    plist_file.unlink()
                    
            elif self.system == 'windows':
                subprocess.run(['sc', 'stop', self.config.service_name], 
                             check=False, capture_output=True)
                subprocess.run(['sc', 'delete', self.config.service_name], 
                             check=False, capture_output=True)
                
        except Exception as e:
            logger.error(f"Service uninstallation failed: {e}")
            
    def _remove_files(self) -> None:
        """Remove installation files."""
        try:
            target_path = Path(self.config.target_directory)
            if target_path.exists():
                shutil.rmtree(target_path)
        except Exception as e:
            logger.error(f"File removal failed: {e}")
            
    def _remove_directories(self) -> None:
        """Remove installation directories."""
        try:
            directories = [
                self.config.config_directory,
                self.config.log_directory,
                self.config.data_directory
            ]
            
            for directory in directories:
                path = Path(directory)
                if path.exists():
                    shutil.rmtree(path)
        except Exception as e:
            logger.error(f"Directory removal failed: {e}")
            
    def _cleanup_configuration(self) -> None:
        """Clean up configuration."""
        try:
            # Remove configuration from system locations
            if self.system == 'linux':
                config_dirs = ['/etc/antivirus']
                for config_dir in config_dirs:
                    if Path(config_dir).exists():
                        shutil.rmtree(config_dir)
        except Exception as e:
            logger.error(f"Configuration cleanup failed: {e}")


def create_installer(install_config: InstallationConfig) -> BaseInstaller:
    """Factory function to create platform-specific installer."""
    system = platform.system().lower()
    
    if system == 'linux':
        from .installation import LinuxInstaller
        return LinuxInstaller(install_config)
    elif system == 'darwin':
        from .installation import MacOSInstaller
        return MacOSInstaller(install_config)
    elif system == 'windows':
        from .installation import WindowsInstaller
        return WindowsInstaller(install_config)
    else:
        raise NotImplementedError(f"Installation not supported for {system}")


class LinuxInstaller(BaseInstaller):
    """Linux-specific installer."""
    
    def __init__(self, config: InstallationConfig):
        super().__init__(config)
        # Linux-specific configuration
        config.target_directory = config.target_directory or '/opt/antivirus'
        config.config_directory = config.config_directory or '/etc/antivirus'
        config.log_directory = config.log_directory or '/var/log/antivirus'
        config.data_directory = config.data_directory or '/var/lib/antivirus'


class MacOSInstaller(BaseInstaller):
    """macOS-specific installer."""
    
    def __init__(self, config: InstallationConfig):
        super().__init__(config)
        # macOS-specific configuration
        config.target_directory = config.target_directory or '/usr/local/antivirus'
        config.config_directory = config.config_directory or '/Library/Application Support/antivirus'
        config.log_directory = config.log_directory or '/var/log/antivirus'
        config.data_directory = config.data_directory or '/Library/Application Support/antivirus/data'


class WindowsInstaller(BaseInstaller):
    """Windows-specific installer."""
    
    def __init__(self, config: InstallationConfig):
        super().__init__(config)
        # Windows-specific configuration
        program_files = os.environ.get('PROGRAMFILES', 'C:\\Program Files')
        config.target_directory = config.target_directory or f'{program_files}\\Antivirus'
        config.config_directory = config.config_directory or f'{os.environ.get("APPDATA", "")}\\antivirus'
        config.log_directory = config.log_directory or f'{program_files}\\Antivirus\\logs'
        config.data_directory = config.data_directory or f'{program_files}\\Antivirus\\data'


def main():
    """Main entry point for installation script."""
    import argparse
    
    parser = argparse.ArgumentParser(description='Antivirus System Installer')
    parser.add_argument('--type', choices=['service', 'application', 'library', 'all'],
                      default='service', help='Installation type')
    parser.add_argument('--mode', choices=['interactive', 'silent', 'unattended'],
                      default='interactive', help='Installation mode')
    parser.add_argument('--target', help='Target directory')
    parser.add_argument('--user', help='Service user')
    parser.add_argument('--group', help='Service group')
    parser.add_argument('--no-deps', action='store_true', help='Skip dependencies')
    parser.add_argument('--uninstall', action='store_true', help='Uninstall')
    parser.add_argument('--verify', action='store_true', help='Verify installation')
    
    args = parser.parse_args()
    
    # Set up logging
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(levelname)s - %(message)s'
    )
    
    # Create installation configuration
    config = InstallationConfig(
        install_type=InstallType(args.type),
        install_mode=InstallMode(args.mode),
        target_directory=args.target or '',
        config_directory='',
        log_directory='',
        data_directory='',
        service_name='antivirus-service',
        service_description='Antivirus System Service',
        user=args.user,
        group=args.group,
        install_dependencies=not args.no_deps
    )
    
    # Create and run installer
    installer = create_installer(config)
    
    try:
        if args.uninstall:
            success = installer.uninstall()
        elif args.verify:
            success = installer.verify()
        else:
            success = installer.install()
            
        if success:
            print("Operation completed successfully")
            sys.exit(0)
        else:
            print("Operation failed")
            sys.exit(1)
            
    except Exception as e:
        logger.error(f"Installation error: {e}")
        sys.exit(1)


if __name__ == '__main__':
    main()