"""
Installation and Deployment Scripts
==================================

Cross-platform installation and deployment scripts:
- Installation automation
- Service registration
- Configuration deployment
- Dependency management
- Rollback capabilities

Supports Windows, Linux, and macOS installation methods.
"""

from .installation import (
    InstallationConfig, InstallType, InstallMode,
    BaseInstaller, LinuxInstaller, MacOSInstaller, WindowsInstaller,
    create_installer
)

__all__ = [
    'InstallationConfig', 'InstallType', 'InstallMode',
    'BaseInstaller', 'LinuxInstaller', 'MacOSInstaller', 'WindowsInstaller',
    'create_installer'
]