#!/usr/bin/env python3
"""
System Integration Setup and Validation Script
==============================================

Sets up and validates the cross-platform integration layer:
- Platform detection and validation
- Dependency checking
- Configuration validation
- Integration testing
- Performance validation

This script ensures the integration layer is properly installed and configured.
"""

import os
import sys
import platform
import subprocess
import json
import logging
from pathlib import Path
from typing import Dict, List, Optional, Any

# Add the integration directory to Python path
integration_dir = Path(__file__).parent
sys.path.insert(0, str(integration_dir))

# Set up logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


class IntegrationValidator:
    """Validates the integration layer installation and configuration."""
    
    def __init__(self):
        self.system = platform.system().lower()
        self.architecture = platform.machine()
        self.python_version = sys.version_info
        self.validation_results: Dict[str, bool] = {}
        self.warnings: List[str] = []
        self.errors: List[str] = []
        
    def validate_all(self) -> bool:
        """Run all validation checks."""
        logger.info(f"Starting integration validation on {self.system} {self.architecture}")
        
        try:
            # Basic system validation
            self.validate_system()
            
            # Python environment validation
            self.validate_python_environment()
            
            # Dependencies validation
            self.validate_dependencies()
            
            # Integration modules validation
            self.validate_integration_modules()
            
            # Configuration validation
            self.validate_configuration()
            
            # Platform-specific validation
            self.validate_platform_specific()
            
            # Functional validation
            self.validate_functionality()
            
            # Generate report
            self.generate_report()
            
            return len(self.errors) == 0
            
        except Exception as e:
            logger.error(f"Validation failed with error: {e}")
            return False
            
    def validate_system(self) -> None:
        """Validate basic system requirements."""
        logger.info("Validating system requirements...")
        
        # Check operating system
        supported_systems = ['windows', 'linux', 'darwin']
        if self.system not in supported_systems:
            self.errors.append(f"Unsupported operating system: {self.system}")
        else:
            logger.info(f"✓ Supported operating system: {self.system}")
            
        # Check Python version
        if self.python_version < (3, 8):
            self.errors.append(f"Python 3.8+ required, found {self.python_version.major}.{self.python_version.minor}")
        else:
            logger.info(f"✓ Python version: {self.python_version.major}.{self.python_version.minor}.{self.python_version.micro}")
            
        # Check architecture
        supported_architectures = ['x86_64', 'amd64', 'i386', 'i686', 'arm64', 'aarch64']
        if self.architecture not in supported_architectures:
            self.warnings.append(f"Untested architecture: {self.architecture}")
        else:
            logger.info(f"✓ Architecture: {self.architecture}")
            
    def validate_python_environment(self) -> None:
        """Validate Python environment and required modules."""
        logger.info("Validating Python environment...")
        
        # Check required standard library modules
        required_modules = [
            'os', 'sys', 'threading', 'json', 'pathlib', 
            'collections', 'enum', 'dataclasses', 'abc'
        ]
        
        for module in required_modules:
            try:
                __import__(module)
                logger.info(f"✓ Standard library module: {module}")
            except ImportError:
                self.errors.append(f"Missing required module: {module}")
                
        # Check platform-specific modules
        if self.system == 'linux':
            linux_modules = ['pwd', 'grp', 'signal']
            for module in linux_modules:
                try:
                    __import__(module)
                    logger.info(f"✓ Linux module: {module}")
                except ImportError:
                    self.warnings.append(f"Linux module not available: {module}")
                    
        # Check optional third-party modules
        optional_modules = {
            'psutil': 'System monitoring and process management',
            'cryptography': 'Encryption and security',
            'yaml': 'YAML configuration support'
        }
        
        for module, description in optional_modules.items():
            try:
                __import__(module)
                logger.info(f"✓ Optional module: {module} ({description})")
            except ImportError:
                self.warnings.append(f"Optional module not found: {module} ({description})")
                
    def validate_dependencies(self) -> None:
        """Validate system dependencies."""
        logger.info("Validating system dependencies...")
        
        if self.system == 'linux':
            self.validate_linux_dependencies()
        elif self.system == 'darwin':
            self.validate_macos_dependencies()
        elif self.system == 'windows':
            self.validate_windows_dependencies()
            
    def validate_linux_dependencies(self) -> None:
        """Validate Linux-specific dependencies."""
        # Check package managers
        package_managers = ['apt', 'yum', 'dnf', 'pacman']
        available_managers = [pm for pm in package_managers if shutil.which(pm)]
        
        if available_managers:
            logger.info(f"✓ Available package managers: {', '.join(available_managers)}")
        else:
            self.warnings.append("No supported package manager found")
            
        # Check systemd
        if shutil.which('systemctl'):
            logger.info("✓ systemd available")
        else:
            self.warnings.append("systemd not available")
            
        # Check Python development headers
        try:
            import sysconfig
            include_dir = sysconfig.get_path('include')
            if Path(include_dir).exists():
                logger.info("✓ Python development headers available")
            else:
                self.warnings.append("Python development headers not found")
        except Exception:
            self.warnings.append("Could not check Python development headers")
            
    def validate_macos_dependencies(self) -> None:
        """Validate macOS-specific dependencies."""
        # Check if running on macOS
        if platform.system() != 'Darwin':
            self.errors.append("Not running on macOS")
            return
            
        # Check Xcode command line tools
        try:
            result = subprocess.run(['xcode-select', '-p'], 
                                  capture_output=True, text=True, timeout=5)
            if result.returncode == 0:
                logger.info("✓ Xcode command line tools installed")
            else:
                self.warnings.append("Xcode command line tools not installed")
        except (subprocess.TimeoutExpired, FileNotFoundError):
            self.warnings.append("Could not check Xcode command line tools")
            
        # Check Homebrew
        if shutil.which('brew'):
            logger.info("✓ Homebrew available")
        else:
            self.warnings.append("Homebrew not installed")
            
    def validate_windows_dependencies(self) -> None:
        """Validate Windows-specific dependencies."""
        # Check if running on Windows
        if platform.system() != 'Windows':
            self.errors.append("Not running on Windows")
            return
            
        # Check PowerShell
        if shutil.which('powershell') or shutil.which('pwsh'):
            logger.info("✓ PowerShell available")
        else:
            self.warnings.append("PowerShell not found")
            
        # Check Visual C++ Redistributable
        try:
            import ctypes
            # This is a basic check - in practice, you'd check more thoroughly
            logger.info("✓ Visual C++ runtime check completed")
        except Exception:
            self.warnings.append("Could not verify Visual C++ runtime")
            
    def validate_integration_modules(self) -> None:
        """Validate integration module imports."""
        logger.info("Validating integration modules...")
        
        # Test abstraction layer
        try:
            from integration.abstraction import (
                FileSystemAbstraction, ProcessManager, 
                EventManager, ConfigurationManager
            )
            logger.info("✓ Abstraction layer imports successful")
        except ImportError as e:
            self.errors.append(f"Abstraction layer import failed: {e}")
            
        # Test platform-specific modules
        try:
            if self.system == 'linux':
                from integration.platforms import LinuxFileSystem, LinuxProcessManager
                logger.info("✓ Linux platform modules available")
            elif self.system == 'darwin':
                from integration.platforms import MacOSFileSystem, MacOSProcessManager
                logger.info("✓ macOS platform modules available")
            elif self.system == 'windows':
                from integration.platforms import WindowsFileSystem, WindowsProcessManager
                logger.info("✓ Windows platform modules available")
        except ImportError as e:
            self.errors.append(f"Platform-specific module import failed: {e}")
            
        # Test services module
        try:
            from integration.services import ServiceBase, SystemServiceManager
            logger.info("✓ Services module available")
        except ImportError as e:
            self.errors.append(f"Services module import failed: {e}")
            
        # Test monitoring module
        try:
            from integration.monitoring import SystemMonitor, PerformanceMetric
            logger.info("✓ Monitoring module available")
        except ImportError as e:
            self.errors.append(f"Monitoring module import failed: {e}")
            
    def validate_configuration(self) -> None:
        """Validate integration configuration."""
        logger.info("Validating configuration...")
        
        try:
            from integration.abstraction import create_configuration_manager
            config_manager = create_configuration_manager()
            
            # Test basic configuration operations
            test_key = "test_key"
            test_value = "test_value"
            
            if config_manager.set_config(test_key, test_value):
                retrieved_value = config_manager.get_config(test_key)
                if retrieved_value == test_value:
                    logger.info("✓ Configuration operations working")
                    config_manager.delete_config(test_key)
                else:
                    self.errors.append("Configuration read/write mismatch")
            else:
                self.errors.append("Configuration write operation failed")
                
        except Exception as e:
            self.errors.append(f"Configuration validation failed: {e}")
            
    def validate_platform_specific(self) -> None:
        """Validate platform-specific features."""
        logger.info("Validating platform-specific features...")
        
        if self.system == 'linux':
            self.validate_linux_specific()
        elif self.system == 'darwin':
            self.validate_macos_specific()
        elif self.system == 'windows':
            self.validate_windows_specific()
            
    def validate_linux_specific(self) -> None:
        """Validate Linux-specific features."""
        # Check /proc filesystem
        if Path('/proc').exists():
            logger.info("✓ /proc filesystem available")
        else:
            self.errors.append("/proc filesystem not available")
            
        # Check systemd availability
        if shutil.which('systemctl'):
            try:
                result = subprocess.run(['systemctl', 'list-units', '--type=service'], 
                                      capture_output=True, text=True, timeout=5)
                if result.returncode == 0:
                    logger.info("✓ systemd service management available")
                else:
                    self.warnings.append("systemd not functioning properly")
            except Exception:
                self.warnings.append("Could not test systemd functionality")
        else:
            self.warnings.append("systemctl not found")
            
    def validate_macos_specific(self) -> None:
        """Validate macOS-specific features."""
        # Check launchd
        if shutil.which('launchctl'):
            logger.info("✓ launchd available")
        else:
            self.errors.append("launchctl not found")
            
        # Check kqueue support
        try:
            import kqueue
            logger.info("✓ kqueue module available")
        except ImportError:
            self.warnings.append("kqueue module not available (may need installation)")
            
    def validate_windows_specific(self) -> None:
        """Validate Windows-specific features."""
        # Check Windows service control
        if shutil.which('sc'):
            logger.info("✓ Service Control (sc.exe) available")
        else:
            self.warnings.append("sc.exe not found")
            
        # Check PowerShell execution policy
        try:
            result = subprocess.run([
                'powershell', '-Command', 'Get-ExecutionPolicy'
            ], capture_output=True, text=True, timeout=5)
            if result.returncode == 0:
                policy = result.stdout.strip()
                logger.info(f"✓ PowerShell execution policy: {policy}")
            else:
                self.warnings.append("Could not check PowerShell execution policy")
        except Exception:
            self.warnings.append("Could not test PowerShell execution policy")
            
    def validate_functionality(self) -> None:
        """Validate basic functionality."""
        logger.info("Validating basic functionality...")
        
        # Test file system abstraction
        try:
            from integration.abstraction import create_file_system_abstraction
            fs = create_file_system_abstraction()
            
            # Test basic file operation
            test_file = Path('/tmp') / 'antivirus_test_file.txt'
            test_data = b"test data"
            
            if fs.write_file(test_file, test_data):
                file_info = fs.get_file_info(test_file)
                if file_info:
                    logger.info("✓ File system abstraction working")
                    fs.delete_file(test_file)
                else:
                    self.errors.append("File system abstraction file info failed")
            else:
                self.errors.append("File system abstraction write failed")
                
        except Exception as e:
            self.errors.append(f"File system abstraction test failed: {e}")
            
        # Test process manager
        try:
            from integration.abstraction import create_process_manager
            pm = create_process_manager()
            
            # Get current process info
            current_pid = os.getpid()
            process_info = pm.get_process_info(current_pid)
            
            if process_info and process_info.pid == current_pid:
                logger.info("✓ Process manager working")
            else:
                self.errors.append("Process manager failed to get process info")
                
        except Exception as e:
            self.errors.append(f"Process manager test failed: {e}")
            
        # Test event manager
        try:
            from integration.abstraction import create_event_manager
            em = create_event_manager({})
            
            # Test event emission
            from integration.abstraction.events import EventType, EventSource, EventSeverity
            event_id = em.emit_event(
                EventType.FILE_ACCESS,
                EventSource.FILE_SYSTEM,
                EventSeverity.LOW,
                "Test event",
                current_pid,
                "test_process",
                os.getuid() if hasattr(os, 'getuid') else 0
            )
            
            if event_id:
                logger.info("✓ Event manager working")
            else:
                self.errors.append("Event manager failed to emit event")
                
        except Exception as e:
            self.errors.append(f"Event manager test failed: {e}")
            
        # Test performance monitoring
        try:
            from integration.monitoring import create_performance_monitor
            monitor = create_performance_monitor()
            
            # Get current metrics
            current_metrics = monitor.get_current_metrics()
            if current_metrics is not None:
                logger.info("✓ Performance monitoring working")
            else:
                self.errors.append("Performance monitoring failed")
                
        except Exception as e:
            self.errors.append(f"Performance monitoring test failed: {e}")
            
    def generate_report(self) -> None:
        """Generate validation report."""
        logger.info("=" * 60)
        logger.info("INTEGRATION VALIDATION REPORT")
        logger.info("=" * 60)
        
        logger.info(f"Platform: {self.system} {self.architecture}")
        logger.info(f"Python: {self.python_version.major}.{self.python_version.minor}.{self.python_version.micro}")
        
        # Summary
        total_checks = len(self.validation_results)
        passed_checks = sum(self.validation_results.values())
        
        logger.info(f"Validation Summary:")
        logger.info(f"  Total checks: {total_checks}")
        logger.info(f"  Passed: {passed_checks}")
        logger.info(f"  Failed: {total_checks - passed_checks}")
        logger.info(f"  Warnings: {len(self.warnings)}")
        logger.info(f"  Errors: {len(self.errors)}")
        
        # Errors
        if self.errors:
            logger.info("\nERRORS:")
            for error in self.errors:
                logger.error(f"  ✗ {error}")
                
        # Warnings
        if self.warnings:
            logger.info("\nWARNINGS:")
            for warning in self.warnings:
                logger.warning(f"  ! {warning}")
                
        # Overall status
        if self.errors:
            logger.error("\n✗ VALIDATION FAILED - Please resolve errors before proceeding")
        elif self.warnings:
            logger.warning("\n⚠ VALIDATION PASSED WITH WARNINGS - Review warnings before proceeding")
        else:
            logger.info("\n✓ VALIDATION PASSED - Integration layer is properly configured")
            
        logger.info("=" * 60)


def main():
    """Main entry point."""
    import argparse
    import shutil
    
    parser = argparse.ArgumentParser(description='Integration Layer Validator')
    parser.add_argument('--json', action='store_true', help='Output results in JSON format')
    parser.add_argument('--verbose', '-v', action='store_true', help='Verbose output')
    parser.add_argument('--fix', action='store_true', help='Attempt to fix common issues')
    
    args = parser.parse_args()
    
    # Set logging level
    if args.verbose:
        logging.getLogger().setLevel(logging.DEBUG)
        
    # Create validator
    validator = IntegrationValidator()
    
    # Run validation
    try:
        success = validator.validate_all()
        
        if args.json:
            # Output JSON report
            report = {
                'success': success,
                'platform': validator.system,
                'architecture': validator.architecture,
                'python_version': f"{validator.python_version.major}.{validator.python_version.minor}.{validator.python_version.micro}",
                'errors': validator.errors,
                'warnings': validator.warnings,
                'validation_results': validator.validation_results
            }
            print(json.dumps(report, indent=2))
        else:
            # Check exit code
            sys.exit(0 if success else 1)
            
    except Exception as e:
        logger.error(f"Validation error: {e}")
        if args.json:
            print(json.dumps({'success': False, 'error': str(e)}))
        sys.exit(1)


if __name__ == '__main__':
    main()