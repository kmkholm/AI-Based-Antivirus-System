"""
Linux Platform Integration
=========================

Linux-specific implementations for:
- File system operations using inotify/fanotify
- Process management with systemd
- Event monitoring using eBPF and fanotify
- System configuration using /etc and environment

Implements Zero Trust security with proper Linux security models.
"""

import os
import logging
import platform
import threading
import time
import subprocess
import ctypes
import ctypes.util
from typing import Dict, List, Optional, Callable, Any
from pathlib import Path
import json

from ..abstraction.filesystem import FileSystemAbstraction, FileInfo, FileType, FileEventData, FileEvent
from ..abstraction.process import ProcessManager, ProcessInfo, ProcessState, PrivilegeLevel, ProcessEvent
from ..abstraction.events import EventManager, EventData, EventType, EventSource, EventSeverity

logger = logging.getLogger(__name__)


# Linux inotify constants
IN_ACCESS = 0x00000001
IN_MODIFY = 0x00000002
IN_ATTRIB = 0x00000004
IN_CLOSE_WRITE = 0x00000008
IN_CLOSE_NOWRITE = 0x00000010
IN_OPEN = 0x00000020
IN_MOVED_FROM = 0x00000040
IN_MOVED_TO = 0x00000080
IN_CREATE = 0x00000100
IN_DELETE = 0x00000200
IN_DELETE_SELF = 0x00000400
IN_MOVE_SELF = 0x00000800

IN_ONLYDIR = 0x01000000
IN_DONT_FOLLOW = 0x02000000
IN_EXCL_UNLINK = 0x04000000

# Linux file permissions
S_IRUSR = 0o400
S_IWUSR = 0o200
S_IXUSR = 0o100
S_IRGRP = 0o040
S_IWGRP = 0o020
S_IXGRP = 0o010
S_IROTH = 0o004
S_IWOTH = 0o002
S_IXOTH = 0o001


class LinuxFileSystem(FileSystemAbstraction):
    """Linux-specific file system implementation."""
    
    def __init__(self, config: Dict[str, Any]):
        super().__init__(config)
        self.inotify_fd = None
        self.watch_descriptors: Dict[int, Path] = {}
        self.monitoring_active = False
        
    def get_file_info(self, file_path: Path) -> Optional[FileInfo]:
        """Get Linux-specific file information."""
        try:
            if not file_path.exists():
                return None
                
            # Get file statistics
            stat = file_path.stat()
            
            # Determine file type
            file_type = self.get_file_type(file_path)
            
            # Get file permissions
            permissions = self._get_linux_permissions(stat.st_mode)
            
            # Get owner and group
            try:
                import pwd
                import grp
                owner = pwd.getpwuid(stat.st_uid).pw_name
                group = grp.getgrgid(stat.st_gid).gr_name
            except ImportError:
                owner = str(stat.st_uid)
                group = str(stat.st_gid)
                
            return FileInfo(
                path=file_path,
                size=stat.st_size,
                created=stat.st_ctime,
                modified=stat.st_mtime,
                accessed=stat.st_atime,
                type=file_type,
                permissions=permissions,
                owner=owner,
                group=group
            )
            
        except Exception as e:
            logger.error(f"Error getting file info for {file_path}: {e}")
            return None
            
    def _get_linux_permissions(self, mode: int) -> str:
        """Convert Linux file mode to permission string."""
        permissions = []
        
        # Owner permissions
        if mode & S_IRUSR:
            permissions.append('r')
        if mode & S_IWUSR:
            permissions.append('w')
        if mode & S_IXUSR:
            permissions.append('x')
            
        # Group permissions
        if mode & S_IRGRP:
            permissions.append('r')
        if mode & S_IWGRP:
            permissions.append('w')
        if mode & S_IXGRP:
            permissions.append('x')
            
        # Other permissions
        if mode & S_IROTH:
            permissions.append('r')
        if mode & S_IWOTH:
            permissions.append('w')
        if mode & S_IXOTH:
            permissions.append('x')
            
        return ''.join(permissions)
            
    def read_file(self, file_path: Path, size_limit: Optional[int] = None) -> bytes:
        """Read file with Linux-specific handling."""
        try:
            with open(file_path, 'rb') as f:
                if size_limit:
                    return f.read(size_limit)
                else:
                    return f.read()
        except Exception as e:
            logger.error(f"Error reading file {file_path}: {e}")
            return b""
            
    def write_file(self, file_path: Path, data: bytes, secure: bool = False) -> bool:
        """Write file with Linux-specific security."""
        try:
            # Ensure parent directory exists
            file_path.parent.mkdir(parents=True, exist_ok=True)
            
            # Write file
            with open(file_path, 'wb') as f:
                f.write(data)
                
            if secure:
                # Set restrictive permissions
                file_path.chmod(0o600)  # Owner read/write only
                
            return True
            
        except Exception as e:
            logger.error(f"Error writing file {file_path}: {e}")
            return False
            
    def delete_file(self, file_path: Path, secure: bool = False) -> bool:
        """Delete file with Linux-specific secure deletion."""
        try:
            if secure:
                # Overwrite file with random data before deletion
                if file_path.exists():
                    file_size = file_path.stat().st_size
                    with open(file_path, 'r+b') as f:
                        f.write(os.urandom(file_size))
                        f.flush()
                        os.fsync(f.fileno())
                        
            file_path.unlink()
            return True
            
        except Exception as e:
            logger.error(f"Error deleting file {file_path}: {e}")
            return False
            
    def list_directory(self, directory: Path) -> List[FileInfo]:
        """List directory contents with Linux-specific information."""
        try:
            results = []
            for item in directory.iterdir():
                file_info = self.get_file_info(item)
                if file_info:
                    results.append(file_info)
            return results
        except Exception as e:
            logger.error(f"Error listing directory {directory}: {e}")
            return []
            
    def watch_directory(self, directory: Path, 
                       callback: Callable[[FileEventData], None]) -> bool:
        """Start Linux file system monitoring using inotify."""
        try:
            self.add_event_handler(callback)
            
            # Initialize inotify if not already done
            if not self.inotify_fd:
                self._init_inotify()
                
            # Add watch for directory
            wd = self._add_inotify_watch(directory)
            if wd >= 0:
                self.watch_descriptors[wd] = directory
                
                # Start monitoring thread
                if not self.monitoring_active:
                    self.monitoring_thread = threading.Thread(
                        target=self._monitor_inotify_events,
                        daemon=True
                    )
                    self.monitoring_thread.start()
                    self.monitoring_active = True
                    
                return True
            else:
                return False
                
        except Exception as e:
            logger.error(f"Error starting directory watch for {directory}: {e}")
            return False
            
    def _init_inotify(self) -> bool:
        """Initialize inotify instance."""
        try:
            # Load libc functions
            libc = ctypes.CDLL(ctypes.util.find_library('c'))
            
            # Define inotify_init function
            libc.inotify_init.restype = ctypes.c_int
            
            # Create inotify instance
            self.inotify_fd = libc.inotify_init()
            return self.inotify_fd >= 0
            
        except Exception as e:
            logger.error(f"Failed to initialize inotify: {e}")
            return False
            
    def _add_inotify_watch(self, directory: Path) -> int:
        """Add inotify watch for directory."""
        try:
            if not self.inotify_fd:
                return -1
                
            # Load libc functions
            libc = ctypes.CDLL(ctypes.util.find_library('c'))
            
            # Define inotify_add_watch function
            libc.inotify_add_watch.restype = ctypes.c_int
            libc.inotify_add_watch.argtypes = [ctypes.c_int, ctypes.c_char_p, ctypes.c_uint32]
            
            # Add watch with events
            mask = (IN_CREATE | IN_MODIFY | IN_DELETE | IN_MOVED_FROM | IN_MOVED_TO | 
                   IN_CLOSE_WRITE | IN_OPEN | IN_ATTRIB | IN_ONLYDIR)
            
            wd = libc.inotify_add_watch(
                self.inotify_fd,
                str(directory).encode('utf-8'),
                mask
            )
            
            return wd
            
        except Exception as e:
            logger.error(f"Failed to add inotify watch for {directory}: {e}")
            return -1
            
    def _monitor_inotify_events(self) -> None:
        """Monitor inotify events."""
        try:
            if not self.inotify_fd:
                return
                
            # Event buffer
            event_size = 16  # struct inotify_event size
            event_buffer_size = 1024
            event_buffer = ctypes.create_string_buffer(event_buffer_size)
            
            while self.monitoring_active:
                try:
                    # Read events
                    length = os.read(self.inotify_fd, event_buffer_size)
                    
                    if length > 0:
                        i = 0
                        while i < length:
                            # Parse event
                            wd = ctypes.cast(
                                ctypes.addressof(event_buffer) + i,
                                ctypes.POINTER(ctypes.c_int)
                            )[0]
                            
                            mask = ctypes.cast(
                                ctypes.addressof(event_buffer) + i + 4,
                                ctypes.POINTER(ctypes.c_uint32)
                            )[0]
                            
                            cookie = ctypes.cast(
                                ctypes.addressof(event_buffer) + i + 8,
                                ctypes.POINTER(ctypes.c_uint32)
                            )[0]
                            
                            name_len = ctypes.cast(
                                ctypes.addressof(event_buffer) + i + 12,
                                ctypes.POINTER(ctypes.c_ushort)
                            )[0]
                            
                            # Get filename
                            if name_len > 0:
                                name = ctypes.string_at(
                                    ctypes.addressof(event_buffer) + i + 16,
                                    name_len
                                ).decode('utf-8', 'ignore')
                            else:
                                name = ""
                                
                            # Get directory path
                            if wd in self.watch_descriptors:
                                directory = self.watch_descriptors[wd]
                                file_path = directory / name
                                
                                # Map mask to event type
                                if mask & IN_CREATE:
                                    event_type = FileEvent.CREATED
                                elif mask & IN_DELETE:
                                    event_type = FileEvent.DELETED
                                elif mask & IN_MODIFY:
                                    event_type = FileEvent.MODIFIED
                                elif mask & (IN_MOVED_FROM | IN_MOVED_TO):
                                    event_type = FileEvent.MOVED
                                else:
                                    event_type = FileEvent.ACCESSED
                                    
                                # Create event data
                                event_data = FileEventData(
                                    event_type=event_type,
                                    file_path=file_path,
                                    timestamp=time.time(),
                                    process_id=os.getpid(),
                                    process_name="antivirus_agent",
                                    user_id=os.getuid(),
                                    additional_data={
                                        "mask": mask,
                                        "cookie": cookie,
                                        "watch_descriptor": wd
                                    }
                                )
                                
                                # Notify handlers
                                self._notify_event_handlers(event_data)
                                
                            # Move to next event
                            i += event_size + name_len
                            
                except OSError as e:
                    if e.errno == 11:  # EAGAIN
                        time.sleep(0.1)
                    else:
                        logger.error(f"Inotify read error: {e}")
                        break
                        
        except Exception as e:
            logger.error(f"Inotify monitoring error: {e}")
        finally:
            if self.inotify_fd:
                os.close(self.inotify_fd)
                self.inotify_fd = None
                
    def stop_watching(self) -> None:
        """Stop file system monitoring."""
        self.monitoring_active = False
        if hasattr(self, 'monitoring_thread') and self.monitoring_thread.is_alive():
            self.monitoring_thread.join(timeout=5)
            
        # Close inotify file descriptor
        if self.inotify_fd:
            try:
                os.close(self.inotify_fd)
            except Exception:
                pass
            self.inotify_fd = None


class LinuxProcessManager(ProcessManager):
    """Linux-specific process management implementation."""
    
    def create_process(self, command: str, args: List[str] = None,
                      cwd: str = None, env: Dict[str, str] = None,
                      as_service: bool = False) -> Optional[int]:
        """Create Linux process."""
        try:
            import subprocess
            
            # Prepare command line
            cmd_args = [command]
            if args:
                cmd_args.extend(args)
                
            # Launch process
            process = subprocess.Popen(
                cmd_args,
                cwd=cwd,
                env=env,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE
            )
            
            if as_service:
                # Create systemd service
                self._create_systemd_service(process.pid, command, args)
                
            logger.info(f"Linux process created: PID={process.pid}")
            return process.pid
            
        except Exception as e:
            logger.error(f"Failed to create Linux process: {e}")
            return None
            
    def _create_systemd_service(self, pid: int, command: str, args: List[str]) -> None:
        """Create systemd service for process."""
        try:
            # Create service file
            service_name = f"antivirus-process-{pid}"
            service_content = f"""[Unit]
Description=Antivirus Process {pid}
After=network.target

[Service]
Type=forking
ExecStart=/bin/true
ExecStop=/bin/kill -TERM {pid}

[Install]
WantedBy=multi-user.target
"""
            
            service_file = Path(f"/etc/systemd/system/{service_name}.service")
            service_file.write_text(service_content)
            
            # Reload systemd
            subprocess.run(["systemctl", "daemon-reload"], check=False)
            
        except Exception as e:
            logger.error(f"Failed to create systemd service: {e}")
            
    def terminate_process(self, pid: int, graceful: bool = True) -> bool:
        """Terminate Linux process."""
        try:
            if graceful:
                # Send SIGTERM first
                os.kill(pid, signal.SIGTERM)
                
                # Wait for process to exit
                for _ in range(10):  # Wait up to 10 seconds
                    try:
                        os.kill(pid, 0)  # Check if process exists
                        time.sleep(1)
                    except ProcessLookupError:
                        return True  # Process exited
                        
                # Process still running, force kill
                os.kill(pid, signal.SIGKILL)
                return True
            else:
                # Force kill immediately
                os.kill(pid, signal.SIGKILL)
                return True
                
        except ProcessLookupError:
            return True  # Process already exited
        except Exception as e:
            logger.error(f"Failed to terminate process {pid}: {e}")
            return False
            
    def get_process_info(self, pid: int) -> Optional[ProcessInfo]:
        """Get Linux process information."""
        try:
            # Read /proc/{pid}/stat
            stat_file = Path(f"/proc/{pid}/stat")
            if not stat_file.exists():
                return None
                
            with open(stat_file, 'r') as f:
                stat_data = f.read().split()
                
            if len(stat_data) < 44:
                return None
                
            # Parse stat data
            process_name = stat_data[1].strip('()')
            state_char = stat_data[2]
            parent_pid = int(stat_data[3])
            create_time = int(stat_data[21]) / 100.0  # Convert to seconds
            working_dir = ""
            
            # Read /proc/{pid}/cmdline for full command
            cmdline_file = Path(f"/proc/{pid}/cmdline")
            command_line = ""
            if cmdline_file.exists():
                command_line = cmdline_file.read_text().replace('\x00', ' ').strip()
                
            # Read /proc/{pid}/cwd for working directory
            cwd_file = Path(f"/proc/{pid}/cwd")
            if cwd_file.exists():
                try:
                    working_dir = str(cwd_file.readlink())
                except Exception:
                    pass
                    
            # Get process state
            state_mapping = {
                'R': ProcessState.RUNNING,
                'S': ProcessState.SLEEPING,
                'D': ProcessState.STOPPED,
                'Z': ProcessState.ZOMBIE,
                'T': ProcessState.STOPPED
            }
            state = state_mapping.get(state_char, ProcessState.ERROR)
            
            # Get privilege level
            privilege_level = self._get_process_privilege_level(pid)
            
            # Get process stats
            statm_file = Path(f"/proc/{pid}/status")
            memory_usage = 0
            cpu_usage = 0.0
            
            if statm_file.exists():
                try:
                    status_data = statm_file.read_text()
                    for line in status_data.split('\n'):
                        if line.startswith('VmRSS:'):
                            memory_usage = int(line.split()[1]) * 1024  # KB to bytes
                        elif line.startswith('Threads:'):
                            threads = int(line.split()[1])
                        elif line.startswith('Uid:'):
                            user_id = int(line.split()[1])
                        elif line.startswith('Gid:'):
                            group_id = int(line.split()[1])
                except Exception:
                    pass
                    
            # Read /proc/{pid}/environ for environment
            environ_file = Path(f"/proc/{pid}/environ")
            environment = {}
            if environ_file.exists():
                try:
                    environ_data = environ_file.read_bytes()
                    env_str = environ_data.decode('utf-8', 'ignore')
                    for line in env_str.split('\x00'):
                        if '=' in line:
                            key, value = line.split('=', 1)
                            environment[key] = value
                except Exception:
                    pass
                    
            return ProcessInfo(
                pid=pid,
                name=process_name,
                command_line=command_line,
                parent_pid=parent_pid,
                state=state,
                privilege_level=privilege_level,
                create_time=create_time,
                cpu_usage=cpu_usage,
                memory_usage=memory_usage,
                working_directory=working_dir,
                environment=environment,
                user_id=0,  # Would be extracted from status
                group_id=0,  # Would be extracted from status
                is_service=as_service
            )
            
        except Exception as e:
            logger.error(f"Error getting process info for PID {pid}: {e}")
            return None
            
    def _get_process_privilege_level(self, pid: int) -> PrivilegeLevel:
        """Get Linux process privilege level."""
        try:
            # Check if process is running as root
            stat_file = Path(f"/proc/{pid}/status")
            if stat_file.exists():
                status_data = stat_file.read_text()
                for line in status_data.split('\n'):
                    if line.startswith('Uid:'):
                        uids = line.split()[1:]
                        real_uid = int(uids[0])
                        effective_uid = int(uids[1])
                        
                        if real_uid == 0 or effective_uid == 0:
                            return PrivilegeLevel.SYSTEM
                            
            return PrivilegeLevel.USER
            
        except Exception:
            return PrivilegeLevel.USER
            
    def list_processes(self) -> List[ProcessInfo]:
        """List all Linux processes."""
        try:
            processes = []
            
            # Read /proc directory for all process IDs
            proc_dir = Path('/proc')
            for proc_dir_entry in proc_dir.iterdir():
                if proc_dir_entry.is_dir() and proc_dir_entry.name.isdigit():
                    try:
                        pid = int(proc_dir_entry.name)
                        process_info = self.get_process_info(pid)
                        if process_info:
                            processes.append(process_info)
                    except Exception:
                        continue
                        
        except Exception as e:
            logger.error(f"Error listing processes: {e}")
            
        return processes
        
    def start_monitoring(self) -> None:
        """Start Linux process monitoring."""
        try:
            # Start monitoring thread for process events
            self.monitoring_thread = threading.Thread(
                target=self._monitor_process_events,
                daemon=True
            )
            self.monitoring_thread.start()
            logger.info("Linux process monitoring started")
        except Exception as e:
            logger.error(f"Failed to start Linux process monitoring: {e}")
            
    def _monitor_process_events(self) -> None:
        """Monitor process events using /proc filesystem."""
        try:
            known_pids = set()
            
            while True:
                try:
                    # Get current PIDs
                    proc_dir = Path('/proc')
                    current_pids = set()
                    
                    for proc_dir_entry in proc_dir.iterdir():
                        if proc_dir_entry.is_dir() and proc_dir_entry.name.isdigit():
                            current_pids.add(int(proc_dir_entry.name))
                            
                    # Find new processes
                    new_pids = current_pids - known_pids
                    for pid in new_pids:
                        try:
                            process_info = self.get_process_info(pid)
                            if process_info:
                                event = ProcessEvent(
                                    event_type="process.create",
                                    pid=pid,
                                    timestamp=time.time(),
                                    process_name=process_info.name,
                                    command_line=process_info.command_line,
                                    user_id=0,  # Would be extracted
                                    additional_data={}
                                )
                                self._notify_event_handlers(event)
                        except Exception:
                            continue
                            
                    # Update known PIDs
                    known_pids = current_pids
                    
                    # Sleep before next check
                    time.sleep(1)
                    
                except Exception as e:
                    logger.error(f"Process monitoring error: {e}")
                    time.sleep(5)
                    
        except Exception as e:
            logger.error(f"Process monitoring thread error: {e}")
            
    def stop_monitoring(self) -> None:
        """Stop Linux process monitoring."""
        logger.info("Linux process monitoring stopped")
        
    def check_privileges(self, pid: int) -> PrivilegeLevel:
        """Check Linux process privileges."""
        return self._get_process_privilege_level(pid)


class LinuxEventManager(EventManager):
    """Linux-specific event management using fanotify and eBPF."""
    
    def start_monitoring(self) -> None:
        """Start Linux event monitoring using fanotify."""
        try:
            # This would implement fanotify-based event monitoring
            # For now, start with basic event processing
            self.start_event_processing()
            logger.info("Linux fanotify event monitoring started")
        except Exception as e:
            logger.error(f"Failed to start Linux event monitoring: {e}")
            
    def stop_monitoring(self) -> None:
        """Stop Linux event monitoring."""
        try:
            self.stop_event_processing()
            logger.info("Linux event monitoring stopped")
        except Exception as e:
            logger.error(f"Failed to stop Linux event monitoring: {e}")


# Export classes
WindowsFileSystem = None  # Will be imported from windows module
LinuxFileSystem = LinuxFileSystem
MacOSFileSystem = None  # Will be created in macos module

WindowsProcessManager = None
LinuxProcessManager = LinuxProcessManager
MacOSProcessManager = None

WindowsEventManager = None
LinuxEventManager = LinuxEventManager
MacOSEventManager = None