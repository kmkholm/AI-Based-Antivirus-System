"""
Platform-Specific Implementations
================================

Platform-specific implementations for:
- Windows (ETW, Windows Services, Registry)
- Linux (inotify, systemd, process management)
- macOS (kqueue, launchd, endpoint security)

Each platform module provides specialized implementations optimized for
the target operating system while maintaining a common interface.
"""

# Import platform-specific implementations
try:
    from .windows import WindowsFileSystem, WindowsProcessManager, WindowsEventManager
    _has_windows = True
except ImportError:
    WindowsFileSystem = WindowsProcessManager = WindowsEventManager = None
    _has_windows = False

try:
    from .linux import LinuxFileSystem, LinuxProcessManager, LinuxEventManager
    _has_linux = True
except ImportError:
    LinuxFileSystem = LinuxProcessManager = LinuxEventManager = None
    _has_linux = False

try:
    from .macos import MacOSFileSystem, MacOSProcessManager, MacOSEventManager
    _has_macos = True
except ImportError:
    MacOSFileSystem = MacOSProcessManager = MacOSEventManager = None
    _has_macos = False

__all__ = [
    'WindowsFileSystem', 'WindowsProcessManager', 'WindowsEventManager',
    'LinuxFileSystem', 'LinuxProcessManager', 'LinuxEventManager',
    'MacOSFileSystem', 'MacOSProcessManager', 'MacOSEventManager'
]

# Platform availability flags
has_windows = _has_windows
has_linux = _has_linux
has_macos = _has_macos