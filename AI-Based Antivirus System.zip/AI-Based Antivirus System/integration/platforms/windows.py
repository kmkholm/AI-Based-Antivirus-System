"""
Windows Platform Integration
===========================

Windows-specific implementations for:
- File system operations using Windows APIs
- Process management with Windows services
- Event monitoring using ETW (Event Tracing for Windows)
- System configuration using Windows Registry

Implements Zero Trust security with proper Windows security models.
"""

import os
import logging
import platform
import threading
import time
import ctypes
from ctypes import wintypes
from typing import Dict, List, Optional, Callable, Any
from pathlib import Path
import json

from ..abstraction.filesystem import FileSystemAbstraction, FileInfo, FileType, FileEventData, FileEvent
from ..abstraction.process import ProcessManager, ProcessInfo, ProcessState, PrivilegeLevel, ProcessEvent
from ..abstraction.events import EventManager, EventData, EventType, EventSource, EventSeverity

logger = logging.getLogger(__name__)


# Windows API constants and structures
INVALID_HANDLE_VALUE = -1
FILE_NOTIFY_CHANGE_FILE_NAME = 0x00000001
FILE_NOTIFY_CHANGE_DIR_NAME = 0x00000002
FILE_NOTIFY_CHANGE_ATTRIBUTES = 0x00000004
FILE_NOTIFY_CHANGE_SIZE = 0x00000008
FILE_NOTIFY_CHANGE_LAST_WRITE = 0x00000010
FILE_NOTIFY_CHANGE_CREATION = 0x00000040

FILE_ACTION_ADDED = 1
FILE_ACTION_REMOVED = 2
FILE_ACTION_MODIFIED = 3
FILE_ACTION_RENAMED_OLD_NAME = 4
FILE_ACTION_RENAMED_NEW_NAME = 5

THREAD_PRIORITY_NORMAL = 0
THREAD_PRIORITY_HIGH = 1
THREAD_PRIORITY_LOW = -1

PROCESS_QUERY_INFORMATION = 0x0400
PROCESS_VM_READ = 0x0010

# Windows API function definitions
kernel32 = ctypes.windll.kernel32
advapi32 = ctypes.windll.advapi32
psapi = ctypes.windll.psapi


class WindowsFileSystem(FileSystemAbstraction):
    """Windows-specific file system implementation."""
    
    def __init__(self, config: Dict[str, Any]):
        super().__init__(config)
        self.watch_handles: Dict[Path, int] = {}
        self.monitoring_thread = None
        self.stop_monitoring_flag = threading.Event()
        
    def get_file_info(self, file_path: Path) -> Optional[FileInfo]:
        """Get Windows-specific file information."""
        try:
            if not file_path.exists():
                return None
                
            # Get file statistics
            stat = file_path.stat()
            
            # Determine file type
            file_type = self.get_file_type(file_path)
            
            # Get additional Windows-specific info
            try:
                import win32api
                import win32security
                
                # Get file security descriptor
                sd = win32security.GetFileSecurity(
                    str(file_path), win32security.DACL_SECURITY_INFORMATION
                )
                
                # Get owner and group
                owner_sid, _, _ = win32security.GetSecurityDescriptorOwner(sd)
                group_sid, _, _ = win32security.GetSecurityDescriptorGroup(sd)
                
                owner = win32security.ConvertSidToStringSid(owner_sid)
                group = win32security.ConvertSidToStringSid(group_sid)
                
            except ImportError:
                owner = None
                group = None
                
            # Get file permissions
            permissions = self._get_windows_permissions(file_path)
            
            return FileInfo(
                path=file_path,
                size=stat.st_size,
                created=stat.st_ctime,
                modified=stat.st_mtime,
                accessed=stat.st_atime,
                type=file_type,
                permissions=permissions,
                owner=owner,
                group=group
            )
            
        except Exception as e:
            logger.error(f"Error getting file info for {file_path}: {e}")
            return None
            
    def _get_windows_permissions(self, file_path: Path) -> str:
        """Get Windows file permissions."""
        try:
            import win32security
            
            # Get file DACL
            dacl = win32security.GetFileSecurity(
                str(file_path), win32security.DACL_SECURITY_INFORMATION
            ).GetSecurityDescriptorDacl()
            
            if not dacl:
                return "no_dacl"
                
            # Check basic permissions
            permissions = []
            
            try:
                # Check for read access
                if dacl.GetAceCount() > 0:
                    permissions.append("read")
                    
                # Check for write access
                if any(ace.GetAccessMask() & 0x00000002 for ace in dacl):
                    permissions.append("write")
                    
                # Check for execute access
                if any(ace.GetAccessMask() & 0x00000001 for ace in dacl):
                    permissions.append("execute")
                    
            except Exception:
                pass
                
            return ",".join(permissions) if permissions else "unknown"
            
        except Exception:
            return "unknown"
            
    def read_file(self, file_path: Path, size_limit: Optional[int] = None) -> bytes:
        """Read file with Windows-specific handling."""
        try:
            with open(file_path, 'rb') as f:
                if size_limit:
                    return f.read(size_limit)
                else:
                    return f.read()
        except Exception as e:
            logger.error(f"Error reading file {file_path}: {e}")
            return b""
            
    def write_file(self, file_path: Path, data: bytes, secure: bool = False) -> bool:
        """Write file with Windows-specific security."""
        try:
            # Ensure parent directory exists
            file_path.parent.mkdir(parents=True, exist_ok=True)
            
            # Write file
            with open(file_path, 'wb') as f:
                f.write(data)
                
            if secure:
                # Set restrictive permissions on Windows
                import win32security
                
                # Get current user SID
                user_token = win32security.OpenProcessToken(
                    win32api.GetCurrentProcess(),
                    win32security.TOKEN_QUERY
                )
                user_sid, _, _ = win32security.GetTokenInformation(
                    user_token, win32security.TokenUser
                )
                
                # Create security descriptor with owner-only access
                sd = win32security.SecurityDescriptor()
                dacl = win32security.DiscretionaryAcl(False, 8)
                dacl.AddAccessAllowedAce(
                    win32security.ACL_REVISION,
                    win32security.GENERIC_ALL,
                    user_sid
                )
                sd.SetDacl(True, dacl)
                
                # Apply security descriptor
                win32security.SetFileSecurity(
                    str(file_path),
                    win32security.DACL_SECURITY_INFORMATION,
                    sd
                )
                
            return True
            
        except Exception as e:
            logger.error(f"Error writing file {file_path}: {e}")
            return False
            
    def delete_file(self, file_path: Path, secure: bool = False) -> bool:
        """Delete file with Windows-specific secure deletion."""
        try:
            if secure:
                # Use Windows MoveFileEx with MOVEFILE_DELAY_UNTIL_REBOOT
                # for secure deletion
                if kernel32.MoveFileExW(
                    str(file_path).encode('utf-16-le'),
                    None,
                    4  # MOVEFILE_DELAY_UNTIL_REBOOT
                ):
                    return True
                else:
                    logger.warning("Secure deletion scheduled for next boot")
                    return False
            else:
                file_path.unlink()
                return True
                
        except Exception as e:
            logger.error(f"Error deleting file {file_path}: {e}")
            return False
            
    def list_directory(self, directory: Path) -> List[FileInfo]:
        """List directory contents with Windows-specific information."""
        try:
            results = []
            for item in directory.iterdir():
                file_info = self.get_file_info(item)
                if file_info:
                    results.append(file_info)
            return results
        except Exception as e:
            logger.error(f"Error listing directory {directory}: {e}")
            return []
            
    def watch_directory(self, directory: Path, 
                       callback: Callable[[FileEventData], None]) -> bool:
        """Start Windows file system monitoring using ReadDirectoryChangesW."""
        try:
            self.add_event_handler(callback)
            
            # Start monitoring thread
            self.monitoring_thread = threading.Thread(
                target=self._monitor_directory_changes, 
                args=(directory,),
                daemon=True
            )
            self.monitoring_thread.start()
            
            return True
            
        except Exception as e:
            logger.error(f"Error starting directory watch for {directory}: {e}")
            return False
            
    def _monitor_directory_changes(self, directory: Path) -> None:
        """Monitor directory changes using Windows API."""
        try:
            # Open directory handle
            handle = kernel32.CreateFileW(
                str(directory).encode('utf-16-le'),
                1,  # FILE_LIST_DIRECTORY
                3,  # FILE_SHARE_READ | FILE_SHARE_WRITE
                None,
                3,  # OPEN_EXISTING
                0x02000000,  # FILE_FLAG_BACKUP_SEMANTICS
                None
            )
            
            if handle == INVALID_HANDLE_VALUE:
                logger.error(f"Failed to open directory handle for {directory}")
                return
                
            # Buffer for change notifications
            buffer_size = 65536
            buffer = ctypes.create_string_buffer(buffer_size)
            
            while not self.stop_monitoring_flag.is_set():
                # Wait for changes
                result = kernel32.ReadDirectoryChangesW(
                    handle,
                    buffer,
                    buffer_size,
                    True,  # Watch subdirectories
                    FILE_NOTIFY_CHANGE_FILE_NAME | FILE_NOTIFY_CHANGE_DIR_NAME | FILE_NOTIFY_CHANGE_LAST_WRITE,
                    None,
                    None,
                    None
                )
                
                if result > 0:
                    # Parse change notifications
                    position = 0
                    while position < result:
                        # Get next notification
                        notify_info = ctypes.cast(
                            ctypes.addressof(buffer) + position,
                            ctypes.POINTER(ctypes.c_uint32)
                        )
                        action = notify_info[0]
                        
                        # Get file name (Unicode)
                        name_ptr = ctypes.cast(
                            ctypes.addressof(buffer) + position + 8,
                            ctypes.POINTER(ctypes.c_wchar)
                        )
                        filename = ""
                        
                        # Build full path
                        file_path = directory / filename
                        
                        # Map action to event type
                        if action == FILE_ACTION_ADDED:
                            event_type = FileEvent.CREATED
                        elif action == FILE_ACTION_REMOVED:
                            event_type = FileEvent.DELETED
                        elif action == FILE_ACTION_MODIFIED:
                            event_type = FileEvent.MODIFIED
                        elif action == FILE_ACTION_RENAMED_OLD_NAME:
                            event_type = FileEvent.RENAME
                        else:
                            event_type = FileEvent.CREATED  # default
                            
                        # Create event data
                        event_data = FileEventData(
                            event_type=event_type,
                            file_path=file_path,
                            timestamp=time.time(),
                            process_id=os.getpid(),
                            process_name="antivirus_agent",
                            user_id=os.getuid() if hasattr(os, 'getuid') else 0,
                            additional_data={"action": action}
                        )
                        
                        # Notify handlers
                        self._notify_event_handlers(event_data)
                        
                        # Move to next entry
                        position += 12 + (len(filename) * 2)
                        
        except Exception as e:
            logger.error(f"Directory monitoring error: {e}")
        finally:
            if 'handle' in locals() and handle != INVALID_HANDLE_VALUE:
                kernel32.CloseHandle(handle)
                
    def stop_watching(self) -> None:
        """Stop file system monitoring."""
        self.stop_monitoring_flag.set()
        if self.monitoring_thread and self.monitoring_thread.is_alive():
            self.monitoring_thread.join(timeout=5)


class WindowsProcessManager(ProcessManager):
    """Windows-specific process management implementation."""
    
    def create_process(self, command: str, args: List[str] = None,
                      cwd: str = None, env: Dict[str, str] = None,
                      as_service: bool = False) -> Optional[int]:
        """Create Windows process."""
        try:
            import subprocess
            
            # Prepare command line
            cmd_args = [command]
            if args:
                cmd_args.extend(args)
                
            # Create startup info
            startup_info = subprocess.STARTUPINFO()
            startup_info.dwFlags |= 1  # STARTF_USESHOWWINDOW
            
            # Launch process
            process = subprocess.Popen(
                cmd_args,
                cwd=cwd,
                env=env,
                startupinfo=startup_info,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE
            )
            
            if as_service:
                # Register as Windows service if needed
                self._register_as_service(process.pid, command, args)
                
            logger.info(f"Windows process created: PID={process.pid}")
            return process.pid
            
        except Exception as e:
            logger.error(f"Failed to create Windows process: {e}")
            return None
            
    def _register_as_service(self, pid: int, command: str, args: List[str]) -> None:
        """Register process as Windows service."""
        try:
            # Use sc.exe to create service
            cmd_args = [command] + (args or [])
            cmd_line = f"binPath= {' '.join(cmd_args)}"
            
            # This would typically be called with elevated privileges
            # subprocess.run(["sc", "create", "AntivirusAgent", cmd_line])
            
        except Exception as e:
            logger.error(f"Failed to register service: {e}")
            
    def terminate_process(self, pid: int, graceful: bool = True) -> bool:
        """Terminate Windows process."""
        try:
            if graceful:
                # Send WM_CLOSE first
                if kernel32.PostMessageA(pid, 0x0010, 0, 0):  # WM_CLOSE
                    # Wait for process to exit
                    return self._wait_for_process_exit(pid, 10)
                else:
                    # Process not responding, force terminate
                    return self._force_terminate_process(pid)
            else:
                return self._force_terminate_process(pid)
                
        except Exception as e:
            logger.error(f"Failed to terminate process {pid}: {e}")
            return False
            
    def _wait_for_process_exit(self, pid: int, timeout: int) -> bool:
        """Wait for process to exit gracefully."""
        try:
            for _ in range(timeout * 10):  # Check 10 times per second
                if not self.is_process_alive(pid):
                    return True
                time.sleep(0.1)
            return False
        except Exception:
            return False
            
    def _force_terminate_process(self, pid: int) -> bool:
        """Force terminate process using Windows API."""
        try:
            # Open process with terminate permission
            handle = kernel32.OpenProcess(
                1,  # PROCESS_TERMINATE
                False,
                pid
            )
            
            if handle:
                # Terminate process
                result = kernel32.TerminateProcess(handle, 0)
                kernel32.CloseHandle(handle)
                return result != 0
            else:
                return False
                
        except Exception:
            return False
            
    def get_process_info(self, pid: int) -> Optional[ProcessInfo]:
        """Get Windows process information."""
        try:
            # Open process with query information permission
            handle = kernel32.OpenProcess(
                PROCESS_QUERY_INFORMATION,
                False,
                pid
            )
            
            if not handle:
                return None
                
            try:
                # Get process creation time
                creation_time = wintypes.FILETIME()
                if kernel32.GetProcessTimes(handle, 
                                          ctypes.byref(creation_time),
                                          ctypes.byref(wintypes.FILETIME()),
                                          ctypes.byref(wintypes.FILETIME()),
                                          ctypes.byref(wintypes.FILETIME())):
                    create_timestamp = creation_time.dwLowDateTime + (creation_time.dwHighDateTime << 32)
                    create_time = create_timestamp / 10000000 - 11644473600  # Convert to Unix time
                else:
                    create_time = time.time()
                    
                # Get process name
                process_name = self._get_process_name(handle)
                
                # Get command line
                command_line = self._get_process_command_line(handle)
                
                # Get current working directory
                working_dir = self._get_process_working_directory(handle)
                
                # Get environment variables
                environment = self._get_process_environment(handle)
                
                # Check if process is running
                is_alive = kernel32.GetExitCodeProcess(handle, ctypes.byref(wintypes.DWORD())) == 1
                state = ProcessState.RUNNING if is_alive else ProcessState.TERMINATED
                
                # Get privilege level
                privilege_level = self._get_process_privilege_level(pid)
                
                # Get CPU and memory usage (simplified)
                cpu_usage = 0.0
                memory_usage = 0
                
                try:
                    # Use psapi for memory information
                    memory_info = psapiPROCESS_MEMORY_COUNTERS_EX()
                    if psapi.GetProcessMemoryInfo(handle, 
                                                ctypes.byref(memory_info),
                                                ctypes.sizeof(memory_info)):
                        memory_usage = memory_info.WorkingSetSize
                except Exception:
                    pass
                    
                return ProcessInfo(
                    pid=pid,
                    name=process_name,
                    command_line=command_line,
                    parent_pid=0,  # Would need additional API call
                    state=state,
                    privilege_level=privilege_level,
                    create_time=create_time,
                    cpu_usage=cpu_usage,
                    memory_usage=memory_usage,
                    working_directory=working_dir,
                    environment=environment,
                    user_id=os.getuid() if hasattr(os, 'getuid') else 0,
                    group_id=0,
                    is_service=as_service
                )
                
            finally:
                kernel32.CloseHandle(handle)
                
        except Exception as e:
            logger.error(f"Error getting process info for PID {pid}: {e}")
            return None
            
    def _get_process_name(self, process_handle) -> str:
        """Get process name from handle."""
        try:
            buffer = ctypes.create_string_buffer(260)
            psapi.GetModuleBaseNameA(process_handle, None, buffer, 259)
            return buffer.value.decode('ascii', 'ignore')
        except Exception:
            return "unknown"
            
    def _get_process_command_line(self, process_handle) -> str:
        """Get process command line (simplified)."""
        # This would require reading PEB or using WMI
        return "unknown"
        
    def _get_process_working_directory(self, process_handle) -> str:
        """Get process working directory (simplified)."""
        # This would require reading PEB
        return ""
        
    def _get_process_environment(self, process_handle) -> Dict[str, str]:
        """Get process environment variables (simplified)."""
        # This would require reading environment block
        return {}
        
    def _get_process_privilege_level(self, pid: int) -> PrivilegeLevel:
        """Get Windows process privilege level."""
        try:
            # Check if running as administrator
            import win32security
            
            # Open process token
            handle = kernel32.OpenProcessToken(
                kernel32.GetCurrentProcess(),
                win32security.TOKEN_QUERY
            )
            
            if handle:
                # Get token elevation
                elevation = ctypes.c_int()
                elevation_size = ctypes.sizeof(elevation)
                if kernel32.GetTokenInformation(
                    handle, 22,  # TokenElevationType
                    ctypes.byref(elevation),
                    ctypes.byref(elevation_size),
                    ctypes.byref(ctypes.c_int())
                ):
                    if elevation.value == 1:  # TokenElevationTypeFull
                        kernel32.CloseHandle(handle)
                        return PrivilegeLevel.ELEVATED
                        
                kernel32.CloseHandle(handle)
                
        except Exception:
            pass
            
        return PrivilegeLevel.USER
        
    def list_processes(self) -> List[ProcessInfo]:
        """List all Windows processes."""
        try:
            processes = []
            
            # Enumerate processes using Windows API
            snapshot = kernel32.CreateToolhelp32Snapshot(2, 0)  # TH32CS_SNAPPROCESS
            
            if snapshot != INVALID_HANDLE_VALUE:
                try:
                    # This is a simplified version - full implementation would use Process32First/Next
                    pass
                finally:
                    kernel32.CloseHandle(snapshot)
                    
            # For now, return empty list
            # Full implementation would enumerate all processes
            
        except Exception as e:
            logger.error(f"Error listing processes: {e}")
            
        return processes
        
    def start_monitoring(self) -> None:
        """Start Windows process monitoring."""
        # Implementation would use ETW or WMI for process events
        logger.info("Windows process monitoring started")
        
    def stop_monitoring(self) -> None:
        """Stop Windows process monitoring."""
        logger.info("Windows process monitoring stopped")
        
    def check_privileges(self, pid: int) -> PrivilegeLevel:
        """Check Windows process privileges."""
        return self._get_process_privilege_level(pid)


class WindowsEventManager(EventManager):
    """Windows-specific event management using ETW."""
    
    def start_monitoring(self) -> None:
        """Start Windows event monitoring using ETW."""
        try:
            # This would implement ETW-based event monitoring
            # For now, start with basic event processing
            self.start_event_processing()
            logger.info("Windows ETW event monitoring started")
        except Exception as e:
            logger.error(f"Failed to start Windows event monitoring: {e}")
            
    def stop_monitoring(self) -> None:
        """Stop Windows event monitoring."""
        try:
            self.stop_event_processing()
            logger.info("Windows event monitoring stopped")
        except Exception as e:
            logger.error(f"Failed to stop Windows event monitoring: {e}")


# Windows process memory info structure
class psapiPROCESS_MEMORY_COUNTERS_EX(ctypes.Structure):
    _fields_ = [
        ("cb", ctypes.c_ulong),
        ("PageFaultCount", ctypes.c_ulong),
        ("PeakWorkingSetSize", ctypes.c_size_t),
        ("WorkingSetSize", ctypes.c_size_t),
        ("QuotaPeakPagedPoolUsage", ctypes.c_size_t),
        ("QuotaPagedPoolUsage", ctypes.c_size_t),
        ("QuotaPeakNonPagedPoolUsage", ctypes.c_size_t),
        ("QuotaNonPagedPoolUsage", ctypes.c_size_t),
        ("PagefileUsage", ctypes.c_size_t),
        ("PeakPagefileUsage", ctypes.c_size_t),
        ("PrivateUsage", ctypes.c_size_t),
    ]