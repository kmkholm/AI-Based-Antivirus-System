"""
macOS Platform Integration
=========================

macOS-specific implementations for:
- File system operations using kqueue
- Process management with launchd
- Event monitoring using kqueue and endpoint security
- System configuration using plist files

Implements Zero Trust security with proper macOS security models.
"""

import os
import logging
import platform
import threading
import time
import subprocess
import ctypes
import ctypes.util
from typing import Dict, List, Optional, Callable, Any
from pathlib import Path
import json

from ..abstraction.filesystem import FileSystemAbstraction, FileInfo, FileType, FileEventData, FileEvent
from ..abstraction.process import ProcessManager, ProcessInfo, ProcessState, PrivilegeLevel, ProcessEvent
from ..abstraction.events import EventManager, EventData, EventType, EventSource, EventSeverity

logger = logging.getLogger(__name__)


# macOS kqueue constants
EVFILT_READ = -1
EVFILT_WRITE = -2
EVFILT_VNODE = -3
EVFILT_PROC = -4
EVFILT_AIO = -5
EVFILT_VFS = -9
EVFILT_TIMER = -10

EV_ADD = 0x0001
EV_ENABLE = 0x0004
EV_DISABLE = 0x0008
EV_CLEAR = 0x0020
EV_ONESHOT = 0x0010

NOTE_DELETE = 0x0001
NOTE_WRITE = 0x0002
NOTE_EXTEND = 0x0004
NOTE_ATTRIB = 0x0008
NOTE_LINK = 0x0010
NOTE_RENAME = 0x0080
NOTE_REVOKE = 0x0100

NOTE_EXIT = 0x80000000
NOTE_FORK = 0x40000000
NOTE_EXEC = 0x20000000
NOTE_SIGNAL = 0x08000000

# macOS file modes
S_IRUSR = 0o400
S_IWUSR = 0o200
S_IXUSR = 0o100
S_IRGRP = 0o040
S_IWGRP = 0o020
S_IXGRP = 0o010
S_IROTH = 0o004
S_IWOTH = 0o002
S_IXOTH = 0o001


class MacOSFileSystem(FileSystemAbstraction):
    """macOS-specific file system implementation."""
    
    def __init__(self, config: Dict[str, Any]):
        super().__init__(config)
        self.kqueue_fd = None
        self.watch_handlers: Dict[int, Path] = {}
        self.monitoring_active = False
        
    def get_file_info(self, file_path: Path) -> Optional[FileInfo]:
        """Get macOS-specific file information."""
        try:
            if not file_path.exists():
                return None
                
            # Get file statistics
            stat = file_path.stat()
            
            # Determine file type
            file_type = self.get_file_type(file_path)
            
            # Get file permissions
            permissions = self._get_macos_permissions(stat.st_mode)
            
            # Get owner and group
            try:
                import pwd
                import grp
                owner = pwd.getpwuid(stat.st_uid).pw_name
                group = grp.getgrgid(stat.st_gid).gr_name
            except ImportError:
                owner = str(stat.st_uid)
                group = str(stat.st_gid)
                
            return FileInfo(
                path=file_path,
                size=stat.st_size,
                created=stat.st_ctime,
                modified=stat.st_mtime,
                accessed=stat.st_atime,
                type=file_type,
                permissions=permissions,
                owner=owner,
                group=group
            )
            
        except Exception as e:
            logger.error(f"Error getting file info for {file_path}: {e}")
            return None
            
    def _get_macos_permissions(self, mode: int) -> str:
        """Convert macOS file mode to permission string."""
        permissions = []
        
        # Owner permissions
        if mode & S_IRUSR:
            permissions.append('r')
        if mode & S_IWUSR:
            permissions.append('w')
        if mode & S_IXUSR:
            permissions.append('x')
            
        # Group permissions
        if mode & S_IRGRP:
            permissions.append('r')
        if mode & S_IWGRP:
            permissions.append('w')
        if mode & S_IXGRP:
            permissions.append('x')
            
        # Other permissions
        if mode & S_IROTH:
            permissions.append('r')
        if mode & S_IWOTH:
            permissions.append('w')
        if mode & S_IXOTH:
            permissions.append('x')
            
        return ''.join(permissions)
            
    def read_file(self, file_path: Path, size_limit: Optional[int] = None) -> bytes:
        """Read file with macOS-specific handling."""
        try:
            with open(file_path, 'rb') as f:
                if size_limit:
                    return f.read(size_limit)
                else:
                    return f.read()
        except Exception as e:
            logger.error(f"Error reading file {file_path}: {e}")
            return b""
            
    def write_file(self, file_path: Path, data: bytes, secure: bool = False) -> bool:
        """Write file with macOS-specific security."""
        try:
            # Ensure parent directory exists
            file_path.parent.mkdir(parents=True, exist_ok=True)
            
            # Write file
            with open(file_path, 'wb') as f:
                f.write(data)
                
            if secure:
                # Set restrictive permissions
                file_path.chmod(0o600)  # Owner read/write only
                
            return True
            
        except Exception as e:
            logger.error(f"Error writing file {file_path}: {e}")
            return False
            
    def delete_file(self, file_path: Path, secure: bool = False) -> bool:
        """Delete file with macOS-specific secure deletion."""
        try:
            if secure:
                # Overwrite file with random data before deletion
                if file_path.exists():
                    file_size = file_path.stat().st_size
                    with open(file_path, 'r+b') as f:
                        f.write(os.urandom(file_size))
                        f.flush()
                        os.fsync(f.fileno())
                        
            file_path.unlink()
            return True
            
        except Exception as e:
            logger.error(f"Error deleting file {file_path}: {e}")
            return False
            
    def list_directory(self, directory: Path) -> List[FileInfo]:
        """List directory contents with macOS-specific information."""
        try:
            results = []
            for item in directory.iterdir():
                file_info = self.get_file_info(item)
                if file_info:
                    results.append(file_info)
            return results
        except Exception as e:
            logger.error(f"Error listing directory {directory}: {e}")
            return []
            
    def watch_directory(self, directory: Path, 
                       callback: Callable[[FileEventData], None]) -> bool:
        """Start macOS file system monitoring using kqueue."""
        try:
            self.add_event_handler(callback)
            
            # Initialize kqueue if not already done
            if not self.kqueue_fd:
                self._init_kqueue()
                
            # Add watch for directory
            if directory.exists():
                fd = directory.open('r')
                watch_fd = self._add_kqueue_watch(fd.fileno(), directory)
                if watch_fd >= 0:
                    self.watch_handlers[watch_fd] = directory
                    
                    # Start monitoring thread
                    if not self.monitoring_active:
                        self.monitoring_thread = threading.Thread(
                            target=self._monitor_kqueue_events,
                            daemon=True
                        )
                        self.monitoring_thread.start()
                        self.monitoring_active = True
                        
                    return True
                    
            return False
                
        except Exception as e:
            logger.error(f"Error starting directory watch for {directory}: {e}")
            return False
            
    def _init_kqueue(self) -> bool:
        """Initialize kqueue instance."""
        try:
            # Load libc functions
            libc = ctypes.CDLL(ctypes.util.find_library('c'))
            
            # Define kqueue function
            libc.kqueue.restype = ctypes.c_int
            
            # Create kqueue instance
            self.kqueue_fd = libc.kqueue()
            return self.kqueue_fd >= 0
            
        except Exception as e:
            logger.error(f"Failed to initialize kqueue: {e}")
            return False
            
    def _add_kqueue_watch(self, file_fd: int, file_path: Path) -> int:
        """Add kqueue watch for file/directory."""
        try:
            if not self.kqueue_fd:
                return -1
                
            # Load libc functions
            libc = ctypes.CDLL(ctypes.util.find_library('c'))
            
            # Define kevent function
            libc.kevent.restype = ctypes.c_int
            libc.kevent.argtypes = [ctypes.c_int, ctypes.POINTER(struct_kevent), 
                                   ctypes.c_int, ctypes.POINTER(struct_kevent), 
                                   ctypes.c_int, ctypes.c_void_p]
            
            # Create kevent structure
            kevent = struct_kevent()
            kevent.ident = file_fd
            kevent.filter = EVFILT_VNODE
            kevent.flags = EV_ADD | EV_CLEAR
            kevent.fflags = NOTE_DELETE | NOTE_WRITE | NOTE_EXTEND | NOTE_ATTRIB | NOTE_RENAME
            kevent.data = 0
            kevent.udata = 0
            
            # Add event to kqueue
            result = libc.kevent(
                self.kqueue_fd,
                ctypes.byref(kevent),
                1,
                None,
                0,
                None
            )
            
            return result
            
        except Exception as e:
            logger.error(f"Failed to add kqueue watch for {file_path}: {e}")
            return -1
            
    def _monitor_kqueue_events(self) -> None:
        """Monitor kqueue events."""
        try:
            if not self.kqueue_fd:
                return
                
            # Event structure
            kevent = struct_kevent()
            
            while self.monitoring_active:
                try:
                    # Wait for events
                    num_events = libc.kevent(
                        self.kqueue_fd,
                        None,
                        0,
                        ctypes.byref(kevent),
                        1,
                        None
                    )
                    
                    if num_events > 0:
                        # Process event
                        if kevent.filter == EVFILT_VNODE:
                            self._process_vnode_event(kevent)
                            
                except OSError as e:
                    if e.errno == 11:  # EAGAIN
                        time.sleep(0.1)
                    else:
                        logger.error(f"Kqueue read error: {e}")
                        break
                        
        except Exception as e:
            logger.error(f"Kqueue monitoring error: {e}")
        finally:
            if self.kqueue_fd:
                try:
                    ctypes.CDLL(ctypes.util.find_library('c')).close(self.kqueue_fd)
                except Exception:
                    pass
                self.kqueue_fd = None
                
    def _process_vnode_event(self, kevent) -> None:
        """Process vnode event from kqueue."""
        try:
            # Find the file path for this event
            file_path = None
            for watch_fd, path in self.watch_handlers.items():
                if watch_fd == kevent.ident:
                    file_path = path
                    break
                    
            if not file_path:
                return
                
            # Map flags to event type
            if kevent.fflags & NOTE_DELETE:
                event_type = FileEvent.DELETED
            elif kevent.fflags & NOTE_WRITE:
                event_type = FileEvent.MODIFIED
            elif kevent.fflags & NOTE_RENAME:
                event_type = FileEvent.MOVED
            elif kevent.fflags & NOTE_ATTRIB:
                event_type = FileEvent.ACCESSED
            else:
                event_type = FileEvent.ACCESSED  # default
                
            # Create event data
            event_data = FileEventData(
                event_type=event_type,
                file_path=file_path,
                timestamp=time.time(),
                process_id=os.getpid(),
                process_name="antivirus_agent",
                user_id=os.getuid(),
                additional_data={
                    "flags": kevent.fflags,
                    "filter": kevent.filter,
                    "watch_fd": kevent.ident
                }
            )
            
            # Notify handlers
            self._notify_event_handlers(event_data)
            
        except Exception as e:
            logger.error(f"Error processing vnode event: {e}")
            
    def stop_watching(self) -> None:
        """Stop file system monitoring."""
        self.monitoring_active = False
        if hasattr(self, 'monitoring_thread') and self.monitoring_thread.is_alive():
            self.monitoring_thread.join(timeout=5)
            
        # Close kqueue file descriptor
        if self.kqueue_fd:
            try:
                ctypes.CDLL(ctypes.util.find_library('c')).close(self.kqueue_fd)
            except Exception:
                pass
            self.kqueue_fd = None


# kevent structure for macOS
class struct_kevent(ctypes.Structure):
    _fields_ = [
        ("ident", ctypes.c_ulong),  # Event identifier
        ("filter", ctypes.c_short), # Event filter
        ("flags", ctypes.c_ushort), # Event flags
        ("fflags", ctypes.c_uint),  # Filter-specific flags
        ("data", ctypes.c_long),    # Filter-specific data
        ("udata", ctypes.c_void_p), # User-defined data
    ]


class MacOSProcessManager(ProcessManager):
    """macOS-specific process management implementation."""
    
    def create_process(self, command: str, args: List[str] = None,
                      cwd: str = None, env: Dict[str, str] = None,
                      as_service: bool = False) -> Optional[int]:
        """Create macOS process."""
        try:
            import subprocess
            
            # Prepare command line
            cmd_args = [command]
            if args:
                cmd_args.extend(args)
                
            # Launch process
            process = subprocess.Popen(
                cmd_args,
                cwd=cwd,
                env=env,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE
            )
            
            if as_service:
                # Create launchd service
                self._create_launchd_service(process.pid, command, args)
                
            logger.info(f"macOS process created: PID={process.pid}")
            return process.pid
            
        except Exception as e:
            logger.error(f"Failed to create macOS process: {e}")
            return None
            
    def _create_launchd_service(self, pid: int, command: str, args: List[str]) -> None:
        """Create launchd service for process."""
        try:
            # Create plist file
            import plistlib
            
            service_name = f"com.antivirus.process-{pid}"
            plist_content = {
                "Label": service_name,
                "ProgramArguments": [command] + (args or []),
                "RunAtLoad": False,
                "KeepAlive": False
            }
            
            plist_file = Path(f"/Library/LaunchAgents/{service_name}.plist")
            plist_file.parent.mkdir(parents=True, exist_ok=True)
            
            with open(plist_file, 'wb') as f:
                plistlib.dump(plist_content, f)
                
        except Exception as e:
            logger.error(f"Failed to create launchd service: {e}")
            
    def terminate_process(self, pid: int, graceful: bool = True) -> bool:
        """Terminate macOS process."""
        try:
            if graceful:
                # Send SIGTERM first
                os.kill(pid, signal.SIGTERM)
                
                # Wait for process to exit
                for _ in range(10):  # Wait up to 10 seconds
                    try:
                        os.kill(pid, 0)  # Check if process exists
                        time.sleep(1)
                    except ProcessLookupError:
                        return True  # Process exited
                        
                # Process still running, force kill
                os.kill(pid, signal.SIGKILL)
                return True
            else:
                # Force kill immediately
                os.kill(pid, signal.SIGKILL)
                return True
                
        except ProcessLookupError:
            return True  # Process already exited
        except Exception as e:
            logger.error(f"Failed to terminate process {pid}: {e}")
            return False
            
    def get_process_info(self, pid: int) -> Optional[ProcessInfo]:
        """Get macOS process information."""
        try:
            # Use ps command for process information
            ps_output = subprocess.check_output(
                ["ps", "-o", "pid,ppid,user,comm,lstart,etime,pcpu,pmem,stat,start", "-p", str(pid)],
                text=True
            )
            
            lines = ps_output.strip().split('\n')
            if len(lines) < 2:
                return None
                
            data = lines[1].split()
            if len(data) < 10:
                return None
                
            # Parse ps output (simplified parsing)
            process_name = data[2]  # comm
            parent_pid = int(data[1])  # ppid
            user = data[0]  # user
            
            # Get process state
            stat_output = subprocess.check_output(
                ["ps", "-o", "state", "-p", str(pid)],
                text=True
            ).strip().split('\n')[1]
            
            state_mapping = {
                'R': ProcessState.RUNNING,
                'S': ProcessState.SLEEPING,
                'D': ProcessState.STOPPED,
                'Z': ProcessState.ZOMBIE,
                'T': ProcessState.STOPPED
            }
            state = state_mapping.get(stat_output, ProcessState.RUNNING)
            
            # Get privilege level
            privilege_level = self._get_process_privilege_level(pid)
            
            # Get additional process information
            statm_output = subprocess.check_output(
                ["ps", "-o", "vsz,rss,thcount", "-p", str(pid)],
                text=True
            ).strip().split('\n')[1]
            
            memory_usage = 0
            try:
                memory_data = statm_output.split()
                memory_usage = int(memory_data[1]) * 1024  # RSS in KB
            except (ValueError, IndexError):
                pass
                
            # Get working directory using lsof
            working_dir = ""
            try:
                lsof_output = subprocess.check_output(
                    ["lsof", "-p", str(pid), "-d", "cwd", "-F", "n"],
                    text=True
                )
                for line in lsof_output.split('\n'):
                    if line.startswith('n'):
                        working_dir = line[1:]
                        break
            except (subprocess.CalledProcessError, IndexError):
                pass
                
            # Get environment variables (simplified)
            environment = {}
            
            return ProcessInfo(
                pid=pid,
                name=process_name,
                command_line=command,  # Simplified
                parent_pid=parent_pid,
                state=state,
                privilege_level=privilege_level,
                create_time=time.time(),  # Would need additional API call
                cpu_usage=0.0,  # Would need additional API call
                memory_usage=memory_usage,
                working_directory=working_dir,
                environment=environment,
                user_id=os.getuid(),
                group_id=os.getgid(),
                is_service=as_service
            )
            
        except Exception as e:
            logger.error(f"Error getting process info for PID {pid}: {e}")
            return None
            
    def _get_process_privilege_level(self, pid: int) -> PrivilegeLevel:
        """Get macOS process privilege level."""
        try:
            # Check if process is running as root
            ps_output = subprocess.check_output(
                ["ps", "-o", "user", "-p", str(pid)],
                text=True
            )
            
            user = ps_output.strip().split('\n')[1]
            if user == 'root':
                return PrivilegeLevel.SYSTEM
                
            return PrivilegeLevel.USER
            
        except Exception:
            return PrivilegeLevel.USER
            
    def list_processes(self) -> List[ProcessInfo]:
        """List all macOS processes."""
        try:
            processes = []
            
            # Get all process IDs
            ps_output = subprocess.check_output(
                ["ps", "-eo", "pid"],
                text=True
            )
            
            pids = []
            for line in ps_output.strip().split('\n')[1:]:  # Skip header
                try:
                    pid = int(line.strip())
                    pids.append(pid)
                except ValueError:
                    continue
                    
            # Get info for each process
            for pid in pids:
                try:
                    process_info = self.get_process_info(pid)
                    if process_info:
                        processes.append(process_info)
                except Exception:
                    continue
                    
        except Exception as e:
            logger.error(f"Error listing processes: {e}")
            
        return processes
        
    def start_monitoring(self) -> None:
        """Start macOS process monitoring."""
        try:
            # Start monitoring thread for process events
            self.monitoring_thread = threading.Thread(
                target=self._monitor_process_events,
                daemon=True
            )
            self.monitoring_thread.start()
            logger.info("macOS process monitoring started")
        except Exception as e:
            logger.error(f"Failed to start macOS process monitoring: {e}")
            
    def _monitor_process_events(self) -> None:
        """Monitor process events using kqueue."""
        try:
            # This would use kqueue for process monitoring
            # For now, use simple polling approach
            known_pids = set()
            
            while True:
                try:
                    # Get current PIDs
                    ps_output = subprocess.check_output(
                        ["ps", "-eo", "pid"],
                        text=True
                    )
                    
                    current_pids = set()
                    for line in ps_output.strip().split('\n')[1:]:
                        try:
                            pid = int(line.strip())
                            current_pids.add(pid)
                        except ValueError:
                            continue
                            
                    # Find new processes (simplified)
                    new_pids = current_pids - known_pids
                    for pid in new_pids:
                        try:
                            process_info = self.get_process_info(pid)
                            if process_info:
                                event = ProcessEvent(
                                    event_type="process.create",
                                    pid=pid,
                                    timestamp=time.time(),
                                    process_name=process_info.name,
                                    command_line=process_info.command_line,
                                    user_id=0,
                                    additional_data={}
                                )
                                self._notify_event_handlers(event)
                        except Exception:
                            continue
                            
                    # Update known PIDs
                    known_pids = current_pids
                    
                    # Sleep before next check
                    time.sleep(1)
                    
                except Exception as e:
                    logger.error(f"Process monitoring error: {e}")
                    time.sleep(5)
                    
        except Exception as e:
            logger.error(f"Process monitoring thread error: {e}")
            
    def stop_monitoring(self) -> None:
        """Stop macOS process monitoring."""
        logger.info("macOS process monitoring stopped")
        
    def check_privileges(self, pid: int) -> PrivilegeLevel:
        """Check macOS process privileges."""
        return self._get_process_privilege_level(pid)


class MacOSEventManager(EventManager):
    """macOS-specific event management using kqueue and endpoint security."""
    
    def start_monitoring(self) -> None:
        """Start macOS event monitoring using kqueue."""
        try:
            # This would implement kqueue-based event monitoring
            # For now, start with basic event processing
            self.start_event_processing()
            logger.info("macOS kqueue event monitoring started")
        except Exception as e:
            logger.error(f"Failed to start macOS event monitoring: {e}")
            
    def stop_monitoring(self) -> None:
        """Stop macOS event monitoring."""
        try:
            self.stop_event_processing()
            logger.info("macOS event monitoring stopped")
        except Exception as e:
            logger.error(f"Failed to stop macOS event monitoring: {e}")


# Export classes
WindowsFileSystem = None
LinuxFileSystem = None
MacOSFileSystem = MacOSFileSystem

WindowsProcessManager = None
LinuxProcessManager = None
MacOSProcessManager = MacOSProcessManager

WindowsEventManager = None
LinuxEventManager = None
MacOSEventManager = MacOSEventManager


# Import signal module for macOS
import signal