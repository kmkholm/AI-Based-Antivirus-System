"""
System Performance Monitoring Integration
========================================

Provides comprehensive system performance monitoring across platforms:
- CPU, memory, and disk usage monitoring
- Process performance tracking
- Network performance monitoring
- Custom metrics collection
- Performance alerts and thresholding
- Real-time performance dashboards
- Historical performance data analysis

Implements performance monitoring with minimal system overhead.
"""

import os
import sys
import time
import platform
import logging
import threading
import psutil
import json
from typing import Dict, List, Optional, Any, Callable
from pathlib import Path
from dataclasses import dataclass, asdict
from enum import Enum
from collections import deque
import queue
import statistics

logger = logging.getLogger(__name__)


class MetricType(Enum):
    """Performance metric types."""
    CPU_USAGE = "cpu_usage"
    MEMORY_USAGE = "memory_usage"
    DISK_USAGE = "disk_usage"
    NETWORK_IO = "network_io"
    PROCESS_COUNT = "process_count"
    THREAD_COUNT = "thread_count"
    FILE_DESCRIPTORS = "file_descriptors"
    TEMPERATURE = "temperature"
    BATTERY_LEVEL = "battery_level"
    CUSTOM = "custom"


class AlertSeverity(Enum):
    """Alert severity levels."""
    INFO = "info"
    WARNING = "warning"
    CRITICAL = "critical"
    EMERGENCY = "emergency"


@dataclass
class PerformanceMetric:
    """Performance metric data."""
    metric_type: MetricType
    timestamp: float
    value: float
    unit: str
    source: str
    tags: Dict[str, str] = None
    
    def __post_init__(self):
        if self.tags is None:
            self.tags = {}


@dataclass
class PerformanceAlert:
    """Performance alert."""
    alert_id: str
    metric_type: MetricType
    severity: AlertSeverity
    threshold: float
    actual_value: float
    timestamp: float
    message: str
    source: str
    resolved: bool = False


class PerformanceThreshold:
    """Performance threshold for alerts."""
    
    def __init__(self, warning: float, critical: float, duration: float = 0):
        self.warning = warning
        self.critical = critical
        self.duration = duration
        self.last_alert_time = 0
        
    def check(self, value: float, current_time: float) -> Optional[AlertSeverity]:
        """Check if value exceeds thresholds."""
        if self.critical > 0 and value >= self.critical:
            # Critical threshold
            if self._should_alert(current_time):
                return AlertSeverity.CRITICAL
        elif self.warning > 0 and value >= self.warning:
            # Warning threshold
            if self._should_alert(current_time):
                return AlertSeverity.WARNING
                
        return None
        
    def _should_alert(self, current_time: float) -> bool:
        """Check if alert should be sent (rate limiting)."""
        if self.duration == 0:
            return True
            
        return (current_time - self.last_alert_time) >= self.duration


class SystemMonitor:
    """System performance monitoring."""
    
    def __init__(self, config: Dict[str, Any]):
        self.config = config
        self.metrics_buffer: Dict[str, deque] = {}
        self.thresholds: Dict[MetricType, PerformanceThreshold] = {}
        self.alerts: List[PerformanceAlert] = []
        self.alert_handlers: List[Callable] = []
        self.monitoring_active = False
        
        # Configure default thresholds
        self._setup_default_thresholds()
        
        # Metrics buffer size
        self.buffer_size = config.get('buffer_size', 1000)
        
    def _setup_default_thresholds(self) -> None:
        """Setup default performance thresholds."""
        self.thresholds = {
            MetricType.CPU_USAGE: PerformanceThreshold(80.0, 95.0, 60.0),
            MetricType.MEMORY_USAGE: PerformanceThreshold(85.0, 95.0, 30.0),
            MetricType.DISK_USAGE: PerformanceThreshold(90.0, 98.0, 120.0),
            MetricType.PROCESS_COUNT: PerformanceThreshold(500.0, 1000.0, 300.0),
            MetricType.THREAD_COUNT: PerformanceThreshold(1000.0, 2000.0, 300.0)
        }
        
    def start_monitoring(self) -> None:
        """Start performance monitoring."""
        if self.monitoring_active:
            return
            
        self.monitoring_active = True
        self.monitoring_thread = threading.Thread(target=self._monitoring_loop, daemon=True)
        self.monitoring_thread.start()
        
        logger.info("System performance monitoring started")
        
    def stop_monitoring(self) -> None:
        """Stop performance monitoring."""
        self.monitoring_active = False
        if hasattr(self, 'monitoring_thread') and self.monitoring_thread.is_alive():
            self.monitoring_thread.join(timeout=5)
            
        logger.info("System performance monitoring stopped")
        
    def _monitoring_loop(self) -> None:
        """Main monitoring loop."""
        while self.monitoring_active:
            try:
                current_time = time.time()
                
                # Collect system metrics
                self._collect_cpu_metrics(current_time)
                self._collect_memory_metrics(current_time)
                self._collect_disk_metrics(current_time)
                self._collect_network_metrics(current_time)
                self._collect_process_metrics(current_time)
                self._collect_custom_metrics(current_time)
                
                # Sleep before next collection
                time.sleep(1.0)
                
            except Exception as e:
                logger.error(f"Performance monitoring error: {e}")
                time.sleep(5)
                
    def _collect_cpu_metrics(self, timestamp: float) -> None:
        """Collect CPU performance metrics."""
        try:
            # CPU usage percentage
            cpu_percent = psutil.cpu_percent(interval=None)
            self._store_metric(MetricType.CPU_USAGE, timestamp, cpu_percent, "%", "system")
            
            # Per-CPU usage
            if hasattr(psutil, 'cpu_percent'):
                per_cpu = psutil.cpu_percent(interval=None, percpu=True)
                for i, cpu_percent in enumerate(per_cpu):
                    self._store_metric(MetricType.CPU_USAGE, timestamp, cpu_percent, "%", f"cpu_{i}")
                    
            # CPU frequency
            if hasattr(psutil, 'cpu_freq'):
                cpu_freq = psutil.cpu_freq()
                if cpu_freq:
                    self._store_metric(MetricType.CUSTOM, timestamp, cpu_freq.current, "MHz", "cpu_freq")
                    
        except Exception as e:
            logger.error(f"CPU metrics collection error: {e}")
            
    def _collect_memory_metrics(self, timestamp: float) -> None:
        """Collect memory performance metrics."""
        try:
            # Virtual memory
            memory = psutil.virtual_memory()
            self._store_metric(MetricType.MEMORY_USAGE, timestamp, memory.percent, "%", "system")
            self._store_metric(MetricType.MEMORY_USAGE, timestamp, memory.used / (1024**3), "GB", "used")
            self._store_metric(MetricType.MEMORY_USAGE, timestamp, memory.available / (1024**3), "GB", "available")
            
            # Swap memory
            swap = psutil.swap_memory()
            self._store_metric(MetricType.MEMORY_USAGE, timestamp, swap.percent, "%", "swap")
            
        except Exception as e:
            logger.error(f"Memory metrics collection error: {e}")
            
    def _collect_disk_metrics(self, timestamp: float) -> None:
        """Collect disk performance metrics."""
        try:
            # Disk usage for all partitions
            for partition in psutil.disk_partitions():
                try:
                    usage = psutil.disk_usage(partition.mountpoint)
                    self._store_metric(MetricType.DISK_USAGE, timestamp, 
                                     (usage.used / usage.total) * 100, "%", partition.mountpoint)
                except PermissionError:
                    continue
                    
            # Disk I/O
            disk_io = psutil.disk_io_counters()
            if disk_io:
                self._store_metric(MetricType.DISK_USAGE, timestamp, disk_io.read_bytes, "bytes", "read_total")
                self._store_metric(MetricType.DISK_USAGE, timestamp, disk_io.write_bytes, "bytes", "write_total")
                
        except Exception as e:
            logger.error(f"Disk metrics collection error: {e}")
            
    def _collect_network_metrics(self, timestamp: float) -> None:
        """Collect network performance metrics."""
        try:
            # Network I/O
            network_io = psutil.net_io_counters()
            if network_io:
                self._store_metric(MetricType.NETWORK_IO, timestamp, network_io.bytes_sent, "bytes", "sent")
                self._store_metric(MetricType.NETWORK_IO, timestamp, network_io.bytes_recv, "bytes", "recv")
                
            # Network connections
            connections = len(psutil.net_connections())
            self._store_metric(MetricType.NETWORK_IO, timestamp, connections, "count", "connections")
            
        except Exception as e:
            logger.error(f"Network metrics collection error: {e}")
            
    def _collect_process_metrics(self, timestamp: float) -> None:
        """Collect process performance metrics."""
        try:
            # Process count
            process_count = len(psutil.pids())
            self._store_metric(MetricType.PROCESS_COUNT, timestamp, process_count, "count", "total")
            
            # Thread count
            total_threads = 0
            for proc in psutil.process_iter(['num_threads']):
                try:
                    total_threads += proc.info['num_threads'] or 0
                except (psutil.NoSuchProcess, psutil.AccessDenied):
                    continue
            self._store_metric(MetricType.THREAD_COUNT, timestamp, total_threads, "count", "total")
            
        except Exception as e:
            logger.error(f"Process metrics collection error: {e}")
            
    def _collect_custom_metrics(self, timestamp: float) -> None:
        """Collect custom platform-specific metrics."""
        try:
            # Battery level (laptops)
            if hasattr(psutil, 'sensors_battery'):
                battery = psutil.sensors_battery()
                if battery:
                    self._store_metric(MetricType.BATTERY_LEVEL, timestamp, battery.percent, "%", "main")
                    
            # Temperature sensors
            if hasattr(psutil, 'sensors_temperatures'):
                temps = psutil.sensors_temperatures()
                for name, entries in temps.items():
                    for entry in entries:
                        self._store_metric(MetricType.TEMPERATURE, timestamp, entry.current, "C", name)
                        
        except Exception as e:
            logger.error(f"Custom metrics collection error: {e}")
            
    def _store_metric(self, metric_type: MetricType, timestamp: float, 
                     value: float, unit: str, source: str) -> None:
        """Store performance metric."""
        try:
            # Create metric
            metric = PerformanceMetric(
                metric_type=metric_type,
                timestamp=timestamp,
                value=value,
                unit=unit,
                source=source
            )
            
            # Add to buffer
            buffer_key = f"{metric_type.value}:{source}"
            if buffer_key not in self.metrics_buffer:
                self.metrics_buffer[buffer_key] = deque(maxlen=self.buffer_size)
            self.metrics_buffer[buffer_key].append(metric)
            
            # Check thresholds
            self._check_thresholds(metric)
            
        except Exception as e:
            logger.error(f"Metric storage error: {e}")
            
    def _check_thresholds(self, metric: PerformanceMetric) -> None:
        """Check metric against thresholds."""
        try:
            # Find matching threshold
            threshold = self.thresholds.get(metric.metric_type)
            if not threshold:
                return
                
            # Check threshold
            severity = threshold.check(metric.value, metric.timestamp)
            if severity:
                self._create_alert(metric, severity, threshold)
                
        except Exception as e:
            logger.error(f"Threshold checking error: {e}")
            
    def _create_alert(self, metric: PerformanceMetric, severity: AlertSeverity,
                     threshold: PerformanceThreshold) -> None:
        """Create performance alert."""
        try:
            alert = PerformanceAlert(
                alert_id=f"{metric.metric_type.value}:{metric.source}:{int(metric.timestamp)}",
                metric_type=metric.metric_type,
                severity=severity,
                threshold=threshold.critical if severity == AlertSeverity.CRITICAL else threshold.warning,
                actual_value=metric.value,
                timestamp=metric.timestamp,
                message=f"{metric.metric_type.value} {metric.source} at {metric.value:.1f}{metric.unit}",
                source=metric.source
            )
            
            self.alerts.append(alert)
            
            # Update last alert time
            threshold.last_alert_time = metric.timestamp
            
            # Notify handlers
            for handler in self.alert_handlers:
                try:
                    handler(alert)
                except Exception as e:
                    logger.error(f"Alert handler error: {e}")
                    
            logger.warning(f"Performance alert: {alert.message}")
            
        except Exception as e:
            logger.error(f"Alert creation error: {e}")
            
    def get_current_metrics(self) -> Dict[str, Any]:
        """Get current performance metrics."""
        try:
            current_metrics = {}
            
            for buffer_key, metrics in self.metrics_buffer.items():
                if metrics:
                    latest_metric = metrics[-1]
                    current_metrics[buffer_key] = {
                        "value": latest_metric.value,
                        "unit": latest_metric.unit,
                        "timestamp": latest_metric.timestamp,
                        "metric_type": latest_metric.metric_type.value
                    }
                    
            return current_metrics
            
        except Exception as e:
            logger.error(f"Current metrics error: {e}")
            return {}
            
    def get_metric_history(self, metric_type: MetricType, source: str = None,
                          duration: int = 3600) -> List[PerformanceMetric]:
        """Get historical metrics."""
        try:
            buffer_key = f"{metric_type.value}:{source}" if source else f"{metric_type.value}:*"
            cutoff_time = time.time() - duration
            
            # Find matching buffer
            matching_buffer = None
            for key, metrics in self.metrics_buffer.items():
                if key.startswith(f"{metric_type.value}:"):
                    matching_buffer = metrics
                    break
                    
            if not matching_buffer:
                return []
                
            # Filter by time and source
            filtered_metrics = []
            for metric in reversed(matching_buffer):
                if metric.timestamp >= cutoff_time:
                    if source is None or metric.source == source:
                        filtered_metrics.append(metric)
                        
            return filtered_metrics
            
        except Exception as e:
            logger.error(f"Metric history error: {e}")
            return []
            
    def get_performance_summary(self) -> Dict[str, Any]:
        """Get performance summary statistics."""
        try:
            summary = {
                "timestamp": time.time(),
                "system_info": self._get_system_info(),
                "current_values": self.get_current_metrics(),
                "alerts": len(self.alerts),
                "monitoring_active": self.monitoring_active
            }
            
            # Add statistical summaries
            for buffer_key, metrics in self.metrics_buffer.items():
                if metrics:
                    values = [m.value for m in metrics]
                    summary[f"{buffer_key}_stats"] = {
                        "min": min(values),
                        "max": max(values),
                        "avg": statistics.mean(values),
                        "count": len(values)
                    }
                    
            return summary
            
        except Exception as e:
            logger.error(f"Performance summary error: {e}")
            return {}
            
    def _get_system_info(self) -> Dict[str, Any]:
        """Get system information."""
        try:
            return {
                "platform": platform.system(),
                "platform_version": platform.version(),
                "architecture": platform.machine(),
                "processor": platform.processor(),
                "boot_time": psutil.boot_time(),
                "cpu_count": psutil.cpu_count(),
                "cpu_count_physical": psutil.cpu_count(logical=False),
                "memory_total": psutil.virtual_memory().total / (1024**3)
            }
        except Exception:
            return {}
            
    def add_alert_handler(self, handler: Callable[[PerformanceAlert], None]) -> None:
        """Add performance alert handler."""
        self.alert_handlers.append(handler)
        
    def set_threshold(self, metric_type: MetricType, threshold: PerformanceThreshold) -> None:
        """Set performance threshold for metric type."""
        self.thresholds[metric_type] = threshold
        
    def get_alerts(self, severity: Optional[AlertSeverity] = None) -> List[PerformanceAlert]:
        """Get performance alerts."""
        if severity:
            return [alert for alert in self.alerts if alert.severity == severity]
        return self.alerts.copy()
        
    def clear_alerts(self) -> None:
        """Clear all alerts."""
        self.alerts.clear()


class ProcessMonitor:
    """Process performance monitoring."""
    
    def __init__(self, config: Dict[str, Any]):
        self.config = config
        self.monitored_pids: set = set()
        self.process_metrics: Dict[int, Dict[str, List]] = {}
        self.monitoring_active = False
        
    def start_monitoring(self, pids: List[int] = None) -> None:
        """Start process monitoring."""
        if pids:
            self.monitored_pids.update(pids)
            
        if not self.monitoring_active:
            self.monitoring_active = True
            self.monitoring_thread = threading.Thread(target=self._process_monitoring_loop, daemon=True)
            self.monitoring_thread.start()
            
        logger.info(f"Process monitoring started for {len(self.monitored_pids)} processes")
        
    def stop_monitoring(self) -> None:
        """Stop process monitoring."""
        self.monitoring_active = False
        if hasattr(self, 'monitoring_thread') and self.monitoring_thread.is_alive():
            self.monitoring_thread.join(timeout=5)
            
        logger.info("Process monitoring stopped")
        
    def _process_monitoring_loop(self) -> None:
        """Process monitoring loop."""
        while self.monitoring_active:
            try:
                # Remove non-existent processes
                valid_pids = set()
                for pid in list(self.monitored_pids):
                    try:
                        psutil.Process(pid).info
                        valid_pids.add(pid)
                    except (psutil.NoSuchProcess, psutil.AccessDenied):
                        continue
                        
                self.monitored_pids = valid_pids
                
                # Collect metrics for monitored processes
                for pid in self.monitored_pids:
                    self._collect_process_metrics(pid)
                    
                time.sleep(1.0)
                
            except Exception as e:
                logger.error(f"Process monitoring error: {e}")
                time.sleep(5)
                
    def _collect_process_metrics(self, pid: int) -> None:
        """Collect metrics for specific process."""
        try:
            process = psutil.Process(pid)
            
            # Initialize process metrics if not exists
            if pid not in self.process_metrics:
                self.process_metrics[pid] = {
                    'cpu_percent': [],
                    'memory_percent': [],
                    'memory_info': [],
                    'num_threads': [],
                    'num_fds': []
                }
                
            # Collect metrics
            cpu_percent = process.cpu_percent()
            memory_percent = process.memory_percent()
            memory_info = process.memory_info()
            num_threads = process.num_threads()
            
            # File descriptors (Unix only)
            num_fds = 0
            try:
                num_fds = process.num_fds()
            except (AttributeError, psutil.AccessDenied):
                pass
                
            # Store metrics
            self.process_metrics[pid]['cpu_percent'].append((time.time(), cpu_percent))
            self.process_metrics[pid]['memory_percent'].append((time.time(), memory_percent))
            self.process_metrics[pid]['memory_info'].append((time.time(), memory_info))
            self.process_metrics[pid]['num_threads'].append((time.time(), num_threads))
            self.process_metrics[pid]['num_fds'].append((time.time(), num_fds))
            
            # Keep only recent data (last 1000 points)
            for metric_name, values in self.process_metrics[pid].items():
                if len(values) > 1000:
                    self.process_metrics[pid][metric_name] = values[-1000:]
                    
        except (psutil.NoSuchProcess, psutil.AccessDenied) as e:
            logger.debug(f"Process {pid} monitoring error: {e}")
        except Exception as e:
            logger.error(f"Process {pid} metrics collection error: {e}")
            
    def get_process_metrics(self, pid: int, metric_name: str, 
                           duration: int = 300) -> List[tuple]:
        """Get process metrics for specific time duration."""
        if pid not in self.process_metrics or metric_name not in self.process_metrics[pid]:
            return []
            
        cutoff_time = time.time() - duration
        values = self.process_metrics[pid][metric_name]
        
        return [(timestamp, value) for timestamp, value in values if timestamp >= cutoff_time]


class NetworkMonitor:
    """Network performance monitoring."""
    
    def __init__(self, config: Dict[str, Any]):
        self.config = config
        self.monitoring_active = False
        self.last_network_stats = None
        self.bandwidth_history: Dict[str, deque] = {}
        
    def start_monitoring(self) -> None:
        """Start network monitoring."""
        if not self.monitoring_active:
            self.monitoring_active = True
            self.monitoring_thread = threading.Thread(target=self._network_monitoring_loop, daemon=True)
            self.monitoring_thread.start()
            
        logger.info("Network monitoring started")
        
    def stop_monitoring(self) -> None:
        """Stop network monitoring."""
        self.monitoring_active = False
        if hasattr(self, 'monitoring_thread') and self.monitoring_thread.is_alive():
            self.monitoring_thread.join(timeout=5)
            
        logger.info("Network monitoring stopped")
        
    def _network_monitoring_loop(self) -> None:
        """Network monitoring loop."""
        while self.monitoring_active:
            try:
                self._collect_network_metrics()
                time.sleep(1.0)
            except Exception as e:
                logger.error(f"Network monitoring error: {e}")
                time.sleep(5)
                
    def _collect_network_metrics(self) -> None:
        """Collect network performance metrics."""
        try:
            current_stats = psutil.net_io_counters()
            if not current_stats or not self.last_network_stats:
                self.last_network_stats = current_stats
                return
                
            # Calculate bandwidth usage
            current_time = time.time()
            bytes_sent_per_sec = current_stats.bytes_sent - self.last_network_stats.bytes_sent
            bytes_recv_per_sec = current_stats.bytes_recv - self.last_network_stats.bytes_recv
            
            # Store bandwidth history
            if 'bytes_sent' not in self.bandwidth_history:
                self.bandwidth_history['bytes_sent'] = deque(maxlen=100)
                self.bandwidth_history['bytes_recv'] = deque(maxlen=100)
                
            self.bandwidth_history['bytes_sent'].append((current_time, bytes_sent_per_sec))
            self.bandwidth_history['bytes_recv'].append((current_time, bytes_recv_per_sec))
            
            self.last_network_stats = current_stats
            
        except Exception as e:
            logger.error(f"Network metrics collection error: {e}")
            
    def get_bandwidth_usage(self, duration: int = 60) -> Dict[str, List[tuple]]:
        """Get bandwidth usage for specific duration."""
        cutoff_time = time.time() - duration
        
        result = {}
        for metric, history in self.bandwidth_history.items():
            result[metric] = [(timestamp, value) for timestamp, value in history if timestamp >= cutoff_time]
            
        return result


class PerformanceExporter:
    """Performance data exporter."""
    
    def __init__(self, output_directory: str = "/var/log/antivirus"):
        self.output_directory = Path(output_directory)
        self.output_directory.mkdir(parents=True, exist_ok=True)
        
    def export_metrics(self, monitor: SystemMonitor, format: str = "json", 
                      duration: int = 3600) -> str:
        """Export performance metrics to file."""
        try:
            timestamp = int(time.time())
            filename = f"performance_metrics_{timestamp}.{format}"
            filepath = self.output_directory / filename
            
            if format == "json":
                return self._export_json(monitor, filepath, duration)
            elif format == "csv":
                return self._export_csv(monitor, filepath, duration)
            else:
                raise ValueError(f"Unsupported export format: {format}")
                
        except Exception as e:
            logger.error(f"Metrics export error: {e}")
            return ""
            
    def _export_json(self, monitor: SystemMonitor, filepath: Path, duration: int) -> str:
        """Export metrics to JSON format."""
        try:
            export_data = {
                "export_time": time.time(),
                "duration": duration,
                "metrics": {}
            }
            
            # Export all metric types
            for buffer_key, metrics in monitor.metrics_buffer.items():
                if metrics:
                    recent_metrics = [asdict(m) for m in metrics if m.timestamp >= time.time() - duration]
                    export_data["metrics"][buffer_key] = recent_metrics
                    
            # Export alerts
            export_data["alerts"] = [asdict(alert) for alert in monitor.get_alerts()]
            
            with open(filepath, 'w') as f:
                json.dump(export_data, f, indent=2)
                
            return str(filepath)
            
        except Exception as e:
            logger.error(f"JSON export error: {e}")
            return ""
            
    def _export_csv(self, monitor: SystemMonitor, filepath: Path, duration: int) -> str:
        """Export metrics to CSV format."""
        try:
            import csv
            
            with open(filepath, 'w', newline='') as f:
                writer = csv.writer(f)
                writer.writerow(["timestamp", "metric_type", "value", "unit", "source"])
                
                for buffer_key, metrics in monitor.metrics_buffer.items():
                    if metrics:
                        metric_type = buffer_key.split(':')[0]
                        for metric in metrics:
                            if metric.timestamp >= time.time() - duration:
                                writer.writerow([
                                    metric.timestamp,
                                    metric.metric_type.value,
                                    metric.value,
                                    metric.unit,
                                    metric.source
                                ])
                                
            return str(filepath)
            
        except Exception as e:
            logger.error(f"CSV export error: {e}")
            return ""


def create_performance_monitor(config: Dict[str, Any] = None) -> SystemMonitor:
    """Factory function to create performance monitor."""
    if config is None:
        config = {}
        
    return SystemMonitor(config)


def main():
    """Main entry point for performance monitoring."""
    import argparse
    
    parser = argparse.ArgumentParser(description='Antivirus Performance Monitor')
    parser.add_argument('--config', help='Configuration file')
    parser.add_argument('--export', help='Export metrics to file')
    parser.add_argument('--duration', type=int, default=3600, help='Export duration in seconds')
    parser.add_argument('--daemon', action='store_true', help='Run as daemon')
    
    args = parser.parse_args()
    
    # Set up logging
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(levelname)s - %(message)s'
    )
    
    # Create performance monitor
    monitor = create_performance_monitor()
    
    try:
        if args.daemon:
            # Run as monitoring daemon
            monitor.start_monitoring()
            logger.info("Performance monitoring daemon started")
            
            # Keep running
            while True:
                time.sleep(10)
                
        else:
            # Export metrics and exit
            if args.export:
                exporter = PerformanceExporter()
                filepath = exporter.export_metrics(monitor, duration=args.duration)
                if filepath:
                    print(f"Metrics exported to: {filepath}")
                else:
                    print("Export failed")
                    sys.exit(1)
            else:
                # Run once and show summary
                monitor.start_monitoring()
                time.sleep(5)  # Collect some metrics
                
                summary = monitor.get_performance_summary()
                print(json.dumps(summary, indent=2))
                
    except KeyboardInterrupt:
        logger.info("Monitoring stopped by user")
    except Exception as e:
        logger.error(f"Performance monitor error: {e}")
        sys.exit(1)
    finally:
        monitor.stop_monitoring()


if __name__ == '__main__':
    main()