"""
Process Management Abstraction Layer
===================================

Provides unified process management across Windows, Linux, and macOS:
- Process creation, monitoring, and termination
- Process security and privilege management
- Real-time process behavior monitoring
- System service/daemon management
- Process isolation and sandboxing

Supports Zero Trust security with comprehensive process audit logging.
"""

import os
import platform
import logging
import time
import threading
from typing import Dict, List, Optional, Callable, Any, Tuple
from abc import ABC, abstractmethod
from dataclasses import dataclass
from enum import Enum
import signal

logger = logging.getLogger(__name__)


class ProcessState(Enum):
    """Process state enumeration."""
    CREATED = "created"
    RUNNING = "running"
    SLEEPING = "sleeping"
    STOPPED = "stopped"
    ZOMBIE = "zombie"
    TERMINATED = "terminated"
    ERROR = "error"


class PrivilegeLevel(Enum):
    """Process privilege levels."""
    USER = "user"
    ELEVATED = "elevated"
    SYSTEM = "system"
    KERNEL = "kernel"


@dataclass
class ProcessInfo:
    """Process information structure."""
    pid: int
    name: str
    command_line: str
    parent_pid: int
    state: ProcessState
    privilege_level: PrivilegeLevel
    create_time: float
    cpu_usage: float
    memory_usage: int
    working_directory: str
    environment: Dict[str, str]
    user_id: int
    group_id: int
    is_service: bool = False
    is_sandboxed: bool = False


@dataclass
class ProcessEvent:
    """Process event data."""
    event_type: str
    pid: int
    timestamp: float
    process_name: str
    command_line: str
    user_id: int
    additional_data: Dict[str, Any]


class ProcessManager(ABC):
    """Abstract base class for process management."""
    
    def __init__(self, config: Dict[str, Any]):
        self.config = config
        self.monitored_processes: Dict[int, ProcessInfo] = {}
        self.event_handlers: List[Callable[[ProcessEvent], None]] = []
        self.monitoring_active = False
        self._lock = threading.RLock()
        
    @abstractmethod
    def create_process(self, command: str, args: List[str] = None, 
                      cwd: str = None, env: Dict[str, str] = None,
                      as_service: bool = False) -> Optional[int]:
        """Create a new process."""
        pass
        
    @abstractmethod
    def terminate_process(self, pid: int, graceful: bool = True) -> bool:
        """Terminate a process."""
        pass
        
    @abstractmethod
    def get_process_info(self, pid: int) -> Optional[ProcessInfo]:
        """Get process information."""
        pass
        
    @abstractmethod
    def list_processes(self) -> List[ProcessInfo]:
        """List all running processes."""
        pass
        
    @abstractmethod
    def start_monitoring(self) -> None:
        """Start process monitoring."""
        pass
        
    @abstractmethod
    def stop_monitoring(self) -> None:
        """Stop process monitoring."""
        pass
        
    @abstractmethod
    def check_privileges(self, pid: int) -> PrivilegeLevel:
        """Check process privilege level."""
        pass
        
    def is_process_alive(self, pid: int) -> bool:
        """Check if process is running."""
        try:
            if platform.system().lower() == 'windows':
                return self._check_windows_process(pid)
            else:
                return os.kill(pid, 0) == 0
        except (OSError, ProcessLookupError):
            return False
            
    def _check_windows_process(self, pid: int) -> bool:
        """Check Windows process existence."""
        try:
            import ctypes
            return ctypes.windll.kernel32.OpenProcess(
                0, False, pid) != 0
        except (AttributeError, OSError):
            return False
            
    def monitor_process(self, pid: int) -> None:
        """Add process to monitoring list."""
        with self._lock:
            if pid not in self.monitored_processes:
                self.monitored_processes[pid] = self.get_process_info(pid)
                
    def unmonitor_process(self, pid: int) -> None:
        """Remove process from monitoring list."""
        with self._lock:
            if pid in self.monitored_processes:
                del self.monitored_processes[pid]
                
    def add_event_handler(self, handler: Callable[[ProcessEvent], None]) -> None:
        """Add process event handler."""
        with self._lock:
            self.event_handlers.append(handler)
            
    def remove_event_handler(self, handler: Callable[[ProcessEvent], None]) -> None:
        """Remove process event handler."""
        with self._lock:
            if handler in self.event_handlers:
                self.event_handlers.remove(handler)
                
    def _notify_event_handlers(self, event: ProcessEvent) -> None:
        """Notify all registered event handlers."""
        with self._lock:
            for handler in self.event_handlers:
                try:
                    handler(event)
                except Exception as e:
                    logger.error(f"Error in process event handler: {e}")


class SecureProcessLauncher:
    """Secure process launching with proper isolation and restrictions."""
    
    @staticmethod
    def launch_secure_process(command: str, args: List[str] = None,
                             cwd: str = None, env: Dict[str, str] = None,
                             sandbox: bool = False, 
                             max_runtime: Optional[int] = None) -> Optional[int]:
        """Launch process with security restrictions."""
        try:
            import subprocess
            import tempfile
            
            # Prepare command line
            cmd_args = [command]
            if args:
                cmd_args.extend(args)
                
            # Create environment with restrictions
            secure_env = os.environ.copy()
            if env:
                secure_env.update(env)
                
            # Add sandbox restrictions if requested
            if sandbox:
                secure_env.update({
                    'SANDBOX_MODE': '1',
                    'RESTRICTED_ACCESS': '1'
                })
                
            # Set working directory to safe location
            if not cwd:
                cwd = tempfile.gettempdir()
                
            # Launch with security flags
            creation_flags = 0
            if platform.system().lower() == 'windows':
                import ctypes
                creation_flags |= ctypes.windll.kernel32.CREATE_SUSPENDED
                
            process = subprocess.Popen(
                cmd_args,
                cwd=cwd,
                env=secure_env,
                creationflags=creation_flags,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE
            )
            
            logger.info(f"Secure process launched: PID={process.pid}, Command='{' '.join(cmd_args)}'")
            return process.pid
            
        except Exception as e:
            logger.error(f"Failed to launch secure process: {e}")
            return None
            
    @staticmethod
    def create_sandboxed_process(isolated_dir: str) -> Callable:
        """Create sandboxed process function for dynamic analysis."""
        
        def execute_in_sandbox(script_path: str, timeout: int = 30) -> Tuple[bool, str, str]:
            """Execute script in isolated environment."""
            import subprocess
            import tempfile
            
            try:
                # Create isolated environment
                isolated_env = {
                    'SANDBOX_PATH': isolated_dir,
                    'ISOLATED_EXECUTION': '1',
                    'TIMEOUT': str(timeout)
                }
                
                # Limit access to sandbox directory
                safe_cwd = isolated_dir
                
                # Execute with timeout
                result = subprocess.run(
                    ['python', script_path],
                    cwd=safe_cwd,
                    env={**os.environ, **isolated_env},
                    capture_output=True,
                    text=True,
                    timeout=timeout
                )
                
                return (
                    result.returncode == 0,
                    result.stdout,
                    result.stderr
                )
                
            except subprocess.TimeoutExpired:
                logger.warning(f"Sandbox execution timeout: {script_path}")
                return False, "", "Execution timeout"
            except Exception as e:
                logger.error(f"Sandbox execution error: {e}")
                return False, "", str(e)
                
        return execute_in_sandbox


class ServiceManager:
    """Cross-platform service/daemon management."""
    
    def __init__(self, config: Dict[str, Any]):
        self.config = config
        self.system = platform.system().lower()
        
    def create_service_definition(self, service_name: str, 
                                 executable_path: str,
                                 args: List[str] = None,
                                 working_directory: str = None,
                                 environment: Dict[str, str] = None,
                                 restart_policy: str = "on-failure") -> Dict[str, Any]:
        """Create platform-specific service definition."""
        
        if self.system == 'windows':
            return self._create_windows_service(
                service_name, executable_path, args, working_directory, 
                environment, restart_policy
            )
        elif self.system == 'linux':
            return self._create_linux_service(
                service_name, executable_path, args, working_directory,
                environment, restart_policy
            )
        elif self.system == 'darwin':
            return self._create_macos_service(
                service_name, executable_path, args, working_directory,
                environment, restart_policy
            )
        else:
            raise NotImplementedError(f"Service creation not supported for {self.system}")
            
    def _create_windows_service(self, name: str, path: str, args: List[str] = None,
                               cwd: str = None, env: Dict[str, str] = None,
                               restart: str = "on-failure") -> Dict[str, Any]:
        """Create Windows service definition."""
        return {
            "type": "windows-service",
            "service_name": name,
            "executable": path,
            "arguments": args or [],
            "working_directory": cwd or "",
            "environment": env or {},
            "restart_policy": restart,
            "description": f"Antivirus service: {name}"
        }
        
    def _create_linux_service(self, name: str, path: str, args: List[str] = None,
                             cwd: str = None, env: Dict[str, str] = None,
                             restart: str = "on-failure") -> Dict[str, Any]:
        """Create Linux systemd service definition."""
        cmd_args = [path] + (args or [])
        env_str = "\n".join([f"Environment={k}={v}" for k, v in (env or {}).items()])
        
        service_content = f"""[Unit]
Description=Antivirus service: {name}
After=network.target

[Service]
Type=simple
ExecStart={' '.join(cmd_args)}
WorkingDirectory={cwd or '/'}
{env_str}
Restart={restart}
RestartSec=10

[Install]
WantedBy=multi-user.target
"""
        
        return {
            "type": "systemd",
            "service_name": name,
            "service_content": service_content,
            "executable": path,
            "arguments": args or []
        }
        
    def _create_macos_service(self, name: str, path: str, args: List[str] = None,
                             cwd: str = None, env: Dict[str, str] = None,
                             restart: str = "on-failure") -> Dict[str, Any]:
        """Create macOS launchd service definition."""
        cmd_args = [path] + (args or [])
        env_dict = {k: {"Value": v} for k, v in (env or {}).items()}
        
        plist_content = {
            "Label": f"com.antivirus.{name}",
            "ProgramArguments": cmd_args,
            "WorkingDirectory": cwd or "/",
            "EnvironmentVariables": env_dict,
            "RunAtLoad": True,
            "KeepAlive": restart == "always",
            "StandardOutPath": f"/var/log/antivirus/{name}.out.log",
            "StandardErrorPath": f"/var/log/antivirus/{name}.err.log"
        }
        
        return {
            "type": "launchd",
            "service_name": name,
            "plist_content": plist_content,
            "executable": path,
            "arguments": args or []
        }
        
    def install_service(self, service_definition: Dict[str, Any]) -> bool:
        """Install system service based on definition."""
        try:
            if service_definition["type"] == "windows-service":
                return self._install_windows_service(service_definition)
            elif service_definition["type"] == "systemd":
                return self._install_linux_service(service_definition)
            elif service_definition["type"] == "launchd":
                return self._install_macos_service(service_definition)
            else:
                raise ValueError(f"Unknown service type: {service_definition['type']}")
        except Exception as e:
            logger.error(f"Service installation failed: {e}")
            return False
            
    def _install_windows_service(self, service_def: Dict[str, Any]) -> bool:
        """Install Windows service."""
        try:
            import subprocess
            import winreg
            
            # Use sc.exe to create service
            cmd = [
                "sc", "create", service_def["service_name"],
                "binPath=", service_def["executable"] + " " + " ".join(service_def["arguments"]),
                "DisplayName=", service_def["description"],
                "Start=", "DEMAND"
            ]
            
            result = subprocess.run(cmd, capture_output=True, text=True)
            return result.returncode == 0
            
        except Exception as e:
            logger.error(f"Windows service installation failed: {e}")
            return False
            
    def _install_linux_service(self, service_def: Dict[str, Any]) -> bool:
        """Install Linux systemd service."""
        try:
            import subprocess
            
            # Write service file
            service_file = f"/etc/systemd/system/{service_def['service_name']}.service"
            with open(service_file, 'w') as f:
                f.write(service_def["service_content"])
                
            # Reload systemd and enable service
            subprocess.run(["systemctl", "daemon-reload"], check=True)
            subprocess.run(["systemctl", "enable", service_def["service_name"]], check=True)
            
            return True
            
        except Exception as e:
            logger.error(f"Linux service installation failed: {e}")
            return False
            
    def _install_macos_service(self, service_def: Dict[str, Any]) -> bool:
        """Install macOS launchd service."""
        try:
            import subprocess
            import plistlib
            import os
            
            # Create log directory
            os.makedirs("/var/log/antivirus", exist_ok=True)
            
            # Write plist file
            plist_file = f"/Library/LaunchDaemons/com.antivirus.{service_def['service_name']}.plist"
            with open(plist_file, 'wb') as f:
                plistlib.dump(service_def["plist_content"], f)
                
            # Load service
            subprocess.run([
                "launchctl", "load", plist_file
            ], check=True)
            
            return True
            
        except Exception as e:
            logger.error(f"macOS service installation failed: {e}")
            return False
            
    def start_service(self, service_name: str) -> bool:
        """Start system service."""
        try:
            if self.system == 'windows':
                return subprocess.run([
                    "sc", "start", service_name
                ], capture_output=True).returncode == 0
            elif self.system == 'linux':
                return subprocess.run([
                    "systemctl", "start", service_name
                ], capture_output=True).returncode == 0
            elif self.system == 'darwin':
                return subprocess.run([
                    "launchctl", "start", f"com.antivirus.{service_name}"
                ], capture_output=True).returncode == 0
            else:
                return False
        except Exception as e:
            logger.error(f"Service start failed: {e}")
            return False
            
    def stop_service(self, service_name: str) -> bool:
        """Stop system service."""
        try:
            if self.system == 'windows':
                return subprocess.run([
                    "sc", "stop", service_name
                ], capture_output=True).returncode == 0
            elif self.system == 'linux':
                return subprocess.run([
                    "systemctl", "stop", service_name
                ], capture_output=True).returncode == 0
            elif self.system == 'darwin':
                return subprocess.run([
                    "launchctl", "stop", f"com.antivirus.{service_name}"
                ], capture_output=True).returncode == 0
            else:
                return False
        except Exception as e:
            logger.error(f"Service stop failed: {e}")
            return False
            
    def enable_service(self, service_name: str) -> bool:
        """Enable system service (start on boot)."""
        try:
            if self.system == 'windows':
                return subprocess.run([
                    "sc", "config", service_name, "start=", "auto"
                ], capture_output=True).returncode == 0
            elif self.system == 'linux':
                return subprocess.run([
                    "systemctl", "enable", service_name
                ], capture_output=True).returncode == 0
            elif self.system == 'darwin':
                # macOS services are typically loaded at boot
                return True
            else:
                return False
        except Exception as e:
            logger.error(f"Service enable failed: {e}")
            return False


def create_process_manager() -> ProcessManager:
    """Factory function to create platform-specific process manager."""
    system = platform.system().lower()
    
    if system == 'windows':
        from .platforms.windows import WindowsProcessManager
        return WindowsProcessManager
    elif system == 'linux':
        from .platforms.linux import LinuxProcessManager
        return LinuxProcessManager
    elif system == 'darwin':
        from .platforms.macos import MacOSProcessManager
        return MacOSProcessManager
    else:
        raise NotImplementedError(f"Platform {system} not supported")