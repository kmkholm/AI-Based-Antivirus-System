"""
Configuration Management Abstraction
===================================

Provides unified configuration management across Windows, Linux, and macOS:
- Cross-platform configuration storage and retrieval
- Secure configuration encryption and validation
- Configuration versioning and rollback
- Runtime configuration updates
- Environment-specific configuration profiles

Implements Zero Trust security with encrypted configuration storage.
"""

import os
import platform
import logging
import json
import yaml
import time
import threading
from typing import Dict, Any, Optional, List, Union
from abc import ABC, abstractmethod
from dataclasses import dataclass, asdict
from pathlib import Path
from cryptography.fernet import Fernet
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
import base64

logger = logging.getLogger(__name__)


class ConfigScope(Enum):
    """Configuration scope enumeration."""
    GLOBAL = "global"
    USER = "user"
    SYSTEM = "system"
    SERVICE = "service"
    TEMPORARY = "temporary"


class ConfigFormat(Enum):
    """Configuration file format."""
    JSON = "json"
    YAML = "yaml"
    PROPERTIES = "properties"
    INI = "ini"
    XML = "xml"


@dataclass
class ConfigMetadata:
    """Configuration metadata."""
    scope: ConfigScope
    format: ConfigFormat
    version: int
    created: float
    modified: float
    checksum: str
    encrypted: bool
    tags: List[str] = None
    
    def __post_init__(self):
        if self.tags is None:
            self.tags = []


class ConfigValidator:
    """Configuration validation engine."""
    
    def __init__(self):
        self.schema_cache: Dict[str, Dict] = {}
        
    def validate_config(self, config_data: Dict[str, Any], 
                       schema_name: str) -> bool:
        """Validate configuration against schema."""
        try:
            schema = self._get_schema(schema_name)
            if not schema:
                return True  # No schema, accept as valid
                
            return self._validate_recursive(config_data, schema)
            
        except Exception as e:
            logger.error(f"Configuration validation error: {e}")
            return False
            
    def _get_schema(self, schema_name: str) -> Optional[Dict[str, Any]]:
        """Get configuration schema."""
        if schema_name not in self.schema_cache:
            self._load_schema(schema_name)
        return self.schema_cache.get(schema_name)
        
    def _load_schema(self, schema_name: str) -> None:
        """Load configuration schema."""
        # Define common schemas
        schemas = {
            "antivirus_agent": {
                "required": ["version", "components", "security"],
                "properties": {
                    "version": {"type": "string"},
                    "components": {
                        "type": "object",
                        "properties": {
                            "file_scanner": {"type": "boolean"},
                            "real_time_monitor": {"type": "boolean"},
                            "ai_detection": {"type": "boolean"},
                            "threat_intelligence": {"type": "boolean"}
                        }
                    },
                    "security": {
                        "type": "object",
                        "properties": {
                            "encryption_enabled": {"type": "boolean"},
                            "zero_trust": {"type": "boolean"},
                            "audit_logging": {"type": "boolean"}
                        }
                    }
                }
            },
            "file_system": {
                "required": ["watch_paths"],
                "properties": {
                    "watch_paths": {"type": "array", "items": {"type": "string"}},
                    "max_file_size": {"type": "integer", "minimum": 0},
                    "cache_ttl": {"type": "integer", "minimum": 0}
                }
            },
            "event_system": {
                "required": ["correlation_window", "max_queue_size"],
                "properties": {
                    "correlation_window": {"type": "number", "minimum": 0},
                    "max_queue_size": {"type": "integer", "minimum": 1},
                    "filter_severity": {"type": "string", "enum": ["low", "medium", "high", "critical"]}
                }
            }
        }
        
        self.schema_cache[schema_name] = schemas.get(schema_name, {})
        
    def _validate_recursive(self, data: Any, schema: Dict[str, Any]) -> bool:
        """Recursively validate configuration data."""
        if isinstance(schema, dict):
            if "type" in schema:
                return self._validate_type(data, schema)
            elif "properties" in schema:
                return self._validate_object(data, schema)
            elif "items" in schema:
                return self._validate_array(data, schema)
        return True
        
    def _validate_type(self, data: Any, schema: Dict[str, Any]) -> bool:
        """Validate data type."""
        expected_type = schema["type"]
        
        if expected_type == "string" and not isinstance(data, str):
            return False
        elif expected_type == "boolean" and not isinstance(data, bool):
            return False
        elif expected_type == "integer" and not isinstance(data, int):
            return False
        elif expected_type == "number" and not isinstance(data, (int, float)):
            return False
        elif expected_type == "array" and not isinstance(data, list):
            return False
        elif expected_type == "object" and not isinstance(data, dict):
            return False
            
        return True
        
    def _validate_object(self, data: Any, schema: Dict[str, Any]) -> bool:
        """Validate object properties."""
        if not isinstance(data, dict):
            return False
            
        properties = schema["properties"]
        required = schema.get("required", [])
        
        # Check required properties
        for prop in required:
            if prop not in data:
                return False
                
        # Validate each property
        for key, value in data.items():
            if key in properties:
                if not self._validate_recursive(value, properties[key]):
                    return False
                    
        return True
        
    def _validate_array(self, data: Any, schema: Dict[str, Any]) -> bool:
        """Validate array items."""
        if not isinstance(data, list):
            return False
            
        item_schema = schema["items"]
        for item in data:
            if not self._validate_recursive(item, item_schema):
                return False
                
        return True


class ConfigEncryptor:
    """Configuration encryption/decryption."""
    
    def __init__(self, key: Optional[bytes] = None):
        self.key = key or self._generate_key()
        self.cipher = Fernet(self.key)
        
    def _generate_key(self) -> bytes:
        """Generate encryption key from system entropy."""
        import hashlib
        import secrets
        
        # Generate random salt
        salt = secrets.token_bytes(16)
        
        # Derive key using PBKDF2
        kdf = PBKDF2HMAC(
            algorithm=hashes.SHA256(),
            length=32,
            salt=salt,
            iterations=100000,
        )
        
        key = base64.urlsafe_b64encode(kdf.derive(salt))
        return key
        
    def encrypt(self, data: str) -> str:
        """Encrypt configuration data."""
        try:
            encrypted_data = self.cipher.encrypt(data.encode())
            return base64.urlsafe_b64encode(encrypted_data).decode()
        except Exception as e:
            logger.error(f"Configuration encryption failed: {e}")
            return ""
            
    def decrypt(self, encrypted_data: str) -> str:
        """Decrypt configuration data."""
        try:
            decoded_data = base64.urlsafe_b64decode(encrypted_data.encode())
            decrypted_data = self.cipher.decrypt(decoded_data)
            return decrypted_data.decode()
        except Exception as e:
            logger.error(f"Configuration decryption failed: {e}")
            return ""


class ConfigurationManager(ABC):
    """Abstract base class for configuration management."""
    
    def __init__(self, config_dir: str = None):
        self.config_dir = Path(config_dir or self._get_default_config_dir())
        self.config_dir.mkdir(parents=True, exist_ok=True)
        self.config_cache: Dict[str, Dict[str, Any]] = {}
        self.config_metadata: Dict[str, ConfigMetadata] = {}
        self.validator = ConfigValidator()
        self.encryptor = ConfigEncryptor()
        self._lock = threading.RLock()
        
    def _get_default_config_dir(self) -> str:
        """Get platform-specific default configuration directory."""
        system = platform.system().lower()
        
        if system == 'windows':
            return os.path.join(os.environ.get('APPDATA', ''), 'antivirus')
        elif system == 'linux':
            return '/etc/antivirus'
        elif system == 'darwin':
            return '/Library/Application Support/antivirus'
        else:
            return './config'
            
    @abstractmethod
    def get_config(self, key: str, scope: ConfigScope = ConfigScope.USER,
                  default: Any = None) -> Any:
        """Get configuration value."""
        pass
        
    @abstractmethod
    def set_config(self, key: str, value: Any, scope: ConfigScope = ConfigScope.USER,
                  encrypt: bool = False) -> bool:
        """Set configuration value."""
        pass
        
    @abstractmethod
    def delete_config(self, key: str, scope: ConfigScope = ConfigScope.USER) -> bool:
        """Delete configuration value."""
        pass
        
    @abstractmethod
    def list_configs(self, scope: ConfigScope = ConfigScope.USER) -> List[str]:
        """List configuration keys."""
        pass
        
    def load_config_file(self, file_path: Path, scope: ConfigScope = ConfigScope.GLOBAL) -> bool:
        """Load configuration from file."""
        try:
            if not file_path.exists():
                return False
                
            # Determine format from extension
            ext = file_path.suffix.lower()
            if ext == '.json':
                format_type = ConfigFormat.JSON
            elif ext in ['.yml', '.yaml']:
                format_type = ConfigFormat.YAML
            else:
                format_type = ConfigFormat.JSON  # default
                
            # Read and parse file
            with open(file_path, 'r') as f:
                if format_type == ConfigFormat.JSON:
                    config_data = json.load(f)
                elif format_type == ConfigFormat.YAML:
                    config_data = yaml.safe_load(f)
                else:
                    return False
                    
            # Validate configuration
            config_name = file_path.stem
            if not self.validator.validate_config(config_data, config_name):
                logger.error(f"Configuration validation failed for {file_path}")
                return False
                
            # Cache configuration
            with self._lock:
                self.config_cache[config_name] = config_data
                
                # Update metadata
                file_stat = file_path.stat()
                self.config_metadata[config_name] = ConfigMetadata(
                    scope=scope,
                    format=format_type,
                    version=1,
                    created=file_stat.st_ctime,
                    modified=file_stat.st_mtime,
                    checksum=self._compute_checksum(config_data),
                    encrypted=False
                )
                
            logger.info(f"Configuration loaded: {file_path}")
            return True
            
        except Exception as e:
            logger.error(f"Configuration loading failed: {e}")
            return False
            
    def save_config_file(self, config_name: str, file_path: Path,
                        scope: ConfigScope = ConfigScope.GLOBAL,
                        encrypt: bool = False) -> bool:
        """Save configuration to file."""
        try:
            with self._lock:
                if config_name not in self.config_cache:
                    return False
                    
                config_data = self.config_cache[config_name]
                
            # Convert to string
            if file_path.suffix.lower() == '.json':
                content = json.dumps(config_data, indent=2)
            elif file_path.suffix.lower() in ['.yml', '.yaml']:
                content = yaml.dump(config_data, default_flow_style=False)
            else:
                return False
                
            # Encrypt if requested
            if encrypt:
                content = self.encryptor.encrypt(content)
                
            # Write file
            file_path.parent.mkdir(parents=True, exist_ok=True)
            with open(file_path, 'w') as f:
                f.write(content)
                
            # Update metadata
            file_stat = file_path.stat()
            with self._lock:
                self.config_metadata[config_name] = ConfigMetadata(
                    scope=scope,
                    format=ConfigFormat.JSON if file_path.suffix == '.json' else ConfigFormat.YAML,
                    version=self.config_metadata.get(config_name, ConfigMetadata(
                        scope=scope, format=ConfigFormat.JSON, version=0, 
                        created=time.time(), modified=time.time(), 
                        checksum="", encrypted=False)).version + 1,
                    created=self.config_metadata.get(config_name, ConfigMetadata(
                        scope=scope, format=ConfigFormat.JSON, version=0, 
                        created=time.time(), modified=time.time(), 
                        checksum="", encrypted=False)).created,
                    modified=file_stat.st_mtime,
                    checksum=self._compute_checksum(config_data),
                    encrypted=encrypt
                )
                
            logger.info(f"Configuration saved: {file_path}")
            return True
            
        except Exception as e:
            logger.error(f"Configuration saving failed: {e}")
            return False
            
    def _compute_checksum(self, data: Dict[str, Any]) -> str:
        """Compute configuration data checksum."""
        import hashlib
        try:
            content = json.dumps(data, sort_keys=True)
            return hashlib.sha256(content.encode()).hexdigest()
        except Exception:
            return ""
            
    def get_config_metadata(self, config_name: str) -> Optional[ConfigMetadata]:
        """Get configuration metadata."""
        with self._lock:
            return self.config_metadata.get(config_name)
            
    def list_config_metadata(self) -> Dict[str, ConfigMetadata]:
        """List all configuration metadata."""
        with self._lock:
            return self.config_metadata.copy()
            
    def backup_config(self, config_name: str, backup_dir: Path) -> Optional[Path]:
        """Create configuration backup."""
        try:
            backup_dir.mkdir(parents=True, exist_ok=True)
            
            timestamp = int(time.time())
            backup_name = f"{config_name}_backup_{timestamp}"
            
            if config_name in self.config_cache:
                backup_file = backup_dir / f"{backup_name}.json"
                return backup_file if self.save_config_file(config_name, backup_file) else None
            else:
                return None
                
        except Exception as e:
            logger.error(f"Configuration backup failed: {e}")
            return None
            
    def restore_config(self, backup_file: Path) -> bool:
        """Restore configuration from backup."""
        try:
            # Load backup configuration
            if self.load_config_file(backup_file):
                logger.info(f"Configuration restored from: {backup_file}")
                return True
            else:
                return False
                
        except Exception as e:
            logger.error(f"Configuration restore failed: {e}")
            return False
            
    def validate_all_configs(self) -> Dict[str, bool]:
        """Validate all loaded configurations."""
        results = {}
        
        with self._lock:
            for config_name, config_data in self.config_cache.items():
                try:
                    results[config_name] = self.validator.validate_config(config_data, config_name)
                except Exception as e:
                    logger.error(f"Config validation error for {config_name}: {e}")
                    results[config_name] = False
                    
        return results
        
    def get_config_statistics(self) -> Dict[str, Any]:
        """Get configuration management statistics."""
        with self._lock:
            return {
                "total_configs": len(self.config_cache),
                "encrypted_configs": sum(1 for m in self.config_metadata.values() if m.encrypted),
                "scopes": {scope.value: sum(1 for m in self.config_metadata.values() if m.scope == scope) 
                          for scope in ConfigScope},
                "config_dir": str(self.config_dir)
            }


class CrossPlatformConfigManager(ConfigurationManager):
    """Cross-platform configuration manager implementation."""
    
    def get_config(self, key: str, scope: ConfigScope = ConfigScope.USER,
                  default: Any = None) -> Any:
        """Get configuration value."""
        try:
            with self._lock:
                config_key = f"{scope.value}.{key}"
                
                # Check cache first
                if config_key in self.config_cache:
                    return self.config_cache[config_key]
                    
                # Load from platform-specific location
                file_path = self._get_config_file_path(scope)
                
                if file_path.exists():
                    config_data = self._load_config_from_file(file_path)
                    if config_data and key in config_data:
                        self.config_cache[config_key] = config_data[key]
                        return config_data[key]
                        
                return default
                
        except Exception as e:
            logger.error(f"Get config failed for {key}: {e}")
            return default
            
    def set_config(self, key: str, value: Any, scope: ConfigScope = ConfigScope.USER,
                  encrypt: bool = False) -> bool:
        """Set configuration value."""
        try:
            with self._lock:
                config_key = f"{scope.value}.{key}"
                self.config_cache[config_key] = value
                
                # Save to file
                file_path = self._get_config_file_path(scope)
                return self._save_config_to_file(file_path, encrypt)
                
        except Exception as e:
            logger.error(f"Set config failed for {key}: {e}")
            return False
            
    def delete_config(self, key: str, scope: ConfigScope = ConfigScope.USER) -> bool:
        """Delete configuration value."""
        try:
            with self._lock:
                config_key = f"{scope.value}.{key}"
                
                if config_key in self.config_cache:
                    del self.config_cache[config_key]
                    
                # Save updated configuration
                file_path = self._get_config_file_path(scope)
                return self._save_config_to_file(file_path)
                
        except Exception as e:
            logger.error(f"Delete config failed for {key}: {e}")
            return False
            
    def list_configs(self, scope: ConfigScope = ConfigScope.USER) -> List[str]:
        """List configuration keys."""
        with self._lock:
            prefix = f"{scope.value}."
            return [key[len(prefix):] for key in self.config_cache.keys() if key.startswith(prefix)]
            
    def _get_config_file_path(self, scope: ConfigScope) -> Path:
        """Get platform-specific configuration file path."""
        if scope == ConfigScope.GLOBAL:
            if platform.system().lower() == 'windows':
                return Path(os.environ.get('PROGRAMDATA', 'C:\\ProgramData')) / 'antivirus' / 'config.json'
            else:
                return Path('/etc') / 'antivirus' / 'config.json'
        elif scope == ConfigScope.SYSTEM:
            return self.config_dir / 'system.json'
        else:
            return self.config_dir / f'{scope.value}_config.json'
            
    def _load_config_from_file(self, file_path: Path) -> Optional[Dict[str, Any]]:
        """Load configuration from file."""
        try:
            if not file_path.exists():
                return {}
                
            with open(file_path, 'r') as f:
                content = f.read()
                
                # Check if file is encrypted
                metadata = self.config_metadata.get(file_path.stem)
                if metadata and metadata.encrypted:
                    content = self.encryptor.decrypt(content)
                    
                if file_path.suffix == '.json':
                    return json.loads(content)
                else:
                    return {}
                    
        except Exception as e:
            logger.error(f"Load config from file failed: {e}")
            return None
            
    def _save_config_to_file(self, file_path: Path, encrypt: bool = False) -> bool:
        """Save configuration to file."""
        try:
            # Get all configs for this scope
            scope = ConfigScope(file_path.stem.split('_')[0]) if '_' in file_path.stem else ConfigScope.USER
            
            configs = {}
            with self._lock:
                prefix = f"{scope.value}."
                for key, value in self.config_cache.items():
                    if key.startswith(prefix):
                        configs[key[len(prefix):]] = value
                        
            # Convert to JSON
            content = json.dumps(configs, indent=2)
            
            # Encrypt if requested
            if encrypt:
                content = self.encryptor.encrypt(content)
                
            # Ensure directory exists
            file_path.parent.mkdir(parents=True, exist_ok=True)
            
            # Write file
            with open(file_path, 'w') as f:
                f.write(content)
                
            return True
            
        except Exception as e:
            logger.error(f"Save config to file failed: {e}")
            return False


def create_configuration_manager() -> ConfigurationManager:
    """Factory function to create platform-specific configuration manager."""
    return CrossPlatformConfigManager()