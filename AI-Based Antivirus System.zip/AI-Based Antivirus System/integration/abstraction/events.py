"""
Event Management Abstraction Layer
==================================

Provides unified event monitoring across Windows, Linux, and macOS:
- File system events (creation, modification, deletion)
- Process events (creation, termination, behavior)
- Network events (connections, data transfer)
- Registry/System configuration events
- Real-time event correlation and filtering

Implements event-driven microservices patterns with zero-trust security.
"""

import os
import platform
import logging
import time
import threading
import json
from typing import Dict, List, Optional, Callable, Any, Set
from abc import ABC, abstractmethod
from dataclasses import dataclass, asdict
from enum import Enum
from collections import defaultdict, deque
import queue
import uuid

logger = logging.getLogger(__name__)


class EventType(Enum):
    """System event types."""
    FILE_CREATE = "file.create"
    FILE_MODIFY = "file.modify"
    FILE_DELETE = "file.delete"
    FILE_ACCESS = "file.access"
    PROCESS_CREATE = "process.create"
    PROCESS_TERMINATE = "process.terminate"
    PROCESS_INJECT = "process.inject"
    NETWORK_CONNECT = "network.connect"
    NETWORK_DATA = "network.data"
    REGISTRY_MODIFY = "registry.modify"
    SYSTEM_CONFIG = "system.config"
    SECURITY_EVENT = "security.event"


class EventSeverity(Enum):
    """Event severity levels."""
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"
    EMERGENCY = "emergency"


class EventSource(Enum):
    """Event sources."""
    FILE_SYSTEM = "filesystem"
    PROCESS_MONITOR = "process_monitor"
    NETWORK_MONITOR = "network_monitor"
    REGISTRY_MONITOR = "registry_monitor"
    USER_INPUT = "user_input"
    SYSTEM_SERVICE = "system_service"
    EXTERNAL = "external"


@dataclass
class EventData:
    """Event data structure."""
    event_id: str
    event_type: EventType
    source: EventSource
    severity: EventSeverity
    timestamp: float
    process_id: int
    process_name: str
    user_id: int
    description: str
    details: Dict[str, Any]
    correlation_id: Optional[str] = None
    parent_event_id: Optional[str] = None
    risk_score: float = 0.0
    tags: List[str] = None
    
    def __post_init__(self):
        if self.tags is None:
            self.tags = []


class EventFilter:
    """Event filtering for selective processing."""
    
    def __init__(self):
        self.allowed_types: Set[EventType] = set()
        self.allowed_sources: Set[EventSource] = set()
        self.min_severity: Optional[EventSeverity] = None
        self.allowed_users: Set[int] = set()
        self.allowed_processes: Set[str] = set()
        self.excluded_types: Set[EventType] = set()
        self.min_risk_score: float = 0.0
        
    def add_event_type(self, event_type: EventType) -> 'EventFilter':
        """Allow specific event type."""
        self.allowed_types.add(event_type)
        return self
        
    def add_source(self, source: EventSource) -> 'EventFilter':
        """Allow specific event source."""
        self.allowed_sources.add(source)
        return self
        
    def set_min_severity(self, severity: EventSeverity) -> 'EventFilter':
        """Set minimum severity."""
        self.min_severity = severity
        return self
        
    def set_min_risk_score(self, score: float) -> 'EventFilter':
        """Set minimum risk score."""
        self.min_risk_score = score
        return self
        
    def matches(self, event: EventData) -> bool:
        """Check if event matches filter criteria."""
        # Check allowed event types
        if self.allowed_types and event.event_type not in self.allowed_types:
            return False
            
        # Check allowed sources
        if self.allowed_sources and event.source not in self.allowed_sources:
            return False
            
        # Check minimum severity
        if self.min_severity:
            severity_values = {v: i for i, v in enumerate(EventSeverity)}
            if severity_values[event.severity] < severity_values[self.min_severity]:
                return False
                
        # Check minimum risk score
        if event.risk_score < self.min_risk_score:
            return False
            
        # Check allowed processes
        if self.allowed_processes and event.process_name not in self.allowed_processes:
            return False
            
        # Check excluded types
        if event.event_type in self.excluded_types:
            return False
            
        return True


class EventCorrelator:
    """Event correlation engine for detecting complex patterns."""
    
    def __init__(self, correlation_window: float = 60.0):
        self.correlation_window = correlation_window
        self.event_buffer: deque = deque()
        self.correlation_rules: List[Callable] = []
        self._lock = threading.RLock()
        
    def add_event(self, event: EventData) -> List[EventData]:
        """Add event and return correlated events."""
        with self._lock:
            current_time = time.time()
            
            # Remove old events
            while self.event_buffer and (current_time - self.event_buffer[0].timestamp) > self.correlation_window:
                self.event_buffer.popleft()
                
            # Add new event
            self.event_buffer.append(event)
            
            # Run correlation rules
            correlated_events = []
            for rule in self.correlation_rules:
                try:
                    correlated_events.extend(rule(self.event_buffer))
                except Exception as e:
                    logger.error(f"Correlation rule error: {e}")
                    
            return correlated_events
            
    def add_correlation_rule(self, rule: Callable) -> None:
        """Add correlation rule function."""
        with self._lock:
            self.correlation_rules.append(rule)
            
    @staticmethod
    def process_injection_rule(events: deque) -> List[EventData]:
        """Detect process injection patterns."""
        correlated = []
        current_time = time.time()
        
        # Look for suspicious process creation followed by memory allocation
        recent_events = [e for e in events if (current_time - e.timestamp) < 10]
        
        process_creates = [e for e in recent_events if e.event_type == EventType.PROCESS_CREATE]
        memory_allocs = [e for e in recent_events if 'memory_allocate' in e.description.lower()]
        
        for create in process_creates:
            for alloc in memory_allocs:
                if abs(create.timestamp - alloc.timestamp) < 5 and create.process_id == alloc.process_id:
                    correlation_id = str(uuid.uuid4())
                    create.correlation_id = correlation_id
                    alloc.correlation_id = correlation_id
                    correlated.extend([create, alloc])
                    
        return correlated
        
    @staticmethod
    def file_execution_chain_rule(events: deque) -> List[EventData]:
        """Detect file creation followed by execution."""
        correlated = []
        current_time = time.time()
        
        recent_events = [e for e in events if (current_time - e.timestamp) < 30]
        
        file_creates = [e for e in recent_events if e.event_type == EventType.FILE_CREATE]
        process_creates = [e for e in recent_events if e.event_type == EventType.PROCESS_CREATE]
        
        for create in file_creates:
            for proc in process_creates:
                if (abs(create.timestamp - proc.timestamp) < 10 and 
                    create.details.get('file_path') in proc.details.get('command_line', '')):
                    correlation_id = str(uuid.uuid4())
                    create.correlation_id = correlation_id
                    proc.correlation_id = correlation_id
                    correlated.extend([create, proc])
                    
        return correlated


class EventManager(ABC):
    """Abstract base class for event management."""
    
    def __init__(self, config: Dict[str, Any]):
        self.config = config
        self.event_handlers: Dict[EventType, List[Callable]] = defaultdict(list)
        self.global_handlers: List[Callable] = []
        self.event_queue: queue.Queue = queue.Queue(maxsize=10000)
        self.processing_active = False
        self.event_filter = EventFilter()
        self.correlator = EventCorrelator()
        self._lock = threading.RLock()
        
    @abstractmethod
    def start_monitoring(self) -> None:
        """Start event monitoring."""
        pass
        
    @abstractmethod
    def stop_monitoring(self) -> None:
        """Stop event monitoring."""
        pass
        
    def add_event_handler(self, event_type: EventType, 
                         handler: Callable[[EventData], None]) -> None:
        """Add event handler for specific event type."""
        with self._lock:
            self.event_handlers[event_type].append(handler)
            
    def add_global_handler(self, handler: Callable[[EventData], None]) -> None:
        """Add global event handler for all events."""
        with self._lock:
            self.global_handlers.append(handler)
            
    def remove_event_handler(self, event_type: EventType,
                           handler: Callable[[EventData], None]) -> None:
        """Remove event handler."""
        with self._lock:
            if handler in self.event_handlers[event_type]:
                self.event_handlers[event_type].remove(handler)
                
    def set_event_filter(self, event_filter: EventFilter) -> None:
        """Set event filtering criteria."""
        with self._lock:
            self.event_filter = event_filter
            
    def emit_event(self, event_type: EventType, source: EventSource,
                  severity: EventSeverity, description: str,
                  process_id: int, process_name: str, user_id: int,
                  details: Dict[str, Any] = None) -> str:
        """Emit a new event."""
        event_id = str(uuid.uuid4())
        
        event = EventData(
            event_id=event_id,
            event_type=event_type,
            source=source,
            severity=severity,
            timestamp=time.time(),
            process_id=process_id,
            process_name=process_name,
            user_id=user_id,
            description=description,
            details=details or {}
        )
        
        # Apply correlation
        correlated_events = self.correlator.add_event(event)
        
        # Process all correlated events
        events_to_process = [event] + correlated_events
        for evt in events_to_process:
            if self.event_filter.matches(evt):
                try:
                    self.event_queue.put_nowait(evt)
                except queue.Full:
                    logger.warning("Event queue full, dropping event")
                    
        return event_id
        
    def start_event_processing(self) -> None:
        """Start event processing thread."""
        if self.processing_active:
            return
            
        self.processing_active = True
        self.processing_thread = threading.Thread(target=self._process_events, daemon=True)
        self.processing_thread.start()
        
    def stop_event_processing(self) -> None:
        """Stop event processing."""
        self.processing_active = False
        if hasattr(self, 'processing_thread'):
            self.processing_thread.join(timeout=5)
            
    def _process_events(self) -> None:
        """Process events from queue."""
        logger.info("Event processing started")
        
        while self.processing_active:
            try:
                event = self.event_queue.get(timeout=1)
                self._handle_event(event)
            except queue.Empty:
                continue
            except Exception as e:
                logger.error(f"Event processing error: {e}")
                
        logger.info("Event processing stopped")
        
    def _handle_event(self, event: EventData) -> None:
        """Handle individual event."""
        try:
            # Call global handlers
            for handler in self.global_handlers:
                try:
                    handler(event)
                except Exception as e:
                    logger.error(f"Global event handler error: {e}")
                    
            # Call specific event type handlers
            for handler in self.event_handlers[event.event_type]:
                try:
                    handler(event)
                except Exception as e:
                    logger.error(f"Event handler error for {event.event_type}: {e}")
                    
            # Log event
            logger.info(f"Event: {event.event_type.value} | {event.description} | "
                       f"PID={event.process_id} | Severity={event.severity.value}")
                       
        except Exception as e:
            logger.error(f"Event handling failed: {e}")
            
    def get_event_statistics(self) -> Dict[str, Any]:
        """Get event processing statistics."""
        return {
            "queue_size": self.event_queue.qsize(),
            "processing_active": self.processing_active,
            "total_handlers": len(self.global_handlers) + sum(len(handlers) for handlers in self.event_handlers.values()),
            "correlation_rules": len(self.correlator.correlation_rules)
        }
        
    def export_events(self, start_time: float, end_time: float, 
                     output_format: str = "json") -> str:
        """Export events to file."""
        if output_format == "json":
            # This would typically read from a persistent store
            # For now, return a placeholder
            return json.dumps({
                "start_time": start_time,
                "end_time": end_time,
                "events": []
            }, indent=2)
        else:
            raise ValueError(f"Unsupported export format: {output_format}")


class EventLogger:
    """Event logging and persistence."""
    
    def __init__(self, log_directory: str = "/var/log/antivirus"):
        self.log_directory = Path(log_directory)
        self.log_directory.mkdir(parents=True, exist_ok=True)
        self.current_log_file = None
        self._lock = threading.Lock()
        
    def log_event(self, event: EventData) -> None:
        """Log event to persistent storage."""
        with self._lock:
            try:
                # Create daily log file
                current_date = time.strftime("%Y-%m-%d")
                log_file = self.log_directory / f"events_{current_date}.log"
                
                with open(log_file, 'a') as f:
                    log_entry = {
                        "timestamp": event.timestamp,
                        "event_id": event.event_id,
                        "event_type": event.event_type.value,
                        "source": event.source.value,
                        "severity": event.severity.value,
                        "process_id": event.process_id,
                        "process_name": event.process_name,
                        "user_id": event.user_id,
                        "description": event.description,
                        "details": event.details,
                        "correlation_id": event.correlation_id,
                        "risk_score": event.risk_score,
                        "tags": event.tags
                    }
                    f.write(json.dumps(log_entry) + "\n")
                    
            except Exception as e:
                logger.error(f"Event logging failed: {e}")
                
    def get_recent_events(self, hours: int = 24) -> List[Dict[str, Any]]:
        """Get recent events from log files."""
        events = []
        cutoff_time = time.time() - (hours * 3600)
        
        try:
            # Read from today's and yesterday's log files
            for day_offset in range(2):
                date = time.strftime("%Y-%m-%d", time.localtime(time.time() - day_offset * 86400))
                log_file = self.log_directory / f"events_{date}.log"
                
                if log_file.exists():
                    with open(log_file, 'r') as f:
                        for line in f:
                            try:
                                event_data = json.loads(line.strip())
                                if event_data["timestamp"] >= cutoff_time:
                                    events.append(event_data)
                            except json.JSONDecodeError:
                                continue
                                
        except Exception as e:
            logger.error(f"Error reading event logs: {e}")
            
        return sorted(events, key=lambda x: x["timestamp"], reverse=True)


def create_event_manager() -> EventManager:
    """Factory function to create platform-specific event manager."""
    system = platform.system().lower()
    
    if system == 'windows':
        from .platforms.windows import WindowsEventManager
        return WindowsEventManager
    elif system == 'linux':
        from .platforms.linux import LinuxEventManager
        return LinuxEventManager
    elif system == 'darwin':
        from .platforms.macos import MacOSEventManager
        return MacOSEventManager
    else:
        raise NotImplementedError(f"Platform {system} not supported")