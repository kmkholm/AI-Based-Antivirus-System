"""
Cross-Platform System Integration Layer
======================================

This module provides a unified abstraction layer for cross-platform system
operations, including file system, process management, and system monitoring.

Architecture:
- Platform-agnostic interfaces
- OS-specific implementations
- Event-driven design
- Zero Trust security
- Comprehensive monitoring

Based on system_architecture.md specifications.
"""

from .filesystem import (
    FileSystemAbstraction, FileInfo, FileType, FileEventData, 
    SecureFileHandler, FileCache, FileEvent
)
from .process import (
    ProcessManager, ProcessInfo, ProcessState, PrivilegeLevel, 
    SecureProcessLauncher, ServiceManager, ProcessEvent
)
from .events import (
    EventManager, EventData, EventType, EventSource, EventSeverity,
    EventFilter, EventCorrelator, EventLogger
)
from .config import (
    ConfigurationManager, ConfigScope, ConfigFormat, ConfigMetadata,
    ConfigValidator, ConfigEncryptor
)

__all__ = [
    # File system
    'FileSystemAbstraction', 'FileInfo', 'FileType', 'FileEventData', 
    'SecureFileHandler', 'FileCache', 'FileEvent',
    # Process management
    'ProcessManager', 'ProcessInfo', 'ProcessState', 'PrivilegeLevel',
    'SecureProcessLauncher', 'ServiceManager', 'ProcessEvent',
    # Event management
    'EventManager', 'EventData', 'EventType', 'EventSource', 'EventSeverity',
    'EventFilter', 'EventCorrelator', 'EventLogger',
    # Configuration
    'ConfigurationManager', 'ConfigScope', 'ConfigFormat', 'ConfigMetadata',
    'ConfigValidator', 'ConfigEncryptor'
]

__version__ = '1.0.0'