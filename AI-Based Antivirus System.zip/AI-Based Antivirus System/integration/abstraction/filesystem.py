"""
File System Abstraction Layer
============================

Provides platform-agnostic file system operations with support for:
- Cross-platform file access and manipulation
- Secure file operations with proper permissions
- Real-time file monitoring and access control
- Quarantine and isolated file handling
- Performance-optimized caching

Implements Zero Trust security principles with comprehensive audit logging.
"""

import os
import hashlib
import platform
import logging
from typing import Dict, List, Optional, Callable, Any
from pathlib import Path
from abc import ABC, abstractmethod
from dataclasses import dataclass
from enum import Enum
import threading
import time

logger = logging.getLogger(__name__)


class FileType(Enum):
    """File type classification."""
    REGULAR = "regular"
    DIRECTORY = "directory"
    EXECUTABLE = "executable"
    SCRIPT = "script"
    COMPRESSED = "compressed"
    UNKNOWN = "unknown"


class FileEvent(Enum):
    """File system events."""
    CREATED = "created"
    MODIFIED = "modified"
    DELETED = "deleted"
    ACCESSED = "accessed"
    MOVED = "moved"
    RENAME = "rename"


@dataclass
class FileInfo:
    """File information structure."""
    path: Path
    size: int
    created: float
    modified: float
    accessed: float
    type: FileType
    permissions: str
    hash_md5: Optional[str] = None
    hash_sha256: Optional[str] = None
    owner: Optional[str] = None
    group: Optional[str] = None


@dataclass
class FileEventData:
    """File system event data."""
    event_type: FileEvent
    file_path: Path
    timestamp: float
    process_id: int
    process_name: str
    user_id: int
    additional_data: Dict[str, Any]


class FileSystemAbstraction(ABC):
    """Abstract base class for file system operations."""
    
    def __init__(self, config: Dict[str, Any]):
        self.config = config
        self.cache = {}
        self.event_handlers: List[Callable[[FileEventData], None]] = []
        self.monitoring_active = False
        self._lock = threading.RLock()
        
    @abstractmethod
    def get_file_info(self, file_path: Path) -> Optional[FileInfo]:
        """Get file information."""
        pass
        
    @abstractmethod
    def read_file(self, file_path: Path, size_limit: Optional[int] = None) -> bytes:
        """Read file contents."""
        pass
        
    @abstractmethod
    def write_file(self, file_path: Path, data: bytes, 
                   secure: bool = False) -> bool:
        """Write file with optional secure mode."""
        pass
        
    @abstractmethod
    def delete_file(self, file_path: Path, secure: bool = False) -> bool:
        """Delete file with optional secure wipe."""
        pass
        
    @abstractmethod
    def list_directory(self, directory: Path) -> List[FileInfo]:
        """List directory contents."""
        pass
        
    @abstractmethod
    def watch_directory(self, directory: Path, 
                       callback: Callable[[FileEventData], None]) -> bool:
        """Start directory monitoring."""
        pass
        
    @abstractmethod
    def stop_watching(self) -> None:
        """Stop file system monitoring."""
        pass
        
    def compute_hashes(self, file_path: Path) -> Dict[str, str]:
        """Compute file hashes efficiently."""
        if not file_path.exists():
            return {}
            
        hashes = {}
        try:
            with open(file_path, 'rb') as f:
                # Compute MD5 and SHA256 in single pass
                md5_hash = hashlib.md5()
                sha256_hash = hashlib.sha256()
                
                for chunk in iter(lambda: f.read(4096), b''):
                    md5_hash.update(chunk)
                    sha256_hash.update(chunk)
                    
            hashes['md5'] = md5_hash.hexdigest()
            hashes['sha256'] = sha256_hash.hexdigest()
        except Exception as e:
            logger.error(f"Error computing hashes for {file_path}: {e}")
            
        return hashes
        
    def get_file_type(self, file_path: Path) -> FileType:
        """Determine file type based on extension and content."""
        try:
            if file_path.is_dir():
                return FileType.DIRECTORY
                
            suffix = file_path.suffix.lower()
            
            if suffix in ['.exe', '.dll', '.bin']:
                return FileType.EXECUTABLE
            elif suffix in ['.py', '.sh', '.ps1', '.bat', '.js']:
                return FileType.SCRIPT
            elif suffix in ['.zip', '.rar', '.7z', '.gz', '.tar']:
                return FileType.COMPRESSED
            else:
                return FileType.REGULAR
        except Exception:
            return FileType.UNKNOWN
            
    def safe_file_operation(self, operation: Callable, *args, **kwargs) -> Any:
        """Safe file operation with exception handling."""
        try:
            return operation(*args, **kwargs)
        except PermissionError:
            logger.warning(f"Permission denied for file operation")
            return None
        except FileNotFoundError:
            logger.warning(f"File not found: {args[0] if args else 'unknown'}")
            return None
        except Exception as e:
            logger.error(f"File operation error: {e}")
            return None
            
    def add_event_handler(self, handler: Callable[[FileEventData], None]) -> None:
        """Add file system event handler."""
        with self._lock:
            self.event_handlers.append(handler)
            
    def remove_event_handler(self, handler: Callable[[FileEventData], None]) -> None:
        """Remove file system event handler."""
        with self._lock:
            if handler in self.event_handlers:
                self.event_handlers.remove(handler)
                
    def _notify_event_handlers(self, event_data: FileEventData) -> None:
        """Notify all registered event handlers."""
        with self._lock:
            for handler in self.event_handlers:
                try:
                    handler(event_data)
                except Exception as e:
                    logger.error(f"Error in event handler: {e}")


class SecureFileHandler:
    """Secure file operations with proper handling of sensitive data."""
    
    @staticmethod
    def create_secure_temp_file(data: bytes) -> Path:
        """Create a secure temporary file with restricted permissions."""
        import tempfile
        import stat
        
        fd, path = tempfile.mkstemp(prefix='antivirus_secure_')
        os.close(fd)
        
        # Set restrictive permissions (owner read/write only)
        os.chmod(path, stat.S_IRUSR | stat.S_IWUSR)
        
        # Write data securely
        with open(path, 'wb') as f:
            f.write(data)
            
        return Path(path)
        
    @staticmethod
    def secure_delete(file_path: Path, passes: int = 3) -> bool:
        """Securely delete file with multiple overwrite passes."""
        import stat
        
        if not file_path.exists():
            return True
            
        try:
            # Get file size
            file_size = file_path.stat().st_size
            
            with open(file_path, 'r+b') as f:
                # Overwrite with random data multiple times
                for pass_num in range(passes):
                    f.seek(0)
                    f.write(os.urandom(file_size))
                    f.flush()
                    os.fsync(f.fileno())
                    
            # Finally delete the file
            file_path.unlink()
            return True
            
        except Exception as e:
            logger.error(f"Secure delete failed for {file_path}: {e}")
            return False
            
    @staticmethod
    def quarantine_file(file_path: Path, quarantine_dir: Path) -> Optional[Path]:
        """Move file to quarantine with proper isolation."""
        try:
            quarantine_dir.mkdir(parents=True, exist_ok=True)
            
            # Generate quarantine filename with timestamp
            timestamp = int(time.time())
            quarantine_filename = f"{timestamp}_{file_path.name}"
            quarantine_path = quarantine_dir / quarantine_filename
            
            # Move file to quarantine
            file_path.rename(quarantine_path)
            
            # Set restrictive permissions
            quarantine_path.chmod(0o600)
            
            logger.info(f"File quarantined: {file_path} -> {quarantine_path}")
            return quarantine_path
            
        except Exception as e:
            logger.error(f"Quarantine failed for {file_path}: {e}")
            return None


class FileCache:
    """High-performance file information caching."""
    
    def __init__(self, max_size: int = 1000, ttl: float = 300):
        self.max_size = max_size
        self.ttl = ttl
        self.cache: Dict[Path, Dict] = {}
        self.timestamps: Dict[Path, float] = {}
        self._lock = threading.RLock()
        
    def get(self, file_path: Path) -> Optional[FileInfo]:
        """Get cached file info if valid."""
        with self._lock:
            if file_path not in self.cache:
                return None
                
            # Check TTL
            if time.time() - self.timestamps[file_path] > self.ttl:
                self._remove(file_path)
                return None
                
            return FileInfo(**self.cache[file_path])
            
    def set(self, file_info: FileInfo) -> None:
        """Cache file information."""
        with self._lock:
            # Evict oldest if cache is full
            if len(self.cache) >= self.max_size:
                self._evict_oldest()
                
            self.cache[file_info.path] = {
                'path': file_info.path,
                'size': file_info.size,
                'created': file_info.created,
                'modified': file_info.modified,
                'accessed': file_info.accessed,
                'type': file_info.type,
                'permissions': file_info.permissions,
                'hash_md5': file_info.hash_md5,
                'hash_sha256': file_info.hash_sha256,
                'owner': file_info.owner,
                'group': file_info.group
            }
            self.timestamps[file_info.path] = time.time()
            
    def invalidate(self, file_path: Path) -> None:
        """Invalidate cache entry."""
        with self._lock:
            self._remove(file_path)
            
    def _remove(self, file_path: Path) -> None:
        """Remove entry from cache."""
        if file_path in self.cache:
            del self.cache[file_path]
        if file_path in self.timestamps:
            del self.timestamps[file_path]
            
    def _evict_oldest(self) -> None:
        """Remove oldest cache entry."""
        if not self.timestamps:
            return
            
        oldest = min(self.timestamps.items(), key=lambda x: x[1])
        self._remove(oldest[0])
        
    def clear(self) -> None:
        """Clear all cached data."""
        with self._lock:
            self.cache.clear()
            self.timestamps.clear()


def create_file_system_abstraction() -> FileSystemAbstraction:
    """Factory function to create platform-specific file system abstraction."""
    system = platform.system().lower()
    
    if system == 'windows':
        from .platforms.windows import WindowsFileSystem
        return WindowsFileSystem
    elif system == 'linux':
        from .platforms.linux import LinuxFileSystem
        return LinuxFileSystem
    elif system == 'darwin':
        from .platforms.macos import MacOSFileSystem
        return MacOSFileSystem
    else:
        raise NotImplementedError(f"Platform {system} not supported")