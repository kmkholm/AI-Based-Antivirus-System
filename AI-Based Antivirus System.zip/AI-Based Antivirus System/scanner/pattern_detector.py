"""
Suspicious Pattern Detector
===========================

Detects suspicious patterns and behaviors in files including:
- Shellcode patterns
- Packer signatures
- Anti-analysis techniques
- Suspicious strings and URLs
- Behavioral indicators
"""

import hashlib
import logging
import math
import re
from pathlib import Path
from typing import Dict, List, Optional, Any, Tuple

from .models import FileInfo, ThreatLevel


class SuspiciousPatternDetector:
    """
    Detects suspicious patterns and behaviors in files.
    
    Identifies various types of malicious indicators including:
    - Shellcode patterns
    - Packer signatures
    - Anti-analysis techniques
    - Suspicious network indicators
    - Behavioral patterns
    """
    
    def __init__(self):
        self.logger = logging.getLogger(__name__)
        
        # Suspicious strings patterns
        self.suspicious_strings = [
            # Network indicators
            r'https?://[^\s<>"]{2,}',
            r'ftp://[^\s<>"]{2,}',
            r'[a-zA-Z0-9.-]+\.(?:com|net|org|ru|cn|tk|ml|ga|cf|top|xyz|info)(?:/[^\s]*)?',
            r'\b(?:\d{1,3}\.){3}\d{1,3}\b',
            
            # File system operations
            r'(?:cmd\.exe|powershell\.exe|wscript\.exe|cscript\.exe)',
            r'(?:regedit\.exe|reg\.exe)',
            r'(?:tasklist\.exe|taskkill\.exe)',
            r'(?:net\s+(?:user|localgroup|share|session|view))',
            r'(?:whoami|systeminfo|ipconfig|ping|tracert)',
            
            # Registry operations
            r'HKEY_[A-Z_\\]+',
            r'(?:RegOpenKey|RegSetValue|RegCreateKey|RegDeleteKey)',
            r'(?:HKLM\\|HKCU\\|HKCR\\|HKU\\)',
            
            # Process operations
            r'(?:CreateProcess|VirtualAlloc|VirtualProtect)',
            r'(?:WriteProcessMemory|CreateRemoteThread)',
            r'(?:OpenProcess|TerminateProcess)',
            r'(?:GetCurrentProcess|GetProcessId)',
            
            # Network operations
            r'(?:WSAStartup|socket|connect|send|recv)',
            r'(?:InternetOpen|InternetConnect|HttpOpenRequest)',
            r'(?:URLDownloadToFile|WinHttp)',
            r'(?:loadlibrary|getprocaddress)',
            
            # Anti-analysis
            r'(?:IsDebuggerPresent|CheckRemoteDebuggerPresent)',
            r'(?:GetTickCount|QueryPerformanceCounter)',
            r'(?:GetSystemTime|GetLocalTime)',
            r'(?:Sleep|Delay)',
            r'(?:PebBeingDebugged|NtGlobalFlags)',
            
            # Encryption/Crypto
            r'(?:CryptAcquireContext|CryptGenKey|CryptEncrypt)',
            r'(?:MD5|SHA1|SHA256|CRC32)',
            r'(?:RC4|AES|DES|RSA)',
            r'(?:base64|Base64)',
            
            # Packers/Protectors
            r'(?:UPX|ASPack|PECompact|Themida)',
            r'(?:MPRESS|Themida|WinUpack)',
        ]
        
        # Shellcode patterns (x86/x64)
        self.shellcode_patterns = [
            # Common shellcode headers
            b'\xfc\x48\x83\xe4\xf0',  # 64-bit shellcode preamble
            b'\x89\xe5\x83\xec\x20',  # Function prologue
            b'\x50\x53\x52\x51\x56',  # Stack setup
            b'\xe8\x00\x00\x00\x00',  # Call instruction with offset
            b'\xff\x15',              # Call dword ptr
            b'\xff\x25',              # Jmp dword ptr
            
            # NOP sleds and patterns
            b'\x90' * 10,             # NOP sled
            b'\xeb\xfe',              # Infinite loop
            b'\xcc\xcc\xcc\xcc',      # INT3 padding
        ]
        
        # Packers and protectors
        self.packer_signatures = {
            'UPX': [
                b'UPX!',
                b'$Id: UPX',
                b'8SPLH',
                b'8SPLW'
            ],
            'ASPack': [
                b'ASPack',
                b'.aspack',
                b'.ASPACK'
            ],
            'PECompact': [
                b'PECompact',
                b'.pec2',
                b'.pec1'
            ],
            'Themida': [
                b'Themida',
                b'Themida/WinLicense',
                b'WinLicense'
            ],
            'MPRESS': [
                b'MPRESS',
                b'_MPRESS_'
            ],
            'FSG': [
                b'FSG',
                b'.fsg'
            ]
        }
        
        # Anti-analysis techniques
        self.anti_analysis_patterns = {
            'Debugger Check': [
                r'IsDebuggerPresent',
                r'CheckRemoteDebuggerPresent',
                r'NtGlobalFlags',
                r'BeingDebugged'
            ],
            'Timing Checks': [
                r'GetTickCount',
                r'QueryPerformanceCounter',
                r'__rdtsc',
                r'RTDSC'
            ],
            'Environment Checks': [
                r'VMware',
                r'VBox',
                r'QEMU',
                r'Wine',
                r'Sandboxie'
            ]
        }
        
        # Behavioral indicators
        self.behavioral_indicators = {
            'File System': [
                r'(?:CreateFile|WriteFile|DeleteFile)',
                r'(?:CopyFile|MoveFile|RenameFile)',
                r'(?:SetFileAttributes|GetFileAttributes)'
            ],
            'Registry': [
                r'(?:RegOpenKey|RegSetValue|RegCreateKey)',
                r'(?:RegDeleteKey|RegEnumKey|RegQueryValue)'
            ],
            'Process': [
                r'(?:CreateProcess|ShellExecute)',
                r'(?:TerminateProcess|OpenProcess)',
                r'(?:CreateThread|CreateRemoteThread)'
            ],
            'Network': [
                r'(?:socket|bind|listen|accept)',
                r'(?:connect|send|recv|closesocket)',
                r'(?:InternetOpen|HttpOpenRequest)'
            ]
        }
    
    def analyze_file(self, file_info: FileInfo) -> Dict[str, Any]:
        """
        Analyze a file for suspicious patterns.
        
        Args:
            file_info: FileInfo object containing file path and basic info
        
        Returns:
            Dictionary containing pattern analysis results
        """
        try:
            result = {
                'patterns': [],
                'suspicious_strings': [],
                'packer_detected': [],
                'anti_analysis': [],
                'behavioral_indicators': [],
                'shellcode_detected': False,
                'entropy_score': 0.0,
                'suspicion_score': 0.0,
                'risk_level': ThreatLevel.CLEAN
            }
            
            file_path = file_info.path
            
            if not file_path.exists():
                result['error'] = 'File not found'
                return result
            
            # Calculate entropy
            result['entropy_score'] = self._calculate_file_entropy(file_path)
            
            # Read file content for analysis
            with open(file_path, 'rb') as f:
                content = f.read()
            
            # Convert to string for pattern matching (with error handling)
            try:
                text_content = content.decode('utf-8', errors='ignore')
            except UnicodeDecodeError:
                text_content = ""
            
            # Detect shellcode patterns
            shellcode_result = self._detect_shellcode_patterns(content)
            result['shellcode_detected'] = shellcode_result['detected']
            if shellcode_result['detected']:
                result['patterns'].extend(shellcode_result['patterns'])
            
            # Detect packer signatures
            packer_result = self._detect_packer_signatures(content)
            result['packer_detected'] = packer_result['detected']
            if packer_result['patterns']:
                result['patterns'].extend(packer_result['patterns'])
            
            # Detect suspicious strings
            strings_result = self._detect_suspicious_strings(text_content)
            result['suspicious_strings'] = strings_result['strings']
            if strings_result['patterns']:
                result['patterns'].extend(strings_result['patterns'])
            
            # Detect anti-analysis techniques
            anti_analysis_result = self._detect_anti_analysis(text_content)
            result['anti_analysis'] = anti_analysis_result['techniques']
            if anti_analysis_result['patterns']:
                result['patterns'].extend(anti_analysis_result['patterns'])
            
            # Detect behavioral indicators
            behavior_result = self._detect_behavioral_indicators(text_content)
            result['behavioral_indicators'] = behavior_result['indicators']
            if behavior_result['patterns']:
                result['patterns'].extend(behavior_result['patterns'])
            
            # Calculate overall suspicion score
            result['suspicion_score'] = self._calculate_suspicion_score(result)
            result['risk_level'] = self._determine_risk_level(result['suspicion_score'])
            
            return result
            
        except Exception as e:
            self.logger.error(f"Error analyzing file for patterns: {e}")
            return {
                'patterns': [],
                'error': str(e),
                'suspicion_score': 0.0,
                'risk_level': ThreatLevel.CLEAN
            }
    
    def _calculate_file_entropy(self, file_path: Path) -> float:
        """Calculate Shannon entropy of file."""
        try:
            with open(file_path, 'rb') as f:
                data = f.read()
            
            if not data:
                return 0.0
            
            # Count byte frequencies
            byte_counts = [0] * 256
            for byte in data:
                byte_counts[byte] += 1
            
            data_len = len(data)
            entropy = 0.0
            
            for count in byte_counts:
                if count > 0:
                    probability = count / data_len
                    entropy -= probability * math.log2(probability)
            
            return entropy
            
        except Exception as e:
            self.logger.error(f"Error calculating entropy: {e}")
            return 0.0
    
    def _detect_shellcode_patterns(self, content: bytes) -> Dict[str, Any]:
        """Detect shellcode patterns in binary content."""
        result = {
            'detected': False,
            'patterns': []
        }
        
        for pattern in self.shellcode_patterns:
            if pattern in content:
                result['detected'] = True
                result['patterns'].append({
                    'type': 'shellcode',
                    'name': 'Shellcode Pattern',
                    'description': f'Detected shellcode pattern: {pattern.hex()}',
                    'confidence': 0.8,
                    'severity': ThreatLevel.SUSPICIOUS.value
                })
        
        return result
    
    def _detect_packer_signatures(self, content: bytes) -> Dict[str, Any]:
        """Detect known packer signatures."""
        result = {
            'detected': [],
            'patterns': []
        }
        
        for packer_name, signatures in self.packer_signatures.items():
            packer_detected = False
            for signature in signatures:
                if signature in content:
                    if not packer_detected:
                        result['detected'].append(packer_name)
                        packer_detected = True
                    
                    result['patterns'].append({
                        'type': 'packer',
                        'name': f'{packer_name} Packer',
                        'description': f'Detected {packer_name} packer signature',
                        'confidence': 0.9,
                        'severity': ThreatLevel.SUSPICIOUS.value
                    })
        
        return result
    
    def _detect_suspicious_strings(self, content: str) -> Dict[str, Any]:
        """Detect suspicious strings in text content."""
        result = {
            'strings': [],
            'patterns': []
        }
        
        for pattern_str in self.suspicious_strings:
            try:
                matches = re.findall(pattern_str, content, re.IGNORECASE)
                for match in matches:
                    result['strings'].append(match)
                    
                    # Determine severity based on pattern type
                    severity = ThreatLevel.SUSPICIOUS.value
                    confidence = 0.6
                    
                    if any(indicator in pattern_str for indicator in [
                        'powershell', 'cmd.exe', 'CreateProcess', 'VirtualAlloc'
                    ]):
                        severity = ThreatLevel.MALICIOUS.value
                        confidence = 0.8
                    
                    result['patterns'].append({
                        'type': 'suspicious_string',
                        'name': 'Suspicious String',
                        'description': f'Suspicious pattern detected: {match[:50]}...',
                        'pattern': pattern_str,
                        'match': match,
                        'confidence': confidence,
                        'severity': severity
                    })
            except re.error as e:
                self.logger.error(f"Error with regex pattern {pattern_str}: {e}")
                continue
        
        return result
    
    def _detect_anti_analysis(self, content: str) -> Dict[str, Any]:
        """Detect anti-analysis techniques."""
        result = {
            'techniques': [],
            'patterns': []
        }
        
        for technique_type, patterns in self.anti_analysis_patterns.items():
            for pattern in patterns:
                if re.search(pattern, content, re.IGNORECASE):
                    result['techniques'].append(technique_type)
                    
                    result['patterns'].append({
                        'type': 'anti_analysis',
                        'name': f'{technique_type} Anti-Analysis',
                        'description': f'Detected anti-analysis technique: {technique_type}',
                        'pattern': pattern,
                        'confidence': 0.7,
                        'severity': ThreatLevel.SUSPICIOUS.value
                    })
        
        return result
    
    def _detect_behavioral_indicators(self, content: str) -> Dict[str, Any]:
        """Detect behavioral indicators."""
        result = {
            'indicators': [],
            'patterns': []
        }
        
        for behavior_type, patterns in self.behavioral_indicators.items():
            for pattern in patterns:
                if re.search(pattern, content, re.IGNORECASE):
                    result['indicators'].append(behavior_type)
                    
                    result['patterns'].append({
                        'type': 'behavioral',
                        'name': f'{behavior_type} Behavior',
                        'description': f'Detected {behavior_type.lower()} behavior',
                        'pattern': pattern,
                        'confidence': 0.6,
                        'severity': ThreatLevel.SUSPICIOUS.value
                    })
        
        return result
    
    def _calculate_suspicion_score(self, result: Dict[str, Any]) -> float:
        """Calculate overall suspicion score based on detected patterns."""
        score = 0.0
        
        # High entropy indicates packing/compression
        if result['entropy_score'] > 7.5:
            score += 0.2
        elif result['entropy_score'] > 6.5:
            score += 0.1
        
        # Shellcode detection
        if result['shellcode_detected']:
            score += 0.4
        
        # Packer detection
        if result['packer_detected']:
            score += 0.3
        
        # Anti-analysis techniques
        if result['anti_analysis']:
            score += 0.1 * len(result['anti_analysis'])
        
        # Behavioral indicators
        if result['behavioral_indicators']:
            score += 0.1 * len(result['behavioral_indicators'])
        
        # Suspicious strings
        if result['suspicious_strings']:
            score += min(0.2, 0.05 * len(result['suspicious_strings']))
        
        # Cap score at 1.0
        return min(1.0, score)
    
    def _determine_risk_level(self, suspicion_score: float) -> ThreatLevel:
        """Determine risk level based on suspicion score."""
        if suspicion_score >= 0.8:
            return ThreatLevel.CRITICAL
        elif suspicion_score >= 0.6:
            return ThreatLevel.MALICIOUS
        elif suspicion_score >= 0.4:
            return ThreatLevel.SUSPICIOUS
        else:
            return ThreatLevel.CLEAN
    
    def analyze_network_indicators(self, file_path: Path) -> Dict[str, Any]:
        """
        Specifically analyze network-related indicators.
        
        Args:
            file_path: Path to the file to analyze
        
        Returns:
            Dictionary containing network analysis results
        """
        indicators = {
            'urls': [],
            'domains': [],
            'ip_addresses': [],
            'email_addresses': [],
            'network_patterns': []
        }
        
        try:
            with open(file_path, 'rb') as f:
                content = f.read()
            
            # Convert to string for pattern matching
            try:
                text_content = content.decode('utf-8', errors='ignore')
            except UnicodeDecodeError:
                return indicators
            
            # URL patterns
            url_pattern = r'https?://[^\s<>"]{2,}'
            urls = re.findall(url_pattern, text_content, re.IGNORECASE)
            indicators['urls'].extend(urls)
            
            # Domain patterns
            domain_pattern = r'[a-zA-Z0-9.-]+\.(?:com|net|org|ru|cn|tk|ml|ga|cf|top|xyz|info|cc|tv|me|us|uk|ca|de|fr|jp|br|in|mx|it|es|nl|se|ch|be|at|dk|no|fi|pl|cz|hu|pt|gr|ie|lt|lv|ee|is|mt|cy|lu|si|sk|hr|bg|ro|ba|mk|al|rs|me|md|ua|by|ge|am|az|kg|kz|uz|tj|tm|af|pk|lk|bd|mm|th|vn|la|kh|my|sg|id|ph|tw|kr|jp|mongolia|china|japan|korea|vietnam|laos|cambodia|thailand|singapore|indonesia|philippines|taiwan)'
            domains = re.findall(domain_pattern, text_content, re.IGNORECASE)
            indicators['domains'].extend(domains)
            
            # IP address patterns
            ip_pattern = r'\b(?:\d{1,3}\.){3}\d{1,3}\b'
            ip_addresses = re.findall(ip_pattern, text_content)
            indicators['ip_addresses'].extend(ip_addresses)
            
            # Email address patterns
            email_pattern = r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b'
            emails = re.findall(email_pattern, text_content)
            indicators['email_addresses'].extend(emails)
            
            # Look for network-related strings
            network_strings = [
                'socket', 'connect', 'send', 'recv', 'bind', 'listen',
                'http', 'https', 'ftp', 'smtp', 'pop3', 'imap', 'dns',
                'tcp', 'udp', 'port', 'proxy', 'vpn', 'tor'
            ]
            
            for net_str in network_strings:
                if net_str.lower() in text_content.lower():
                    indicators['network_patterns'].append(net_str)
            
        except Exception as e:
            self.logger.error(f"Error analyzing network indicators: {e}")
            indicators['error'] = str(e)
        
        return indicators
    
    def analyze_crypto_indicators(self, file_path: Path) -> Dict[str, Any]:
        """
        Analyze crypto-related indicators.
        
        Args:
            file_path: Path to the file to analyze
        
        Returns:
            Dictionary containing crypto analysis results
        """
        indicators = {
            'hashes': [],
            'encryption_algorithms': [],
            'crypto_patterns': []
        }
        
        try:
            with open(file_path, 'rb') as f:
                content = f.read()
            
            # Convert to string for pattern matching
            try:
                text_content = content.decode('utf-8', errors='ignore')
            except UnicodeDecodeError:
                return indicators
            
            # Hash patterns
            hash_patterns = {
                'MD5': r'\b[a-fA-F0-9]{32}\b',
                'SHA1': r'\b[a-fA-F0-9]{40}\b',
                'SHA256': r'\b[a-fA-F0-9]{64}\b',
                'SHA512': r'\b[a-fA-F0-9]{128}\b'
            }
            
            for hash_type, pattern in hash_patterns.items():
                hashes = re.findall(pattern, text_content, re.IGNORECASE)
                indicators['hashes'].extend([(hash_type, h) for h in hashes])
            
            # Encryption algorithms
            crypto_keywords = [
                'AES', 'DES', '3DES', 'RSA', 'ECC', 'DSA', 'ECDSA',
                'RC4', 'RC5', 'RC6', 'Blowfish', 'Twofish', 'Serpent',
                'ChaCha20', 'XOR', 'ROT13', 'Caesar', 'Vigenere'
            ]
            
            for keyword in crypto_keywords:
                if keyword.upper() in text_content.upper():
                    indicators['encryption_algorithms'].append(keyword)
            
            # Crypto-related function names
            crypto_functions = [
                'CryptAcquireContext', 'CryptGenKey', 'CryptEncrypt', 'CryptDecrypt',
                'CryptCreateObject', 'CryptDestroyObject', 'CryptReleaseContext',
                'MD5Init', 'MD5Update', 'MD5Final', 'SHA1Init', 'SHA1Update', 'SHA1Final',
                'SHA256Init', 'SHA256Update', 'SHA256Final'
            ]
            
            for func in crypto_functions:
                if func in text_content:
                    indicators['crypto_patterns'].append(func)
            
        except Exception as e:
            self.logger.error(f"Error analyzing crypto indicators: {e}")
            indicators['error'] = str(e)
        
        return indicators
