"""
Data Models for File Scanner Module
===================================

Defines all data structures used across the file scanner components.
"""

import hashlib
import json
from datetime import datetime
from enum import Enum
from pathlib import Path
from typing import Any, Dict, List, Optional, Union
from dataclasses import dataclass, field
from uuid import UUID, uuid4


class ThreatLevel(Enum):
    """Threat severity levels."""
    CLEAN = 0
    SUSPICIOUS = 1
    MALICIOUS = 2
    HIGH_RISK = 3
    CRITICAL = 4


class FileType(Enum):
    """Supported file types."""
    PE_EXE = "pe_exe"
    PE_DLL = "pe_dll"
    PE_SYS = "pe_sys"
    ELF_EXE = "elf_exe"
    ELF_SO = "elf_so"
    MACHO_EXE = "macho_exe"
    MACHO_DYLIB = "macho_dylib"
    ARCHIVE = "archive"
    DOCUMENT = "document"
    SCRIPT = "script"
    UNKNOWN = "unknown"


class ScanMode(Enum):
    """Scanning modes."""
    ON_DEMAND = "on_demand"
    ON_ACCESS = "on_access"
    SCHEDULED = "scheduled"
    REAL_TIME = "real_time"


class ActionType(Enum):
    """Actions to take on threats."""
    ALLOW = "allow"
    QUARANTINE = "quarantine"
    DELETE = "delete"
    BLOCK = "block"
    REPORt = "report"


@dataclass
class FileInfo:
    """File information and metadata."""
    path: Path
    size: int
    sha256: str = ""
    md5: str = ""
    sha1: str = ""
    file_type: FileType = FileType.UNKNOWN
    mime_type: str = ""
    created_time: Optional[datetime] = None
    modified_time: Optional[datetime] = None
    access_time: Optional[datetime] = None
    permissions: str = ""
    owner: str = ""
    entropy: float = 0.0
    is_executable: bool = False
    is_signed: bool = False
    digital_signature: Dict[str, Any] = field(default_factory=dict)
    pe_info: Dict[str, Any] = field(default_factory=dict)
    elf_info: Dict[str, Any] = field(default_factory=dict)
    macho_info: Dict[str, Any] = field(default_factory=dict)
    compilation_info: Dict[str, Any] = field(default_factory=dict)
    version_info: Dict[str, Any] = field(default_factory=dict)
    dependencies: List[str] = field(default_factory=list)
    import_functions: List[str] = field(default_factory=list)
    export_functions: List[str] = field(default_factory=list)
    resources: List[Dict[str, Any]] = field(default_factory=list)
    
    def __post_init__(self):
        """Compute file hashes and metadata after initialization."""
        if not self.sha256:
            self._compute_hashes()
        if not self.created_time and self.path.exists():
            stat = self.path.stat()
            self.size = stat.st_size
            self.created_time = datetime.fromtimestamp(stat.st_ctime)
            self.modified_time = datetime.fromtimestamp(stat.st_mtime)
            self.access_time = datetime.fromtimestamp(stat.st_atime)
            self.permissions = oct(stat.st_mode)[-3:]
    
    def _compute_hashes(self):
        """Compute file hashes."""
        sha256_hash = hashlib.sha256()
        md5_hash = hashlib.md5()
        sha1_hash = hashlib.sha1()
        
        try:
            with open(self.path, "rb") as f:
                for chunk in iter(lambda: f.read(4096), b""):
                    sha256_hash.update(chunk)
                    md5_hash.update(chunk)
                    sha1_hash.update(chunk)
            
            self.sha256 = sha256_hash.hexdigest()
            self.md5 = md5_hash.hexdigest()
            self.sha1 = sha1_hash.hexdigest()
        except (IOError, OSError):
            pass


@dataclass
class ThreatInfo:
    """Information about detected threats."""
    name: str
    level: ThreatLevel
    description: str = ""
    signature: str = ""
    engine: str = ""
    confidence: float = 0.0
    severity_score: float = 0.0
    family: str = ""
    variant: str = ""
    behavior_indicators: List[str] = field(default_factory=list)
    yara_matches: List[Dict[str, Any]] = field(default_factory=list)
    metadata: Dict[str, Any] = field(default_factory=dict)
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            'name': self.name,
            'level': self.level.value,
            'description': self.description,
            'signature': self.signature,
            'engine': self.engine,
            'confidence': self.confidence,
            'severity_score': self.severity_score,
            'family': self.family,
            'variant': self.variant,
            'behavior_indicators': self.behavior_indicators,
            'yara_matches': self.yara_matches,
            'metadata': self.metadata
        }


@dataclass
class ScanResult:
    """Complete scan result for a file."""
    file_info: FileInfo
    is_clean: bool
    threats: List[ThreatInfo] = field(default_factory=list)
    suspicious_patterns: List[Dict[str, Any]] = field(default_factory=list)
    scan_duration: float = 0.0
    scan_timestamp: datetime = field(default_factory=datetime.now)
    engine_versions: Dict[str, str] = field(default_factory=dict)
    error_message: str = ""
    recommended_action: ActionType = ActionType.ALLOW
    additional_info: Dict[str, Any] = field(default_factory=dict)
    scan_id: UUID = field(default_factory=uuid4)
    
    @property
    def threat_level(self) -> ThreatLevel:
        """Get the highest threat level among all threats."""
        if not self.threats:
            return ThreatLevel.CLEAN
        return max(self.threats, key=lambda t: t.level).level
    
    @property
    def max_confidence(self) -> float:
        """Get the maximum confidence score among threats."""
        if not self.threats:
            return 0.0
        return max(t.confidence for t in self.threats)
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for serialization."""
        return {
            'file_info': {
                'path': str(self.file_info.path),
                'size': self.file_info.size,
                'sha256': self.file_info.sha256,
                'md5': self.file_info.md5,
                'sha1': self.file_info.sha1,
                'file_type': self.file_info.file_type.value,
                'mime_type': self.file_info.mime_type,
                'entropy': self.file_info.entropy,
                'is_executable': self.file_info.is_executable
            },
            'is_clean': self.is_clean,
            'threats': [t.to_dict() for t in self.threats],
            'suspicious_patterns': self.suspicious_patterns,
            'scan_duration': self.scan_duration,
            'scan_timestamp': self.scan_timestamp.isoformat(),
            'engine_versions': self.engine_versions,
            'error_message': self.error_message,
            'recommended_action': self.recommended_action.value,
            'threat_level': self.threat_level.value,
            'max_confidence': self.max_confidence,
            'scan_id': str(self.scan_id)
        }


@dataclass
class QuarantineEntry:
    """Entry in the quarantine database."""
    file_id: str
    original_path: Path
    quarantine_path: Path
    quarantine_timestamp: datetime
    reason: str
    threat_info: ThreatInfo
    file_info: FileInfo
    size: int
    sha256: str
    user: str = ""
    action_taken: str = ""
    restoration_count: int = 0
    metadata: Dict[str, Any] = field(default_factory=dict)
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for storage."""
        return {
            'file_id': self.file_id,
            'original_path': str(self.original_path),
            'quarantine_path': str(self.quarantine_path),
            'quarantine_timestamp': self.quarantine_timestamp.isoformat(),
            'reason': self.reason,
            'threat_info': self.threat_info.to_dict(),
            'file_info': {
                'size': self.file_info.size,
                'sha256': self.file_info.sha256,
                'file_type': self.file_info.file_type.value
            },
            'size': self.size,
            'sha256': self.sha256,
            'user': self.user,
            'action_taken': self.action_taken,
            'restoration_count': self.restoration_count,
            'metadata': self.metadata
        }


@dataclass
class ScanTask:
    """Task for async scanning."""
    file_path: Path
    scan_mode: ScanMode
    priority: int = 0
    callback: Optional[callable] = None
    task_id: UUID = field(default_factory=uuid4)
    created_at: datetime = field(default_factory=datetime.now)
    timeout: Optional[int] = None
    
    def __lt__(self, other):
        """Compare tasks by priority."""
        return self.priority > other.priority


@dataclass
class EngineStatus:
    """Status information for scanning engines."""
    name: str
    version: str
    is_available: bool = True
    last_update: Optional[datetime] = None
    definition_version: str = ""
    signature_count: int = 0
    last_scan_time: Optional[datetime] = None
    average_scan_time: float = 0.0
    error_count: int = 0
    last_error: str = ""


@dataclass
class ScanConfiguration:
    """Configuration for file scanning."""
    max_file_size: int = 100 * 1024 * 1024  # 100MB
    enable_pe_analysis: bool = True
    enable_elf_analysis: bool = True
    enable_macho_analysis: bool = True
    enable_entropy_analysis: bool = True
    enable_yara_scanning: bool = True
    enable_clamav_scanning: bool = True
    max_scan_threads: int = 4
    scan_timeout: int = 30  # seconds
    quarantine_enabled: bool = True
    quarantine_path: Path = Path("./quarantine")
    log_level: str = "INFO"
    log_file: Optional[Path] = None
    cache_enabled: bool = True
    cache_ttl: int = 3600  # 1 hour
    suspicious_threshold: float = 0.7
    malicious_threshold: float = 0.8
    auto_quarantine: bool = False
    max_quarantine_size: int = 1024 * 1024 * 1024  # 1GB
    real_time_enabled: bool = True
    scheduled_scan_enabled: bool = True
    custom_rules: List[Dict[str, Any]] = field(default_factory=list)
    excluded_paths: List[str] = field(default_factory=list)
    excluded_extensions: List[str] = field(default_factory=list)
    included_file_types: List[str] = field(default_factory=list)
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert configuration to dictionary."""
        result = {}
        for key, value in self.__dict__.items():
            if isinstance(value, Path):
                result[key] = str(value)
            else:
                result[key] = value
        return result
