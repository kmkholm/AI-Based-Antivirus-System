"""
File Scanner Module
===================

Comprehensive file scanning engine for the antivirus system.
Supports multi-threaded scanning, PE analysis, file type detection,
suspicious pattern detection, and quarantine management.
"""

from .scanner_engine import FileScannerEngine
from .pe_analyzer import PEAnalyzer
from .file_detector import FileTypeDetector
from .pattern_detector import SuspiciousPatternDetector
from .quarantine_manager import QuarantineManager
from .scan_scheduler import ScanScheduler
from .scan_config import ScanConfiguration
from .models import ScanResult, FileInfo, ThreatInfo, QuarantineEntry

__all__ = [
    'FileScannerEngine',
    'PEAnalyzer',
    'FileTypeDetector',
    'SuspiciousPatternDetector',
    'QuarantineManager',
    'ScanScheduler',
    'ScanConfiguration',
    'ScanResult',
    'FileInfo',
    'ThreatInfo',
    'QuarantineEntry'
]
