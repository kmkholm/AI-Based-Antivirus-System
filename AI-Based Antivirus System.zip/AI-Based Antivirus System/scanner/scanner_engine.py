"""
File Scanner Engine
===================

Core file scanning engine with multi-threaded support.
Orchestrates all scanning components and provides unified interface.
"""

import asyncio
import logging
import os
import time
import threading
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timedelta
from pathlib import Path
from queue import PriorityQueue, Queue, Empty
from typing import Dict, List, Optional, Set, Callable, Any
from uuid import UUID, uuid4

from .models import (
    ScanResult, FileInfo, ThreatInfo, ThreatLevel, ActionType,
    ScanTask, ScanMode, ScanConfiguration, EngineStatus
)
from .file_detector import FileTypeDetector
from .pe_analyzer import PEAnalyzer
from .pattern_detector import SuspiciousPatternDetector
from .quarantine_manager import QuarantineManager
from .scan_scheduler import ScanScheduler


class ScanCache:
    """Simple in-memory cache for scan results."""
    
    def __init__(self, ttl: int = 3600):
        self.ttl = ttl
        self._cache: Dict[str, tuple[ScanResult, datetime]] = {}
        self._lock = threading.RLock()
    
    def get(self, file_hash: str) -> Optional[ScanResult]:
        """Get cached scan result."""
        with self._lock:
            if file_hash in self._cache:
                result, timestamp = self._cache[file_hash]
                if datetime.now() - timestamp < timedelta(seconds=self.ttl):
                    return result
                else:
                    del self._cache[file_hash]
        return None
    
    def set(self, file_hash: str, result: ScanResult):
        """Cache scan result."""
        with self._lock:
            self._cache[file_hash] = (result, datetime.now())
    
    def clear(self):
        """Clear cache."""
        with self._lock:
            self._cache.clear()
    
    def size(self) -> int:
        """Get cache size."""
        return len(self._cache)


class FileScannerEngine:
    """
    Main file scanner engine with multi-threaded support.
    
    Orchestrates file detection, PE analysis, pattern detection,
    and threat evaluation to provide comprehensive scanning capabilities.
    """
    
    def __init__(self, config: Optional[ScanConfiguration] = None):
        """Initialize the file scanner engine."""
        self.config = config or ScanConfiguration()
        self.logger = logging.getLogger(__name__)
        
        # Initialize components
        self.file_detector = FileTypeDetector()
        self.pe_analyzer = PEAnalyzer() if self.config.enable_pe_analysis else None
        self.pattern_detector = SuspiciousPatternDetector()
        self.quarantine_manager = QuarantineManager(
            self.config.quarantine_path
        ) if self.config.quarantine_enabled else None
        self.scan_scheduler = ScanScheduler(self)
        
        # Threading and async support
        self._executor = ThreadPoolExecutor(max_workers=self.config.max_scan_threads)
        self._task_queue = PriorityQueue()
        self._results_cache = ScanCache(self.config.cache_ttl)
        self._running = False
        self._worker_threads: List[threading.Thread] = []
        self._lock = threading.RLock()
        
        # Engine status
        self.engine_status: Dict[str, EngineStatus] = {}
        self._initialize_engines()
        
        # Statistics
        self.stats = {
            'files_scanned': 0,
            'threats_detected': 0,
            'cache_hits': 0,
            'quarantined_files': 0,
            'scan_time_total': 0.0,
            'last_scan': None
        }
    
    def _initialize_engines(self):
        """Initialize engine status tracking."""
        engines = ['file_detector', 'pe_analyzer', 'pattern_detector']
        for engine_name in engines:
            if hasattr(self, engine_name) and getattr(self, engine_name):
                self.engine_status[engine_name] = EngineStatus(
                    name=engine_name,
                    version="1.0.0",  # Would be set by actual engines
                    is_available=True
                )
        
        # Add ClamAV engine status if enabled
        if self.config.enable_clamav_scanning:
            self.engine_status['clamav'] = EngineStatus(
                name='clamav',
                version='1.0.0',
                is_available=False  # Would be checked by actual integration
            )
    
    def start(self):
        """Start the scanner engine and worker threads."""
        if self._running:
            return
        
        self._running = True
        
        # Start worker threads
        for i in range(self.config.max_scan_threads):
            thread = threading.Thread(
                target=self._worker_loop,
                name=f"ScannerWorker-{i}",
                daemon=True
            )
            thread.start()
            self._worker_threads.append(thread)
        
        # Start scheduler if enabled
        if self.config.scheduled_scan_enabled:
            self.scan_scheduler.start()
        
        self.logger.info(f"Scanner engine started with {self.config.max_scan_threads} workers")
    
    def stop(self):
        """Stop the scanner engine."""
        if not self._running:
            return
        
        self._running = False
        
        # Stop scheduler
        if self.config.scheduled_scan_enabled:
            self.scan_scheduler.stop()
        
        # Wait for worker threads to complete
        for thread in self._worker_threads:
            thread.join(timeout=5.0)
        
        # Shutdown executor
        self._executor.shutdown(wait=True)
        
        self.logger.info("Scanner engine stopped")
    
    def scan_file(self, file_path: Union[str, Path], 
                  scan_mode: ScanMode = ScanMode.ON_DEMAND,
                  priority: int = 0) -> ScanResult:
        """
        Scan a single file.
        
        Args:
            file_path: Path to the file to scan
            scan_mode: Scanning mode (on-demand, on-access, etc.)
            priority: Task priority (higher numbers = higher priority)
        
        Returns:
            ScanResult with detailed scan information
        """
        file_path = Path(file_path)
        start_time = time.time()
        
        self.logger.debug(f"Starting scan for: {file_path}")
        
        try:
            # Check if file exists
            if not file_path.exists():
                return self._create_error_result(
                    file_path, f"File not found: {file_path}"
                )
            
            # Check exclusions
            if self._is_excluded(file_path):
                return self._create_clean_result(file_path, "File excluded from scan")
            
            # Create file info
            file_info = FileInfo(file_path)
            
            # Check cache first
            if self.config.cache_enabled:
                cached_result = self._results_cache.get(file_info.sha256)
                if cached_result:
                    self.stats['cache_hits'] += 1
                    self.logger.debug(f"Cache hit for: {file_path}")
                    return cached_result
            
            # Check file size limit
            if file_info.size > self.config.max_file_size:
                return self._create_error_result(
                    file_path, f"File too large: {file_info.size} bytes"
                )
            
            # Perform scan
            result = self._perform_scan(file_info, scan_mode)
            
            # Cache result
            if self.config.cache_enabled and result.threat_level != ThreatLevel.CRITICAL:
                self._results_cache.set(file_info.sha256, result)
            
            # Update statistics
            self._update_stats(result, time.time() - start_time)
            
            # Auto-quarantine if needed
            if (self.config.auto_quarantine and 
                result.threat_level in [ThreatLevel.MALICIOUS, ThreatLevel.CRITICAL] and
                self.quarantine_manager):
                self.quarantine_file(file_path, result)
            
            return result
            
        except Exception as e:
            self.logger.error(f"Error scanning file {file_path}: {e}")
            return self._create_error_result(file_path, str(e))
    
    def scan_files(self, file_paths: List[Union[str, Path]], 
                   scan_mode: ScanMode = ScanMode.ON_DEMAND,
                   max_workers: Optional[int] = None) -> List[ScanResult]:
        """
        Scan multiple files concurrently.
        
        Args:
            file_paths: List of file paths to scan
            scan_mode: Scanning mode
            max_workers: Maximum number of worker threads
        
        Returns:
            List of ScanResult objects
        """
        if not file_paths:
            return []
        
        max_workers = max_workers or self.config.max_scan_threads
        results = []
        
        with ThreadPoolExecutor(max_workers=max_workers) as executor:
            # Submit all tasks
            future_to_path = {
                executor.submit(self.scan_file, path, scan_mode): path
                for path in file_paths
            }
            
            # Collect results
            for future in as_completed(future_to_path):
                try:
                    result = future.result()
                    results.append(result)
                except Exception as e:
                    path = future_to_path[future]
                    self.logger.error(f"Error in async scan for {path}: {e}")
                    results.append(self._create_error_result(Path(path), str(e)))
        
        return results
    
    def scan_directory(self, directory: Union[str, Path], 
                      recursive: bool = True,
                      file_extensions: Optional[List[str]] = None) -> List[ScanResult]:
        """
        Scan all files in a directory.
        
        Args:
            directory: Directory to scan
            recursive: Whether to scan subdirectories
            file_extensions: List of extensions to include (None for all)
        
        Returns:
            List of ScanResult objects
        """
        directory = Path(directory)
        
        if not directory.exists() or not directory.is_dir():
            return [self._create_error_result(directory, "Directory not found")]
        
        file_paths = []
        
        if recursive:
            for file_path in directory.rglob('*'):
                if file_path.is_file():
                    if self._should_scan_file(file_path, file_extensions):
                        file_paths.append(file_path)
        else:
            for file_path in directory.iterdir():
                if file_path.is_file():
                    if self._should_scan_file(file_path, file_extensions):
                        file_paths.append(file_path)
        
        self.logger.info(f"Found {len(file_paths)} files to scan in {directory}")
        
        return self.scan_files(file_paths, ScanMode.ON_DEMAND)
    
    def quarantine_file(self, file_path: Union[str, Path], 
                       scan_result: Optional[ScanResult] = None) -> bool:
        """Quarantine a suspicious or malicious file."""
        if not self.quarantine_manager:
            self.logger.warning("Quarantine manager not available")
            return False
        
        try:
            file_path = Path(file_path)
            
            # Use provided scan result or perform quick scan
            if not scan_result:
                scan_result = self.scan_file(file_path, ScanMode.ON_DEMAND)
            
            # Check if file should be quarantined
            if (scan_result.threat_level in [ThreatLevel.MALICIOUS, ThreatLevel.CRITICAL] or
                scan_result.threat_level == ThreatLevel.SUSPICIOUS):
                
                return self.quarantine_manager.quarantine_file(
                    file_path, scan_result
                )
            else:
                self.logger.info(f"File {file_path} not quarantined - threat level: {scan_result.threat_level}")
                return False
                
        except Exception as e:
            self.logger.error(f"Error quarantining file {file_path}: {e}")
            return False
    
    def restore_quarantined_file(self, file_id: str, target_path: Optional[Path] = None) -> bool:
        """Restore a quarantined file."""
        if not self.quarantine_manager:
            return False
        
        return self.quarantine_manager.restore_file(file_id, target_path)
    
    def get_quarantined_files(self) -> List[Dict[str, Any]]:
        """Get list of quarantined files."""
        if not self.quarantine_manager:
            return []
        
        return [entry.to_dict() for entry in self.quarantine_manager.get_entries()]
    
    def get_scan_statistics(self) -> Dict[str, Any]:
        """Get scanning statistics."""
        with self._lock:
            stats = self.stats.copy()
            stats['engine_status'] = {
                name: {
                    'available': status.is_available,
                    'version': status.version,
                    'last_scan': status.last_scan_time.isoformat() if status.last_scan_time else None,
                    'error_count': status.error_count
                }
                for name, status in self.engine_status.items()
            }
            stats['cache_size'] = self._results_cache.size()
            stats['quarantine_size'] = len(self.get_quarantined_files()) if self.quarantine_manager else 0
            return stats
    
    def clear_cache(self):
        """Clear the scan result cache."""
        self._results_cache.clear()
        self.logger.info("Scan cache cleared")
    
    def update_configuration(self, config: ScanConfiguration):
        """Update scanner configuration."""
        self.config = config
        self.logger.info("Scanner configuration updated")
    
    def _worker_loop(self):
        """Worker thread main loop for processing queued tasks."""
        while self._running:
            try:
                # Get next task with timeout
                try:
                    task = self._task_queue.get(timeout=1.0)
                except Empty:
                    continue
                
                # Process task
                try:
                    result = self.scan_file(task.file_path, task.scan_mode)
                    if task.callback:
                        task.callback(result)
                except Exception as e:
                    self.logger.error(f"Error processing task {task.task_id}: {e}")
                
                self._task_queue.task_done()
                
            except Exception as e:
                self.logger.error(f"Error in worker loop: {e}")
    
    def _perform_scan(self, file_info: FileInfo, scan_mode: ScanMode) -> ScanResult:
        """Perform the actual file scan."""
        start_time = time.time()
        
        # Initialize result
        result = ScanResult(
            file_info=file_info,
            is_clean=True,
            scan_timestamp=datetime.now()
        )
        
        try:
            # 1. File type detection
            if self.file_detector:
                file_type_info = self.file_detector.detect_file_type(file_info)
                result.file_info.file_type = file_type_info['file_type']
                result.file_info.mime_type = file_type_info['mime_type']
                result.file_info.is_executable = file_type_info['is_executable']
                result.engine_versions['file_detector'] = "1.0.0"
            
            # 2. PE analysis (Windows executables)
            if (self.pe_analyzer and 
                file_info.file_type.value.startswith('pe_')):
                pe_result = self.pe_analyzer.analyze_pe_file(file_info)
                result.file_info.pe_info = pe_result
                result.file_info.entropy = pe_result.get('entropy', 0.0)
                result.engine_versions['pe_analyzer'] = "1.0.0"
            
            # 3. Suspicious pattern detection
            if self.pattern_detector:
                pattern_result = self.pattern_detector.analyze_file(file_info)
                result.suspicious_patterns = pattern_result['patterns']
                
                # Create threat info from patterns
                for pattern in pattern_result['patterns']:
                    if pattern['confidence'] > 0.5:
                        threat = ThreatInfo(
                            name=pattern['name'],
                            level=ThreatLevel(pattern['severity']),
                            description=pattern['description'],
                            confidence=pattern['confidence'],
                            engine='pattern_detector'
                        )
                        result.threats.append(threat)
                
                result.engine_versions['pattern_detector'] = "1.0.0"
            
            # 4. Overall threat evaluation
            result = self._evaluate_threats(result)
            
            # 5. Set final flags
            result.is_clean = len(result.threats) == 0
            result.scan_duration = time.time() - start_time
            
            return result
            
        except Exception as e:
            self.logger.error(f"Error in scan process: {e}")
            result.error_message = str(e)
            return result
    
    def _evaluate_threats(self, result: ScanResult) -> ScanResult:
        """Evaluate and score detected threats."""
        if not result.threats:
            return result
        
        # Remove duplicates and consolidate
        unique_threats = []
        seen_threats = set()
        
        for threat in result.threats:
            threat_key = (threat.name, threat.signature)
            if threat_key not in seen_threats:
                seen_threats.add(threat_key)
                unique_threats.append(threat)
        
        result.threats = unique_threats
        
        # Determine recommended action
        max_threat_level = result.threat_level
        
        if max_threat_level == ThreatLevel.CLEAN:
            result.recommended_action = ActionType.ALLOW
        elif max_threat_level == ThreatLevel.SUSPICIOUS:
            result.recommended_action = ActionType.REPORt
        elif max_threat_level in [ThreatLevel.MALICIOUS, ThreatLevel.CRITICAL]:
            result.recommended_action = ActionType.QUARANTINE
        
        return result
    
    def _is_excluded(self, file_path: Path) -> bool:
        """Check if file should be excluded from scanning."""
        # Check path exclusions
        for excluded_path in self.config.excluded_paths:
            if str(file_path).startswith(excluded_path):
                return True
        
        # Check extension exclusions
        if file_path.suffix.lower() in self.config.excluded_extensions:
            return True
        
        # Check file type exclusions
        if self.config.included_file_types:
            return str(file_path.suffix.lower()) not in [
                ext.lower() for ext in self.config.included_file_types
            ]
        
        return False
    
    def _should_scan_file(self, file_path: Path, 
                         file_extensions: Optional[List[str]]) -> bool:
        """Check if file should be scanned."""
        if self._is_excluded(file_path):
            return False
        
        if file_extensions:
            return file_path.suffix.lower() in [
                ext.lower() for ext in file_extensions
            ]
        
        return True
    
    def _create_error_result(self, file_path: Path, error: str) -> ScanResult:
        """Create an error scan result."""
        file_info = FileInfo(file_path)
        return ScanResult(
            file_info=file_info,
            is_clean=True,  # Default to clean for errors
            error_message=error,
            scan_timestamp=datetime.now()
        )
    
    def _create_clean_result(self, file_path: Path, reason: str) -> ScanResult:
        """Create a clean scan result with reason."""
        file_info = FileInfo(file_path)
        return ScanResult(
            file_info=file_info,
            is_clean=True,
            additional_info={'clean_reason': reason},
            scan_timestamp=datetime.now()
        )
    
    def _update_stats(self, result: ScanResult, duration: float):
        """Update scanning statistics."""
        with self._lock:
            self.stats['files_scanned'] += 1
            self.stats['scan_time_total'] += duration
            self.stats['last_scan'] = datetime.now()
            
            if not result.is_clean:
                self.stats['threats_detected'] += 1
            
            if result.threat_level in [ThreatLevel.MALICIOUS, ThreatLevel.CRITICAL]:
                self.stats['quarantined_files'] += 1
