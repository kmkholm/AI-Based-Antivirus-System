"""
Quarantine Manager
==================

Manages quarantined files including storage, tracking, and restoration.
Provides secure isolation of suspicious and malicious files.
"""

import json
import logging
import os
import shutil
import uuid
from datetime import datetime, timedelta
from pathlib import Path
from typing import Dict, List, Optional, Any, Union

from .models import QuarantineEntry, ScanResult, ThreatInfo, ActionType


class QuarantineManager:
    """
    Manages quarantined files and their metadata.
    
    Provides secure storage and tracking of suspicious/malicious files
    with capabilities for restoration and management.
    """
    
    def __init__(self, quarantine_directory: Union[str, Path]):
        """
        Initialize quarantine manager.
        
        Args:
            quarantine_directory: Directory for storing quarantined files
        """
        self.quarantine_dir = Path(quarantine_directory)
        self.logger = logging.getLogger(__name__)
        self.metadata_file = self.quarantine_dir / "quarantine_metadata.json"
        self.lock_file = self.quarantine_dir / ".quarantine_lock"
        
        # Create quarantine directory if it doesn't exist
        self.quarantine_dir.mkdir(parents=True, exist_ok=True)
        
        # Load existing entries
        self.entries: Dict[str, QuarantineEntry] = {}
        self._load_metadata()
        
        # Cleanup configuration
        self.auto_cleanup_days = 30  # Auto-cleanup after 30 days
        self.max_file_size = 100 * 1024 * 1024  # 100MB max file size
        
    def quarantine_file(self, file_path: Union[str, Path], 
                       scan_result: Optional[ScanResult] = None,
                       reason: str = "Manual quarantine",
                       user: str = "") -> bool:
        """
        Quarantine a suspicious or malicious file.
        
        Args:
            file_path: Path to the file to quarantine
            scan_result: ScanResult containing threat information
            reason: Reason for quarantine
            user: User who initiated quarantine
        
        Returns:
            True if quarantine successful, False otherwise
        """
        try:
            file_path = Path(file_path)
            
            if not file_path.exists():
                self.logger.error(f"File not found for quarantine: {file_path}")
                return False
            
            # Check if file is already quarantined
            file_hash = self._calculate_file_hash(file_path)
            if file_hash in self.entries:
                self.logger.warning(f"File already quarantined: {file_path}")
                return True
            
            # Check file size
            if file_path.stat().st_size > self.max_file_size:
                self.logger.error(f"File too large for quarantine: {file_path}")
                return False
            
            # Generate quarantine ID
            quarantine_id = str(uuid.uuid4())
            
            # Create quarantined file path
            quarantine_filename = f"{quarantine_id}_{file_path.name}"
            quarantine_path = self.quarantine_dir / quarantine_filename
            
            # Create entry metadata
            threat_info = None
            if scan_result and scan_result.threats:
                # Get the highest priority threat
                threat_info = max(scan_result.threats, key=lambda t: t.level)
            else:
                # Create default threat info
                from .models import ThreatLevel
                threat_info = ThreatInfo(
                    name="Quarantined File",
                    level=ThreatLevel.SUSPICIOUS,
                    description=reason
                )
            
            # Create quarantine entry
            entry = QuarantineEntry(
                file_id=quarantine_id,
                original_path=file_path,
                quarantine_path=quarantine_path,
                quarantine_timestamp=datetime.now(),
                reason=reason,
                threat_info=threat_info,
                file_info=scan_result.file_info if scan_result else None,
                size=file_path.stat().st_size,
                sha256=file_hash,
                user=user
            )
            
            # Copy file to quarantine directory
            try:
                shutil.copy2(file_path, quarantine_path)
                # Make file read-only
                quarantine_path.chmod(0o444)
            except Exception as e:
                self.logger.error(f"Error copying file to quarantine: {e}")
                return False
            
            # Add to entries
            self.entries[quarantine_id] = entry
            
            # Save metadata
            self._save_metadata()
            
            self.logger.info(f"File quarantined: {file_path} (ID: {quarantine_id})")
            return True
            
        except Exception as e:
            self.logger.error(f"Error quarantining file {file_path}: {e}")
            return False
    
    def restore_file(self, quarantine_id: str, target_path: Optional[Path] = None) -> bool:
        """
        Restore a quarantined file to its original location or specified path.
        
        Args:
            quarantine_id: ID of the quarantined file
            target_path: Target path for restoration (defaults to original path)
        
        Returns:
            True if restoration successful, False otherwise
        """
        try:
            if quarantine_id not in self.entries:
                self.logger.error(f"Quarantined file not found: {quarantine_id}")
                return False
            
            entry = self.entries[quarantine_id]
            source_path = entry.quarantine_path
            
            if not source_path.exists():
                self.logger.error(f"Quarantined file not found on disk: {source_path}")
                return False
            
            # Determine target path
            if target_path is None:
                target_path = entry.original_path
            else:
                target_path = Path(target_path)
            
            # Ensure target directory exists
            target_path.parent.mkdir(parents=True, exist_ok=True)
            
            # Copy file from quarantine to target
            try:
                # Temporarily make file writable
                source_path.chmod(0o644)
                shutil.copy2(source_path, target_path)
                source_path.chmod(0o444)
            except Exception as e:
                self.logger.error(f"Error restoring file: {e}")
                return False
            
            # Update entry
            entry.action_taken = "restored"
            entry.restoration_count += 1
            self._save_metadata()
            
            self.logger.info(f"File restored: {entry.original_path} -> {target_path}")
            return True
            
        except Exception as e:
            self.logger.error(f"Error restoring quarantined file {quarantine_id}: {e}")
            return False
    
    def delete_file(self, quarantine_id: str) -> bool:
        """
        Permanently delete a quarantined file.
        
        Args:
            quarantine_id: ID of the quarantined file
        
        Returns:
            True if deletion successful, False otherwise
        """
        try:
            if quarantine_id not in self.entries:
                self.logger.error(f"Quarantined file not found: {quarantine_id}")
                return False
            
            entry = self.entries[quarantine_id]
            
            # Delete file from disk
            try:
                if entry.quarantine_path.exists():
                    entry.quarantine_path.unlink()
            except Exception as e:
                self.logger.error(f"Error deleting quarantined file: {e}")
                return False
            
            # Remove from entries
            del self.entries[quarantine_id]
            
            # Save metadata
            self._save_metadata()
            
            self.logger.info(f"Quarantined file deleted: {quarantine_id}")
            return True
            
        except Exception as e:
            self.logger.error(f"Error deleting quarantined file {quarantine_id}: {e}")
            return False
    
    def get_entries(self) -> List[QuarantineEntry]:
        """
        Get all quarantine entries.
        
        Returns:
            List of QuarantineEntry objects
        """
        return list(self.entries.values())
    
    def get_entry(self, quarantine_id: str) -> Optional[QuarantineEntry]:
        """
        Get a specific quarantine entry.
        
        Args:
            quarantine_id: ID of the quarantined file
        
        Returns:
            QuarantineEntry object or None if not found
        """
        return self.entries.get(quarantine_id)
    
    def search_entries(self, query: str) -> List[QuarantineEntry]:
        """
        Search quarantine entries by filename or threat name.
        
        Args:
            query: Search query string
        
        Returns:
            List of matching QuarantineEntry objects
        """
        results = []
        query_lower = query.lower()
        
        for entry in self.entries.values():
            # Search in original filename
            if query_lower in entry.original_path.name.lower():
                results.append(entry)
                continue
            
            # Search in threat name
            if query_lower in entry.threat_info.name.lower():
                results.append(entry)
                continue
            
            # Search in reason
            if query_lower in entry.reason.lower():
                results.append(entry)
                continue
        
        return results
    
    def get_statistics(self) -> Dict[str, Any]:
        """
        Get quarantine statistics.
        
        Returns:
            Dictionary containing quarantine statistics
        """
        stats = {
            'total_entries': len(self.entries),
            'total_size': 0,
            'oldest_entry': None,
            'newest_entry': None,
            'threat_levels': {},
            'threat_names': {}
        }
        
        for entry in self.entries.values():
            # Size
            stats['total_size'] += entry.size
            
            # Dates
            if stats['oldest_entry'] is None or entry.quarantine_timestamp < stats['oldest_entry']:
                stats['oldest_entry'] = entry.quarantine_timestamp
            
            if stats['newest_entry'] is None or entry.quarantine_timestamp > stats['newest_entry']:
                stats['newest_entry'] = entry.quarantine_timestamp
            
            # Threat levels
            level = entry.threat_info.level.name
            stats['threat_levels'][level] = stats['threat_levels'].get(level, 0) + 1
            
            # Threat names
            name = entry.threat_info.name
            stats['threat_names'][name] = stats['threat_names'].get(name, 0) + 1
        
        return stats
    
    def cleanup_old_entries(self, days: Optional[int] = None) -> int:
        """
        Clean up old quarantine entries.
        
        Args:
            days: Number of days to keep entries (defaults to auto_cleanup_days)
        
        Returns:
            Number of entries cleaned up
        """
        if days is None:
            days = self.auto_cleanup_days
        
        cutoff_date = datetime.now() - timedelta(days=days)
        cleaned_count = 0
        
        entries_to_remove = []
        for quarantine_id, entry in self.entries.items():
            if entry.quarantine_timestamp < cutoff_date:
                entries_to_remove.append(quarantine_id)
        
        for quarantine_id in entries_to_remove:
            if self.delete_file(quarantine_id):
                cleaned_count += 1
        
        if cleaned_count > 0:
            self.logger.info(f"Cleaned up {cleaned_count} old quarantine entries")
        
        return cleaned_count
    
    def export_entries(self, export_path: Union[str, Path]) -> bool:
        """
        Export quarantine entries to a JSON file.
        
        Args:
            export_path: Path to export file
        
        Returns:
            True if export successful, False otherwise
        """
        try:
            export_path = Path(export_path)
            
            export_data = {
                'export_timestamp': datetime.now().isoformat(),
                'entries': [entry.to_dict() for entry in self.entries.values()]
            }
            
            with open(export_path, 'w') as f:
                json.dump(export_data, f, indent=2, default=str)
            
            self.logger.info(f"Quarantine entries exported to: {export_path}")
            return True
            
        except Exception as e:
            self.logger.error(f"Error exporting quarantine entries: {e}")
            return False
    
    def import_entries(self, import_path: Union[str, Path]) -> bool:
        """
        Import quarantine entries from a JSON file.
        
        Args:
            import_path: Path to import file
        
        Returns:
            True if import successful, False otherwise
        """
        try:
            import_path = Path(import_path)
            
            with open(import_path, 'r') as f:
                import_data = json.load(f)
            
            imported_count = 0
            for entry_data in import_data.get('entries', []):
                try:
                    # Reconstruct entry (simplified - would need full implementation)
                    quarantine_id = entry_data.get('file_id')
                    if quarantine_id and quarantine_id not in self.entries:
                        # Note: This is a simplified import - actual file restoration
                        # would require additional logic
                        imported_count += 1
                except Exception as e:
                    self.logger.error(f"Error importing entry: {e}")
                    continue
            
            if imported_count > 0:
                self._save_metadata()
                self.logger.info(f"Imported {imported_count} quarantine entries")
            
            return True
            
        except Exception as e:
            self.logger.error(f"Error importing quarantine entries: {e}")
            return False
    
    def get_quarantine_directory(self) -> Path:
        """
        Get the quarantine directory path.
        
        Returns:
            Path to quarantine directory
        """
        return self.quarantine_dir
    
    def is_file_quarantined(self, file_path: Union[str, Path]) -> bool:
        """
        Check if a file is currently quarantined.
        
        Args:
            file_path: Path to the file to check
        
        Returns:
            True if file is quarantined, False otherwise
        """
        file_hash = self._calculate_file_hash(Path(file_path))
        return file_hash in self.entries
    
    def get_file_quarantine_id(self, file_path: Union[str, Path]) -> Optional[str]:
        """
        Get the quarantine ID for a file if it exists.
        
        Args:
            file_path: Path to the file to check
        
        Returns:
            Quarantine ID if file is quarantined, None otherwise
        """
        file_hash = self._calculate_file_hash(Path(file_path))
        for quarantine_id, entry in self.entries.items():
            if entry.file_info and entry.file_info.sha256 == file_hash:
                return quarantine_id
        return None
    
    def _calculate_file_hash(self, file_path: Path) -> str:
        """Calculate SHA256 hash of a file."""
        import hashlib
        
        hash_sha256 = hashlib.sha256()
        try:
            with open(file_path, "rb") as f:
                for chunk in iter(lambda: f.read(4096), b""):
                    hash_sha256.update(chunk)
            return hash_sha256.hexdigest()
        except Exception as e:
            self.logger.error(f"Error calculating hash for {file_path}: {e}")
            return ""
    
    def _load_metadata(self):
        """Load quarantine metadata from disk."""
        try:
            if self.metadata_file.exists():
                with open(self.metadata_file, 'r') as f:
                    data = json.load(f)
                
                # Reconstruct entries (simplified implementation)
                for entry_data in data.get('entries', []):
                    try:
                        quarantine_id = entry_data.get('file_id')
                        if quarantine_id:
                            # Create entry object from data
                            entry = self._reconstruct_entry(entry_data)
                            if entry:
                                self.entries[quarantine_id] = entry
                    except Exception as e:
                        self.logger.error(f"Error reconstructing entry: {e}")
                        continue
                
                self.logger.info(f"Loaded {len(self.entries)} quarantine entries")
            
        except Exception as e:
            self.logger.error(f"Error loading quarantine metadata: {e}")
    
    def _save_metadata(self):
        """Save quarantine metadata to disk."""
        try:
            # Create backup
            if self.metadata_file.exists():
                backup_file = self.metadata_file.with_suffix('.json.backup')
                shutil.copy2(self.metadata_file, backup_file)
            
            data = {
                'version': '1.0',
                'last_updated': datetime.now().isoformat(),
                'total_entries': len(self.entries),
                'entries': [entry.to_dict() for entry in self.entries.values()]
            }
            
            with open(self.metadata_file, 'w') as f:
                json.dump(data, f, indent=2, default=str)
            
        except Exception as e:
            self.logger.error(f"Error saving quarantine metadata: {e}")
    
    def _reconstruct_entry(self, entry_data: Dict[str, Any]) -> Optional[QuarantineEntry]:
        """Reconstruct a QuarantineEntry from saved data."""
        try:
            # This is a simplified reconstruction
            # In a full implementation, you would need to handle all fields properly
            
            threat_info_dict = entry_data.get('threat_info', {})
            file_info_dict = entry_data.get('file_info', {})
            
            from .models import ThreatLevel
            
            threat_info = ThreatInfo(
                name=threat_info_dict.get('name', 'Unknown'),
                level=ThreatLevel(threat_info_dict.get('level', 1)),
                description=threat_info_dict.get('description', ''),
                confidence=threat_info_dict.get('confidence', 0.0)
            )
            
            return QuarantineEntry(
                file_id=entry_data.get('file_id', ''),
                original_path=Path(entry_data.get('original_path', '')),
                quarantine_path=Path(entry_data.get('quarantine_path', '')),
                quarantine_timestamp=datetime.fromisoformat(
                    entry_data.get('quarantine_timestamp', datetime.now().isoformat())
                ),
                reason=entry_data.get('reason', ''),
                threat_info=threat_info,
                file_info=None,  # Would need proper reconstruction
                size=entry_data.get('size', 0),
                sha256=entry_data.get('sha256', ''),
                user=entry_data.get('user', ''),
                action_taken=entry_data.get('action_taken', ''),
                restoration_count=entry_data.get('restoration_count', 0)
            )
            
        except Exception as e:
            self.logger.error(f"Error reconstructing entry: {e}")
            return None
    
    def __enter__(self):
        """Context manager entry."""
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        """Context manager exit."""
        self._save_metadata()
