"""
PE (Portable Executable) Analyzer
=================================

Detailed analysis of Windows PE files including header parsing,
import/export analysis, resource extraction, and entropy calculation.
"""

import hashlib
import logging
import math
import os
import struct
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional, Any, Tuple

from .models import FileInfo


class PEAnalyzer:
    """
    PE (Windows Portable Executable) file analyzer.
    
    Analyzes PE headers, sections, imports, exports, resources,
    and calculates various metrics for threat detection.
    """
    
    def __init__(self):
        self.logger = logging.getLogger(__name__)
        
        # PE Constants
        self.PE_SIGNATURE = b'PE\x00\x00'
        self.DOS_HEADER_SIZE = 64
        self.PE_HEADER_SIZE = 24
        
        # Known suspicious imports
        self.suspicious_imports = {
            'CreateProcessA', 'CreateProcessW', 'CreateProcessInternalA',
            'CreateProcessInternalW', 'ShellExecuteA', 'ShellExecuteW',
            'WinExec', 'system', 'popen', 'exec', 'eval',
            'LoadLibraryA', 'LoadLibraryW', 'LoadLibraryExA', 'LoadLibraryExW',
            'GetProcAddress', 'VirtualAlloc', 'VirtualAllocEx', 'VirtualProtect',
            'WriteProcessMemory', 'CreateRemoteThread', 'OpenProcess',
            'SetWindowsHookExA', 'SetWindowsHookExW', 'CallNextHookEx',
            'UnhookWindowsHookEx', 'GetAsyncKeyState', 'GetKeyboardState',
            'GetForegroundWindow', 'GetWindowTextA', 'GetWindowTextW',
            'FindWindowA', 'FindWindowW', 'SendMessageA', 'SendMessageW',
            'PostMessageA', 'PostMessageW', 'RegOpenKeyA', 'RegOpenKeyW',
            'RegOpenKeyExA', 'RegOpenKeyExW', 'RegSetValueA', 'RegSetValueW',
            'RegSetValueExA', 'RegSetValueExW', 'RegCreateKeyA', 'RegCreateKeyW',
            'InternetOpenA', 'InternetOpenW', 'InternetConnectA', 'InternetConnectW',
            'HttpOpenRequestA', 'HttpOpenRequestW', 'HttpSendRequestA', 'HttpSendRequestW',
            'URLDownloadToFileA', 'URLDownloadToFileW', 'WinHttpOpen', 'WinHttpConnect',
            'WinHttpOpenRequest', 'WinHttpSendRequest', 'WinHttpReceiveResponse',
            'WSAStartup', 'socket', 'connect', 'send', 'recv', 'bind', 'listen',
            'accept', 'closesocket', 'WSASocket', 'WSASend', 'WSARecv'
        }
        
        # Known packers
        self.known_packers = {
            'UPX', 'ASPack', 'FSG', 'PECompact', 'Themida', 'WinUpack',
            'MPRESS', 'EXE Stealth', 'FSG 2.0', 'MEW', 'Morphine', 'PELock'
        }
        
        # Suspicious section names
        self.suspicious_sections = {
            '.upx', '.aspack', '.fsg', '.pecompact', '.mpress', '.aspack',
            '.packed', '.text', '.code', 'text', 'code', 'data', 'bss',
            'init', 'fini', 'pdata', 'rsrc', 'reloc', 'edata', 'idata'
        }
    
    def analyze_pe_file(self, file_info: FileInfo) -> Dict[str, Any]:
        """
        Analyze a PE file and extract comprehensive information.
        
        Args:
            file_info: FileInfo object containing file path and basic info
        
        Returns:
            Dictionary containing detailed PE analysis results
        """
        try:
            with open(file_info.path, 'rb') as f:
                pe_data = f.read()
            
            result = {
                'is_valid_pe': False,
                'dos_header': {},
                'pe_header': {},
                'optional_header': {},
                'sections': [],
                'imports': [],
                'exports': [],
                'resources': [],
                'digital_signature': {},
                'packer_info': {},
                'suspicious_indicators': [],
                'entropy': 0.0,
                'compile_info': {},
                'version_info': {}
            }
            
            # Parse DOS header
            result['dos_header'] = self._parse_dos_header(pe_data)
            
            # Get PE header offset
            pe_offset = result['dos_header'].get('e_lfanew', 0)
            if not pe_offset or pe_offset >= len(pe_data):
                return result
            
            # Verify PE signature
            if not pe_data[pe_offset:pe_offset+4] == self.PE_SIGNATURE:
                return result
            
            result['is_valid_pe'] = True
            
            # Parse PE header
            pe_header_start = pe_offset + 4
            result['pe_header'] = self._parse_pe_header(pe_data, pe_header_start)
            
            # Parse optional header
            optional_header_start = pe_header_start + 20
            if optional_header_start + 224 < len(pe_data):
                result['optional_header'] = self._parse_optional_header(
                    pe_data, optional_header_start
                )
            
            # Parse section headers
            sections_start = optional_header_start + result['pe_header'].get('SizeOfOptionalHeader', 0)
            result['sections'] = self._parse_sections(pe_data, sections_start, result['pe_header'])
            
            # Parse imports
            result['imports'] = self._parse_imports(pe_data, result['optional_header'])
            
            # Parse exports
            result['exports'] = self._parse_exports(pe_data, result['optional_header'])
            
            # Parse resources
            result['resources'] = self._parse_resources(pe_data, result['optional_header'])
            
            # Calculate entropy
            result['entropy'] = self._calculate_entropy(pe_data)
            
            # Check for packers
            result['packer_info'] = self._detect_packers(result)
            
            # Extract suspicious indicators
            result['suspicious_indicators'] = self._extract_suspicious_indicators(result)
            
            # Extract version information
            result['version_info'] = self._extract_version_info(pe_data, result['optional_header'])
            
            # Extract compilation timestamp
            result['compile_info'] = self._extract_compilation_info(result['optional_header'])
            
            return result
            
        except Exception as e:
            self.logger.error(f"Error analyzing PE file {file_info.path}: {e}")
            return {'is_valid_pe': False, 'error': str(e)}
    
    def _parse_dos_header(self, data: bytes) -> Dict[str, Any]:
        """Parse DOS header."""
        if len(data) < 64:
            return {}
        
        try:
            dos_header = struct.unpack('<58H', data[0:58])
            
            return {
                'e_magic': dos_header[0],
                'e_cblp': dos_header[1],
                'e_cp': dos_header[2],
                'e_crlc': dos_header[3],
                'e_cparhdr': dos_header[4],
                'e_minalloc': dos_header[5],
                'e_maxalloc': dos_header[6],
                'e_ss': dos_header[7],
                'e_sp': dos_header[8],
                'e_csum': dos_header[9],
                'e_ip': dos_header[10],
                'e_cs': dos_header[11],
                'e_lfarlc': dos_header[12],
                'e_ovno': dos_header[13],
                'e_res': list(dos_header[14:18]),
                'e_oemid': dos_header[18],
                'e_oeminfo': dos_header[19],
                'e_res2': list(dos_header[20:30]),
                'e_lfanew': dos_header[30]
            }
        except struct.error as e:
            self.logger.error(f"Error parsing DOS header: {e}")
            return {}
    
    def _parse_pe_header(self, data: bytes, offset: int) -> Dict[str, Any]:
        """Parse PE header."""
        if offset + 20 > len(data):
            return {}
        
        try:
            pe_header = struct.unpack('<HHHHLHH', data[offset:offset+20])
            
            return {
                'Machine': pe_header[0],
                'NumberOfSections': pe_header[1],
                'TimeDateStamp': pe_header[2],
                'PointerToSymbolTable': pe_header[3],
                'NumberOfSymbols': pe_header[4],
                'SizeOfOptionalHeader': pe_header[5],
                'Characteristics': pe_header[6]
            }
        except struct.error as e:
            self.logger.error(f"Error parsing PE header: {e}")
            return {}
    
    def _parse_optional_header(self, data: bytes, offset: int) -> Dict[str, Any]:
        """Parse optional header."""
        if offset + 224 > len(data):
            return {}
        
        try:
            # Parse standard fields
            optional = struct.unpack('<HBB', data[offset:offset+4])
            
            # Parse Windows-specific fields
            if len(data) >= offset + 240:
                win_specific = struct.unpack('<10L', data[offset+88:offset+128])
                
                return {
                    'Magic': optional[0],
                    'MajorLinkerVersion': optional[1],
                    'MinorLinkerVersion': optional[2],
                    'SizeOfCode': optional[3],
                    'SizeOfInitializedData': optional[4],
                    'SizeOfUninitializedData': optional[5],
                    'AddressOfEntryPoint': optional[6],
                    'BaseOfCode': optional[7],
                    'BaseOfData': optional[8],
                    'ImageBase': win_specific[0],
                    'SectionAlignment': win_specific[1],
                    'FileAlignment': win_specific[2],
                    'MajorOperatingSystemVersion': win_specific[3],
                    'MinorOperatingSystemVersion': win_specific[4],
                    'MajorImageVersion': win_specific[5],
                    'MinorImageVersion': win_specific[6],
                    'MajorSubsystemVersion': win_specific[7],
                    'MinorSubsystemVersion': win_specific[8],
                    'Win32VersionValue': win_specific[9]
                }
        except struct.error as e:
            self.logger.error(f"Error parsing optional header: {e}")
            return {}
    
    def _parse_sections(self, data: bytes, offset: int, pe_header: Dict[str, Any]) -> List[Dict[str, Any]]:
        """Parse section headers."""
        sections = []
        num_sections = pe_header.get('NumberOfSections', 0)
        
        if num_sections <= 0 or offset + (num_sections * 40) > len(data):
            return sections
        
        for i in range(num_sections):
            section_offset = offset + (i * 40)
            if section_offset + 40 > len(data):
                break
            
            try:
                section = struct.unpack('<8sIIIIIIIHHI', data[section_offset:section_offset+40])
                
                sections.append({
                    'Name': section[0].decode('ascii', errors='ignore').rstrip('\x00'),
                    'VirtualSize': section[1],
                    'VirtualAddress': section[2],
                    'SizeOfRawData': section[3],
                    'PointerToRawData': section[4],
                    'PointerToRelocations': section[5],
                    'PointerToLinenumbers': section[6],
                    'NumberOfRelocations': section[7],
                    'NumberOfLinenumbers': section[8],
                    'Characteristics': section[9]
                })
            except struct.error as e:
                self.logger.error(f"Error parsing section {i}: {e}")
                continue
        
        return sections
    
    def _parse_imports(self, data: bytes, optional_header: Dict[str, Any]) -> List[Dict[str, Any]]:
        """Parse import table."""
        imports = []
        import_table_rva = optional_header.get('DataDirectory', {}).get('ImportTable', {}).get('VirtualAddress', 0)
        import_table_size = optional_header.get('DataDirectory', {}).get('ImportTable', {}).get('Size', 0)
        
        if import_table_rva == 0 or import_table_size == 0:
            return imports
        
        # Convert RVA to file offset
        import_table_offset = self._rva_to_offset(data, import_table_rva, optional_header)
        if not import_table_offset:
            return imports
        
        try:
            # Parse import descriptor table
            descriptor_offset = import_table_offset
            while descriptor_offset < import_table_offset + import_table_size:
                descriptor = struct.unpack('<LLLLL', data[descriptor_offset:descriptor_offset+20])
                
                if all(x == 0 for x in descriptor):
                    break
                
                import_info = {
                    'ImportLookupTableRVA': descriptor[0],
                    'TimeDateStamp': descriptor[1],
                    'ForwarderChain': descriptor[2],
                    'NameRVA': descriptor[3],
                    'ImportAddressTableRVA': descriptor[4],
                    'ModuleName': '',
                    'Functions': []
                }
                
                # Get module name
                name_offset = self._rva_to_offset(data, descriptor[3], optional_header)
                if name_offset:
                    import_info['ModuleName'] = self._read_string(data, name_offset)
                
                # Get function names
                lookup_offset = self._rva_to_offset(data, descriptor[0], optional_header)
                if lookup_offset:
                    functions = []
                    i = 0
                    while True:
                        if lookup_offset + (i * 4) >= len(data):
                            break
                        
                        lookup_entry = struct.unpack('<L', data[lookup_offset + (i * 4):lookup_offset + (i * 4) + 4])[0]
                        if lookup_entry == 0:
                            break
                        
                        # Check if it's an ordinal import
                        if lookup_entry & 0x80000000:
                            ordinal = lookup_entry & 0x7FFFFFFF
                            functions.append({'ordinal': ordinal})
                        else:
                            # Named import
                            name_offset = self._rva_to_offset(data, lookup_entry & 0x7FFFFFFF, optional_header)
                            if name_offset:
                                name = self._read_string(data, name_offset + 2)  # Skip hint
                                functions.append({'name': name})
                        
                        i += 1
                    
                    import_info['Functions'] = functions
                
                imports.append(import_info)
                descriptor_offset += 20
            
        except Exception as e:
            self.logger.error(f"Error parsing imports: {e}")
        
        return imports
    
    def _parse_exports(self, data: bytes, optional_header: Dict[str, Any]) -> List[Dict[str, Any]]:
        """Parse export table."""
        exports = []
        export_table_rva = optional_header.get('DataDirectory', {}).get('ExportTable', {}).get('VirtualAddress', 0)
        
        if export_table_rva == 0:
            return exports
        
        try:
            # This is a simplified export parser
            # A full implementation would be more complex
            export_offset = self._rva_to_offset(data, export_table_rva, optional_header)
            if export_offset and export_offset + 40 < len(data):
                # Parse export directory
                export_info = struct.unpack('<LLLLLLLLLL', data[export_offset:export_offset+40])
                
                exports = {
                    'Characteristics': export_info[0],
                    'TimeDateStamp': export_info[1],
                    'MajorVersion': export_info[2],
                    'MinorVersion': export_info[3],
                    'NameRVA': export_info[4],
                    'Base': export_info[5],
                    'NumberOfFunctions': export_info[6],
                    'NumberOfNames': export_info[7],
                    'AddressOfFunctionsRVA': export_info[8],
                    'AddressOfNamesRVA': export_info[9],
                    'AddressOfNameOrdinalsRVA': export_info[10]
                }
        
        except Exception as e:
            self.logger.error(f"Error parsing exports: {e}")
        
        return exports
    
    def _parse_resources(self, data: bytes, optional_header: Dict[str, Any]) -> List[Dict[str, Any]]:
        """Parse resource section."""
        resources = []
        resource_rva = optional_header.get('DataDirectory', {}).get('ResourceTable', {}).get('VirtualAddress', 0)
        
        if resource_rva == 0:
            return resources
        
        try:
            # This is a simplified resource parser
            # Resource parsing is complex and would require a full parser
            resource_offset = self._rva_to_offset(data, resource_rva, optional_header)
            if resource_offset:
                resources.append({
                    'type': 'simplified',
                    'offset': resource_offset,
                    'note': 'Full resource parsing requires complete implementation'
                })
        
        except Exception as e:
            self.logger.error(f"Error parsing resources: {e}")
        
        return resources
    
    def _calculate_entropy(self, data: bytes) -> float:
        """Calculate Shannon entropy of data."""
        if not data:
            return 0.0
        
        # Count byte frequencies
        byte_counts = [0] * 256
        for byte in data:
            byte_counts[byte] += 1
        
        data_len = len(data)
        entropy = 0.0
        
        for count in byte_counts:
            if count > 0:
                probability = count / data_len
                entropy -= probability * math.log2(probability)
        
        return entropy
    
    def _detect_packers(self, pe_info: Dict[str, Any]) -> Dict[str, Any]:
        """Detect known packers."""
        packer_info = {
            'is_packed': False,
            'detected_packers': [],
            'suspicious_indicators': []
        }
        
        # Check section names for packer signatures
        for section in pe_info.get('sections', []):
            section_name = section.get('Name', '').lower()
            for packer in self.known_packers:
                if packer.lower() in section_name:
                    packer_info['detected_packers'].append(packer)
                    packer_info['is_packed'] = True
        
        # Check for high entropy (common in packed files)
        if pe_info.get('entropy', 0) > 7.5:
            packer_info['suspicious_indicators'].append('High entropy detected')
            packer_info['is_packed'] = True
        
        # Check for suspicious section patterns
        num_sections = len(pe_info.get('sections', []))
        if num_sections < 3:
            packer_info['suspicious_indicators'].append('Unusually few sections')
        
        return packer_info
    
    def _extract_suspicious_indicators(self, pe_info: Dict[str, Any]) -> List[str]:
        """Extract suspicious indicators from PE analysis."""
        indicators = []
        
        # Check for suspicious imports
        all_imports = []
        for import_info in pe_info.get('imports', []):
            for func in import_info.get('Functions', []):
                if 'name' in func:
                    all_imports.append(func['name'])
        
        for imp in all_imports:
            if imp in self.suspicious_imports:
                indicators.append(f'Suspicious import: {imp}')
        
        # Check for suspicious section names
        for section in pe_info.get('sections', []):
            section_name = section.get('Name', '').lower()
            if section_name in self.suspicious_sections:
                indicators.append(f'Suspicious section: {section_name}')
        
        # Check for packers
        if pe_info.get('packer_info', {}).get('is_packed'):
            indicators.append('File appears to be packed')
        
        # Check entropy
        if pe_info.get('entropy', 0) > 7.5:
            indicators.append('High entropy (possible packing/encryption)')
        
        # Check for very small file size with large sections
        pe_header = pe_info.get('pe_header', {})
        time_stamp = pe_header.get('TimeDateStamp', 0)
        if time_stamp == 0:
            indicators.append('Missing or zero compilation timestamp')
        
        return indicators
    
    def _extract_version_info(self, data: bytes, optional_header: Dict[str, Any]) -> Dict[str, Any]:
        """Extract version information."""
        version_info = {}
        
        # Simplified version info extraction
        # Full implementation would parse the version resource
        version_rva = optional_header.get('DataDirectory', {}).get('VersionInformation', {}).get('VirtualAddress', 0)
        
        if version_rva > 0:
            version_info['has_version_info'] = True
            # Additional parsing would be needed for actual version data
        else:
            version_info['has_version_info'] = False
        
        return version_info
    
    def _extract_compilation_info(self, optional_header: Dict[str, Any]) -> Dict[str, Any]:
        """Extract compilation timestamp and version info."""
        compile_info = {}
        
        time_stamp = optional_header.get('TimeDateStamp', 0)
        if time_stamp:
            compile_info['timestamp'] = datetime.fromtimestamp(time_stamp).isoformat()
            compile_info['timestamp_raw'] = time_stamp
        
        compile_info['linker_version'] = f"{optional_header.get('MajorLinkerVersion', 0)}.{optional_header.get('MinorLinkerVersion', 0)}"
        compile_info['os_version'] = f"{optional_header.get('MajorOperatingSystemVersion', 0)}.{optional_header.get('MinorOperatingSystemVersion', 0)}"
        compile_info['subsystem_version'] = f"{optional_header.get('MajorSubsystemVersion', 0)}.{optional_header.get('MinorSubsystemVersion', 0)}"
        
        return compile_info
    
    def _rva_to_offset(self, data: bytes, rva: int, optional_header: Dict[str, Any]) -> Optional[int]:
        """Convert RVA to file offset."""
        if rva == 0:
            return None
        
        # This is a simplified implementation
        # A full implementation would need to handle all section alignments
        section_alignment = optional_header.get('SectionAlignment', 0x1000)
        file_alignment = optional_header.get('FileAlignment', 0x200)
        
        # For simplicity, assume RVA is directly accessible
        # Real implementation would need to check each section
        return rva if rva < len(data) else None
    
    def _read_string(self, data: bytes, offset: int) -> str:
        """Read null-terminated string from data."""
        if offset >= len(data):
            return ""
        
        end = offset
        while end < len(data) and data[end] != 0:
            end += 1
        
        return data[offset:end].decode('ascii', errors='ignore')
