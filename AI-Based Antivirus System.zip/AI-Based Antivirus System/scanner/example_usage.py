#!/usr/bin/env python3
"""
Example Usage of the File Scanner Module
========================================

Demonstrates the various capabilities of the file scanner module
including basic scanning, PE analysis, quarantine management, and scheduling.
"""

import logging
import sys
import time
from pathlib import Path

# Add the current directory to Python path for imports
sys.path.insert(0, str(Path(__file__).parent))

from scanner import (
    FileScannerEngine,
    ScanConfiguration,
    PresetConfigurations,
    QuarantineManager,
    ScanScheduler,
    ScanSchedule,
    ScheduleType,
    PEAnalyzer,
    FileTypeDetector,
    SuspiciousPatternDetector,
    ThreatLevel,
    ScanMode
)


def setup_logging():
    """Setup logging for the example."""
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        handlers=[
            logging.StreamHandler(sys.stdout),
            logging.FileHandler('scanner_example.log')
        ]
    )


def create_test_files():
    """Create test files for demonstration."""
    test_dir = Path("./test_files")
    test_dir.mkdir(exist_ok=True)
    
    # Create a clean text file
    clean_file = test_dir / "clean_file.txt"
    clean_file.write_text("This is a clean text file with no malicious content.")
    
    # Create a file with suspicious content
    suspicious_file = test_dir / "suspicious_file.txt"
    suspicious_file.write_text("""
This file contains suspicious patterns:
- http://malicious.com
- CreateProcessA
- VirtualAlloc
- RegOpenKeyA
- HKLM\\Software
- Password123
- encrypted_content_with_high_entropy
""")
    
    # Create a Python script
    script_file = test_dir / "test_script.py"
    script_file.write_text("""#!/usr/bin/env python3
import os
import subprocess
import socket

# This is a test script with potentially suspicious functions
def connect_to_server(host, port):
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.connect((host, port))
    return sock

def execute_command(cmd):
    return subprocess.call(cmd, shell=True)

if __name__ == "__main__":
    connect_to_server("127.0.0.1", 8080)
    execute_command("ls -la")
""")
    
    print(f"Created test files in: {test_dir}")
    return test_dir


def basic_scanning_example():
    """Demonstrate basic file scanning."""
    print("\n=== Basic File Scanning Example ===")
    
    # Create configuration
    config = ScanConfiguration(
        max_scan_threads=2,
        enable_pe_analysis=True,
        enable_entropy_analysis=True,
        quarantine_enabled=True
    )
    
    # Initialize scanner
    scanner = FileScannerEngine(config)
    scanner.start()
    
    # Scan individual files
    test_files = [
        "test_files/clean_file.txt",
        "test_files/suspicious_file.txt",
        "test_files/test_script.py"
    ]
    
    for file_path in test_files:
        print(f"\nScanning: {file_path}")
        result = scanner.scan_file(file_path)
        
        print(f"  Clean: {result.is_clean}")
        print(f"  Threat Level: {result.threat_level}")
        print(f"  Scan Duration: {result.scan_duration:.3f}s")
        
        if not result.is_clean:
            print(f"  Threats Found:")
            for threat in result.threats:
                print(f"    - {threat.name}: {threat.description}")
                print(f"      Confidence: {threat.confidence:.2f}")
        
        if result.suspicious_patterns:
            print(f"  Suspicious Patterns:")
            for pattern in result.suspicious_patterns:
                print(f"    - {pattern.get('name', 'Unknown')}")
    
    # Get scanning statistics
    stats = scanner.get_scan_statistics()
    print(f"\n=== Scanner Statistics ===")
    print(f"Files Scanned: {stats['files_scanned']}")
    print(f"Threats Detected: {stats['threats_detected']}")
    print(f"Cache Hits: {stats['cache_hits']}")
    print(f"Quarantined Files: {stats['quarantined_files']}")
    
    scanner.stop()
    return scanner


def pe_analysis_example():
    """Demonstrate PE file analysis."""
    print("\n=== PE Analysis Example ===")
    
    analyzer = PEAnalyzer()
    
    # Create a mock PE file (simplified for demo)
    pe_file = Path("test_files/mock_pe.exe")
    pe_file.write_bytes(b"MZ" + b"X" * 1000)  # Simplified PE header
    
    from scanner.models import FileInfo
    file_info = FileInfo(pe_file)
    
    print(f"Analyzing PE file: {pe_file}")
    result = analyzer.analyze_pe_file(file_info)
    
    print(f"Valid PE: {result.get('is_valid_pe', False)}")
    print(f"Entropy: {result.get('entropy', 0.0):.2f}")
    print(f"Suspicious Indicators: {len(result.get('suspicious_indicators', []))}")
    
    if result.get('packer_info', {}).get('is_packed'):
        print(f"Packers Detected: {result['packer_info']['detected_packers']}")


def file_type_detection_example():
    """Demonstrate file type detection."""
    print("\n=== File Type Detection Example ===")
    
    detector = FileTypeDetector()
    
    test_files = [
        "test_files/clean_file.txt",
        "test_files/test_script.py",
        "test_files/suspicious_file.txt"
    ]
    
    for file_path in test_files:
        file_path = Path(file_path)
        if not file_path.exists():
            continue
        
        from scanner.models import FileInfo
        file_info = FileInfo(file_path)
        result = detector.detect_file_type(file_info)
        
        print(f"\nFile: {file_path.name}")
        print(f"  Type: {result['file_type']}")
        print(f"  MIME: {result['mime_type']}")
        print(f"  Executable: {result['is_executable']}")
        print(f"  Script: {result['is_script']}")
        print(f"  Detection Method: {result['detection_method']}")
        
        if result.get('additional_info'):
            print(f"  Additional Info: {result['additional_info']}")


def pattern_detection_example():
    """Demonstrate suspicious pattern detection."""
    print("\n=== Pattern Detection Example ===")
    
    detector = SuspiciousPatternDetector()
    
    test_files = [
        "test_files/suspicious_file.txt",
        "test_files/test_script.py"
    ]
    
    for file_path in test_files:
        file_path = Path(file_path)
        if not file_path.exists():
            continue
        
        from scanner.models import FileInfo
        file_info = FileInfo(file_path)
        result = detector.analyze_file(file_info)
        
        print(f"\nFile: {file_path.name}")
        print(f"  Suspicion Score: {result['suspicion_score']:.2f}")
        print(f"  Risk Level: {result['risk_level']}")
        print(f"  Entropy: {result['entropy_score']:.2f}")
        print(f"  Shellcode Detected: {result['shellcode_detected']}")
        
        if result['suspicious_strings']:
            print(f"  Suspicious Strings: {len(result['suspicious_strings'])}")
            for string in result['suspicious_strings'][:3]:  # Show first 3
                print(f"    - {string}")
        
        if result['anti_analysis']:
            print(f"  Anti-Analysis Techniques: {result['anti_analysis']}")
        
        if result['behavioral_indicators']:
            print(f"  Behavioral Indicators: {result['behavioral_indicators']}")


def quarantine_example(scanner):
    """Demonstrate quarantine functionality."""
    print("\n=== Quarantine Management Example ===")
    
    # Quarantine a suspicious file
    suspicious_file = "test_files/suspicious_file.txt"
    
    if Path(suspicious_file).exists():
        print(f"Quarantining: {suspicious_file}")
        
        # First scan to get result
        result = scanner.scan_file(suspicious_file)
        
        # Quarantine the file
        success = scanner.quarantine_file(suspicious_file, result)
        
        if success:
            print("File quarantined successfully")
            
            # List quarantined files
            quarantined_files = scanner.get_quarantined_files()
            print(f"\nQuarantined Files: {len(quarantined_files)}")
            
            for entry in quarantined_files:
                print(f"  - {entry['original_path']}")
                print(f"    Reason: {entry['reason']}")
                print(f"    Threat: {entry['threat_info']['name']}")
                print(f"    Timestamp: {entry['quarantine_timestamp']}")


def scheduler_example(scanner):
    """Demonstrate scan scheduling."""
    print("\n=== Scan Scheduling Example ===")
    
    scheduler = ScanScheduler(scanner)
    scheduler.start()
    
    # Create a test directory for scanning
    scan_target = Path("test_files")
    scan_target.mkdir(exist_ok=True)
    
    # Add a one-time scan
    one_time_scan = ScanSchedule(
        schedule_id="example_once",
        name="Example One-Time Scan",
        schedule_type=ScheduleType.ONCE,
        target_path=scan_target,
        parameters={
            "run_time": (time.time() + 10)  # Run in 10 seconds
        },
        description="Demo one-time scan"
    )
    
    # Add a daily scan
    daily_scan = ScanSchedule(
        schedule_id="example_daily",
        name="Example Daily Scan",
        schedule_type=ScheduleType.DAILY,
        target_path=scan_target,
        parameters={"run_time": "03:00"},  # 3 AM daily
        description="Demo daily scan"
    )
    
    # Add schedules
    scheduler.add_schedule(one_time_scan)
    scheduler.add_schedule(daily_scan)
    
    print("Added scan schedules:")
    print("  - One-time scan (in 10 seconds)")
    print("  - Daily scan (at 3 AM)")
    
    # Get scheduler statistics
    stats = scheduler.get_statistics()
    print(f"\nScheduler Statistics:")
    print(f"  Total Schedules: {stats['total_schedules']}")
    print(f"  Enabled Schedules: {stats['enabled_schedules']}")
    print(f"  Active Scans: {stats['active_scans']}")
    
    # Run one schedule immediately
    print(f"\nRunning daily scan immediately...")
    success = scheduler.run_schedule_now("example_daily")
    if success:
        print("Daily scan executed successfully")
    
    # Cleanup
    scheduler.stop()


def configuration_example():
    """Demonstrate configuration management."""
    print("\n=== Configuration Management Example ===")
    
    from scanner.scan_config import ConfigurationManager
    
    config_manager = ConfigurationManager()
    
    # Get preset configurations
    print("Available preset configurations:")
    presets = [
        ("Fast Scan", PresetConfigurations.get_fast_scan_config()),
        ("Thorough Scan", PresetConfigurations.get_thorough_scan_config()),
        ("Real-time Protection", PresetConfigurations.get_realtime_protection_config())
    ]
    
    for name, config in presets:
        print(f"\n{name}:")
        print(f"  Max File Size: {config.max_file_size / (1024*1024):.0f} MB")
        print(f"  Max Threads: {config.max_scan_threads}")
        print(f"  Scan Timeout: {config.scan_timeout}s")
        print(f"  Cache TTL: {config.cache_ttl}s")
        print(f"  Real-time: {config.real_time_enabled}")
        print(f"  Auto Quarantine: {config.auto_quarantine}")
    
    # Create custom configuration
    custom_config = PresetConfigurations.get_custom_scan_config(
        max_file_size=50 * 1024 * 1024,  # 50MB
        max_threads=2,
        timeout=15,
        quarantine=True
    )
    
    # Save custom configuration
    config_manager.save_config("example_custom", custom_config)
    print(f"\nCustom configuration saved as 'example_custom'")
    
    # List available configurations
    configs = config_manager.list_configs()
    print(f"\nAvailable configurations: {configs}")


def performance_example():
    """Demonstrate performance testing."""
    print("\n=== Performance Example ===")
    
    # Create multiple test files
    test_dir = Path("test_performance")
    test_dir.mkdir(exist_ok=True)
    
    print("Creating test files...")
    num_files = 20
    for i in range(num_files):
        test_file = test_dir / f"perf_test_{i}.txt"
        test_file.write_text(f"Performance test file {i} with some content to scan.")
    
    # Test with different configurations
    configs = [
        ("Single Thread", ScanConfiguration(max_scan_threads=1)),
        ("Multi Thread", ScanConfiguration(max_scan_threads=4)),
        ("Fast Scan", PresetConfigurations.get_fast_scan_config())
    ]
    
    for config_name, config in configs:
        print(f"\nTesting {config_name}...")
        
        scanner = FileScannerEngine(config)
        scanner.start()
        
        # Get all test files
        test_files = list(test_dir.glob("*.txt"))
        
        start_time = time.time()
        results = scanner.scan_files(test_files)
        end_time = time.time()
        
        scan_time = end_time - start_time
        files_per_second = len(test_files) / scan_time
        
        print(f"  Files scanned: {len(results)}")
        print(f"  Scan time: {scan_time:.2f}s")
        print(f"  Files per second: {files_per_second:.2f}")
        print(f"  Average time per file: {scan_time/len(test_files)*1000:.1f}ms")
        
        scanner.stop()


def main():
    """Main example function."""
    setup_logging()
    
    print("File Scanner Module - Example Usage")
    print("=" * 50)
    
    # Create test files
    test_dir = create_test_files()
    
    try:
        # Basic scanning
        scanner = basic_scanning_example()
        
        # File type detection
        file_type_detection_example()
        
        # Pattern detection
        pattern_detection_example()
        
        # Quarantine management
        quarantine_example(scanner)
        
        # PE analysis (simplified)
        pe_analysis_example()
        
        # Configuration management
        configuration_example()
        
        # Scheduling
        scheduler_example(scanner)
        
        # Performance testing
        performance_example()
        
        print("\n=== Example Complete ===")
        print("Check 'scanner_example.log' for detailed logs.")
        
    except Exception as e:
        print(f"Error in example: {e}")
        import traceback
        traceback.print_exc()
    
    finally:
        # Cleanup
        print("\nCleaning up...")
        import shutil
        if Path("test_files").exists():
            shutil.rmtree("test_files")
        if Path("test_performance").exists():
            shutil.rmtree("test_performance")
        if Path("quarantine").exists():
            shutil.rmtree("quarantine")
        print("Cleanup complete.")


if __name__ == "__main__":
    main()
