"""
File Type Detector
==================

Detects and identifies various file types including executables,
archives, documents, and scripts based on magic numbers and structure.
"""

import logging
import os
import re
from pathlib import Path
from typing import Dict, List, Optional, Tuple, Any

from .models import FileInfo, FileType


class FileTypeDetector:
    """
    File type detection based on magic numbers, headers, and structure analysis.
    
    Supports detection of:
    - Windows PE executables (exe, dll, sys)
    - Linux ELF executables
    - macOS Mach-O executables
    - Archive files (zip, rar, 7z, tar, gz, etc.)
    - Document files (pdf, docx, xlsx, etc.)
    - Script files (py, js, vbs, bat, sh, etc.)
    """
    
    def __init__(self):
        self.logger = logging.getLogger(__name__)
        
        # File signatures (magic numbers)
        self.file_signatures = {
            # PE files (Windows)
            b'MZ': FileType.PE_EXE,
            b'PE\x00\x00': FileType.PE_EXE,
            
            # ELF files (Linux)
            b'\x7fELF': FileType.ELF_EXE,
            
            # Mach-O files (macOS)
            b'\xfe\xed\xfa\xce': FileType.MACHO_EXE,
            b'\xfe\xed\xfa\xcf': FileType.MACHO_EXE,
            b'\xce\xfa\xed\xfe': FileType.MACHO_EXE,
            b'\xcf\xfa\xed\xfe': FileType.MACHO_EXE,
            
            # Archives
            b'PK\x03\x04': FileType.ARCHIVE,  # ZIP
            b'PK\x05\x06': FileType.ARCHIVE,  # ZIP (empty)
            b'PK\x07\x08': FileType.ARCHIVE,  # ZIP (spanned)
            b'Rar!\x1a\x07': FileType.ARCHIVE,  # RAR
            b'7z\xbc\xaf\x27\x1c': FileType.ARCHIVE,  # 7-Zip
            b'\x1f\x8b\x08': FileType.ARCHIVE,  # GZIP
            b'BZh': FileType.ARCHIVE,  # BZIP2
            b'ustar': FileType.ARCHIVE,  # TAR (old)
            b'ustar\x00': FileType.ARCHIVE,  # TAR (new)
            b'\x37\x7a\xbc\xaf\x27\x1c': FileType.ARCHIVE,  # 7-Zip (alternative)
            
            # Documents
            b'%PDF': FileType.DOCUMENT,  # PDF
            b'\xd0\xcf\x11\xe0\xa1\xb1\x1a\xe1': FileType.DOCUMENT,  # OLE (old Office)
            b'\x50\x4b\x03\x04': FileType.DOCUMENT,  # OOXML (docx, xlsx, etc.)
            
            # Images
            b'\x89PNG\r\n\x1a\n': FileType.DOCUMENT,  # PNG
            b'GIF8': FileType.DOCUMENT,  # GIF
            b'\xff\xd8\xff': FileType.DOCUMENT,  # JPEG
            b'BM': FileType.DOCUMENT,  # BMP
        }
        
        # Script extensions
        self.script_extensions = {
            '.py': 'python',
            '.js': 'javascript',
            '.vbs': 'vbscript',
            '.bat': 'batch',
            '.cmd': 'batch',
            '.ps1': 'powershell',
            '.sh': 'bash',
            '.bash': 'bash',
            '.zsh': 'zsh',
            '.fish': 'fish',
            '.pl': 'perl',
            '.rb': 'ruby',
            '.php': 'php',
            '.lua': 'lua',
            '.tcl': 'tcl',
            '.awk': 'awk',
            '.sed': 'sed'
        }
        
        # Executable extensions
        self.executable_extensions = {
            '.exe': FileType.PE_EXE,
            '.dll': FileType.PE_DLL,
            '.sys': FileType.PE_SYS,
            '.bin': FileType.PE_EXE,
            '.com': FileType.PE_EXE,
            '.elf': FileType.ELF_EXE,
            '.so': FileType.ELF_SO,
            '.dylib': FileType.MACHO_DYLIB,
            '.app': FileType.MACHO_EXE,
            '.mach': FileType.MACHO_EXE
        }
        
        # Archive extensions
        self.archive_extensions = {
            '.zip', '.rar', '.7z', '.tar', '.gz', '.bz2', '.xz', '.lz',
            '.zst', '.lzh', '.ace', '.arc', '.arj', '.cab', '.msi',
            '.dmg', '.iso', '.pkg', '.deb', '.rpm'
        }
        
        # Document extensions
        self.document_extensions = {
            '.pdf', '.doc', '.docx', '.xls', '.xlsx', '.ppt', '.pptx',
            '.rtf', '.txt', '.md', '.csv', '.json', '.xml', '.yaml', '.yml',
            '.html', '.htm', '.css', '.odt', '.ods', '.odp'
        }
    
    def detect_file_type(self, file_info: FileInfo) -> Dict[str, Any]:
        """
        Detect the type of a file.
        
        Args:
            file_info: FileInfo object containing file path and basic info
        
        Returns:
            Dictionary containing file type information
        """
        try:
            result = {
                'file_type': FileType.UNKNOWN,
                'mime_type': '',
                'is_executable': False,
                'is_archive': False,
                'is_document': False,
                'is_script': False,
                'is_compiled': False,
                'detection_method': '',
                'additional_info': {}
            }
            
            file_path = file_info.path
            
            # Check if file exists
            if not file_path.exists():
                result['detection_method'] = 'file_not_found'
                return result
            
            # Read file header
            header = self._read_file_header(file_path, 512)
            if not header:
                result['detection_method'] = 'read_error'
                return result
            
            # Detect by magic numbers
            magic_result = self._detect_by_magic(header)
            if magic_result:
                result.update(magic_result)
                result['detection_method'] = 'magic_numbers'
                return result
            
            # Detect by file extension
            extension_result = self._detect_by_extension(file_path)
            if extension_result:
                result.update(extension_result)
                result['detection_method'] = 'extension'
                return result
            
            # Detect by content analysis
            content_result = self._detect_by_content(file_path, header)
            if content_result:
                result.update(content_result)
                result['detection_method'] = 'content_analysis'
                return result
            
            result['detection_method'] = 'unknown'
            return result
            
        except Exception as e:
            self.logger.error(f"Error detecting file type for {file_info.path}: {e}")
            return {
                'file_type': FileType.UNKNOWN,
                'detection_method': 'error',
                'error': str(e)
            }
    
    def _read_file_header(self, file_path: Path, max_size: int = 512) -> Optional[bytes]:
        """Read file header for analysis."""
        try:
            with open(file_path, 'rb') as f:
                return f.read(max_size)
        except (IOError, OSError):
            return None
    
    def _detect_by_magic(self, header: bytes) -> Optional[Dict[str, Any]]:
        """Detect file type by magic numbers."""
        result = {}
        
        for signature, file_type in self.file_signatures.items():
            if header.startswith(signature):
                result['file_type'] = file_type
                result['is_executable'] = file_type in [
                    FileType.PE_EXE, FileType.PE_DLL, FileType.PE_SYS,
                    FileType.ELF_EXE, FileType.ELF_SO,
                    FileType.MACHO_EXE, FileType.MACHO_DYLIB
                ]
                result['is_compiled'] = file_type in [
                    FileType.PE_EXE, FileType.PE_DLL, FileType.PE_SYS,
                    FileType.ELF_EXE, FileType.ELF_SO,
                    FileType.MACHO_EXE, FileType.MACHO_DYLIB
                ]
                result['is_archive'] = file_type == FileType.ARCHIVE
                result['is_document'] = file_type == FileType.DOCUMENT
                result['mime_type'] = self._get_mime_type(file_type)
                break
        
        return result if result else None
    
    def _detect_by_extension(self, file_path: Path) -> Optional[Dict[str, Any]]:
        """Detect file type by extension."""
        extension = file_path.suffix.lower()
        result = {}
        
        # Check executable extensions
        if extension in self.executable_extensions:
            result['file_type'] = self.executable_extensions[extension]
            result['is_executable'] = True
            result['is_compiled'] = True
            result['mime_type'] = self._get_mime_type(result['file_type'])
            return result
        
        # Check archive extensions
        if extension in self.archive_extensions:
            result['file_type'] = FileType.ARCHIVE
            result['is_archive'] = True
            result['mime_type'] = 'application/zip'  # Default for archives
            return result
        
        # Check document extensions
        if extension in self.document_extensions:
            result['file_type'] = FileType.DOCUMENT
            result['is_document'] = True
            result['mime_type'] = self._get_mime_type_by_extension(extension)
            return result
        
        # Check script extensions
        if extension in self.script_extensions:
            result['file_type'] = FileType.SCRIPT
            result['is_script'] = True
            result['mime_type'] = 'text/plain'
            result['additional_info'] = {'script_type': self.script_extensions[extension]}
            return result
        
        return None
    
    def _detect_by_content(self, file_path: Path, header: bytes) -> Optional[Dict[str, Any]]:
        """Detect file type by content analysis."""
        result = {}
        
        # Check for shebang lines in scripts
        try:
            with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                first_line = f.readline().strip()
                
                if first_line.startswith('#!'):
                    # Extract interpreter from shebang
                    if 'python' in first_line:
                        result['file_type'] = FileType.SCRIPT
                        result['is_script'] = True
                        result['additional_info'] = {'script_type': 'python', 'shebang': first_line}
                    elif 'bash' in first_line or 'sh' in first_line:
                        result['file_type'] = FileType.SCRIPT
                        result['is_script'] = True
                        result['additional_info'] = {'script_type': 'bash', 'shebang': first_line}
                    elif 'node' in first_line:
                        result['file_type'] = FileType.SCRIPT
                        result['is_script'] = True
                        result['additional_info'] = {'script_type': 'nodejs', 'shebang': first_line}
                    else:
                        result['file_type'] = FileType.SCRIPT
                        result['is_script'] = True
                        result['additional_info'] = {'script_type': 'unknown', 'shebang': first_line}
                    
                    result['mime_type'] = 'text/plain'
                    return result
        except (IOError, UnicodeDecodeError):
            pass
        
        # Check for text content
        try:
            with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                # Read a small portion to check for text content
                content = f.read(1024)
                
                # Check if it's primarily text
                text_ratio = self._calculate_text_ratio(content)
                if text_ratio > 0.8:
                    result['file_type'] = FileType.SCRIPT if result.get('is_script') else FileType.DOCUMENT
                    result['is_document'] = not result.get('is_script', False)
                    result['mime_type'] = 'text/plain'
                    return result
        except (IOError, UnicodeDecodeError):
            pass
        
        return None
    
    def _calculate_text_ratio(self, content: str) -> float:
        """Calculate the ratio of printable characters in text."""
        if not content:
            return 0.0
        
        printable = sum(1 for c in content if c.isprintable() or c.isspace())
        return printable / len(content)
    
    def _get_mime_type(self, file_type: FileType) -> str:
        """Get MIME type for file type."""
        mime_types = {
            FileType.PE_EXE: 'application/x-msdownload',
            FileType.PE_DLL: 'application/x-msdownload',
            FileType.PE_SYS: 'application/x-msdownload',
            FileType.ELF_EXE: 'application/x-elf',
            FileType.ELF_SO: 'application/x-elf',
            FileType.MACHO_EXE: 'application/x-mach-binary',
            FileType.MACHO_DYLIB: 'application/x-mach-binary',
            FileType.ARCHIVE: 'application/zip',
            FileType.DOCUMENT: 'application/octet-stream',
            FileType.SCRIPT: 'text/plain',
            FileType.UNKNOWN: 'application/octet-stream'
        }
        
        return mime_types.get(file_type, 'application/octet-stream')
    
    def _get_mime_type_by_extension(self, extension: str) -> str:
        """Get MIME type by file extension."""
        mime_map = {
            '.pdf': 'application/pdf',
            '.doc': 'application/msword',
            '.docx': 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
            '.xls': 'application/vnd.ms-excel',
            '.xlsx': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
            '.ppt': 'application/vnd.ms-powerpoint',
            '.pptx': 'application/vnd.openxmlformats-officedocument.presentationml.presentation',
            '.txt': 'text/plain',
            '.md': 'text/markdown',
            '.json': 'application/json',
            '.xml': 'application/xml',
            '.html': 'text/html',
            '.htm': 'text/html',
            '.css': 'text/css',
            '.csv': 'text/csv',
            '.rtf': 'application/rtf',
            '.odt': 'application/vnd.oasis.opendocument.text',
            '.ods': 'application/vnd.oasis.opendocument.spreadsheet',
            '.odp': 'application/vnd.oasis.opendocument.presentation',
            '.zip': 'application/zip',
            '.rar': 'application/x-rar-compressed',
            '.7z': 'application/x-7z-compressed',
            '.tar': 'application/x-tar',
            '.gz': 'application/gzip',
            '.bz2': 'application/x-bzip2'
        }
        
        return mime_map.get(extension.lower(), 'application/octet-stream')
    
    def analyze_file_structure(self, file_info: FileInfo) -> Dict[str, Any]:
        """
        Analyze file structure to extract additional information.
        
        Args:
            file_info: FileInfo object containing file path and basic info
        
        Returns:
            Dictionary containing structural analysis results
        """
        analysis = {
            'file_type': FileType.UNKNOWN,
            'structure_info': {},
            'embedded_files': [],
            'metadata': {}
        }
        
        try:
            file_path = file_info.path
            if not file_path.exists():
                return analysis
            
            # Perform type detection first
            type_info = self.detect_file_type(file_info)
            analysis['file_type'] = type_info['file_type']
            
            # Structure analysis based on file type
            if type_info['file_type'] == FileType.ARCHIVE:
                analysis['structure_info'] = self._analyze_archive_structure(file_path)
            elif type_info['file_type'] == FileType.DOCUMENT:
                analysis['structure_info'] = self._analyze_document_structure(file_path)
            elif type_info['file_type'] in [FileType.PE_EXE, FileType.PE_DLL, FileType.PE_SYS]:
                analysis['structure_info'] = self._analyze_pe_structure(file_path)
            elif type_info['file_type'] in [FileType.ELF_EXE, FileType.ELF_SO]:
                analysis['structure_info'] = self._analyze_elf_structure(file_path)
            elif type_info['file_type'] == FileType.MACHO_EXE:
                analysis['structure_info'] = self._analyze_macho_structure(file_path)
            
            # Extract metadata
            analysis['metadata'] = self._extract_metadata(file_path)
            
        except Exception as e:
            self.logger.error(f"Error analyzing file structure for {file_path}: {e}")
            analysis['error'] = str(e)
        
        return analysis
    
    def _analyze_archive_structure(self, file_path: Path) -> Dict[str, Any]:
        """Analyze archive file structure."""
        structure = {'type': 'archive', 'entries': []}
        
        try:
            # Simple archive analysis (would need specific libraries for full parsing)
            extension = file_path.suffix.lower()
            
            if extension == '.zip':
                structure['archive_type'] = 'zip'
            elif extension == '.rar':
                structure['archive_type'] = 'rar'
            elif extension == '.7z':
                structure['archive_type'] = '7z'
            elif extension in ['.tar', '.gz', '.bz2']:
                structure['archive_type'] = 'tar'
            else:
                structure['archive_type'] = 'unknown'
            
            structure['note'] = 'Detailed archive parsing requires specialized libraries'
            
        except Exception as e:
            structure['error'] = str(e)
        
        return structure
    
    def _analyze_document_structure(self, file_path: Path) -> Dict[str, Any]:
        """Analyze document file structure."""
        structure = {'type': 'document', 'format': 'unknown'}
        
        try:
            extension = file_path.suffix.lower()
            
            if extension == '.pdf':
                structure['format'] = 'pdf'
            elif extension in ['.doc', '.docx']:
                structure['format'] = 'word'
            elif extension in ['.xls', '.xlsx']:
                structure['format'] = 'excel'
            elif extension in ['.ppt', '.pptx']:
                structure['format'] = 'powerpoint'
            elif extension == '.rtf':
                structure['format'] = 'rtf'
            else:
                structure['format'] = 'text'
        
        except Exception as e:
            structure['error'] = str(e)
        
        return structure
    
    def _analyze_pe_structure(self, file_path: Path) -> Dict[str, Any]:
        """Analyze PE file structure."""
        structure = {'type': 'pe', 'format': 'exe'}
        
        try:
            extension = file_path.suffix.lower()
            
            if extension == '.dll':
                structure['format'] = 'dll'
            elif extension == '.sys':
                structure['format'] = 'driver'
            else:
                structure['format'] = 'exe'
            
            structure['note'] = 'Detailed PE analysis requires PE parser'
            
        except Exception as e:
            structure['error'] = str(e)
        
        return structure
    
    def _analyze_elf_structure(self, file_path: Path) -> Dict[str, Any]:
        """Analyze ELF file structure."""
        structure = {'type': 'elf', 'format': 'executable'}
        
        try:
            extension = file_path.suffix.lower()
            
            if extension == '.so':
                structure['format'] = 'shared_library'
            else:
                structure['format'] = 'executable'
            
            structure['note'] = 'Detailed ELF analysis requires ELF parser'
            
        except Exception as e:
            structure['error'] = str(e)
        
        return structure
    
    def _analyze_macho_structure(self, file_path: Path) -> Dict[str, Any]:
        """Analyze Mach-O file structure."""
        structure = {'type': 'macho', 'format': 'executable'}
        
        try:
            extension = file_path.suffix.lower()
            
            if extension == '.dylib':
                structure['format'] = 'dynamic_library'
            else:
                structure['format'] = 'executable'
            
            structure['note'] = 'Detailed Mach-O analysis requires Mach-O parser'
            
        except Exception as e:
            structure['error'] = str(e)
        
        return structure
    
    def _extract_metadata(self, file_path: Path) -> Dict[str, Any]:
        """Extract basic file metadata."""
        metadata = {}
        
        try:
            stat = file_path.stat()
            metadata['size'] = stat.st_size
            metadata['created'] = stat.st_ctime
            metadata['modified'] = stat.st_mtime
            metadata['permissions'] = oct(stat.st_mode)[-3:]
            
            # Get owner if available (Unix systems)
            try:
                import pwd
                metadata['owner'] = pwd.getpwuid(stat.st_uid).pw_name
            except (ImportError, KeyError):
                pass
        
        except Exception as e:
            metadata['error'] = str(e)
        
        return metadata
