"""
Scan Scheduler
==============

Handles scheduled scanning operations and configuration management.
Provides cron-like scheduling for automated file system scans.
"""

import logging
import threading
import time
from datetime import datetime, timedelta
from pathlib import Path
from typing import Dict, List, Optional, Any, Callable, Union
from dataclasses import dataclass, field
from enum import Enum

from .models import ScanMode, ScanConfiguration


class ScheduleType(Enum):
    """Types of scan schedules."""
    ONCE = "once"
    HOURLY = "hourly"
    DAILY = "daily"
    WEEKLY = "weekly"
    MONTHLY = "monthly"
    CUSTOM = "custom"


@dataclass
class ScanSchedule:
    """Represents a scheduled scan."""
    schedule_id: str
    name: str
    schedule_type: ScheduleType
    target_path: Path
    parameters: Dict[str, Any] = field(default_factory=dict)
    enabled: bool = True
    created_at: datetime = field(default_factory=datetime.now)
    last_run: Optional[datetime] = None
    next_run: Optional[datetime] = None
    run_count: int = 0
    description: str = ""
    exclusions: List[str] = field(default_factory=list)
    file_extensions: Optional[List[str]] = None
    recursive: bool = True
    priority: int = 0
    
    def __post_init__(self):
        """Calculate next run time after initialization."""
        if self.next_run is None:
            self.next_run = self._calculate_next_run()
    
    def _calculate_next_run(self) -> datetime:
        """Calculate the next run time based on schedule type."""
        now = datetime.now()
        
        if self.schedule_type == ScheduleType.ONCE:
            return self._calculate_once_run(now)
        elif self.schedule_type == ScheduleType.HOURLY:
            return self._calculate_hourly_run(now)
        elif self.schedule_type == ScheduleType.DAILY:
            return self._calculate_daily_run(now)
        elif self.schedule_type == ScheduleType.WEEKLY:
            return self._calculate_weekly_run(now)
        elif self.schedule_type == ScheduleType.MONTHLY:
            return self._calculate_monthly_run(now)
        elif self.schedule_type == ScheduleType.CUSTOM:
            return self._calculate_custom_run(now)
        
        return now + timedelta(hours=1)  # Default fallback
    
    def _calculate_once_run(self, now: datetime) -> datetime:
        """Calculate next run for one-time schedule."""
        run_time = self.parameters.get('run_time')
        if run_time:
            if isinstance(run_time, str):
                run_time = datetime.fromisoformat(run_time)
            return run_time if run_time > now else now + timedelta(minutes=1)
        return now + timedelta(minutes=1)
    
    def _calculate_hourly_run(self, now: datetime) -> datetime:
        """Calculate next run for hourly schedule."""
        interval = self.parameters.get('interval', 1)  # hours
        minute = self.parameters.get('minute', 0)
        return now.replace(minute=minute, second=0, microsecond=0) + timedelta(hours=interval)
    
    def _calculate_daily_run(self, now: datetime) -> datetime:
        """Calculate next run for daily schedule."""
        run_time = self.parameters.get('run_time', "09:00")
        if isinstance(run_time, str):
            hour, minute = map(int, run_time.split(':'))
            run_time = now.replace(hour=hour, minute=minute, second=0, microsecond=0)
        
        if run_time <= now:
            run_time += timedelta(days=1)
        
        return run_time
    
    def _calculate_weekly_run(self, now: datetime) -> datetime:
        """Calculate next run for weekly schedule."""
        run_time = self.parameters.get('run_time', "09:00")
        day_of_week = self.parameters.get('day_of_week', 1)  # Monday = 1
        weekday = now.weekday()
        
        if isinstance(run_time, str):
            hour, minute = map(int, run_time.split(':'))
        
        # Calculate days to add
        days_to_add = (day_of_week - weekday) % 7
        if days_to_add == 0 and now.time() >= run_time:
            days_to_add = 7
        
        target_date = now + timedelta(days=days_to_add)
        return target_date.replace(
            hour=run_time.hour if hasattr(run_time, 'hour') else hour,
            minute=run_time.minute if hasattr(run_time, 'minute') else minute,
            second=0, microsecond=0
        )
    
    def _calculate_monthly_run(self, now: datetime) -> datetime:
        """Calculate next run for monthly schedule."""
        run_time = self.parameters.get('run_time', "09:00")
        day_of_month = self.parameters.get('day_of_month', 1)
        
        if isinstance(run_time, str):
            hour, minute = map(int, run_time.split(':'))
        
        # Calculate target month
        if now.day > day_of_month:
            # Move to next month
            if now.month == 12:
                target_month = now.replace(year=now.year + 1, month=1, day=1)
            else:
                target_month = now.replace(month=now.month + 1, day=1)
            day = min(day_of_month, (target_month - timedelta(days=1)).day)
        else:
            target_month = now
            day = day_of_month
        
        return target_month.replace(
            day=day,
            hour=run_time.hour if hasattr(run_time, 'hour') else hour,
            minute=run_time.minute if hasattr(run_time, 'minute') else minute,
            second=0, microsecond=0
        )
    
    def _calculate_custom_run(self, now: datetime) -> datetime:
        """Calculate next run for custom schedule."""
        cron_expression = self.parameters.get('cron_expression')
        if cron_expression:
            # Simple cron parsing (would need full cron library for complete support)
            return self._parse_cron(cron_expression, now)
        return now + timedelta(hours=1)
    
    def _parse_cron(self, cron_expression: str, now: datetime) -> datetime:
        """Parse simple cron expression (basic implementation)."""
        # This is a simplified cron parser
        # For production use, consider using python-cron or similar
        try:
            parts = cron_expression.split()
            if len(parts) < 5:
                return now + timedelta(hours=1)
            
            minute, hour, day, month, weekday = parts[:5]
            
            # Simple implementation - adjust as needed
            next_run = now + timedelta(minutes=1)
            return next_run
        except Exception:
            return now + timedelta(hours=1)
    
    def update_next_run(self):
        """Update the next run time after execution."""
        self.last_run = datetime.now()
        self.run_count += 1
        
        if self.schedule_type == ScheduleType.ONCE:
            self.enabled = False
        else:
            self.next_run = self._calculate_next_run()


class ScanScheduler:
    """
    Manages scheduled scanning operations.
    
    Provides cron-like scheduling for automated file system scans
    with support for various schedule types and configurations.
    """
    
    def __init__(self, scanner_engine):
        """
        Initialize scan scheduler.
        
        Args:
            scanner_engine: Reference to the file scanner engine
        """
        self.scanner = scanner_engine
        self.logger = logging.getLogger(__name__)
        
        # Scheduling state
        self.schedules: Dict[str, ScanSchedule] = {}
        self.running = False
        self.worker_thread: Optional[threading.Thread] = None
        self.lock = threading.RLock()
        
        # Configuration
        self.check_interval = 60  # Check for due schedules every 60 seconds
        self.max_concurrent_scans = 2
        self.active_scans = 0
        
        # Callbacks
        self.scan_started_callback: Optional[Callable] = None
        self.scan_completed_callback: Optional[Callable] = None
        self.schedule_updated_callback: Optional[Callable] = None
        
        # Load existing schedules
        self._load_schedules()
    
    def start(self):
        """Start the scan scheduler."""
        if self.running:
            return
        
        self.running = True
        self.worker_thread = threading.Thread(target=self._scheduler_loop, daemon=True)
        self.worker_thread.start()
        
        self.logger.info("Scan scheduler started")
    
    def stop(self):
        """Stop the scan scheduler."""
        if not self.running:
            return
        
        self.running = False
        
        if self.worker_thread:
            self.worker_thread.join(timeout=10.0)
        
        self.logger.info("Scan scheduler stopped")
    
    def add_schedule(self, schedule: ScanSchedule) -> bool:
        """
        Add a new scan schedule.
        
        Args:
            schedule: ScanSchedule object to add
        
        Returns:
            True if added successfully, False otherwise
        """
        try:
            with self.lock:
                self.schedules[schedule.schedule_id] = schedule
                self._save_schedules()
                
                if self.schedule_updated_callback:
                    self.schedule_updated_callback('added', schedule)
            
            self.logger.info(f"Added scan schedule: {schedule.name} ({schedule.schedule_id})")
            return True
            
        except Exception as e:
            self.logger.error(f"Error adding scan schedule: {e}")
            return False
    
    def remove_schedule(self, schedule_id: str) -> bool:
        """
        Remove a scan schedule.
        
        Args:
            schedule_id: ID of the schedule to remove
        
        Returns:
            True if removed successfully, False otherwise
        """
        try:
            with self.lock:
                if schedule_id in self.schedules:
                    schedule = self.schedules.pop(schedule_id)
                    self._save_schedules()
                    
                    if self.schedule_updated_callback:
                        self.schedule_updated_callback('removed', schedule)
                    
                    self.logger.info(f"Removed scan schedule: {schedule.name} ({schedule_id})")
                    return True
            
            return False
            
        except Exception as e:
            self.logger.error(f"Error removing scan schedule: {e}")
            return False
    
    def update_schedule(self, schedule: ScanSchedule) -> bool:
        """
        Update an existing scan schedule.
        
        Args:
            schedule: Updated ScanSchedule object
        
        Returns:
            True if updated successfully, False otherwise
        """
        try:
            with self.lock:
                if schedule.schedule_id in self.schedules:
                    self.schedules[schedule.schedule_id] = schedule
                    self._save_schedules()
                    
                    if self.schedule_updated_callback:
                        self.schedule_updated_callback('updated', schedule)
                    
                    self.logger.info(f"Updated scan schedule: {schedule.name} ({schedule.schedule_id})")
                    return True
            
            return False
            
        except Exception as e:
            self.logger.error(f"Error updating scan schedule: {e}")
            return False
    
    def get_schedule(self, schedule_id: str) -> Optional[ScanSchedule]:
        """
        Get a specific scan schedule.
        
        Args:
            schedule_id: ID of the schedule to retrieve
        
        Returns:
            ScanSchedule object or None if not found
        """
        with self.lock:
            return self.schedules.get(schedule_id)
    
    def get_all_schedules(self) -> List[ScanSchedule]:
        """
        Get all scan schedules.
        
        Returns:
            List of all ScanSchedule objects
        """
        with self.lock:
            return list(self.schedules.values())
    
    def get_enabled_schedules(self) -> List[ScanSchedule]:
        """
        Get all enabled scan schedules.
        
        Returns:
            List of enabled ScanSchedule objects
        """
        with self.lock:
            return [s for s in self.schedules.values() if s.enabled]
    
    def get_due_schedules(self) -> List[ScanSchedule]:
        """
        Get all schedules that are due to run.
        
        Returns:
            List of due ScanSchedule objects
        """
        with self.lock:
            now = datetime.now()
            return [s for s in self.schedules.values() 
                   if s.enabled and s.next_run and s.next_run <= now]
    
    def run_schedule_now(self, schedule_id: str) -> bool:
        """
        Manually run a schedule immediately.
        
        Args:
            schedule_id: ID of the schedule to run
        
        Returns:
            True if run successfully, False otherwise
        """
        try:
            with self.lock:
                if schedule_id not in self.schedules:
                    return False
                
                schedule = self.schedules[schedule_id]
                if not schedule.enabled:
                    return False
                
                # Run the scan
                self._execute_scan(schedule)
                return True
                
        except Exception as e:
            self.logger.error(f"Error running schedule {schedule_id}: {e}")
            return False
    
    def enable_schedule(self, schedule_id: str) -> bool:
        """
        Enable a scan schedule.
        
        Args:
            schedule_id: ID of the schedule to enable
        
        Returns:
            True if enabled successfully, False otherwise
        """
        try:
            with self.lock:
                if schedule_id in self.schedules:
                    self.schedules[schedule_id].enabled = True
                    self.schedules[schedule_id].next_run = datetime.now()
                    self._save_schedules()
                    return True
            return False
        except Exception as e:
            self.logger.error(f"Error enabling schedule {schedule_id}: {e}")
            return False
    
    def disable_schedule(self, schedule_id: str) -> bool:
        """
        Disable a scan schedule.
        
        Args:
            schedule_id: ID of the schedule to disable
        
        Returns:
            True if disabled successfully, False otherwise
        """
        try:
            with self.lock:
                if schedule_id in self.schedules:
                    self.schedules[schedule_id].enabled = False
                    self._save_schedules()
                    return True
            return False
        except Exception as e:
            self.logger.error(f"Error disabling schedule {schedule_id}: {e}")
            return False
    
    def get_statistics(self) -> Dict[str, Any]:
        """
        Get scheduler statistics.
        
        Returns:
            Dictionary containing scheduler statistics
        """
        with self.lock:
            total_schedules = len(self.schedules)
            enabled_schedules = len([s for s in self.schedules.values() if s.enabled])
            due_schedules = len(self.get_due_schedules())
            total_runs = sum(s.run_count for s in self.schedules.values())
            
            schedule_types = {}
            for schedule in self.schedules.values():
                schedule_type = schedule.schedule_type.value
                schedule_types[schedule_type] = schedule_types.get(schedule_type, 0) + 1
            
            return {
                'total_schedules': total_schedules,
                'enabled_schedules': enabled_schedules,
                'due_schedules': due_schedules,
                'active_scans': self.active_scans,
                'max_concurrent_scans': self.max_concurrent_scans,
                'total_runs': total_runs,
                'schedule_types': schedule_types,
                'check_interval': self.check_interval
            }
    
    def set_callbacks(self, 
                     scan_started: Optional[Callable] = None,
                     scan_completed: Optional[Callable] = None,
                     schedule_updated: Optional[Callable] = None):
        """
        Set callback functions for scheduler events.
        
        Args:
            scan_started: Callback when scan starts
            scan_completed: Callback when scan completes
            schedule_updated: Callback when schedule is updated
        """
        self.scan_started_callback = scan_started
        self.scan_completed_callback = scan_completed
        self.schedule_updated_callback = schedule_updated
    
    def _scheduler_loop(self):
        """Main scheduler loop."""
        while self.running:
            try:
                # Check for due schedules
                due_schedules = self.get_due_schedules()
                
                for schedule in due_schedules:
                    if self.active_scans < self.max_concurrent_scans:
                        self._execute_scan(schedule)
                
                # Sleep for check interval
                time.sleep(self.check_interval)
                
            except Exception as e:
                self.logger.error(f"Error in scheduler loop: {e}")
                time.sleep(5)  # Short sleep on error
    
    def _execute_scan(self, schedule: ScanSchedule):
        """
        Execute a scheduled scan.
        
        Args:
            schedule: ScanSchedule to execute
        """
        try:
            with self.lock:
                self.active_scans += 1
            
            self.logger.info(f"Starting scheduled scan: {schedule.name}")
            
            if self.scan_started_callback:
                self.scan_started_callback(schedule)
            
            # Run the actual scan
            results = self.scanner.scan_directory(
                schedule.target_path,
                recursive=schedule.recursive,
                file_extensions=schedule.file_extensions
            )
            
            # Update schedule
            schedule.update_next_run()
            self._save_schedules()
            
            self.logger.info(f"Completed scheduled scan: {schedule.name} - {len(results)} files scanned")
            
            if self.scan_completed_callback:
                self.scan_completed_callback(schedule, results)
                
        except Exception as e:
            self.logger.error(f"Error executing scan schedule {schedule.schedule_id}: {e}")
        finally:
            with self.lock:
                self.active_scans = max(0, self.active_scans - 1)
    
    def _load_schedules(self):
        """Load schedules from disk."""
        try:
            schedules_file = Path("scan_schedules.json")
            if schedules_file.exists():
                import json
                with open(schedules_file, 'r') as f:
                    data = json.load(f)
                
                for schedule_data in data.get('schedules', []):
                    try:
                        schedule = self._reconstruct_schedule(schedule_data)
                        if schedule:
                            self.schedules[schedule.schedule_id] = schedule
                    except Exception as e:
                        self.logger.error(f"Error reconstructing schedule: {e}")
                
                self.logger.info(f"Loaded {len(self.schedules)} scan schedules")
                
        except Exception as e:
            self.logger.error(f"Error loading scan schedules: {e}")
    
    def _save_schedules(self):
        """Save schedules to disk."""
        try:
            schedules_file = Path("scan_schedules.json")
            import json
            
            schedule_data = {
                'version': '1.0',
                'last_updated': datetime.now().isoformat(),
                'schedules': [self._serialize_schedule(s) for s in self.schedules.values()]
            }
            
            with open(schedules_file, 'w') as f:
                json.dump(schedule_data, f, indent=2, default=str)
                
        except Exception as e:
            self.logger.error(f"Error saving scan schedules: {e}")
    
    def _reconstruct_schedule(self, data: Dict[str, Any]) -> Optional[ScanSchedule]:
        """Reconstruct ScanSchedule from serialized data."""
        try:
            return ScanSchedule(
                schedule_id=data.get('schedule_id', ''),
                name=data.get('name', ''),
                schedule_type=ScheduleType(data.get('schedule_type', 'daily')),
                target_path=Path(data.get('target_path', '')),
                parameters=data.get('parameters', {}),
                enabled=data.get('enabled', True),
                created_at=datetime.fromisoformat(data.get('created_at', datetime.now().isoformat())),
                last_run=datetime.fromisoformat(data['last_run']) if data.get('last_run') else None,
                next_run=datetime.fromisoformat(data['next_run']) if data.get('next_run') else None,
                run_count=data.get('run_count', 0),
                description=data.get('description', ''),
                exclusions=data.get('exclusions', []),
                file_extensions=data.get('file_extensions'),
                recursive=data.get('recursive', True),
                priority=data.get('priority', 0)
            )
        except Exception as e:
            self.logger.error(f"Error reconstructing schedule: {e}")
            return None
    
    def _serialize_schedule(self, schedule: ScanSchedule) -> Dict[str, Any]:
        """Serialize ScanSchedule to dictionary."""
        return {
            'schedule_id': schedule.schedule_id,
            'name': schedule.name,
            'schedule_type': schedule.schedule_type.value,
            'target_path': str(schedule.target_path),
            'parameters': schedule.parameters,
            'enabled': schedule.enabled,
            'created_at': schedule.created_at.isoformat(),
            'last_run': schedule.last_run.isoformat() if schedule.last_run else None,
            'next_run': schedule.next_run.isoformat() if schedule.next_run else None,
            'run_count': schedule.run_count,
            'description': schedule.description,
            'exclusions': schedule.exclusions,
            'file_extensions': schedule.file_extensions,
            'recursive': schedule.recursive,
            'priority': schedule.priority
        }
