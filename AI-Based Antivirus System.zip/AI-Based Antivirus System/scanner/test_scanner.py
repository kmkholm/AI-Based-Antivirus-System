"""
Test Suite for File Scanner Module
==================================

Comprehensive tests for the file scanner engine and all its components.
Validates functionality, performance, and integration.
"""

import hashlib
import logging
import os
import tempfile
import threading
import time
from datetime import datetime
from pathlib import Path
from typing import List, Dict, Any

import pytest

# Import scanner modules
from scanner import (
    FileScannerEngine,
    PEAnalyzer,
    FileTypeDetector,
    SuspiciousPatternDetector,
    QuarantineManager,
    ScanScheduler,
    ScanConfiguration,
    ScanResult,
    FileInfo,
    ThreatInfo,
    ThreatLevel,
    ActionType,
    ScanMode,
    ScheduleType,
    ScanSchedule
)


class TestFileScannerEngine:
    """Test cases for the main file scanner engine."""
    
    def setup_method(self):
        """Setup test environment."""
        # Create temporary directory for tests
        self.test_dir = Path(tempfile.mkdtemp())
        self.quarantine_dir = self.test_dir / "quarantine"
        
        # Configure logging
        logging.basicConfig(level=logging.INFO)
        
        # Create test configuration
        self.config = ScanConfiguration(
            max_file_size=10 * 1024 * 1024,  # 10MB
            enable_pe_analysis=True,
            enable_elf_analysis=True,
            enable_macho_analysis=True,
            enable_entropy_analysis=True,
            enable_yara_scanning=True,
            enable_clamav_scanning=False,
            max_scan_threads=2,
            scan_timeout=10,
            quarantine_enabled=True,
            quarantine_path=self.quarantine_dir,
            cache_enabled=True,
            cache_ttl=3600,
            suspicious_threshold=0.7,
            malicious_threshold=0.8,
            auto_quarantine=False
        )
        
        # Initialize scanner
        self.scanner = FileScannerEngine(self.config)
    
    def teardown_method(self):
        """Cleanup test environment."""
        if hasattr(self, 'scanner'):
            self.scanner.stop()
        
        # Clean up temporary directory
        import shutil
        if hasattr(self, 'test_dir') and self.test_dir.exists():
            shutil.rmtree(self.test_dir)
    
    def test_scanner_initialization(self):
        """Test scanner initialization."""
        assert self.scanner is not None
        assert self.scanner.config == self.config
        assert self.scanner.file_detector is not None
        assert self.scanner.pe_analyzer is not None
        assert self.scanner.pattern_detector is not None
        assert self.scanner.quarantine_manager is not None
    
    def test_scan_clean_file(self):
        """Test scanning a clean file."""
        # Create a clean test file
        test_file = self.test_dir / "clean_file.txt"
        test_file.write_text("This is a clean test file.")
        
        # Start scanner
        self.scanner.start()
        
        # Scan the file
        result = self.scanner.scan_file(test_file)
        
        # Verify results
        assert result is not None
        assert result.is_clean
        assert result.threat_level == ThreatLevel.CLEAN
        assert result.error_message == ""
        
        # Stop scanner
        self.scanner.stop()
    
    def test_scan_nonexistent_file(self):
        """Test scanning a non-existent file."""
        nonexistent_file = self.test_dir / "nonexistent.txt"
        
        # Start scanner
        self.scanner.start()
        
        # Scan the file
        result = self.scanner.scan_file(nonexistent_file)
        
        # Verify results
        assert result is not None
        assert "not found" in result.error_message
        
        # Stop scanner
        self.scanner.stop()
    
    def test_scan_directory(self):
        """Test scanning a directory."""
        # Create test files
        files = []
        for i in range(3):
            test_file = self.test_dir / f"test_file_{i}.txt"
            test_file.write_text(f"Test file number {i}")
            files.append(test_file)
        
        # Start scanner
        self.scanner.start()
        
        # Scan the directory
        results = self.scanner.scan_directory(self.test_dir, recursive=False)
        
        # Verify results
        assert len(results) == 3
        for result in results:
            assert result.is_clean
        
        # Stop scanner
        self.scanner.stop()
    
    def test_concurrent_scanning(self):
        """Test concurrent file scanning."""
        # Create multiple test files
        files = []
        for i in range(10):
            test_file = self.test_dir / f"concurrent_file_{i}.txt"
            test_file.write_text(f"Concurrent test file {i}")
            files.append(test_file)
        
        # Start scanner
        self.scanner.start()
        
        # Scan files concurrently
        results = self.scanner.scan_files(files)
        
        # Verify results
        assert len(results) == 10
        for result in results:
            assert result.is_clean
        
        # Stop scanner
        self.scanner.stop()
    
    def test_quarantine_functionality(self):
        """Test file quarantine functionality."""
        # Create a suspicious test file
        suspicious_file = self.test_dir / "suspicious.txt"
        suspicious_file.write_text("This file contains suspicious content like CreateProcess, VirtualAlloc, etc.")
        
        # Start scanner
        self.scanner.start()
        
        # Scan and quarantine
        result = self.scanner.scan_file(suspicious_file)
        
        # Quarantine the file
        quarantined = self.scanner.quarantine_file(suspicious_file, result)
        assert quarantined
        
        # Check if file is quarantined
        assert self.scanner.quarantine_manager.is_file_quarantined(suspicious_file)
        
        # Verify quarantine entry
        quarantine_id = self.scanner.quarantine_manager.get_file_quarantine_id(suspicious_file)
        assert quarantine_id is not None
        
        entry = self.scanner.quarantine_manager.get_entry(quarantine_id)
        assert entry is not None
        assert entry.original_path == suspicious_file
        
        # Stop scanner
        self.scanner.stop()
    
    def test_scanner_statistics(self):
        """Test scanner statistics tracking."""
        # Create test file
        test_file = self.test_dir / "stats_test.txt"
        test_file.write_text("Test file for statistics.")
        
        # Start scanner
        self.scanner.start()
        
        # Scan file
        result = self.scanner.scan_file(test_file)
        
        # Get statistics
        stats = self.scanner.get_scan_statistics()
        
        # Verify statistics
        assert stats['files_scanned'] > 0
        assert 'cache_size' in stats
        assert 'quarantine_size' in stats
        
        # Stop scanner
        self.scanner.stop()
    
    def test_cache_functionality(self):
        """Test scan result caching."""
        # Create test file
        test_file = self.test_dir / "cache_test.txt"
        test_file.write_text("Test file for caching.")
        
        # Start scanner
        self.scanner.start()
        
        # Scan file twice
        result1 = self.scanner.scan_file(test_file)
        result2 = self.scanner.scan_file(test_file)
        
        # Verify cache hit
        assert self.scanner.stats['cache_hits'] > 0
        
        # Verify results are consistent
        assert result1.is_clean == result2.is_clean
        assert result1.threat_level == result2.threat_level
        
        # Stop scanner
        self.scanner.stop()


class TestPEAnalyzer:
    """Test cases for PE file analyzer."""
    
    def setup_method(self):
        """Setup test environment."""
        self.test_dir = Path(tempfile.mkdtemp())
        self.pe_analyzer = PEAnalyzer()
    
    def teardown_method(self):
        """Cleanup test environment."""
        import shutil
        if self.test_dir.exists():
            shutil.rmtree(self.test_dir)
    
    def test_pe_analyzer_initialization(self):
        """Test PE analyzer initialization."""
        assert self.pe_analyzer is not None
        assert self.pe_analyzer.suspicious_imports is not None
        assert self.pe_analyzer.known_packers is not None
    
    def test_entropy_calculation(self):
        """Test entropy calculation."""
        # Create test data with low entropy
        low_entropy_data = b"AAAA" * 100  # Repeated bytes
        entropy = self.pe_analyzer._calculate_entropy(low_entropy_data)
        assert entropy < 2.0  # Low entropy
        
        # Create test data with high entropy
        import os
        high_entropy_data = os.urandom(1000)  # Random bytes
        entropy = self.pe_analyzer._calculate_entropy(high_entropy_data)
        assert entropy > 7.0  # High entropy
    
    def test_invalid_pe_file(self):
        """Test analysis of invalid PE file."""
        # Create a non-PE file
        test_file = self.test_dir / "not_pe.txt"
        test_file.write_text("This is not a PE file.")
        
        file_info = FileInfo(test_file)
        result = self.pe_analyzer.analyze_pe_file(file_info)
        
        # Should not be valid PE
        assert not result['is_valid_pe']


class TestFileTypeDetector:
    """Test cases for file type detector."""
    
    def setup_method(self):
        """Setup test environment."""
        self.test_dir = Path(tempfile.mkdtemp())
        self.detector = FileTypeDetector()
    
    def teardown_method(self):
        """Cleanup test environment."""
        import shutil
        if self.test_dir.exists():
            shutil.rmtree(self.test_dir)
    
    def test_detector_initialization(self):
        """Test file type detector initialization."""
        assert self.detector is not None
        assert self.detector.file_signatures is not None
        assert self.detector.executable_extensions is not None
    
    def test_text_file_detection(self):
        """Test detection of text files."""
        test_file = self.test_dir / "text_file.txt"
        test_file.write_text("This is a text file.")
        
        file_info = FileInfo(test_file)
        result = self.detector.detect_file_type(file_info)
        
        # Should be detected as document (text)
        assert result['file_type'] is not None
        assert result['mime_type'] != ""
    
    def test_archive_detection(self):
        """Test detection of archive files."""
        # Create a file that looks like an archive
        archive_file = self.test_dir / "test.zip"
        archive_file.write_bytes(b"PK\x03\x04")  # ZIP signature
        
        file_info = FileInfo(archive_file)
        result = self.detector.detect_file_type(file_info)
        
        # Should be detected as archive
        assert result['file_type'].value == 'archive'
        assert result['is_archive']
    
    def test_script_detection(self):
        """Test detection of script files."""
        # Create a Python script
        script_file = self.test_dir / "script.py"
        script_file.write_text("#!/usr/bin/env python\nprint('Hello, World!')")
        
        file_info = FileInfo(script_file)
        result = self.detector.detect_file_type(file_info)
        
        # Should be detected as script
        assert result['file_type'].value == 'script'
        assert result['is_script']
        assert 'python' in result['additional_info'].get('script_type', '')


class TestSuspiciousPatternDetector:
    """Test cases for suspicious pattern detector."""
    
    def setup_method(self):
        """Setup test environment."""
        self.test_dir = Path(tempfile.mkdtemp())
        self.detector = SuspiciousPatternDetector()
    
    def teardown_method(self):
        """Cleanup test environment."""
        import shutil
        if self.test_dir.exists():
            shutil.rmtree(self.test_dir)
    
    def test_detector_initialization(self):
        """Test pattern detector initialization."""
        assert self.detector is not None
        assert self.detector.suspicious_strings is not None
        assert self.detector.shellcode_patterns is not None
    
    def test_suspicious_string_detection(self):
        """Test detection of suspicious strings."""
        # Create a file with suspicious content
        suspicious_file = self.test_dir / "suspicious.txt"
        suspicious_file.write_text("This file contains http://malicious.com and CreateProcessA.")
        
        file_info = FileInfo(suspicious_file)
        result = self.detector.analyze_file(file_info)
        
        # Should detect suspicious patterns
        assert len(result['suspicious_strings']) > 0
        assert result['suspicion_score'] > 0
    
    def test_high_entropy_detection(self):
        """Test detection of high entropy (packed/encrypted) files."""
        # Create a file with high entropy
        high_entropy_file = self.test_dir / "high_entropy.bin"
        import os
        high_entropy_file.write_bytes(os.urandom(1024))  # Random data
        
        file_info = FileInfo(high_entropy_file)
        result = self.detector.analyze_file(file_info)
        
        # Should detect high entropy
        assert result['entropy_score'] > 7.0
        assert result['suspicion_score'] > 0
    
    def test_network_indicators_detection(self):
        """Test detection of network-related indicators."""
        # Create a file with network indicators
        network_file = self.test_dir / "network.txt"
        network_file.write_text("Connect to 192.168.1.100:80 and download from example.com")
        
        result = self.detector.analyze_network_indicators(network_file)
        
        # Should detect network indicators
        assert len(result['urls']) > 0 or len(result['domains']) > 0 or len(result['ip_addresses']) > 0


class TestQuarantineManager:
    """Test cases for quarantine manager."""
    
    def setup_method(self):
        """Setup test environment."""
        self.test_dir = Path(tempfile.mkdtemp())
        self.quarantine_dir = self.test_dir / "quarantine"
        self.quarantine_manager = QuarantineManager(self.quarantine_dir)
    
    def teardown_method(self):
        """Cleanup test environment."""
        import shutil
        if self.test_dir.exists():
            shutil.rmtree(self.test_dir)
    
    def test_quarantine_initialization(self):
        """Test quarantine manager initialization."""
        assert self.quarantine_manager is not None
        assert self.quarantine_dir.exists()
        assert len(self.quarantine_manager.entries) == 0
    
    def test_quarantine_file(self):
        """Test file quarantine functionality."""
        # Create a test file
        test_file = self.test_dir / "test_file.txt"
        test_file.write_text("Test file for quarantine.")
        
        # Create a simple scan result
        file_info = FileInfo(test_file)
        threat_info = ThreatInfo(
            name="Test Threat",
            level=ThreatLevel.SUSPICIOUS,
            description="Test quarantine"
        )
        
        from scanner.models import ScanResult
        scan_result = ScanResult(
            file_info=file_info,
            is_clean=False,
            threats=[threat_info]
        )
        
        # Quarantine the file
        success = self.quarantine_manager.quarantine_file(test_file, scan_result)
        assert success
        
        # Verify file is quarantined
        assert self.quarantine_manager.is_file_quarantined(test_file)
        assert len(self.quarantine_manager.get_entries()) == 1
    
    def test_restore_file(self):
        """Test file restoration from quarantine."""
        # Create a test file
        test_file = self.test_dir / "test_file.txt"
        test_file.write_text("Test file for restore.")
        
        # Create a simple scan result
        file_info = FileInfo(test_file)
        threat_info = ThreatInfo(
            name="Test Threat",
            level=ThreatLevel.SUSPICIOUS,
            description="Test restore"
        )
        
        from scanner.models import ScanResult
        scan_result = ScanResult(
            file_info=file_info,
            is_clean=False,
            threats=[threat_info]
        )
        
        # Quarantine the file
        success = self.quarantine_manager.quarantine_file(test_file, scan_result)
        assert success
        
        # Get quarantine ID
        quarantine_id = self.quarantine_manager.get_file_quarantine_id(test_file)
        assert quarantine_id is not None
        
        # Restore the file
        restore_path = self.test_dir / "restored_file.txt"
        success = self.quarantine_manager.restore_file(quarantine_id, restore_path)
        assert success
        assert restore_path.exists()
    
    def test_quarantine_statistics(self):
        """Test quarantine statistics."""
        # Create a test file
        test_file = self.test_dir / "test_file.txt"
        test_file.write_text("Test file for stats.")
        
        # Create a simple scan result
        file_info = FileInfo(test_file)
        threat_info = ThreatInfo(
            name="Test Threat",
            level=ThreatLevel.SUSPICIOUS,
            description="Test statistics"
        )
        
        from scanner.models import ScanResult
        scan_result = ScanResult(
            file_info=file_info,
            is_clean=False,
            threats=[threat_info]
        )
        
        # Quarantine the file
        self.quarantine_manager.quarantine_file(test_file, scan_result)
        
        # Get statistics
        stats = self.quarantine_manager.get_statistics()
        
        # Verify statistics
        assert stats['total_entries'] == 1
        assert stats['total_size'] > 0


class TestScanScheduler:
    """Test cases for scan scheduler."""
    
    def setup_method(self):
        """Setup test environment."""
        self.test_dir = Path(tempfile.mkdtemp())
        
        # Create a mock scanner engine
        class MockScanner:
            def scan_directory(self, path, recursive=True, file_extensions=None):
                return []
        
        self.mock_scanner = MockScanner()
        self.scheduler = ScanScheduler(self.mock_scanner)
    
    def teardown_method(self):
        """Cleanup test environment."""
        import shutil
        if self.test_dir.exists():
            shutil.rmtree(self.test_dir)
    
    def test_scheduler_initialization(self):
        """Test scheduler initialization."""
        assert self.scheduler is not None
        assert len(self.scheduler.schedules) == 0
        assert not self.scheduler.running
    
    def test_add_schedule(self):
        """Test adding a scan schedule."""
        # Create a test directory
        test_path = self.test_dir / "scan_target"
        test_path.mkdir()
        
        # Create a schedule
        schedule = ScanSchedule(
            schedule_id="test_001",
            name="Test Schedule",
            schedule_type=ScheduleType.ONCE,
            target_path=test_path
        )
        
        # Add schedule
        success = self.scheduler.add_schedule(schedule)
        assert success
        assert len(self.scheduler.schedules) == 1
    
    def test_schedule_execution(self):
        """Test schedule execution."""
        # Create a test directory
        test_path = self.test_dir / "scan_target"
        test_path.mkdir()
        
        # Create a test file
        test_file = test_path / "test.txt"
        test_file.write_text("Test file.")
        
        # Create a schedule
        schedule = ScanSchedule(
            schedule_id="test_002",
            name="Test Schedule",
            schedule_type=ScheduleType.ONCE,
            target_path=test_path
        )
        
        # Add schedule
        self.scheduler.add_schedule(schedule)
        
        # Execute schedule immediately
        success = self.scheduler.run_schedule_now(schedule.schedule_id)
        assert success
    
    def test_scheduler_statistics(self):
        """Test scheduler statistics."""
        # Get initial statistics
        stats = self.scheduler.get_statistics()
        
        # Verify statistics
        assert stats['total_schedules'] == 0
        assert stats['enabled_schedules'] == 0
        assert stats['active_scans'] == 0


def run_performance_test():
    """Run performance tests for the file scanner."""
    print("Running performance tests...")
    
    # Create test configuration
    config = ScanConfiguration(
        max_file_size=50 * 1024 * 1024,
        max_scan_threads=4,
        cache_enabled=True
    )
    
    scanner = FileScannerEngine(config)
    scanner.start()
    
    # Create test files
    test_dir = Path(tempfile.mkdtemp())
    num_files = 100
    
    for i in range(num_files):
        test_file = test_dir / f"perf_test_{i}.txt"
        test_file.write_text(f"Performance test file {i}")
    
    # Test single-threaded scanning
    start_time = time.time()
    results = scanner.scan_files(list(test_dir.glob("*.txt")))
    single_thread_time = time.time() - start_time
    
    # Test multi-threaded scanning
    start_time = time.time()
    results = scanner.scan_files(list(test_dir.glob("*.txt")), max_workers=4)
    multi_thread_time = time.time() - start_time
    
    # Clean up
    scanner.stop()
    import shutil
    shutil.rmtree(test_dir)
    
    print(f"Single-threaded scan: {single_thread_time:.2f} seconds")
    print(f"Multi-threaded scan: {multi_thread_time:.2f} seconds")
    print(f"Speed improvement: {single_thread_time / multi_thread_time:.2f}x")
    print(f"Files scanned: {len(results)}")
    print(f"Clean files: {sum(1 for r in results if r.is_clean)}")


if __name__ == "__main__":
    # Run performance test
    run_performance_test()
    
    # Run specific test classes
    import unittest
    
    test_classes = [
        TestFileScannerEngine,
        TestPEAnalyzer,
        TestFileTypeDetector,
        TestSuspiciousPatternDetector,
        TestQuarantineManager,
        TestScanScheduler
    ]
    
    for test_class in test_classes:
        print(f"\nRunning tests for {test_class.__name__}...")
        suite = unittest.TestLoader().loadTestsFromTestCase(test_class)
        runner = unittest.TextTestRunner(verbosity=2)
        result = runner.run(suite)
        
        if not result.wasSuccessful():
            print(f"Tests failed: {len(result.failures)} failures, {len(result.errors)} errors")
        else:
            print("All tests passed!")
