"""
Scan Configuration
==================

Configuration management for the file scanner module.
Handles loading, saving, and validation of scan configurations.
"""

import json
import logging
import os
from pathlib import Path
from typing import Dict, Any, List, Optional, Union

from .models import ScanConfiguration


class ConfigurationManager:
    """
    Manages scan configurations with validation and inheritance.
    
    Supports multiple configuration profiles with inheritance and
    validation to ensure safe and effective scanning operations.
    """
    
    def __init__(self, config_dir: Optional[Union[str, Path]] = None):
        """
        Initialize configuration manager.
        
        Args:
            config_dir: Directory for storing configurations
        """
        self.config_dir = Path(config_dir) if config_dir else Path("./config")
        self.config_dir.mkdir(parents=True, exist_ok=True)
        
        self.logger = logging.getLogger(__name__)
        
        # Default configuration
        self.default_config = self._create_default_config()
        
        # Load default configuration
        self.config = self.load_config("default")
    
    def _create_default_config(self) -> ScanConfiguration:
        """Create default scan configuration."""
        return ScanConfiguration(
            max_file_size=100 * 1024 * 1024,  # 100MB
            enable_pe_analysis=True,
            enable_elf_analysis=True,
            enable_macho_analysis=True,
            enable_entropy_analysis=True,
            enable_yara_scanning=True,
            enable_clamav_scanning=False,  # Disabled by default
            max_scan_threads=4,
            scan_timeout=30,
            quarantine_enabled=True,
            quarantine_path=Path("./quarantine"),
            log_level="INFO",
            cache_enabled=True,
            cache_ttl=3600,
            suspicious_threshold=0.7,
            malicious_threshold=0.8,
            auto_quarantine=False,
            max_quarantine_size=1024 * 1024 * 1024,  # 1GB
            real_time_enabled=False,  # Disabled by default for safety
            scheduled_scan_enabled=True,
            excluded_paths=[
                "/proc",
                "/sys",
                "/dev",
                "/tmp",
                "/var/tmp"
            ],
            excluded_extensions=[
                ".tmp", ".temp", ".log", ".cache", ".db",
                ".git", ".svn", ".hg", ".bzr"
            ]
        )
    
    def load_config(self, config_name: str = "default") -> Optional[ScanConfiguration]:
        """
        Load a configuration by name.
        
        Args:
            config_name: Name of the configuration to load
        
        Returns:
            ScanConfiguration object or None if not found
        """
        try:
            config_file = self.config_dir / f"{config_name}.json"
            
            if not config_file.exists():
                if config_name == "default":
                    # Create default configuration file
                    self.save_config("default", self.default_config)
                    return self.default_config
                else:
                    self.logger.warning(f"Configuration file not found: {config_file}")
                    return None
            
            with open(config_file, 'r') as f:
                data = json.load(f)
            
            # Validate configuration
            if not self._validate_config_data(data):
                self.logger.error(f"Invalid configuration data in {config_file}")
                return None
            
            # Create configuration object
            config = self._create_config_from_data(data)
            
            self.logger.info(f"Loaded configuration: {config_name}")
            return config
            
        except Exception as e:
            self.logger.error(f"Error loading configuration {config_name}: {e}")
            return None
    
    def save_config(self, config_name: str, config: ScanConfiguration) -> bool:
        """
        Save a configuration.
        
        Args:
            config_name: Name of the configuration
            config: ScanConfiguration object to save
        
        Returns:
            True if saved successfully, False otherwise
        """
        try:
            config_file = self.config_dir / f"{config_name}.json"
            
            # Create backup if exists
            if config_file.exists():
                backup_file = config_file.with_suffix('.json.backup')
                backup_file.write_bytes(config_file.read_bytes())
            
            # Save configuration
            data = self._config_to_dict(config)
            
            with open(config_file, 'w') as f:
                json.dump(data, f, indent=2, default=str)
            
            self.logger.info(f"Saved configuration: {config_name}")
            return True
            
        except Exception as e:
            self.logger.error(f"Error saving configuration {config_name}: {e}")
            return False
    
    def delete_config(self, config_name: str) -> bool:
        """
        Delete a configuration.
        
        Args:
            config_name: Name of the configuration to delete
        
        Returns:
            True if deleted successfully, False otherwise
        """
        try:
            if config_name == "default":
                self.logger.warning("Cannot delete default configuration")
                return False
            
            config_file = self.config_dir / f"{config_name}.json")
            
            if config_file.exists():
                config_file.unlink()
                self.logger.info(f"Deleted configuration: {config_name}")
                return True
            else:
                self.logger.warning(f"Configuration file not found: {config_name}")
                return False
            
        except Exception as e:
            self.logger.error(f"Error deleting configuration {config_name}: {e}")
            return False
    
    def list_configs(self) -> List[str]:
        """
        List available configurations.
        
        Returns:
            List of configuration names
        """
        try:
            config_files = list(self.config_dir.glob("*.json"))
            # Exclude backup files
            config_names = [
                f.stem for f in config_files 
                if not f.stem.endswith('.backup') and f.stem != 'default_backup'
            ]
            return sorted(config_names)
        except Exception as e:
            self.logger.error(f"Error listing configurations: {e}")
            return []
    
    def create_config_from_template(self, template_name: str, 
                                  new_config_name: str,
                                  overrides: Optional[Dict[str, Any]] = None) -> Optional[ScanConfiguration]:
        """
        Create a new configuration from a template.
        
        Args:
            template_name: Name of the template configuration
            new_config_name: Name for the new configuration
            overrides: Dictionary of values to override
        
        Returns:
            New ScanConfiguration object or None if failed
        """
        try:
            # Load template
            template = self.load_config(template_name)
            if not template:
                self.logger.error(f"Template configuration not found: {template_name}")
                return None
            
            # Create new config
            import copy
            new_config = copy.deepcopy(template)
            
            # Apply overrides
            if overrides:
                for key, value in overrides.items():
                    if hasattr(new_config, key):
                        setattr(new_config, key, value)
            
            # Save new configuration
            if self.save_config(new_config_name, new_config):
                return new_config
            else:
                return None
                
        except Exception as e:
            self.logger.error(f"Error creating configuration from template: {e}")
            return None
    
    def get_config_names(self) -> List[str]:
        """Get list of available configuration names."""
        return self.list_configs()
    
    def config_exists(self, config_name: str) -> bool:
        """
        Check if a configuration exists.
        
        Args:
            config_name: Name of the configuration to check
        
        Returns:
            True if configuration exists, False otherwise
        """
        config_file = self.config_dir / f"{config_name}.json"
        return config_file.exists()
    
    def validate_config(self, config: ScanConfiguration) -> List[str]:
        """
        Validate a scan configuration.
        
        Args:
            config: ScanConfiguration to validate
        
        Returns:
            List of validation errors (empty if valid)
        """
        errors = []
        
        # Validate file size limits
        if config.max_file_size <= 0:
            errors.append("max_file_size must be positive")
        
        # Validate thread count
        if config.max_scan_threads <= 0 or config.max_scan_threads > 64:
            errors.append("max_scan_threads must be between 1 and 64")
        
        # Validate timeout
        if config.scan_timeout <= 0:
            errors.append("scan_timeout must be positive")
        
        # Validate thresholds
        if not (0.0 <= config.suspicious_threshold <= 1.0):
            errors.append("suspicious_threshold must be between 0.0 and 1.0")
        
        if not (0.0 <= config.malicious_threshold <= 1.0):
            errors.append("malicious_threshold must be between 0.0 and 1.0")
        
        if config.suspicious_threshold > config.malicious_threshold:
            errors.append("suspicious_threshold must be <= malicious_threshold")
        
        # Validate cache TTL
        if config.cache_ttl <= 0:
            errors.append("cache_ttl must be positive")
        
        # Validate log level
        valid_log_levels = ["DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"]
        if config.log_level.upper() not in valid_log_levels:
            errors.append(f"log_level must be one of: {', '.join(valid_log_levels)}")
        
        # Validate paths
        if config.quarantine_path:
            try:
                config.quarantine_path.mkdir(parents=True, exist_ok=True)
            except Exception as e:
                errors.append(f"Invalid quarantine_path: {e}")
        
        # Validate quarantine size
        if config.max_quarantine_size <= 0:
            errors.append("max_quarantine_size must be positive")
        
        return errors
    
    def _validate_config_data(self, data: Dict[str, Any]) -> bool:
        """Validate configuration data structure."""
        required_fields = [
            'max_file_size', 'max_scan_threads', 'scan_timeout',
            'suspicious_threshold', 'malicious_threshold', 'log_level'
        ]
        
        for field in required_fields:
            if field not in data:
                return False
        
        return True
    
    def _create_config_from_data(self, data: Dict[str, Any]) -> ScanConfiguration:
        """Create ScanConfiguration from dictionary data."""
        # Set defaults for missing fields
        defaults = self._config_to_dict(self.default_config)
        for key, value in defaults.items():
            if key not in data:
                data[key] = value
        
        # Convert path strings to Path objects
        if 'quarantine_path' in data:
            data['quarantine_path'] = Path(data['quarantine_path'])
        
        return ScanConfiguration(**data)
    
    def _config_to_dict(self, config: ScanConfiguration) -> Dict[str, Any]:
        """Convert ScanConfiguration to dictionary."""
        result = config.to_dict()
        
        # Convert Path objects to strings
        if 'quarantine_path' in result and isinstance(result['quarantine_path'], Path):
            result['quarantine_path'] = str(result['quarantine_path'])
        
        return result
    
    def export_configs(self, export_dir: Union[str, Path]) -> bool:
        """
        Export all configurations to a directory.
        
        Args:
            export_dir: Directory to export configurations to
        
        Returns:
            True if export successful, False otherwise
        """
        try:
            export_dir = Path(export_dir)
            export_dir.mkdir(parents=True, exist_ok=True)
            
            for config_name in self.get_config_names():
                config = self.load_config(config_name)
                if config:
                    export_file = export_dir / f"{config_name}.json"
                    self.save_config_to_file(config, export_file)
            
            self.logger.info(f"Exported {len(self.get_config_names())} configurations to {export_dir}")
            return True
            
        except Exception as e:
            self.logger.error(f"Error exporting configurations: {e}")
            return False
    
    def import_configs(self, import_dir: Union[str, Path], 
                      overwrite: bool = False) -> bool:
        """
        Import configurations from a directory.
        
        Args:
            import_dir: Directory containing configuration files
            overwrite: Whether to overwrite existing configurations
        
        Returns:
            True if import successful, False otherwise
        """
        try:
            import_dir = Path(import_dir)
            if not import_dir.exists():
                return False
            
            config_files = list(import_dir.glob("*.json"))
            imported_count = 0
            
            for config_file in config_files:
                config_name = config_file.stem
                
                if not overwrite and self.config_exists(config_name):
                    continue
                
                try:
                    with open(config_file, 'r') as f:
                        data = json.load(f)
                    
                    if self._validate_config_data(data):
                        config = self._create_config_from_data(data)
                        if self.save_config(config_name, config):
                            imported_count += 1
                except Exception as e:
                    self.logger.error(f"Error importing {config_name}: {e}")
            
            self.logger.info(f"Imported {imported_count} configurations from {import_dir}")
            return True
            
        except Exception as e:
            self.logger.error(f"Error importing configurations: {e}")
            return False
    
    def save_config_to_file(self, config: ScanConfiguration, file_path: Path) -> bool:
        """Save configuration to a specific file path."""
        try:
            data = self._config_to_dict(config)
            
            with open(file_path, 'w') as f:
                json.dump(data, f, indent=2, default=str)
            
            return True
            
        except Exception as e:
            self.logger.error(f"Error saving config to file {file_path}: {e}")
            return False


class PresetConfigurations:
    """Predefined configuration templates for common use cases."""
    
    @staticmethod
    def get_fast_scan_config() -> ScanConfiguration:
        """Configuration for fast scanning with basic analysis."""
        return ScanConfiguration(
            max_file_size=50 * 1024 * 1024,  # 50MB
            enable_pe_analysis=True,
            enable_elf_analysis=False,  # Skip for speed
            enable_macho_analysis=False,  # Skip for speed
            enable_entropy_analysis=True,
            enable_yara_scanning=True,
            enable_clamav_scanning=False,
            max_scan_threads=8,  # More threads for speed
            scan_timeout=15,  # Shorter timeout
            quarantine_enabled=True,
            quarantine_path=Path("./quarantine"),
            cache_enabled=True,
            cache_ttl=1800,  # 30 minutes
            suspicious_threshold=0.6,
            malicious_threshold=0.8,
            auto_quarantine=True,
            real_time_enabled=False
        )
    
    @staticmethod
    def get_thorough_scan_config() -> ScanConfiguration:
        """Configuration for thorough scanning with all features."""
        return ScanConfiguration(
            max_file_size=500 * 1024 * 1024,  # 500MB
            enable_pe_analysis=True,
            enable_elf_analysis=True,
            enable_macho_analysis=True,
            enable_entropy_analysis=True,
            enable_yara_scanning=True,
            enable_clamav_scanning=True,
            max_scan_threads=2,  # Fewer threads for stability
            scan_timeout=120,  # Longer timeout
            quarantine_enabled=True,
            quarantine_path=Path("./quarantine"),
            cache_enabled=True,
            cache_ttl=7200,  # 2 hours
            suspicious_threshold=0.7,
            malicious_threshold=0.8,
            auto_quarantine=True,
            real_time_enabled=False,
            custom_rules=[]  # Add custom rules as needed
        )
    
    @staticmethod
    def get_realtime_protection_config() -> ScanConfiguration:
        """Configuration for real-time protection."""
        return ScanConfiguration(
            max_file_size=25 * 1024 * 1024,  # 25MB
            enable_pe_analysis=True,
            enable_elf_analysis=False,  # Skip for speed
            enable_macho_analysis=False,  # Skip for speed
            enable_entropy_analysis=False,  # Skip for speed
            enable_yara_scanning=True,
            enable_clamav_scanning=False,
            max_scan_threads=2,  # Fewer threads for responsiveness
            scan_timeout=5,  # Very short timeout
            quarantine_enabled=True,
            quarantine_path=Path("./quarantine"),
            cache_enabled=True,
            cache_ttl=300,  # 5 minutes
            suspicious_threshold=0.5,  # Lower threshold for real-time
            malicious_threshold=0.7,  # Lower threshold for real-time
            auto_quarantine=False,  # Manual review for real-time
            real_time_enabled=True
        )
    
    @staticmethod
    def get_custom_scan_config(max_file_size: int = 100 * 1024 * 1024,
                             max_threads: int = 4,
                             timeout: int = 30,
                             quarantine: bool = True) -> ScanConfiguration:
        """Create custom configuration with specified parameters."""
        return ScanConfiguration(
            max_file_size=max_file_size,
            enable_pe_analysis=True,
            enable_elf_analysis=True,
            enable_macho_analysis=True,
            enable_entropy_analysis=True,
            enable_yara_scanning=True,
            enable_clamav_scanning=False,
            max_scan_threads=max_threads,
            scan_timeout=timeout,
            quarantine_enabled=quarantine,
            quarantine_path=Path("./quarantine"),
            cache_enabled=True,
            cache_ttl=3600,
            suspicious_threshold=0.7,
            malicious_threshold=0.8,
            auto_quarantine=False
        )
