# File Scanner Module

A comprehensive, multi-threaded file scanning engine for antivirus and security applications. Built with Python and designed for high-performance file analysis, threat detection, and quarantine management.

## Overview

The File Scanner Module is a core component of the AI-based antivirus system, providing:

- **Multi-threaded file scanning** with configurable performance settings
- **PE file analysis** for Windows executables with detailed structural analysis
- **File type detection** supporting multiple formats (PE, ELF, Mach-O, archives, documents)
- **Suspicious pattern detection** using heuristics and behavioral analysis
- **Quarantine management** with secure storage and restoration capabilities
- **Scan scheduling** with cron-like scheduling for automated scanning
- **Configuration management** with preset configurations and validation

## Architecture

The module follows a modular architecture with the following components:

```
scanner/
├── __init__.py                 # Module initialization
├── models.py                  # Data models and enums
├── scanner_engine.py          # Main scanning engine
├── pe_analyzer.py            # PE file analyzer
├── file_detector.py          # File type detection
├── pattern_detector.py       # Suspicious pattern detection
├── quarantine_manager.py     # Quarantine management
├── scan_scheduler.py         # Scheduled scanning
├── scan_config.py            # Configuration management
└── test_scanner.py           # Comprehensive test suite
```

## Key Features

### 1. File Scanner Engine (`FileScannerEngine`)

The main orchestrator that provides:

- **Multi-threaded scanning** with configurable thread pools
- **Caching system** to avoid rescanning identical files
- **Result aggregation** from multiple detection engines
- **Statistics tracking** and performance monitoring
- **Async task queuing** for background processing

```python
from scanner import FileScannerEngine, ScanConfiguration

# Create configuration
config = ScanConfiguration(
    max_scan_threads=4,
    enable_pe_analysis=True,
    quarantine_enabled=True
)

# Initialize scanner
scanner = FileScannerEngine(config)
scanner.start()

# Scan a file
result = scanner.scan_file("suspicious_file.exe")
print(f"Threat level: {result.threat_level}")
print(f"Clean: {result.is_clean}")

scanner.stop()
```

### 2. PE Analyzer (`PEAnalyzer`)

Specialized analyzer for Windows PE files:

- **Header parsing** (DOS, PE, Optional headers)
- **Section analysis** with entropy calculation
- **Import/Export table parsing**
- **Resource extraction**
- **Packer detection** (UPX, ASPack, etc.)
- **Suspicious indicator identification**

```python
from scanner import PEAnalyzer, FileInfo

analyzer = PEAnalyzer()
file_info = FileInfo(Path("windows_exe.exe"))
result = analyzer.analyze_pe_file(file_info)

print(f"Valid PE: {result['is_valid_pe']}")
print(f"Entropy: {result['entropy']}")
print(f"Packers: {result['packer_detected']}")
```

### 3. File Type Detector (`FileTypeDetector`)

Intelligent file type identification:

- **Magic number detection** (file signatures)
- **Extension-based detection** with validation
- **Content analysis** for text and scripts
- **MIME type mapping**
- **Structure analysis** for archives and documents

```python
from scanner import FileTypeDetector, FileInfo

detector = FileTypeDetector()
file_info = FileInfo(Path("unknown_file"))
result = detector.detect_file_type(file_info)

print(f"File type: {result['file_type']}")
print(f"Executable: {result['is_executable']}")
print(f"MIME type: {result['mime_type']}")
```

### 4. Pattern Detector (`SuspiciousPatternDetector`)

Advanced pattern detection for:

- **Shellcode patterns** (x86/x64)
- **Suspicious strings** (network, system operations)
- **Anti-analysis techniques** (debugger detection, timing checks)
- **Behavioral indicators** (file system, registry, process operations)
- **Crypto indicators** (encryption algorithms, hash functions)

```python
from scanner import SuspiciousPatternDetector, FileInfo

detector = SuspiciousPatternDetector()
file_info = FileInfo(Path("suspicious_file"))
result = detector.analyze_file(file_info)

print(f"Suspicion score: {result['suspicion_score']}")
print(f"Risk level: {result['risk_level']}")
print(f"Patterns found: {len(result['patterns'])}")
```

### 5. Quarantine Manager (`QuarantineManager`)

Secure file quarantine system:

- **Secure file storage** with read-only permissions
- **Metadata tracking** with JSON persistence
- **File restoration** to original or custom locations
- **Search and filtering** capabilities
- **Automated cleanup** for old entries
- **Export/Import** functionality

```python
from scanner import QuarantineManager, ScanResult

quarantine = QuarantineManager(Path("./quarantine"))

# Quarantine a file
success = quarantine.quarantine_file("suspicious.exe", scan_result)

# Restore quarantined file
entry_id = quarantine.get_file_quarantine_id("suspicious.exe")
quarantine.restore_file(entry_id, "restored_file.exe")
```

### 6. Scan Scheduler (`ScanScheduler`)

Flexible scheduling system:

- **Multiple schedule types** (once, hourly, daily, weekly, monthly)
- **Custom cron expressions** for advanced scheduling
- **Priority-based execution** with concurrent scan limits
- **Event callbacks** for scan start/completion
- **Statistics and monitoring** capabilities

```python
from scanner import ScanScheduler, ScanSchedule, ScheduleType

scheduler = ScanScheduler(scanner)
scheduler.start()

# Add daily scan
schedule = ScanSchedule(
    schedule_id="daily_scan",
    name="Daily System Scan",
    schedule_type=ScheduleType.DAILY,
    target_path=Path("/system/scan"),
    parameters={"run_time": "02:00"}
)
scheduler.add_schedule(schedule)
```

### 7. Configuration Management (`ConfigurationManager`)

Robust configuration system:

- **Multiple configuration profiles** with inheritance
- **Preset configurations** (fast, thorough, real-time)
- **Validation and error checking**
- **Export/Import** functionality
- **Configuration templates**

```python
from scanner import ConfigurationManager, PresetConfigurations

config_manager = ConfigurationManager()

# Use preset configuration
config = PresetConfigurations.get_fast_scan_config()

# Save custom configuration
config_manager.save_config("custom_scan", config)

# Load configuration
loaded_config = config_manager.load_config("custom_scan")
```

## Installation and Setup

### Requirements

```python
# Core dependencies
pathlib  # Built-in
threading  # Built-in
queue  # Built-in
datetime  # Built-in
json  # Built-in
logging  # Built-in
hashlib  # Built-in
math  # Built-in
struct  # Built-in
re  # Built-in
uuid  # Built-in
dataclasses  # Built-in
enum  # Built-in
asyncio  # Built-in
shutil  # Built-in
```

### Optional Dependencies

```bash
# For enhanced PE parsing
pip install pefile

# For YARA integration
pip install yara-python

# For ClamAV integration
pip install pyclamd

# For advanced file analysis
pip install python-magic
```

### Basic Setup

```python
from scanner import FileScannerEngine, ScanConfiguration, PresetConfigurations

# Use preset configuration
config = PresetConfigurations.get_fast_scan_config()

# Customize configuration
config.max_file_size = 50 * 1024 * 1024  # 50MB
config.auto_quarantine = True

# Initialize and start scanner
scanner = FileScannerEngine(config)
scanner.start()

# Perform scanning
result = scanner.scan_file("test_file.exe")
print(f"Scan result: {result.to_dict()}")

scanner.stop()
```

## Configuration Options

### ScanConfiguration Parameters

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `max_file_size` | int | 100MB | Maximum file size to scan |
| `max_scan_threads` | int | 4 | Number of scanning threads |
| `scan_timeout` | int | 30 | Scan timeout in seconds |
| `enable_pe_analysis` | bool | True | Enable PE file analysis |
| `enable_elf_analysis` | bool | True | Enable ELF file analysis |
| `enable_macho_analysis` | bool | True | Enable Mach-O file analysis |
| `enable_entropy_analysis` | bool | True | Enable entropy calculation |
| `enable_yara_scanning` | bool | True | Enable YARA rule scanning |
| `enable_clamav_scanning` | bool | False | Enable ClamAV scanning |
| `quarantine_enabled` | bool | True | Enable quarantine functionality |
| `quarantine_path` | Path | ./quarantine | Quarantine directory |
| `cache_enabled` | bool | True | Enable result caching |
| `cache_ttl` | int | 3600 | Cache TTL in seconds |
| `suspicious_threshold` | float | 0.7 | Suspicious threshold (0-1) |
| `malicious_threshold` | float | 0.8 | Malicious threshold (0-1) |
| `auto_quarantine` | bool | False | Auto-quarantine malicious files |
| `real_time_enabled` | bool | True | Enable real-time protection |

## Usage Examples

### Basic File Scanning

```python
from scanner import FileScannerEngine, ScanConfiguration

# Initialize scanner
config = ScanConfiguration()
scanner = FileScannerEngine(config)
scanner.start()

# Scan single file
result = scanner.scan_file("suspicious_file.exe")
if not result.is_clean:
    print(f"Threat detected: {result.threat_level}")
    print(f"Threats: {[t.name for t in result.threats]}")

# Scan multiple files
files_to_scan = ["file1.exe", "file2.dll", "file3.sys"]
results = scanner.scan_files(files_to_scan)

scanner.stop()
```

### Directory Scanning

```python
# Scan entire directory
results = scanner.scan_directory(
    directory="/path/to/scan",
    recursive=True,
    file_extensions=[".exe", ".dll", ".sys"]  # Only scan executables
)

print(f"Scanned {len(results)} files")
clean_count = sum(1 for r in results if r.is_clean)
print(f"Clean files: {clean_count}")
print(f"Threats found: {len(results) - clean_count}")
```

### Quarantine Management

```python
# Quarantine suspicious file
result = scanner.scan_file("suspicious_file.exe")
if result.threat_level.value >= ThreatLevel.SUSPICIOUS.value:
    success = scanner.quarantine_file("suspicious_file.exe", result)
    if success:
        print("File quarantined successfully")

# List quarantined files
quarantined_files = scanner.get_quarantined_files()
for entry in quarantined_files:
    print(f"Quarantined: {entry['original_path']}")
    print(f"Reason: {entry['reason']}")
    print(f"Timestamp: {entry['quarantine_timestamp']}")

# Restore file
scanner.restore_quarantined_file(quarantine_id, "restored_file.exe")
```

### Scheduled Scanning

```python
from scanner import ScanScheduler, ScanSchedule, ScheduleType

# Create scheduler
scheduler = ScanScheduler(scanner)
scheduler.start()

# Add daily scan
daily_scan = ScanSchedule(
    schedule_id="daily_system_scan",
    name="Daily System Scan",
    schedule_type=ScheduleType.DAILY,
    target_path=Path("/system"),
    parameters={"run_time": "02:00"},  # 2 AM
    enabled=True
)

scheduler.add_schedule(daily_scan)

# Add weekly full scan
weekly_scan = ScanSchedule(
    schedule_id="weekly_full_scan",
    name="Weekly Full System Scan",
    schedule_type=ScheduleType.WEEKLY,
    target_path=Path("/"),
    parameters={
        "run_time": "01:00",  # 1 AM
        "day_of_week": 1     # Monday
    },
    recursive=True,
    enabled=True
)

scheduler.add_schedule(weekly_scan)

# Get scheduler statistics
stats = scheduler.get_statistics()
print(f"Total schedules: {stats['total_schedules']}")
print(f"Enabled schedules: {stats['enabled_schedules']}")
print(f"Active scans: {stats['active_scans']}")
```

### Custom Configuration

```python
from scanner import ConfigurationManager, PresetConfigurations

# Use configuration manager
config_manager = ConfigurationManager()

# Get preset configuration
fast_config = PresetConfigurations.get_fast_scan_config()
thorough_config = PresetConfigurations.get_thorough_scan_config()
realtime_config = PresetConfigurations.get_realtime_protection_config()

# Create custom configuration
custom_config = PresetConfigurations.get_custom_scan_config(
    max_file_size=25 * 1024 * 1024,  # 25MB
    max_threads=2,
    timeout=10,
    quarantine=True
)

# Save and load configurations
config_manager.save_config("my_scan_config", custom_config)
loaded_config = config_manager.load_config("my_scan_config")

# Validate configuration
errors = config_manager.validate_config(custom_config)
if errors:
    print(f"Configuration errors: {errors}")
else:
    print("Configuration is valid")
```

## Performance Optimization

### Thread Configuration

```python
# For I/O-bound operations (file reading)
config = ScanConfiguration(max_scan_threads=8)

# For CPU-bound operations (PE analysis)
config = ScanConfiguration(max_scan_threads=2)

# For balanced performance
config = ScanConfiguration(max_scan_threads=4)
```

### Caching Strategy

```python
# Enable aggressive caching for repeated scans
config = ScanConfiguration(
    cache_enabled=True,
    cache_ttl=7200,  # 2 hours
    suspicious_threshold=0.6,
    malicious_threshold=0.8
)

# Minimal caching for real-time scanning
config = ScanConfiguration(
    cache_enabled=True,
    cache_ttl=300,  # 5 minutes
    real_time_enabled=True
)
```

### File Size Limits

```python
# Small files for quick scans
config = ScanConfiguration(max_file_size=10 * 1024 * 1024)  # 10MB

# Large files for thorough analysis
config = ScanConfiguration(max_file_size=500 * 1024 * 1024)  # 500MB
```

## Integration Examples

### With ClamAV

```python
# The scanner can integrate with ClamAV for signature-based detection
config = ScanConfiguration(enable_clamav_scanning=True)

# Note: Requires ClamAV daemon running on localhost:3310
```

### With YARA

```python
# Enable YARA rule scanning for advanced pattern detection
config = ScanConfiguration(enable_yara_scanning=True)

# Add custom YARA rules
config.custom_rules = [
    {
        "name": "custom_suspicious_pattern",
        "condition": "uint16(0) == 0x5A4D",  # MZ signature
        "description": "Custom suspicious pattern rule"
    }
]
```

### With SIEM Integration

```python
# Export scan results for SIEM
def export_results_for_siem(scanner, output_file):
    stats = scanner.get_scan_statistics()
    
    with open(output_file, 'w') as f:
        json.dump({
            'timestamp': datetime.now().isoformat(),
            'statistics': stats,
            'quarantine_entries': scanner.get_quarantined_files()
        }, f, indent=2, default=str)
```

## Testing

Run the comprehensive test suite:

```python
# Run all tests
python -m scanner.test_scanner

# Run performance test
python -c "from scanner.test_scanner import run_performance_test; run_performance_test()"

# Run specific test class
python -m unittest scanner.test_scanner.TestFileScannerEngine
```

Test coverage includes:
- File scanning functionality
- PE analysis capabilities
- File type detection
- Pattern detection algorithms
- Quarantine management
- Scheduled scanning
- Configuration management
- Performance benchmarking

## Security Considerations

### File Isolation
- All files are handled with appropriate permissions
- Quarantined files are stored read-only
- Temporary files are cleaned up automatically

### Memory Management
- Large files are processed in chunks
- Memory usage is monitored and limited
- Proper resource cleanup is enforced

### Input Validation
- All file paths are validated
- Configuration parameters are validated
- File type detection prevents buffer overflows

## Best Practices

### 1. Configuration Management
- Use preset configurations for common scenarios
- Validate custom configurations before deployment
- Maintain configuration backups

### 2. Performance Optimization
- Tune thread count based on system resources
- Use appropriate file size limits
- Enable caching for repeated scanning scenarios

### 3. Security Operations
- Enable quarantine for suspicious files
- Implement regular cleanup of old entries
- Monitor and review scan results regularly

### 4. Monitoring and Logging
- Enable detailed logging for troubleshooting
- Monitor scan statistics and performance metrics
- Set up alerts for critical threat detections

## API Reference

### Main Classes

#### `FileScannerEngine`
- `scan_file(file_path, scan_mode, priority) -> ScanResult`
- `scan_files(file_paths, scan_mode, max_workers) -> List[ScanResult]`
- `scan_directory(directory, recursive, file_extensions) -> List[ScanResult]`
- `quarantine_file(file_path, scan_result) -> bool`
- `get_scan_statistics() -> Dict[str, Any]`
- `start() -> None`
- `stop() -> None`

#### `PEAnalyzer`
- `analyze_pe_file(file_info) -> Dict[str, Any]`

#### `FileTypeDetector`
- `detect_file_type(file_info) -> Dict[str, Any]`
- `analyze_file_structure(file_info) -> Dict[str, Any]`

#### `SuspiciousPatternDetector`
- `analyze_file(file_info) -> Dict[str, Any]`
- `analyze_network_indicators(file_path) -> Dict[str, Any]`
- `analyze_crypto_indicators(file_path) -> Dict[str, Any]`

#### `QuarantineManager`
- `quarantine_file(file_path, scan_result) -> bool`
- `restore_file(quarantine_id, target_path) -> bool`
- `delete_file(quarantine_id) -> bool`
- `get_entries() -> List[QuarantineEntry]`
- `get_statistics() -> Dict[str, Any]`

#### `ScanScheduler`
- `add_schedule(schedule) -> bool`
- `remove_schedule(schedule_id) -> bool`
- `run_schedule_now(schedule_id) -> bool`
- `get_statistics() -> Dict[str, Any]`

## Contributing

1. Follow the existing code structure and patterns
2. Add comprehensive tests for new features
3. Update documentation for API changes
4. Ensure backward compatibility
5. Follow security best practices

## License

This module is part of the AI-based antivirus system and follows the same licensing terms.

## Support

For issues and questions:
- Check the test suite for usage examples
- Review the API documentation
- Consult the configuration guide
- Examine the performance optimization notes
