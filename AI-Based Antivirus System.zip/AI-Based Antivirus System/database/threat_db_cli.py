#!/usr/bin/env python3
"""
Threat Database Management CLI
Command-line interface for managing the threat database system
"""

import argparse
import sys
import json
import os
from pathlib import Path
from typing import Optional
import logging

# Add parent directory to path for imports
sys.path.append(str(Path(__file__).parent))

try:
    from database import (
        create_threat_database_system,
        initialize_sample_data,
        get_system_status,
        quick_scan_file,
        generate_sample_reports,
        ThreatSignature,
        ThreatLevel,
        SignatureType
    )
    from database.threat_intel import MockThreatIntelSources
except ImportError as e:
    print(f"Error importing database modules: {e}")
    print("Please ensure the database module is properly installed and configured.")
    sys.exit(1)

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

def init_database(args):
    """Initialize the threat database with sample data"""
    try:
        print("Initializing threat database system...")
        
        # Create system
        database, quarantine, threat_intel, analyzer, backup = create_threat_database_system()
        
        # Initialize sample data
        if args.sample_data:
            print("Adding sample threat data...")
            initialize_sample_data(database, threat_intel)
        
        # Create initial backup
        if args.create_backup:
            print("Creating initial backup...")
            success, message, backup_info = backup.create_full_backup("Initial database backup")
            if success:
                print(f"✓ Backup created: {backup_info.backup_id}")
            else:
                print(f"✗ Backup failed: {message}")
        
        # Get system status
        status = get_system_status(database, quarantine, threat_intel, backup)
        
        print("\n" + "="*50)
        print("DATABASE INITIALIZATION COMPLETE")
        print("="*50)
        print(f"Database Path: {status['database']['database_path']}")
        print(f"Total Signatures: {status['database']['total_signatures']}")
        print(f"System Health: {status['overall_health']} ({status['health_score']}/100)")
        print(f"Backup Status: {status['backup']['total_backups']} backups")
        
        if args.verbose:
            print("\nDetailed Status:")
            print(json.dumps(status, indent=2, default=str))
        
        print("\nSystem is ready for use!")
        
    except Exception as e:
        print(f"Error initializing database: {e}")
        sys.exit(1)

def scan_file(args):
    """Scan a file against the threat database"""
    try:
        if not os.path.exists(args.file_path):
            print(f"Error: File not found: {args.file_path}")
            sys.exit(1)
        
        # Initialize minimal system
        database, _, _, _, _ = create_threat_database_system()
        
        # Perform scan
        result = quick_scan_file(args.file_path, database)
        
        print(f"File: {result['file_path']}")
        print(f"Hash: {result['file_hash']}")
        
        if result['threat_detected']:
            print(f"⚠️  THREAT DETECTED!")
            print(f"Threat Name: {result['threat_name']}")
            print(f"Threat Level: {result['threat_level']}")
            print(f"Confidence: {result['confidence']:.2%}")
            
            if args.verbose:
                print(f"Signature Details: {json.dumps(result['signature'], indent=2)}")
        else:
            print("✓ No threats detected")
            
    except Exception as e:
        print(f"Error scanning file: {e}")
        sys.exit(1)

def add_signature(args):
    """Add a new threat signature to the database"""
    try:
        database, _, _, _, _ = create_threat_database_system()
        
        # Create signature
        signature = ThreatSignature(
            name=args.name,
            type=args.type,
            content=args.content,
            description=args.description,
            threat_level=args.threat_level,
            source=args.source or "manual",
            confidence_score=args.confidence
        )
        
        # Add to database
        signature_id = database.add_signature(signature)
        
        print(f"✓ Signature added successfully (ID: {signature_id})")
        print(f"Name: {args.name}")
        print(f"Type: {args.type}")
        print(f"Content: {args.content[:50]}...")
        
    except Exception as e:
        print(f"Error adding signature: {e}")
        sys.exit(1)

def quarantine_file(args):
    """Quarantine a file"""
    try:
        database, quarantine, _, _, _ = create_threat_database_system()
        
        if not os.path.exists(args.file_path):
            print(f"Error: File not found: {args.file_path}")
            sys.exit(1)
        
        # Quarantine file
        success, message, quarantine_id = quarantine.quarantine_file(
            args.file_path,
            threat_name=args.threat_name or "Unknown",
            threat_level=args.threat_level,
            reason=args.reason or "Manual quarantine"
        )
        
        if success:
            print(f"✓ File quarantined successfully")
            print(f"Quarantine ID: {quarantine_id}")
            print(f"Message: {message}")
        else:
            print(f"✗ Quarantine failed: {message}")
            sys.exit(1)
            
    except Exception as e:
        print(f"Error quarantining file: {e}")
        sys.exit(1)

def list_signatures(args):
    """List threat signatures in the database"""
    try:
        database, _, _, _, _ = create_threat_database_system()
        
        # Search signatures
        signatures = database.search_signatures(
            query_type=args.type,
            threat_level=args.threat_level,
            active_only=not args.include_inactive
        )
        
        print(f"Found {len(signatures)} signatures:")
        print("-" * 80)
        
        for sig in signatures[:args.limit]:
            print(f"ID: {sig['id']}")
            print(f"Name: {sig['name']}")
            print(f"Type: {sig['type']}")
            print(f"Level: {sig['threat_level']}")
            print(f"Confidence: {sig['confidence_score']:.2%}")
            print(f"Usage: {sig['usage_count']}")
            print(f"Updated: {sig['last_updated']}")
            print("-" * 40)
            
    except Exception as e:
        print(f"Error listing signatures: {e}")
        sys.exit(1)

def generate_report(args):
    """Generate threat analysis report"""
    try:
        database, quarantine, threat_intel, analyzer, backup = create_threat_database_system()
        
        # Generate report
        report = analyzer.generate_comprehensive_report(
            report_type=args.report_type,
            days=args.days
        )
        
        # Export report
        output_file = args.output or f"threat_report_{args.report_type}.{args.format}"
        
        success = analyzer.export_report(
            report_data=report,
            output_file=output_file,
            format_type=args.format
        )
        
        if success:
            print(f"✓ Report generated: {output_file}")
            
            if args.create_charts:
                chart_file = f"threat_trends_{args.report_type}.png"
                chart_success = analyzer.create_visualization("threat_trends", chart_file)
                if chart_success:
                    print(f"✓ Chart generated: {chart_file}")
        else:
            print("✗ Report generation failed")
            sys.exit(1)
            
    except Exception as e:
        print(f"Error generating report: {e}")
        sys.exit(1)

def create_backup(args):
    """Create database backup"""
    try:
        database, _, _, _, backup = create_threat_database_system()
        
        backup_type = args.type
        description = args.description or f"Manual {backup_type} backup"
        
        if backup_type == "full":
            success, message, backup_info = backup.create_full_backup(description)
        elif backup_type == "incremental":
            success, message, backup_info = backup.create_incremental_backup(
                base_backup_id=args.base_backup,
                description=description
            )
        else:
            print(f"Error: Unknown backup type: {backup_type}")
            sys.exit(1)
        
        if success:
            print(f"✓ {backup_type.capitalize()} backup created")
            print(f"Backup ID: {backup_info.backup_id}")
            print(f"Size: {backup_info.size_bytes} bytes")
            print(f"File: {backup_info.filepath}")
        else:
            print(f"✗ Backup failed: {message}")
            sys.exit(1)
            
    except Exception as e:
        print(f"Error creating backup: {e}")
        sys.exit(1)

def list_backups(args):
    """List available backups"""
    try:
        database, _, _, _, backup = create_threat_database_system()
        
        backups = backup.list_backups()
        
        print(f"Available backups ({len(backups)}):")
        print("-" * 80)
        
        for backup_info in backups:
            print(f"ID: {backup_info.backup_id}")
            print(f"Type: {backup_info.backup_type}")
            print(f"Created: {backup_info.created_at}")
            print(f"Size: {backup_info.size_bytes} bytes")
            print(f"Description: {backup_info.description}")
            print("-" * 40)
            
    except Exception as e:
        print(f"Error listing backups: {e}")
        sys.exit(1)

def system_status(args):
    """Show system status"""
    try:
        database, quarantine, threat_intel, backup = create_threat_database_system()
        
        status = get_system_status(database, quarantine, threat_intel, backup)
        
        print("THREAT DATABASE SYSTEM STATUS")
        print("="*50)
        print(f"Overall Health: {status['overall_health']}")
        print(f"Health Score: {status['health_score']}/100")
        
        print(f"\nDatabase:")
        print(f"  Total Signatures: {status['database']['total_signatures']}")
        print(f"  Database Size: {status['database']['size_mb']} MB")
        
        print(f"\nQuarantine:")
        print(f"  Quarantined Files: {status['quarantine']['total_quarantined']}")
        print(f"  Total Size: {status['quarantine']['total_size_mb']} MB")
        
        print(f"\nThreat Intelligence:")
        print(f"  Active Sources: {status['threat_intelligence']['active_sources']}")
        print(f"  Total Sources: {status['threat_intelligence']['total_sources']}")
        
        print(f"\nBackup:")
        print(f"  Total Backups: {status['backup']['total_backups']}")
        
        if args.verbose:
            print(f"\nDetailed Status:")
            print(json.dumps(status, indent=2, default=str))
            
    except Exception as e:
        print(f"Error getting system status: {e}")
        sys.exit(1)

def update_threat_intel(args):
    """Update threat intelligence from sources"""
    try:
        database, _, threat_intel, _, _ = create_threat_database_system()
        
        if args.source:
            # Update specific source
            success, count, message = threat_intel.update_from_source(args.source)
            print(f"Source update: {success}")
            print(f"Message: {message}")
            if count:
                print(f"Items imported: {count}")
        else:
            # Update all sources
            results = threat_intel.update_all_sources()
            print("Threat Intelligence Update Results:")
            print("-" * 40)
            
            for source_name, (success, count, message) in results.items():
                status = "✓" if success else "✗"
                print(f"{status} {source_name}: {message}")
                if count:
                    print(f"   Items imported: {count}")
                    
    except Exception as e:
        print(f"Error updating threat intelligence: {e}")
        sys.exit(1)

def main():
    """Main CLI entry point"""
    parser = argparse.ArgumentParser(
        description="Threat Database Management CLI",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  %(prog)s init --sample-data --create-backup
  %(prog)s scan /path/to/suspicious/file
  %(prog)s add-signature --name "Badware" --type hash_sha256 --content abc123...
  %(prog)s quarantine /path/to/file --threat-level high
  %(prog)s report --type comprehensive --format html
  %(prog)s backup create --type full
  %(prog)s status --verbose
        """
    )
    
    parser.add_argument('--verbose', '-v', action='store_true', 
                       help='Enable verbose output')
    parser.add_argument('--config', '-c', default='threat_database.yaml',
                       help='Configuration file path')
    
    subparsers = parser.add_subparsers(dest='command', help='Available commands')
    
    # Init command
    init_parser = subparsers.add_parser('init', help='Initialize the threat database')
    init_parser.add_argument('--sample-data', action='store_true',
                            help='Add sample threat data')
    init_parser.add_argument('--create-backup', action='store_true',
                            help='Create initial backup')
    
    # Scan command
    scan_parser = subparsers.add_parser('scan', help='Scan a file for threats')
    scan_parser.add_argument('file_path', help='Path to file to scan')
    
    # Add signature command
    add_sig_parser = subparsers.add_parser('add-signature', help='Add a threat signature')
    add_sig_parser.add_argument('--name', required=True, help='Signature name')
    add_sig_parser.add_argument('--type', required=True, 
                               choices=['hash_md5', 'hash_sha1', 'hash_sha256', 
                                       'pattern_string', 'pattern_bytes', 'yara_rule'],
                               help='Signature type')
    add_sig_parser.add_argument('--content', required=True, help='Signature content')
    add_sig_parser.add_argument('--description', help='Signature description')
    add_sig_parser.add_argument('--threat-level', default='medium',
                               choices=['low', 'medium', 'high', 'critical'],
                               help='Threat level')
    add_sig_parser.add_argument('--source', help='Signature source')
    add_sig_parser.add_argument('--confidence', type=float, default=0.8,
                               help='Confidence score (0.0-1.0)')
    
    # Quarantine command
    quarantine_parser = subparsers.add_parser('quarantine', help='Quarantine a file')
    quarantine_parser.add_argument('file_path', help='Path to file to quarantine')
    quarantine_parser.add_argument('--threat-name', help='Name of the threat')
    quarantine_parser.add_argument('--threat-level', default='medium',
                                  choices=['low', 'medium', 'high', 'critical'],
                                  help='Threat level')
    quarantine_parser.add_argument('--reason', help='Reason for quarantine')
    
    # List signatures command
    list_parser = subparsers.add_parser('list-signatures', help='List threat signatures')
    list_parser.add_argument('--type', help='Filter by signature type')
    list_parser.add_argument('--threat-level', help='Filter by threat level')
    list_parser.add_argument('--include-inactive', action='store_true',
                            help='Include inactive signatures')
    list_parser.add_argument('--limit', type=int, default=10,
                            help='Limit number of results')
    
    # Report command
    report_parser = subparsers.add_parser('report', help='Generate threat analysis report')
    report_parser.add_argument('--type', default='summary',
                              choices=['summary', 'trends', 'signatures', 'quarantine', 'comprehensive'],
                              help='Report type')
    report_parser.add_argument('--days', type=int, default=30, help='Report period in days')
    report_parser.add_argument('--format', default='json',
                              choices=['json', 'html', 'csv'],
                              help='Report format')
    report_parser.add_argument('--output', help='Output file path')
    report_parser.add_argument('--create-charts', action='store_true',
                              help='Create visualization charts')
    
    # Backup commands
    backup_parser = subparsers.add_parser('backup', help='Backup management')
    backup_subparsers = backup_parser.add_subparsers(dest='backup_action')
    
    backup_create_parser = backup_subparsers.add_parser('create', help='Create backup')
    backup_create_parser.add_argument('--type', default='full',
                                     choices=['full', 'incremental'],
                                     help='Backup type')
    backup_create_parser.add_argument('--description', help='Backup description')
    backup_create_parser.add_argument('--base-backup', help='Base backup ID for incremental')
    
    backup_list_parser = backup_subparsers.add_parser('list', help='List backups')
    
    # System status command
    status_parser = subparsers.add_parser('status', help='Show system status')
    
    # Update threat intelligence command
    update_parser = subparsers.add_parser('update-intel', help='Update threat intelligence')
    update_parser.add_argument('--source', help='Specific source to update')
    
    # Parse arguments
    args = parser.parse_args()
    
    if not args.command:
        parser.print_help()
        sys.exit(1)
    
    # Route to appropriate command handler
    command_handlers = {
        'init': init_database,
        'scan': scan_file,
        'add-signature': add_signature,
        'quarantine': quarantine_file,
        'list-signatures': list_signatures,
        'report': generate_report,
        'backup': handle_backup_command,
        'status': system_status,
        'update-intel': update_threat_intel
    }
    
    if args.command == 'backup':
        handle_backup_command(args)
    else:
        command_handlers[args.command](args)

def handle_backup_command(args):
    """Handle backup-related commands"""
    if args.backup_action == 'create':
        create_backup(args)
    elif args.backup_action == 'list':
        list_backups(args)
    else:
        print("Backup subcommand required. Use 'create' or 'list'")
        sys.exit(1)

if __name__ == "__main__":
    main()