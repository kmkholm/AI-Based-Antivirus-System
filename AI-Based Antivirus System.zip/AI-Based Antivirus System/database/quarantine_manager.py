#!/usr/bin/env python3
"""
Quarantine Management Module
Handles secure file quarantining, restoration, and management
"""

import os
import shutil
import json
import hashlib
import datetime
import tempfile
import uuid
from pathlib import Path
from typing import Dict, List, Optional, Any, Tuple
from dataclasses import dataclass
import logging
from threat_database import ThreatDatabase, QuarantineEntry, ThreatLevel

logger = logging.getLogger(__name__)

@dataclass
class QuarantineConfig:
    """Quarantine system configuration"""
    quarantine_directory: str = "quarantine"
    max_quarantine_size: int = 1024 * 1024 * 1024  # 1GB
    auto_delete_after_days: int = 30
    encryption_enabled: bool = False
    compression_enabled: bool = False
    allow_restore: bool = True
    backup_before_quarantine: bool = True
    scan_after_restore: bool = True
    max_file_size: int = 100 * 1024 * 1024  # 100MB

class QuarantineManager:
    """Manages file quarantining, restoration, and security"""
    
    def __init__(self, database: ThreatDatabase, config: QuarantineConfig = None):
        self.database = database
        self.config = config or QuarantineConfig()
        self.quarantine_dir = Path(self.config.quarantine_directory)
        self.quarantine_dir.mkdir(exist_ok=True)
        
        # Create subdirectories
        (self.quarantine_dir / "files").mkdir(exist_ok=True)
        (self.quarantine_dir / "metadata").mkdir(exist_ok=True)
        (self.quarantine_dir / "backups").mkdir(exist_ok=True)
        
        logger.info(f"Quarantine manager initialized: {self.quarantine_dir}")
    
    def quarantine_file(self, file_path: str, threat_name: str = "Unknown", 
                       threat_level: str = "medium", signature_id: int = None,
                       reason: str = "Manual quarantine", metadata: Dict = None) -> Tuple[bool, str, Optional[int]]:
        """
        Quarantine a file securely
        
        Returns:
            Tuple of (success, message, quarantine_id)
        """
        try:
            source_path = Path(file_path)
            
            # Validate file exists and is accessible
            if not source_path.exists():
                return False, f"File not found: {file_path}", None
            
            if not source_path.is_file():
                return False, f"Path is not a file: {file_path}", None
            
            # Check file size
            file_size = source_path.stat().st_size
            if file_size > self.config.max_file_size:
                return False, f"File too large ({file_size} bytes > {self.config.max_file_size} bytes)", None
            
            # Calculate file hash
            file_hash = self._calculate_file_hash(source_path)
            
            # Check if file is already quarantined
            existing = self.database.get_quarantine_list(status="quarantined")
            for entry in existing:
                if entry['file_hash'] == file_hash:
                    return False, f"File already quarantined (ID: {entry['id']})", entry['id']
            
            # Create unique quarantine path
            quarantine_filename = f"{uuid.uuid4().hex}_{source_path.name}"
            quarantine_path = self.quarantine_dir / "files" / quarantine_filename
            
            # Move file to quarantine
            try:
                if self.config.backup_before_quarantine:
                    backup_path = self.quarantine_dir / "backups" / f"{datetime.datetime.now().strftime('%Y%m%d_%H%M%S')}_{quarantine_filename}"
                    shutil.copy2(source_path, backup_path)
                
                # Move file to quarantine
                shutil.move(str(source_path), str(quarantine_path))
                
            except Exception as e:
                return False, f"Error moving file to quarantine: {e}", None
            
            # Create quarantine entry
            entry = QuarantineEntry(
                original_path=source_path.absolute().as_posix(),
                quarantine_path=quarantine_path.absolute().as_posix(),
                file_hash=file_hash,
                threat_name=threat_name,
                threat_level=threat_level,
                signature_id=signature_id,
                reason=reason,
                metadata=json.dumps(metadata) if metadata else None
            )
            
            quarantine_id = self.database.add_quarantine_entry(entry)
            
            # Save additional metadata
            self._save_quarantine_metadata(quarantine_id, source_path, file_size)
            
            logger.info(f"Quarantined file: {file_path} (ID: {quarantine_id})")
            return True, f"File quarantined successfully (ID: {quarantine_id})", quarantine_id
            
        except Exception as e:
            logger.error(f"Error quarantining file {file_path}: {e}")
            return False, f"Quarantine failed: {e}", None
    
    def restore_file(self, quarantine_id: int, force: bool = False) -> Tuple[bool, str]:
        """
        Restore a quarantined file to its original location
        
        Returns:
            Tuple of (success, message)
        """
        if not self.config.allow_restore:
            return False, "File restoration is disabled"
        
        try:
            # Get quarantine entry
            quarantine_list = self.database.get_quarantine_list()
            entry = None
            for q in quarantine_list:
                if q['id'] == quarantine_id:
                    entry = q
                    break
            
            if not entry:
                return False, f"Quarantine entry not found (ID: {quarantine_id})"
            
            if entry['status'] != 'quarantined':
                return False, f"File status is {entry['status']}, cannot restore"
            
            quarantine_path = Path(entry['quarantine_path'])
            original_path = Path(entry['original_path'])
            
            # Validate quarantine file exists
            if not quarantine_path.exists():
                return False, f"Quarantined file not found: {quarantine_path}"
            
            # Check if original location is available
            if original_path.exists() and not force:
                return False, f"Original file already exists: {original_path}. Use force=True to overwrite"
            
            # Restore file
            try:
                # Create parent directory if needed
                original_path.parent.mkdir(parents=True, exist_ok=True)
                
                # Move file back
                shutil.move(str(quarantine_path), str(original_path))
                
                # Update database
                self.database.restore_quarantined_file(quarantine_id)
                
                # Update metadata
                self._update_quarantine_metadata(quarantine_id, {
                    'restored_at': datetime.datetime.now().isoformat(),
                    'restored_to': original_path.absolute().as_posix()
                })
                
                logger.info(f"Restored file: {original_path} from quarantine (ID: {quarantine_id})")
                
                # Optional: scan after restore
                if self.config.scan_after_restore:
                    # This would trigger a rescan
                    logger.info(f"File marked for rescan: {original_path}")
                
                return True, f"File restored successfully to {original_path}"
                
            except Exception as e:
                return False, f"Error restoring file: {e}"
                
        except Exception as e:
            logger.error(f"Error restoring quarantine entry {quarantine_id}: {e}")
            return False, f"Restoration failed: {e}"
    
    def delete_quarantined_file(self, quarantine_id: int, permanent: bool = True) -> Tuple[bool, str]:
        """
        Delete a quarantined file permanently
        
        Returns:
            Tuple of (success, message)
        """
        try:
            # Get quarantine entry
            quarantine_list = self.database.get_quarantine_list()
            entry = None
            for q in quarantine_list:
                if q['id'] == quarantine_id:
                    entry = q
                    break
            
            if not entry:
                return False, f"Quarantine entry not found (ID: {quarantine_id})"
            
            quarantine_path = Path(entry['quarantine_path'])
            
            # Delete physical file if it exists
            if quarantine_path.exists():
                if permanent:
                    quarantine_path.unlink()
                else:
                    # Move to a deletion queue or mark for later deletion
                    deleted_path = quarantine_path.with_suffix('.deleted')
                    quarantine_path.rename(deleted_path)
            
            # Update database status
            with self.database._get_connection() as conn:
                cursor = conn.cursor()
                cursor.execute(
                    "UPDATE quarantine_files SET status = 'deleted' WHERE id = ?",
                    (quarantine_id,)
                )
                conn.commit()
            
            logger.info(f"Deleted quarantined file: {entry['original_path']} (ID: {quarantine_id})")
            return True, f"Quarantined file deleted successfully (ID: {quarantine_id})"
            
        except Exception as e:
            logger.error(f"Error deleting quarantine entry {quarantine_id}: {e}")
            return False, f"Deletion failed: {e}"
    
    def get_quarantine_status(self, quarantine_id: int) -> Optional[Dict[str, Any]]:
        """Get detailed status of a quarantined file"""
        try:
            quarantine_list = self.database.get_quarantine_list()
            for entry in quarantine_list:
                if entry['id'] == quarantine_id:
                    # Add additional metadata
                    metadata = self._load_quarantine_metadata(quarantine_id)
                    entry['detailed_metadata'] = metadata
                    
                    # Check if file exists
                    quarantine_path = Path(entry['quarantine_path'])
                    entry['file_exists'] = quarantine_path.exists()
                    entry['file_size'] = quarantine_path.stat().st_size if entry['file_exists'] else 0
                    
                    return entry
            
            return None
            
        except Exception as e:
            logger.error(f"Error getting quarantine status for {quarantine_id}: {e}")
            return None
    
    def list_quarantined_files(self, status: str = None, threat_level: str = None) -> List[Dict[str, Any]]:
        """List all quarantined files with filtering"""
        try:
            quarantine_list = self.database.get_quarantine_list(status=status)
            
            filtered_list = []
            for entry in quarantine_list:
                if threat_level and entry['threat_level'] != threat_level:
                    continue
                
                # Add file existence and size info
                quarantine_path = Path(entry['quarantine_path'])
                entry['file_exists'] = quarantine_path.exists()
                entry['current_size'] = quarantine_path.stat().st_size if entry['file_exists'] else 0
                
                # Add detailed metadata
                metadata = self._load_quarantine_metadata(entry['id'])
                entry['metadata_parsed'] = metadata
                
                filtered_list.append(entry)
            
            return filtered_list
            
        except Exception as e:
            logger.error(f"Error listing quarantined files: {e}")
            return []
    
    def cleanup_expired_files(self) -> Tuple[int, str]:
        """Clean up expired quarantined files"""
        if self.config.auto_delete_after_days <= 0:
            return 0, "Auto-deletion disabled"
        
        try:
            cutoff_date = datetime.datetime.now() - datetime.timedelta(days=self.config.auto_delete_after_days)
            
            with self.database._get_connection() as conn:
                cursor = conn.cursor()
                cursor.execute(
                    "SELECT id FROM quarantine_files WHERE status = 'quarantined' AND quarantine_time < ?",
                    (cutoff_date.isoformat(),)
                )
                expired_entries = cursor.fetchall()
            
            deleted_count = 0
            errors = []
            
            for entry in expired_entries:
                try:
                    success, message = self.delete_quarantined_file(entry['id'], permanent=True)
                    if success:
                        deleted_count += 1
                    else:
                        errors.append(f"ID {entry['id']}: {message}")
                except Exception as e:
                    errors.append(f"ID {entry['id']}: {e}")
            
            error_message = f" Errors: {errors}" if errors else ""
            return deleted_count, f"Cleaned up {deleted_count} expired files.{error_message}"
            
        except Exception as e:
            logger.error(f"Error during cleanup: {e}")
            return 0, f"Cleanup failed: {e}"
    
    def get_quarantine_statistics(self) -> Dict[str, Any]:
        """Get quarantine system statistics"""
        try:
            stats = {
                'total_quarantined': 0,
                'by_status': {},
                'by_threat_level': {},
                'total_size': 0,
                'oldest_quarantine': None,
                'newest_quarantine': None,
                'config': {
                    'quarantine_directory': self.quarantine_dir.as_posix(),
                    'max_size': self.config.max_quarantine_size,
                    'auto_delete_days': self.config.auto_delete_after_days,
                    'encryption_enabled': self.config.encryption_enabled,
                    'compression_enabled': self.config.compression_enabled
                }
            }
            
            quarantine_list = self.database.get_quarantine_list()
            
            for entry in quarantine_list:
                status = entry['status']
                threat_level = entry['threat_level']
                
                # Count by status
                stats['by_status'][status] = stats['by_status'].get(status, 0) + 1
                
                # Count by threat level
                stats['by_threat_level'][threat_level] = stats['by_threat_level'].get(threat_level, 0) + 1
                
                # Calculate total size
                if entry['file_exists']:
                    stats['total_size'] += entry['current_size']
                
                # Track date range
                quarantine_time = datetime.datetime.fromisoformat(entry['quarantine_time'].replace('Z', '+00:00'))
                if not stats['oldest_quarantine'] or quarantine_time < stats['oldest_quarantine']:
                    stats['oldest_quarantine'] = quarantine_time
                if not stats['newest_quarantine'] or quarantine_time > stats['newest_quarantine']:
                    stats['newest_quarantine'] = quarantine_time
            
            stats['total_quarantined'] = len(quarantine_list)
            stats['total_size_mb'] = round(stats['total_size'] / (1024 * 1024), 2)
            
            return stats
            
        except Exception as e:
            logger.error(f"Error getting quarantine statistics: {e}")
            return {'error': str(e)}
    
    def export_quarantine_list(self, format_type: str = "json") -> str:
        """Export quarantine list for reporting"""
        try:
            quarantine_list = self.list_quarantined_files()
            
            export_data = {
                'export_time': datetime.datetime.now().isoformat(),
                'total_entries': len(quarantine_list),
                'statistics': self.get_quarantine_statistics(),
                'entries': quarantine_list
            }
            
            if format_type.lower() == "json":
                return json.dumps(export_data, indent=2, default=str)
            else:
                # Simple CSV export
                if not quarantine_list:
                    return "No quarantine entries to export"
                
                import csv
                import io
                
                output = io.StringIO()
                fieldnames = ['id', 'original_path', 'quarantine_time', 'threat_name', 
                             'threat_level', 'status', 'file_size', 'reason']
                writer = csv.DictWriter(output, fieldnames=fieldnames)
                writer.writeheader()
                
                for entry in quarantine_list:
                    writer.writerow({
                        'id': entry['id'],
                        'original_path': entry['original_path'],
                        'quarantine_time': entry['quarantine_time'],
                        'threat_name': entry['threat_name'],
                        'threat_level': entry['threat_level'],
                        'status': entry['status'],
                        'file_size': entry.get('current_size', 0),
                        'reason': entry['reason']
                    })
                
                return output.getvalue()
                
        except Exception as e:
            logger.error(f"Error exporting quarantine list: {e}")
            return f"Export failed: {e}"
    
    def _calculate_file_hash(self, file_path: Path) -> str:
        """Calculate SHA-256 hash of a file"""
        sha256_hash = hashlib.sha256()
        with open(file_path, "rb") as f:
            for byte_block in iter(lambda: f.read(4096), b""):
                sha256_hash.update(byte_block)
        return sha256_hash.hexdigest()
    
    def _save_quarantine_metadata(self, quarantine_id: int, original_path: Path, file_size: int):
        """Save additional quarantine metadata"""
        metadata = {
            'original_name': original_path.name,
            'original_parent': original_path.parent.as_posix(),
            'original_size': file_size,
            'original_permissions': oct(original_path.stat().st_mode)[-3:],
            'original_mtime': original_path.stat().st_mtime,
            'quarantined_at': datetime.datetime.now().isoformat()
        }
        
        metadata_file = self.quarantine_dir / "metadata" / f"{quarantine_id}.json"
        with open(metadata_file, 'w') as f:
            json.dump(metadata, f, indent=2)
    
    def _load_quarantine_metadata(self, quarantine_id: int) -> Dict[str, Any]:
        """Load quarantine metadata"""
        metadata_file = self.quarantine_dir / "metadata" / f"{quarantine_id}.json"
        
        if metadata_file.exists():
            try:
                with open(metadata_file, 'r') as f:
                    return json.load(f)
            except Exception as e:
                logger.warning(f"Error loading metadata for quarantine {quarantine_id}: {e}")
        
        return {}
    
    def _update_quarantine_metadata(self, quarantine_id: int, updates: Dict[str, Any]):
        """Update quarantine metadata"""
        metadata = self._load_quarantine_metadata(quarantine_id)
        metadata.update(updates)
        
        metadata_file = self.quarantine_dir / "metadata" / f"{quarantine_id}.json"
        with open(metadata_file, 'w') as f:
            json.dump(metadata, f, indent=2)
    
    def scan_quarantine_directory(self) -> Dict[str, Any]:
        """Scan quarantine directory for orphaned files and inconsistencies"""
        try:
            scan_results = {
                'orphaned_files': [],
                'missing_metadata': [],
                'missing_files': [],
                'inconsistent_entries': [],
                'summary': {
                    'total_files': 0,
                    'total_metadata': 0,
                    'total_db_entries': 0,
                    'orphaned_count': 0
                }
            }
            
            # Scan files directory
            files_dir = self.quarantine_dir / "files"
            if files_dir.exists():
                for file_path in files_dir.iterdir():
                    if file_path.is_file():
                        scan_results['summary']['total_files'] += 1
                        # Check if metadata exists
                        metadata_file = self.quarantine_dir / "metadata" / f"{file_path.stem}.json"
                        if not metadata_file.exists():
                            scan_results['missing_metadata'].append(file_path.as_posix())
            
            # Scan metadata directory
            metadata_dir = self.quarantine_dir / "metadata"
            if metadata_dir.exists():
                for metadata_file in metadata_dir.iterdir():
                    if metadata_file.is_file() and metadata_file.suffix == '.json':
                        scan_results['summary']['total_metadata'] += 1
                        # Check if corresponding file exists
                        quarantine_id = metadata_file.stem
                        file_path = files_dir / f"{quarantine_id}_*"
                        if not any(files_dir.glob(f"{quarantine_id}_*")):
                            scan_results['missing_files'].append(metadata_file.as_posix())
            
            # Scan database entries
            quarantine_list = self.database.get_quarantine_list()
            scan_results['summary']['total_db_entries'] = len(quarantine_list)
            
            for entry in quarantine_list:
                quarantine_path = Path(entry['quarantine_path'])
                if not quarantine_path.exists():
                    scan_results['missing_files'].append(f"DB ID {entry['id']}: {quarantine_path.as_posix()}")
            
            scan_results['summary']['orphaned_count'] = len(scan_results['orphaned_files'])
            
            logger.info(f"Quarantine scan completed: {scan_results['summary']}")
            return scan_results
            
        except Exception as e:
            logger.error(f"Error scanning quarantine directory: {e}")
            return {'error': str(e)}

def main():
    """Main function to test quarantine management"""
    from threat_database import ThreatDatabase
    
    # Initialize database and quarantine manager
    db = ThreatDatabase("test_threats.db")
    config = QuarantineConfig(
        quarantine_directory="test_quarantine",
        max_file_size=50 * 1024 * 1024  # 50MB
    )
    qm = QuarantineManager(db, config)
    
    # Create a test file
    test_file = "test_file.txt"
    with open(test_file, 'w') as f:
        f.write("This is a test file for quarantine testing.")
    
    # Test quarantine
    success, message, quarantine_id = qm.quarantine_file(
        test_file,
        threat_name="Test Malware",
        threat_level="high",
        reason="Testing quarantine functionality"
    )
    
    print(f"Quarantine result: {success} - {message}")
    if quarantine_id:
        print(f"Quarantine ID: {quarantine_id}")
        
        # Test restore
        success, restore_message = qm.restore_file(quarantine_id, force=True)
        print(f"Restore result: {success} - {restore_message}")
    
    # Get statistics
    stats = qm.get_quarantine_statistics()
    print("Quarantine statistics:", json.dumps(stats, indent=2, default=str))
    
    # Clean up
    if os.path.exists(test_file):
        os.remove(test_file)

if __name__ == "__main__":
    main()