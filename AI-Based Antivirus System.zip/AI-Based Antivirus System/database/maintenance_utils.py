#!/usr/bin/env python3
"""
Database Maintenance Utilities
Provides comprehensive maintenance, cleanup, and optimization utilities
"""

import json
import os
import shutil
import datetime
import logging
from typing import Dict, List, Optional, Any, Tuple
from pathlib import Path
from dataclasses import dataclass
from enum import Enum
import sqlite3
import hashlib
import glob

from threat_database import ThreatDatabase
from backup_recovery import BackupManager
from performance_optimizer import DatabasePerformanceOptimizer
from quarantine_manager import QuarantineManager

logger = logging.getLogger(__name__)

class MaintenanceType(Enum):
    """Types of maintenance operations"""
    CLEANUP = "cleanup"
    OPTIMIZATION = "optimization"
    BACKUP = "backup"
    INTEGRITY_CHECK = "integrity_check"
    ARCHIVE = "archive"
    VACUUM = "vacuum"
    ANALYZE = "analyze"
    REINDEX = "reindex"

class MaintenanceStatus(Enum):
    """Maintenance operation status"""
    SUCCESS = "success"
    FAILED = "failed"
    WARNING = "warning"
    SKIPPED = "skipped"
    IN_PROGRESS = "in_progress"

@dataclass
class MaintenanceTask:
    """Maintenance task definition"""
    name: str
    type: MaintenanceType
    description: str
    enabled: bool = True
    priority: int = 1  # 1 = high, 2 = medium, 3 = low
    frequency_days: int = 7
    last_run: Optional[str] = None
    parameters: Dict[str, Any] = None

@dataclass
class MaintenanceResult:
    """Result of maintenance operation"""
    task_name: str
    status: MaintenanceStatus
    start_time: float
    end_time: float
    duration_seconds: float
    details: str
    records_processed: int = 0
    space_reclaimed_mb: float = 0.0
    error_message: Optional[str] = None

class DatabaseMaintenanceUtil:
    """
    Comprehensive database maintenance and utility system
    """
    
    def __init__(self, database_path: str, 
                 backup_manager: BackupManager,
                 quarantine_manager: QuarantineManager):
        self.database_path = Path(database_path)
        self.backup_manager = backup_manager
        self.quarantine_manager = quarantine_manager
        
        # Maintenance configuration
        self.maintenance_config = {
            "event_retention_days": 90,
            "analysis_retention_days": 180,
            "log_retention_days": 30,
            "orphaned_file_cleanup": True,
            "database_optimization": True,
            "backup_verification": True,
            "integrity_checking": True
        }
        
        # Initialize maintenance tasks
        self.maintenance_tasks = self._initialize_maintenance_tasks()
        
        logger.info("Database maintenance utilities initialized")
    
    def _initialize_maintenance_tasks(self) -> List[MaintenanceTask]:
        """Initialize maintenance tasks"""
        return [
            MaintenanceTask(
                name="cleanup_old_events",
                type=MaintenanceType.CLEANUP,
                description="Clean up old threat events from database",
                priority=1,
                frequency_days=7,
                parameters={"retention_days": self.maintenance_config["event_retention_days"]}
            ),
            MaintenanceTask(
                name="cleanup_old_analysis",
                type=MaintenanceType.CLEANUP,
                description="Clean up old analysis results",
                priority=2,
                frequency_days=30,
                parameters={"retention_days": self.maintenance_config["analysis_retention_days"]}
            ),
            MaintenanceTask(
                name="cleanup_orphaned_files",
                type=MaintenanceType.CLEANUP,
                description="Clean up orphaned quarantine files",
                priority=1,
                frequency_days=1
            ),
            MaintenanceTask(
                name="optimize_database",
                type=MaintenanceType.OPTIMIZATION,
                description="Run database optimization procedures",
                priority=1,
                frequency_days=7
            ),
            MaintenanceTask(
                name="verify_backup_integrity",
                type=MaintenanceType.INTEGRITY_CHECK,
                description="Verify backup file integrity",
                priority=2,
                frequency_days=7
            ),
            MaintenanceTask(
                name="vacuum_database",
                type=MaintenanceType.VACUUM,
                description="Run VACUUM to reclaim space",
                priority=2,
                frequency_days=14
            ),
            MaintenanceTask(
                name="analyze_database",
                type=MaintenanceType.ANALYZE,
                description="Update query planner statistics",
                priority=3,
                frequency_days=7
            ),
            MaintenanceTask(
                name="reindex_database",
                type=MaintenanceType.REINDEX,
                description="Rebuild database indexes",
                priority=3,
                frequency_days=30
            )
        ]
    
    def run_maintenance_schedule(self, force_all: bool = False) -> List[MaintenanceResult]:
        """
        Run maintenance tasks based on schedule
        
        Args:
            force_all: If True, run all tasks regardless of schedule
            
        Returns:
            List of maintenance results
        """
        results = []
        current_time = datetime.datetime.now()
        
        try:
            for task in self.maintenance_tasks:
                if not task.enabled:
                    continue
                
                # Check if task should run
                should_run = force_all
                if not force_run and task.last_run:
                    last_run = datetime.datetime.fromisoformat(task.last_run)
                    days_since_last_run = (current_time - last_run).days
                    should_run = days_since_last_run >= task.frequency_days
                
                if should_run:
                    result = self._execute_maintenance_task(task)
                    results.append(result)
                    
                    # Update last run time
                    task.last_run = current_time.isoformat()
                    
                    # Stop on first failure if not forcing
                    if not force_all and result.status == MaintenanceStatus.FAILED:
                        logger.error(f"Maintenance failed for task {task.name}, stopping schedule")
                        break
                else:
                    # Log that task was skipped
                    results.append(MaintenanceResult(
                        task_name=task.name,
                        status=MaintenanceStatus.SKIPPED,
                        start_time=0,
                        end_time=0,
                        duration_seconds=0,
                        details=f"Task not due for execution (last run: {task.last_run})"
                    ))
            
            logger.info(f"Maintenance schedule completed: {len(results)} tasks processed")
            return results
            
        except Exception as e:
            logger.error(f"Error running maintenance schedule: {e}")
            return [MaintenanceResult(
                task_name="maintenance_schedule",
                status=MaintenanceStatus.FAILED,
                start_time=0,
                end_time=0,
                duration_seconds=0,
                details="Maintenance schedule execution failed",
                error_message=str(e)
            )]
    
    def _execute_maintenance_task(self, task: MaintenanceTask) -> MaintenanceResult:
        """Execute a specific maintenance task"""
        start_time = datetime.datetime.now().timestamp()
        
        try:
            if task.type == MaintenanceType.CLEANUP:
                return self._execute_cleanup_task(task, start_time)
            elif task.type == MaintenanceType.OPTIMIZATION:
                return self._execute_optimization_task(task, start_time)
            elif task.type == MaintenanceType.BACKUP:
                return self._execute_backup_task(task, start_time)
            elif task.type == MaintenanceType.INTEGRITY_CHECK:
                return self._execute_integrity_check_task(task, start_time)
            elif task.type == MaintenanceType.VACUUM:
                return self._execute_vacuum_task(task, start_time)
            elif task.type == MaintenanceType.ANALYZE:
                return self._execute_analyze_task(task, start_time)
            elif task.type == MaintenanceType.REINDEX:
                return self._execute_reindex_task(task, start_time)
            else:
                return MaintenanceResult(
                    task_name=task.name,
                    status=MaintenanceStatus.FAILED,
                    start_time=start_time,
                    end_time=datetime.datetime.now().timestamp(),
                    duration_seconds=datetime.datetime.now().timestamp() - start_time,
                    details=f"Unknown maintenance type: {task.type}"
                )
                
        except Exception as e:
            end_time = datetime.datetime.now().timestamp()
            return MaintenanceResult(
                task_name=task.name,
                status=MaintenanceStatus.FAILED,
                start_time=start_time,
                end_time=end_time,
                duration_seconds=end_time - start_time,
                details=f"Task execution failed",
                error_message=str(e)
            )
    
    def _execute_cleanup_task(self, task: MaintenanceTask, start_time: float) -> MaintenanceResult:
        """Execute cleanup tasks"""
        end_time = datetime.datetime.now().timestamp()
        duration = end_time - start_time
        
        try:
            if task.name == "cleanup_old_events":
                return self._cleanup_old_events(task.parameters.get("retention_days", 90))
            elif task.name == "cleanup_old_analysis":
                return self._cleanup_old_analysis(task.parameters.get("retention_days", 180))
            elif task.name == "cleanup_orphaned_files":
                return self._cleanup_orphaned_files()
            else:
                return MaintenanceResult(
                    task_name=task.name,
                    status=MaintenanceStatus.FAILED,
                    start_time=start_time,
                    end_time=end_time,
                    duration_seconds=duration,
                    details="Unknown cleanup task"
                )
                
        except Exception as e:
            end_time = datetime.datetime.now().timestamp()
            return MaintenanceResult(
                task_name=task.name,
                status=MaintenanceStatus.FAILED,
                start_time=start_time,
                end_time=end_time,
                duration_seconds=duration,
                details="Cleanup task failed",
                error_message=str(e)
            )
    
    def _cleanup_old_events(self, retention_days: int) -> MaintenanceResult:
        """Clean up old threat events"""
        start_time = datetime.datetime.now().timestamp()
        
        try:
            database = ThreatDatabase(str(self.database_path))
            deleted_count = database.cleanup_old_events(retention_days)
            
            end_time = datetime.datetime.now().timestamp()
            
            return MaintenanceResult(
                task_name="cleanup_old_events",
                status=MaintenanceStatus.SUCCESS,
                start_time=start_time,
                end_time=end_time,
                duration_seconds=end_time - start_time,
                details=f"Cleaned up {deleted_count} old events (retention: {retention_days} days)",
                records_processed=deleted_count
            )
            
        except Exception as e:
            end_time = datetime.datetime.now().timestamp()
            return MaintenanceResult(
                task_name="cleanup_old_events",
                status=MaintenanceStatus.FAILED,
                start_time=start_time,
                end_time=end_time,
                duration_seconds=end_time - start_time,
                details="Failed to cleanup old events",
                error_message=str(e)
            )
    
    def _cleanup_old_analysis(self, retention_days: int) -> MaintenanceResult:
        """Clean up old analysis results"""
        start_time = datetime.datetime.now().timestamp()
        
        try:
            cutoff_date = datetime.datetime.now() - datetime.timedelta(days=retention_days)
            
            with sqlite3.connect(self.database_path) as conn:
                cursor = conn.cursor()
                
                # Get initial size
                initial_size = self.database_path.stat().st_size if self.database_path.exists() else 0
                
                # Delete old analysis results
                cursor.execute('''
                    DELETE FROM threat_analysis 
                    WHERE analysis_date < ?
                ''', (cutoff_date.isoformat(),))
                
                deleted_count = cursor.rowcount
                conn.commit()
                
                # Get final size
                final_size = self.database_path.stat().st_size if self.database_path.exists() else initial_size
                space_reclaimed = (initial_size - final_size) / (1024 * 1024)  # MB
                
                end_time = datetime.datetime.now().timestamp()
                
                return MaintenanceResult(
                    task_name="cleanup_old_analysis",
                    status=MaintenanceStatus.SUCCESS,
                    start_time=start_time,
                    end_time=end_time,
                    duration_seconds=end_time - start_time,
                    details=f"Cleaned up {deleted_count} old analysis results (retention: {retention_days} days)",
                    records_processed=deleted_count,
                    space_reclaimed_mb=space_reclaimed
                )
                
        except Exception as e:
            end_time = datetime.datetime.now().timestamp()
            return MaintenanceResult(
                task_name="cleanup_old_analysis",
                status=MaintenanceStatus.FAILED,
                start_time=start_time,
                end_time=end_time,
                duration_seconds=end_time - start_time,
                details="Failed to cleanup old analysis",
                error_message=str(e)
            )
    
    def _cleanup_orphaned_files(self) -> MaintenanceResult:
        """Clean up orphaned quarantine files"""
        start_time = datetime.datetime.now().timestamp()
        
        try:
            # Scan quarantine directory for inconsistencies
            scan_results = self.quarantine_manager.scan_quarantine_directory()
            
            deleted_count = 0
            space_reclaimed = 0.0
            
            # Clean up orphaned files
            for file_path_str in scan_results.get('missing_files', []):
                file_path = Path(file_path_str)
                if file_path.exists():
                    file_size = file_path.stat().st_size
                    file_path.unlink()
                    deleted_count += 1
                    space_reclaimed += file_size
            
            end_time = datetime.datetime.now().timestamp()
            
            return MaintenanceResult(
                task_name="cleanup_orphaned_files",
                status=MaintenanceStatus.SUCCESS,
                start_time=start_time,
                end_time=end_time,
                duration_seconds=end_time - start_time,
                details=f"Cleaned up {deleted_count} orphaned files",
                records_processed=deleted_count,
                space_reclaimed_mb=space_reclaimed / (1024 * 1024)
            )
            
        except Exception as e:
            end_time = datetime.datetime.now().timestamp()
            return MaintenanceResult(
                task_name="cleanup_orphaned_files",
                status=MaintenanceStatus.FAILED,
                start_time=start_time,
                end_time=end_time,
                duration_seconds=end_time - start_time,
                details="Failed to cleanup orphaned files",
                error_message=str(e)
            )
    
    def _execute_optimization_task(self, task: MaintenanceTask, start_time: float) -> MaintenanceResult:
        """Execute database optimization"""
        end_time = datetime.datetime.now().timestamp()
        
        try:
            optimizer = DatabasePerformanceOptimizer(str(self.database_path))
            success, message = optimizer.optimize_database()
            
            end_time = datetime.datetime.now().timestamp()
            
            return MaintenanceResult(
                task_name="optimize_database",
                status=MaintenanceStatus.SUCCESS if success else MaintenanceStatus.FAILED,
                start_time=start_time,
                end_time=end_time,
                duration_seconds=end_time - start_time,
                details=message
            )
            
        except Exception as e:
            end_time = datetime.datetime.now().timestamp()
            return MaintenanceResult(
                task_name="optimize_database",
                status=MaintenanceStatus.FAILED,
                start_time=start_time,
                end_time=end_time,
                duration_seconds=end_time - start_time,
                details="Database optimization failed",
                error_message=str(e)
            )
    
    def _execute_backup_task(self, task: MaintenanceTask, start_time: float) -> MaintenanceResult:
        """Execute backup verification"""
        end_time = datetime.datetime.now().timestamp()
        
        try:
            backups = self.backup_manager.list_backups()
            verified_count = 0
            
            for backup in backups[-5:]:  # Verify last 5 backups
                if self.backup_manager.verify_backup(backup):
                    verified_count += 1
            
            end_time = datetime.datetime.now().timestamp()
            
            return MaintenanceResult(
                task_name="verify_backup_integrity",
                status=MaintenanceStatus.SUCCESS,
                start_time=start_time,
                end_time=end_time,
                duration_seconds=end_time - start_time,
                details=f"Verified integrity of {verified_count} out of {min(5, len(backups))} recent backups"
            )
            
        except Exception as e:
            end_time = datetime.datetime.now().timestamp()
            return MaintenanceResult(
                task_name="verify_backup_integrity",
                status=MaintenanceStatus.FAILED,
                start_time=start_time,
                end_time=end_time,
                duration_seconds=end_time - start_time,
                details="Backup verification failed",
                error_message=str(e)
            )
    
    def _execute_integrity_check_task(self, task: MaintenanceTask, start_time: float) -> MaintenanceResult:
        """Execute integrity check"""
        end_time = datetime.datetime.now().timestamp()
        
        try:
            with sqlite3.connect(self.database_path) as conn:
                cursor = conn.cursor()
                cursor.execute("PRAGMA integrity_check")
                result = cursor.fetchone()
                
                end_time = datetime.datetime.now().timestamp()
                
                if result[0] == "ok":
                    return MaintenanceResult(
                        task_name="database_integrity_check",
                        status=MaintenanceStatus.SUCCESS,
                        start_time=start_time,
                        end_time=end_time,
                        duration_seconds=end_time - start_time,
                        details="Database integrity check passed"
                    )
                else:
                    return MaintenanceResult(
                        task_name="database_integrity_check",
                        status=MaintenanceStatus.FAILED,
                        start_time=start_time,
                        end_time=end_time,
                        duration_seconds=end_time - start_time,
                        details=f"Database integrity check failed: {result[0]}"
                    )
                
        except Exception as e:
            end_time = datetime.datetime.now().timestamp()
            return MaintenanceResult(
                task_name="database_integrity_check",
                status=MaintenanceStatus.FAILED,
                start_time=start_time,
                end_time=end_time,
                duration_seconds=end_time - start_time,
                details="Integrity check execution failed",
                error_message=str(e)
            )
    
    def _execute_vacuum_task(self, task: MaintenanceTask, start_time: float) -> MaintenanceResult:
        """Execute VACUUM operation"""
        end_time = datetime.datetime.now().timestamp()
        
        try:
            with sqlite3.connect(self.database_path) as conn:
                cursor = conn.cursor()
                
                # Get initial size
                initial_size = self.database_path.stat().st_size if self.database_path.exists() else 0
                
                # Run VACUUM
                cursor.execute("VACUUM")
                
                # Get final size
                final_size = self.database_path.stat().st_size if self.database_path.exists() else initial_size
                space_reclaimed = (initial_size - final_size) / (1024 * 1024)  # MB
                
                end_time = datetime.datetime.now().timestamp()
                
                return MaintenanceResult(
                    task_name="vacuum_database",
                    status=MaintenanceStatus.SUCCESS,
                    start_time=start_time,
                    end_time=end_time,
                    duration_seconds=end_time - start_time,
                    details=f"VACUUM completed, {space_reclaimed:.2f}MB space reclaimed",
                    space_reclaimed_mb=space_reclaimed
                )
                
        except Exception as e:
            end_time = datetime.datetime.now().timestamp()
            return MaintenanceResult(
                task_name="vacuum_database",
                status=MaintenanceStatus.FAILED,
                start_time=start_time,
                end_time=end_time,
                duration_seconds=end_time - start_time,
                details="VACUUM operation failed",
                error_message=str(e)
            )
    
    def _execute_analyze_task(self, task: MaintenanceTask, start_time: float) -> MaintenanceResult:
        """Execute ANALYZE operation"""
        end_time = datetime.datetime.now().timestamp()
        
        try:
            with sqlite3.connect(self.database_path) as conn:
                cursor = conn.cursor()
                cursor.execute("ANALYZE")
                
                end_time = datetime.datetime.now().timestamp()
                
                return MaintenanceResult(
                    task_name="analyze_database",
                    status=MaintenanceStatus.SUCCESS,
                    start_time=start_time,
                    end_time=end_time,
                    duration_seconds=end_time - start_time,
                    details="ANALYZE completed successfully"
                )
                
        except Exception as e:
            end_time = datetime.datetime.now().timestamp()
            return MaintenanceResult(
                task_name="analyze_database",
                status=MaintenanceStatus.FAILED,
                start_time=start_time,
                end_time=end_time,
                duration_seconds=end_time - start_time,
                details="ANALYZE operation failed",
                error_message=str(e)
            )
    
    def _execute_reindex_task(self, task: MaintenanceTask, start_time: float) -> MaintenanceResult:
        """Execute REINDEX operation"""
        end_time = datetime.datetime.now().timestamp()
        
        try:
            with sqlite3.connect(self.database_path) as conn:
                cursor = conn.cursor()
                
                # Get index count before reindexing
                cursor.execute("SELECT COUNT(*) FROM sqlite_master WHERE type='index'")
                initial_index_count = cursor.fetchone()[0]
                
                # Run REINDEX
                cursor.execute("REINDEX")
                
                # Get index count after reindexing
                cursor.execute("SELECT COUNT(*) FROM sqlite_master WHERE type='index'")
                final_index_count = cursor.fetchone()[0]
                
                end_time = datetime.datetime.now().timestamp()
                
                return MaintenanceResult(
                    task_name="reindex_database",
                    status=MaintenanceStatus.SUCCESS,
                    start_time=start_time,
                    end_time=end_time,
                    duration_seconds=end_time - start_time,
                    details=f"REINDEX completed, {final_index_count} indexes rebuilt"
                )
                
        except Exception as e:
            end_time = datetime.datetime.now().timestamp()
            return MaintenanceResult(
                task_name="reindex_database",
                status=MaintenanceStatus.FAILED,
                start_time=start_time,
                end_time=end_time,
                duration_seconds=end_time - start_time,
                details="REINDEX operation failed",
                error_message=str(e)
            )
    
    def get_maintenance_history(self, days: int = 30) -> List[Dict[str, Any]]:
        """Get maintenance history"""
        # In a full implementation, this would read from a maintenance log
        # For now, return empty list
        return []
    
    def update_maintenance_schedule(self, task_name: str, updates: Dict[str, Any]) -> bool:
        """Update maintenance task configuration"""
        try:
            for task in self.maintenance_tasks:
                if task.name == task_name:
                    for key, value in updates.items():
                        if hasattr(task, key):
                            setattr(task, key, value)
                    return True
            return False
            
        except Exception as e:
            logger.error(f"Error updating maintenance schedule: {e}")
            return False
    
    def run_custom_maintenance(self, maintenance_type: MaintenanceType, 
                             parameters: Dict[str, Any] = None) -> MaintenanceResult:
        """Run custom maintenance operation"""
        start_time = datetime.datetime.now().timestamp()
        
        # Create a temporary task
        task = MaintenanceTask(
            name=f"custom_{maintenance_type.value}",
            type=maintenance_type,
            description=f"Custom {maintenance_type.value} maintenance",
            parameters=parameters or {}
        )
        
        return self._execute_maintenance_task(task)

def main():
    """Test the maintenance utilities"""
    from backup_recovery import BackupManager
    from quarantine_manager import QuarantineManager
    from threat_database import ThreatDatabase
    
    # Initialize components
    db = ThreatDatabase("test_threats.db")
    backup_manager = BackupManager("test_threats.db")
    quarantine_manager = QuarantineManager(db)
    
    # Initialize maintenance utilities
    maintenance = DatabaseMaintenanceUtil("test_threats.db", backup_manager, quarantine_manager)
    
    # Run maintenance schedule
    results = maintenance.run_maintenance_schedule(force_all=True)
    
    for result in results:
        print(f"{result.task_name}: {result.status.value} - {result.details}")
    
    # Run custom maintenance
    custom_result = maintenance.run_custom_maintenance(
        MaintenanceType.INTEGRITY_CHECK
    )
    print(f"Custom maintenance: {custom_result.status.value} - {custom_result.details}")

if __name__ == "__main__":
    main()
