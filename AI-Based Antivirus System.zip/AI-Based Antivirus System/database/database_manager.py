#!/usr/bin/env python3
"""
Enhanced Database Manager with CRUD operations and performance optimization
Provides comprehensive database management with advanced query capabilities
"""

import sqlite3
import json
import hashlib
import datetime
import threading
import logging
from typing import Optional, List, Dict, Any, Tuple, Union
from pathlib import Path
from dataclasses import dataclass, asdict
from enum import Enum
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
import queue
import re
from contextlib import contextmanager

from threat_database import ThreatDatabase, ThreatSignature, QuarantineEntry, ThreatLevel, SignatureType
from performance_optimizer import DatabasePerformanceOptimizer

logger = logging.getLogger(__name__)

class QueryType(Enum):
    """Query optimization types"""
    SELECT = "select"
    INSERT = "insert"
    UPDATE = "update"
    DELETE = "delete"
    BULK = "bulk"

@dataclass
class DatabaseMetrics:
    """Database performance metrics"""
    total_queries: int = 0
    avg_query_time: float = 0.0
    slow_queries: int = 0
    cache_hit_ratio: float = 0.0
    table_lock_wait_time: float = 0.0
    connection_pool_size: int = 0
    active_connections: int = 0
    database_size_mb: float = 0.0
    last_vacuum_time: Optional[str] = None
    last_analyze_time: Optional[str] = None

class DatabaseManager:
    """
    Enhanced database manager with CRUD operations, performance optimization,
    and advanced query capabilities
    """
    
    def __init__(self, database_path: str = "threats.db", 
                 config_file: str = "threat_database.yaml"):
        self.db_path = Path(database_path)
        self.config_file = Path(config_file)
        self._lock = threading.RLock()
        self._connection_pool = queue.Queue(maxsize=10)
        self._optimizer = None
        
        # Initialize database
        self._initialize_database_manager()
        
        # Performance tracking
        self._metrics = DatabaseMetrics()
        self._query_times = []
        self._max_query_history = 1000
        
        logger.info(f"Database manager initialized: {self.db_path}")
    
    def _initialize_database_manager(self):
        """Initialize database and performance optimizer"""
        # Initialize the base database
        self._database = ThreatDatabase(str(self.db_path))
        
        # Initialize performance optimizer
        self._optimizer = DatabasePerformanceOptimizer(
            database_path=str(self.db_path),
            config_file=str(self.config_file)
        )
        
        # Configure database for optimal performance
        self._optimize_database_settings()
        
        # Initialize connection pool
        self._initialize_connection_pool()
    
    def _optimize_database_settings(self):
        """Apply performance optimizations to the database"""
        try:
            with self._get_connection() as conn:
                cursor = conn.cursor()
                
                # Enable WAL mode for better concurrency
                cursor.execute("PRAGMA journal_mode=WAL")
                result = cursor.fetchone()
                logger.info(f"Database journal mode: {result[0]}")
                
                # Configure cache size (in pages)
                cursor.execute("PRAGMA cache_size=10000")
                
                # Set synchronous mode
                cursor.execute("PRAGMA synchronous=NORMAL")
                
                # Configure temp store to memory
                cursor.execute("PRAGMA temp_store=MEMORY")
                
                # Enable foreign key constraints
                cursor.execute("PRAGMA foreign_keys=ON")
                
                # Set busy timeout
                cursor.execute("PRAGMA busy_timeout=30000")
                
                # Memory map size (in bytes)
                cursor.execute("PRAGMA mmap_size=268435456")  # 256MB
                
                conn.commit()
                logger.info("Database performance settings optimized")
                
        except Exception as e:
            logger.error(f"Error optimizing database settings: {e}")
    
    def _initialize_connection_pool(self):
        """Initialize connection pool"""
        try:
            for _ in range(5):  # Create initial connections
                conn = self._get_connection()
                if conn:
                    self._connection_pool.put(conn)
            
            logger.info(f"Connection pool initialized with {self._connection_pool.qsize()} connections")
            
        except Exception as e:
            logger.error(f"Error initializing connection pool: {e}")
    
    @contextmanager
    def _get_connection(self):
        """Get database connection from pool"""
        conn = None
        try:
            # Try to get from pool first
            try:
                conn = self._connection_pool.get(timeout=5)
            except queue.Empty:
                # Create new connection if pool is empty
                conn = self._create_connection()
            
            yield conn
            
        finally:
            # Return connection to pool or close it
            if conn and not self._connection_pool.full():
                self._connection_pool.put(conn)
            elif conn:
                conn.close()
    
    def _create_connection(self) -> sqlite3.Connection:
        """Create a new database connection"""
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA busy_timeout=30000")
        return conn
    
    # Enhanced CRUD Operations
    
    def create_threat_signature(self, signature: ThreatSignature, 
                              validate_content: bool = True) -> Tuple[bool, int, str]:
        """
        Create a new threat signature with validation and optimization
        
        Args:
            signature: ThreatSignature object to create
            validate_content: Whether to validate signature content
            
        Returns:
            Tuple of (success, signature_id, message)
        """
        start_time = time.time()
        
        try:
            with self._get_connection() as conn:
                cursor = conn.cursor()
                
                # Validate signature content
                if validate_content and not self._validate_signature(signature):
                    return False, 0, "Signature content validation failed"
                
                # Check for duplicates
                cursor.execute(
                    "SELECT id FROM threat_signatures WHERE type = ? AND content = ?",
                    (signature.type, signature.content)
                )
                
                if cursor.fetchone():
                    # Update existing signature metadata
                    cursor.execute('''
                        UPDATE threat_signatures 
                        SET last_updated = ?, confidence_score = ?, 
                            false_positive_rate = ?, usage_count = usage_count + 1
                        WHERE type = ? AND content = ?
                    ''', (
                        datetime.datetime.now().isoformat(),
                        signature.confidence_score,
                        signature.false_positive_rate,
                        signature.type,
                        signature.content
                    ))
                    
                    existing_id = cursor.lastrowid
                    conn.commit()
                    
                    logger.info(f"Updated existing signature: {existing_id}")
                    return True, existing_id, "Signature updated (duplicate found)"
                
                # Add new signature
                signature_id = self._database.add_signature(signature)
                
                # Log performance
                query_time = time.time() - start_time
                self._record_query_performance("create_signature", query_time)
                
                return True, signature_id, f"Signature created successfully"
                
        except Exception as e:
            logger.error(f"Error creating threat signature: {e}")
            return False, 0, f"Error: {str(e)}"
    
    def read_threat_signatures(self, filters: Dict[str, Any] = None,
                             pagination: Dict[str, int] = None,
                             sort_by: str = "last_updated",
                             sort_order: str = "DESC") -> Tuple[List[Dict[str, Any]], int]:
        """
        Read threat signatures with advanced filtering and pagination
        
        Args:
            filters: Dictionary of filter conditions
            pagination: Dictionary with 'page' and 'page_size'
            sort_by: Field to sort by
            sort_order: 'ASC' or 'DESC'
            
        Returns:
            Tuple of (results, total_count)
        """
        start_time = time.time()
        
        try:
            with self._get_connection() as conn:
                cursor = conn.cursor()
                
                # Build base query
                base_query = "FROM threat_signatures WHERE 1=1"
                params = []
                
                # Apply filters
                if filters:
                    for field, value in filters.items():
                        if field == "search_text":
                            base_query += " AND (name LIKE ? OR content LIKE ? OR description LIKE ?)"
                            search_term = f"%{value}%"
                            params.extend([search_term, search_term, search_term])
                        elif field == "threat_levels":
                            if isinstance(value, list):
                                placeholders = ','.join(['?' for _ in value])
                                base_query += f" AND threat_level IN ({placeholders})"
                                params.extend(value)
                            else:
                                base_query += " AND threat_level = ?"
                                params.append(value)
                        elif field == "signature_types":
                            if isinstance(value, list):
                                placeholders = ','.join(['?' for _ in value])
                                base_query += f" AND type IN ({placeholders})"
                                params.extend(value)
                            else:
                                base_query += " AND type = ?"
                                params.append(value)
                        elif field == "date_range":
                            if isinstance(value, dict):
                                if "start" in value:
                                    base_query += " AND first_seen >= ?"
                                    params.append(value["start"])
                                if "end" in value:
                                    base_query += " AND first_seen <= ?"
                                    params.append(value["end"])
                        elif field == "min_confidence":
                            base_query += " AND confidence_score >= ?"
                            params.append(value)
                        elif field == "max_false_positive_rate":
                            base_query += " AND false_positive_rate <= ?"
                            params.append(value)
                        elif field == "active_only":
                            if value:
                                base_query += " AND active = 1"
                        elif field == "min_usage_count":
                            base_query += " AND usage_count >= ?"
                            params.append(value)
                        elif field == "source":
                            base_query += " AND source = ?"
                            params.append(value)
                        else:
                            # Generic field filter
                            base_query += f" AND {field} = ?"
                            params.append(value)
                
                # Get total count
                count_query = f"SELECT COUNT(*) {base_query}"
                cursor.execute(count_query, params)
                total_count = cursor.fetchone()[0]
                
                # Build main query
                valid_sort_fields = [
                    'id', 'name', 'type', 'threat_level', 'confidence_score',
                    'false_positive_rate', 'usage_count', 'last_updated', 'first_seen'
                ]
                if sort_by not in valid_sort_fields:
                    sort_by = "last_updated"
                
                if sort_order.upper() not in ['ASC', 'DESC']:
                    sort_order = "DESC"
                
                # Add pagination
                limit_clause = ""
                if pagination:
                    page = pagination.get('page', 1)
                    page_size = pagination.get('page_size', 50)
                    offset = (page - 1) * page_size
                    limit_clause = f" LIMIT {page_size} OFFSET {offset}"
                
                # Execute query
                query = f"SELECT * {base_query} ORDER BY {sort_by} {sort_order}{limit_clause}"
                cursor.execute(query, params)
                
                results = [dict(row) for row in cursor.fetchall()]
                
                # Log performance
                query_time = time.time() - start_time
                self._record_query_performance("read_signatures", query_time)
                
                return results, total_count
                
        except Exception as e:
            logger.error(f"Error reading threat signatures: {e}")
            return [], 0
    
    def update_threat_signature(self, signature_id: int, updates: Dict[str, Any]) -> Tuple[bool, str]:
        """
        Update an existing threat signature
        
        Args:
            signature_id: ID of the signature to update
            updates: Dictionary of fields to update
            
        Returns:
            Tuple of (success, message)
        """
        start_time = time.time()
        
        try:
            with self._get_connection() as conn:
                cursor = conn.cursor()
                
                # Validate updates
                if not self._validate_signature_updates(updates):
                    return False, "Invalid update fields"
                
                # Build update query
                update_fields = []
                params = []
                
                allowed_fields = [
                    'name', 'description', 'threat_level', 'confidence_score',
                    'false_positive_rate', 'active', 'source', 'metadata'
                ]
                
                for field, value in updates.items():
                    if field in allowed_fields:
                        if field == 'last_updated':
                            continue  # Don't allow manual update of this field
                        update_fields.append(f"{field} = ?")
                        params.append(value)
                
                if not update_fields:
                    return False, "No valid fields to update"
                
                # Add timestamp
                update_fields.append("last_updated = ?")
                params.append(datetime.datetime.now().isoformat())
                
                # Add signature_id to params
                params.append(signature_id)
                
                # Execute update
                query = f"""
                    UPDATE threat_signatures 
                    SET {', '.join(update_fields)}
                    WHERE id = ?
                """
                
                cursor.execute(query, params)
                
                if cursor.rowcount == 0:
                    return False, f"Signature with ID {signature_id} not found"
                
                conn.commit()
                
                # Log performance
                query_time = time.time() - start_time
                self._record_query_performance("update_signature", query_time)
                
                logger.info(f"Updated signature: {signature_id}")
                return True, f"Signature updated successfully"
                
        except Exception as e:
            logger.error(f"Error updating threat signature: {e}")
            return False, f"Error: {str(e)}"
    
    def delete_threat_signature(self, signature_id: int, soft_delete: bool = True) -> Tuple[bool, str]:
        """
        Delete a threat signature
        
        Args:
            signature_id: ID of the signature to delete
            soft_delete: If True, mark as inactive; if False, permanently delete
            
        Returns:
            Tuple of (success, message)
        """
        start_time = time.time()
        
        try:
            with self._get_connection() as conn:
                cursor = conn.cursor()
                
                if soft_delete:
                    # Soft delete - mark as inactive
                    cursor.execute('''
                        UPDATE threat_signatures 
                        SET active = 0, last_updated = ?
                        WHERE id = ?
                    ''', (datetime.datetime.now().isoformat(), signature_id))
                    
                    if cursor.rowcount == 0:
                        return False, f"Signature with ID {signature_id} not found"
                    
                    action = "deactivated"
                else:
                    # Hard delete - remove from database
                    cursor.execute("DELETE FROM threat_signatures WHERE id = ?", (signature_id,))
                    
                    if cursor.rowcount == 0:
                        return False, f"Signature with ID {signature_id} not found"
                    
                    action = "deleted"
                
                conn.commit()
                
                # Log performance
                query_time = time.time() - start_time
                self._record_query_performance("delete_signature", query_time)
                
                logger.info(f"Signature {action}: {signature_id}")
                return True, f"Signature {action} successfully"
                
        except Exception as e:
            logger.error(f"Error deleting threat signature: {e}")
            return False, f"Error: {str(e)}"
    
    def bulk_create_signatures(self, signatures: List[ThreatSignature],
                             batch_size: int = 100) -> Tuple[int, int, List[str]]:
        """
        Create multiple signatures in bulk for better performance
        
        Args:
            signatures: List of ThreatSignature objects
            batch_size: Number of signatures to process in each batch
            
        Returns:
            Tuple of (created_count, failed_count, error_messages)
        """
        start_time = time.time()
        created_count = 0
        failed_count = 0
        error_messages = []
        
        try:
            with self._get_connection() as conn:
                cursor = conn.cursor()
                
                # Process signatures in batches
                for i in range(0, len(signatures), batch_size):
                    batch = signatures[i:i + batch_size]
                    
                    try:
                        for signature in batch:
                            success, sig_id, message = self.create_threat_signature(
                                signature, validate_content=True
                            )
                            
                            if success:
                                created_count += 1
                            else:
                                failed_count += 1
                                error_messages.append(f"Signature '{signature.name}': {message}")
                    
                    except Exception as e:
                        error_messages.append(f"Batch {i//batch_size + 1} error: {str(e)}")
                        failed_count += len(batch)
                
                # Log performance
                query_time = time.time() - start_time
                self._record_query_performance("bulk_create_signatures", query_time)
                
                logger.info(f"Bulk create completed: {created_count} created, {failed_count} failed")
                return created_count, failed_count, error_messages
                
        except Exception as e:
            logger.error(f"Error in bulk create signatures: {e}")
            return created_count, failed_count, [str(e)]
    
    def search_signatures_advanced(self, search_criteria: Dict[str, Any]) -> List[Dict[str, Any]]:
        """
        Advanced signature search with multiple criteria
        
        Args:
            search_criteria: Dictionary containing search parameters
            
        Returns:
            List of matching signatures
        """
        start_time = time.time()
        
        try:
            filters = search_criteria.get('filters', {})
            pagination = search_criteria.get('pagination')
            sort_by = search_criteria.get('sort_by', 'last_updated')
            sort_order = search_criteria.get('sort_order', 'DESC')
            include_metadata = search_criteria.get('include_metadata', False)
            
            results, total_count = self.read_threat_signatures(
                filters=filters,
                pagination=pagination,
                sort_by=sort_by,
                sort_order=sort_order
            )
            
            # Add additional processing if needed
            if include_metadata:
                for result in results:
                    if result.get('metadata'):
                        try:
                            result['metadata_parsed'] = json.loads(result['metadata'])
                        except json.JSONDecodeError:
                            result['metadata_parsed'] = None
            
            # Log performance
            query_time = time.time() - start_time
            self._record_query_performance("advanced_search", query_time)
            
            return results
            
        except Exception as e:
            logger.error(f"Error in advanced signature search: {e}")
            return []
    
    def get_signature_statistics(self) -> Dict[str, Any]:
        """
        Get comprehensive statistics about signatures
        """
        start_time = time.time()
        
        try:
            with self._get_connection() as conn:
                cursor = conn.cursor()
                
                # Total signatures by type
                cursor.execute('''
                    SELECT type, COUNT(*) as count, 
                           AVG(confidence_score) as avg_confidence,
                           AVG(false_positive_rate) as avg_fp_rate
                    FROM threat_signatures 
                    WHERE active = 1
                    GROUP BY type
                ''')
                type_stats = [dict(row) for row in cursor.fetchall()]
                
                # Signatures by threat level
                cursor.execute('''
                    SELECT threat_level, COUNT(*) as count
                    FROM threat_signatures 
                    WHERE active = 1
                    GROUP BY threat_level
                ''')
                level_stats = [dict(row) for row in cursor.fetchall()]
                
                # Most active signatures
                cursor.execute('''
                    SELECT name, type, usage_count, confidence_score, last_updated
                    FROM threat_signatures 
                    WHERE active = 1 AND usage_count > 0
                    ORDER BY usage_count DESC
                    LIMIT 10
                ''')
                active_signatures = [dict(row) for row in cursor.fetchall()]
                
                # Recent activity
                cursor.execute('''
                    SELECT COUNT(*) as recent_count
                    FROM threat_signatures 
                    WHERE first_seen >= datetime('now', '-7 days')
                ''')
                recent_activity = cursor.fetchone()['recent_count']
                
                # Performance statistics
                cursor.execute('''
                    SELECT COUNT(*) as total, 
                           AVG(confidence_score) as avg_confidence,
                           MAX(last_updated) as latest_update
                    FROM threat_signatures
                ''')
                overall_stats = dict(cursor.fetchone())
                
                # Log performance
                query_time = time.time() - start_time
                self._record_query_performance("signature_stats", query_time)
                
                return {
                    'overall': overall_stats,
                    'by_type': type_stats,
                    'by_threat_level': level_stats,
                    'most_active': active_signatures,
                    'recent_activity': recent_activity,
                    'performance': {
                        'query_time': query_time,
                        'total_records': overall_stats['total']
                    }
                }
                
        except Exception as e:
            logger.error(f"Error getting signature statistics: {e}")
            return {'error': str(e)}
    
    def validate_signature(self, signature: ThreatSignature) -> bool:
        """Validate signature content and structure"""
        try:
            if not signature.name or not signature.content:
                return False
            
            # Validate based on signature type
            if signature.type == SignatureType.HASH_SHA256.value:
                if not re.match(r'^[a-fA-F0-9]{64}$', signature.content):
                    return False
            elif signature.type == SignatureType.HASH_MD5.value:
                if not re.match(r'^[a-fA-F0-9]{32}$', signature.content):
                    return False
            elif signature.type == SignatureType.HASH_SHA1.value:
                if not re.match(r'^[a-fA-F0-9]{40}$', signature.content):
                    return False
            elif signature.type == SignatureType.YARA_RULE.value:
                # Basic YARA rule validation
                content = signature.content
                if not ('rule ' in content and 'condition:' in content):
                    return False
            
            # Validate confidence score
            if not 0 <= signature.confidence_score <= 1:
                return False
            
            # Validate false positive rate
            if not 0 <= signature.false_positive_rate <= 1:
                return False
            
            return True
            
        except Exception as e:
            logger.error(f"Error validating signature: {e}")
            return False
    
    def _validate_signature_updates(self, updates: Dict[str, Any]) -> bool:
        """Validate update fields for signatures"""
        allowed_fields = {
            'name', 'description', 'threat_level', 'confidence_score',
            'false_positive_rate', 'active', 'source', 'metadata'
        }
        
        for field in updates.keys():
            if field not in allowed_fields:
                return False
        
        return True
    
    def _record_query_performance(self, query_type: str, query_time: float):
        """Record query performance metrics"""
        self._metrics.total_queries += 1
        self._query_times.append((query_type, query_time))
        
        # Keep only recent query times
        if len(self._query_times) > self._max_query_history:
            self._query_times = self._query_times[-self._max_query_history:]
        
        # Update average query time
        total_time = sum(time for _, time in self._query_times)
        self._metrics.avg_query_time = total_time / len(self._query_times)
        
        # Count slow queries
        self._metrics.slow_queries = sum(
            1 for _, time in self._query_times if time > 1.0
        )
    
    def get_database_metrics(self) -> DatabaseMetrics:
        """Get database performance metrics"""
        try:
            with self._get_connection() as conn:
                cursor = conn.cursor()
                
                # Get database size
                db_size = self.db_path.stat().st_size if self.db_path.exists() else 0
                self._metrics.database_size_mb = db_size / (1024 * 1024)
                
                # Get last maintenance times
                cursor.execute("PRAGMA user_version")
                result = cursor.fetchone()
                if result:
                    # This could be used to track when vacuum/analyze was last run
                    pass
                
                # Get active connections (approximation)
                self._metrics.active_connections = self._connection_pool.qsize()
                
                return self._metrics
                
        except Exception as e:
            logger.error(f"Error getting database metrics: {e}")
            return self._metrics
    
    def optimize_database(self) -> Tuple[bool, str]:
        """Run database optimization procedures"""
        try:
            if self._optimizer:
                success, message = self._optimizer.optimize_database()
                if success:
                    # Update metrics
                    self._metrics.last_vacuum_time = datetime.datetime.now().isoformat()
                    self._metrics.last_analyze_time = datetime.datetime.now().isoformat()
                
                return success, message
            else:
                return False, "Performance optimizer not available"
                
        except Exception as e:
            logger.error(f"Error optimizing database: {e}")
            return False, f"Error: {str(e)}"
    
    def export_database_schema(self) -> str:
        """Export the current database schema"""
        try:
            with self._get_connection() as conn:
                cursor = conn.cursor()
                
                cursor.execute("SELECT sql FROM sqlite_master WHERE type='table'")
                tables = cursor.fetchall()
                
                schema = "-- Threat Database Schema\n"
                schema += f"-- Generated: {datetime.datetime.now().isoformat()}\n\n"
                
                for table in tables:
                    if table[0]:
                        schema += table[0] + ";\n\n"
                
                return schema
                
        except Exception as e:
            logger.error(f"Error exporting database schema: {e}")
            return f"Error: {str(e)}"
    
    def close(self):
        """Close database manager and cleanup resources"""
        try:
            # Close connection pool
            while not self._connection_pool.empty():
                try:
                    conn = self._connection_pool.get_nowait()
                    conn.close()
                except queue.Empty:
                    break
            
            logger.info("Database manager closed")
            
        except Exception as e:
            logger.error(f"Error closing database manager: {e}")

def main():
    """Test the enhanced database manager"""
    # Initialize database manager
    db_manager = DatabaseManager("test_enhanced.db")
    
    # Test creating signatures
    test_signature = ThreatSignature(
        name="Test Signature",
        type=SignatureType.HASH_SHA256.value,
        content="a" * 64,
        description="Test signature for database manager",
        threat_level=ThreatLevel.MEDIUM.value,
        source="test",
        confidence_score=0.8
    )
    
    success, sig_id, message = db_manager.create_threat_signature(test_signature)
    print(f"Create signature: {success} - {message}")
    
    if success:
        # Test reading signatures
        results, total = db_manager.read_threat_signatures()
        print(f"Read signatures: {len(results)} results, {total} total")
        
        # Test updating signature
        success, message = db_manager.update_threat_signature(sig_id, {
            'description': 'Updated test signature'
        })
        print(f"Update signature: {success} - {message}")
        
        # Get statistics
        stats = db_manager.get_signature_statistics()
        print(f"Statistics: {len(stats.get('by_type', []))} signature types")
    
    # Get database metrics
    metrics = db_manager.get_database_metrics()
    print(f"Database metrics: {metrics.total_queries} queries, {metrics.avg_query_time:.4f}s avg time")
    
    # Optimize database
    success, message = db_manager.optimize_database()
    print(f"Database optimization: {success} - {message}")
    
    # Close manager
    db_manager.close()

if __name__ == "__main__":
    main()
