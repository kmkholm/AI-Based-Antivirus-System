#!/usr/bin/env python3
"""
Threat Database and Management System
A comprehensive threat intelligence and malware management system

This package provides:
- SQLite-based threat database with schema and management
- Threat intelligence integration from multiple sources
- Malware signature storage and retrieval
- Quarantine file management with security controls
- Threat history and comprehensive reporting
- Database backup and recovery functionality

Based on signature/heuristic research from docs/signature_heuristic.md
"""

import json

__version__ = "1.0.0"
__author__ = "Threat Database System"
__description__ = "Comprehensive threat intelligence and malware management system"

from .threat_database import (
    ThreatDatabase,
    ThreatSignature,
    QuarantineEntry,
    ThreatLevel,
    SignatureType,
    QuarantineStatus,
    AnalysisType
)

from .threat_intel import (
    ThreatIntelIntegrator,
    ThreatIntelSource,
    MockThreatIntelSources
)

from .quarantine_manager import (
    QuarantineManager,
    QuarantineConfig
)

from .threat_analysis import (
    ThreatAnalyzer,
    ThreatMetrics
)

from .backup_recovery import (
    BackupManager,
    BackupConfig,
    BackupInfo
)

__all__ = [
    # Core database components
    'ThreatDatabase',
    'ThreatSignature', 
    'QuarantineEntry',
    'ThreatLevel',
    'SignatureType',
    'QuarantineStatus',
    'AnalysisType',
    
    # Threat intelligence
    'ThreatIntelIntegrator',
    'ThreatIntelSource',
    'MockThreatIntelSources',
    
    # Quarantine management
    'QuarantineManager',
    'QuarantineConfig',
    
    # Analysis and reporting
    'ThreatAnalyzer',
    'ThreatMetrics',
    
    # Backup and recovery
    'BackupManager',
    'BackupConfig',
    'BackupInfo'
]

# Package metadata
__title__ = "Threat Database Management System"
__email__ = "threat-intel@security.com"
__license__ = "MIT"
__url__ = "https://github.com/security/threat-database"

# Default configuration
DEFAULT_CONFIG = {
    "database": {
        "path": "threats.db",
        "backup_directory": "backups",
        "max_backup_count": 10,
        "auto_backup": True,
        "backup_frequency": 86400  # 24 hours
    },
    "quarantine": {
        "directory": "quarantine",
        "max_size": 1073741824,  # 1GB
        "auto_delete_days": 30,
        "allow_restore": True,
        "scan_after_restore": True
    },
    "threat_intel": {
        "update_frequency": 3600,  # 1 hour
        "confidence_threshold": 0.5,
        "sources": []
    },
    "analysis": {
        "enable_visualizations": True,
        "report_format": "json",
        "auto_cleanup_days": 90
    }
}

def create_threat_database_system(config_dict: dict = None) -> tuple:
    """
    Create a complete threat database system with all components
    
    Args:
        config_dict: Optional configuration dictionary
        
    Returns:
        Tuple of (database, quarantine_manager, threat_intel, analyzer, backup_manager)
    """
    # Merge with defaults
    config = {**DEFAULT_CONFIG, **(config_dict or {})}
    
    # Initialize core components
    database = ThreatDatabase(
        db_path=config["database"]["path"],
        backup_dir=config["database"]["backup_directory"]
    )
    
    # Initialize quarantine manager
    quarantine_config = QuarantineConfig(
        quarantine_directory=config["quarantine"]["directory"],
        max_quarantine_size=config["quarantine"]["max_size"],
        auto_delete_after_days=config["quarantine"]["auto_delete_days"],
        allow_restore=config["quarantine"]["allow_restore"],
        scan_after_restore=config["quarantine"]["scan_after_restore"]
    )
    quarantine_manager = QuarantineManager(database, quarantine_config)
    
    # Initialize threat intelligence integrator
    threat_intel = ThreatIntelIntegrator(database)
    
    # Initialize threat analyzer
    analyzer = ThreatAnalyzer(database, quarantine_manager, threat_intel)
    
    # Initialize backup manager
    backup_config = BackupConfig(
        backup_directory=config["database"]["backup_directory"],
        max_backups=config["database"]["max_backup_count"],
        auto_cleanup=True
    )
    backup_manager = BackupManager(config["database"]["path"], backup_config)
    
    return database, quarantine_manager, threat_intel, analyzer, backup_manager

def initialize_sample_data(database: ThreatDatabase, threat_intel: ThreatIntelIntegrator):
    """
    Initialize database with sample threat data for testing
    
    Args:
        database: ThreatDatabase instance
        threat_intel: ThreatIntelIntegrator instance
    """
    from .threat_intel import MockThreatIntelSources
    
    # Add sample signatures
    sample_iocs = MockThreatIntelSources.get_sample_iocs()
    for ioc in sample_iocs:
        signature = ThreatSignature(
            name=ioc["name"],
            type=SignatureType.HASH_SHA256.value,
            content=ioc["value"],
            description=ioc["description"],
            threat_level=ioc["severity"],
            source="sample_data",
            confidence_score=ioc["confidence"]
        )
        database.add_signature(signature)
    
    # Add sample YARA rules
    sample_yara = MockThreatIntelSources.get_sample_yara_rules()
    for rule in sample_yara:
        signature = ThreatSignature(
            name=rule["name"],
            type=SignatureType.YARA_RULE.value,
            content=rule["content"],
            description=rule["description"],
            threat_level=rule["severity"],
            source="sample_data",
            confidence_score=rule["confidence_score"]
        )
        database.add_signature(signature)
    
    # Add sample threat intel source
    sample_source = ThreatIntelSource(
        name="Sample IOC Feed",
        url="https://example.com/iocs.json",
        source_type="ioc",
        format_type="json",
        enabled=True,
        confidence_threshold=0.7
    )
    threat_intel.add_source(sample_source)
    
    print("Sample data initialized successfully")

def get_system_status(database: ThreatDatabase, quarantine_manager: QuarantineManager = None,
                     threat_intel: ThreatIntelIntegrator = None, 
                     backup_manager: BackupManager = None) -> dict:
    """
    Get comprehensive system status
    
    Returns:
        Dictionary with system status information
    """
    status = {
        "database": {},
        "quarantine": {},
        "threat_intelligence": {},
        "backup": {},
        "overall_health": "unknown"
    }
    
    try:
        # Database status
        db_stats = database.get_statistics()
        status["database"] = {
            "total_signatures": db_stats.get("total_signatures", 0),
            "signatures_by_type": db_stats.get("signatures_by_type", {}),
            "events_last_24h": db_stats.get("events_last_24h", {}),
            "database_path": str(database.db_path),
            "size_mb": round(database.db_path.stat().st_size / (1024 * 1024), 2) if database.db_path.exists() else 0
        }
        
        # Quarantine status
        if quarantine_manager:
            quarantine_stats = quarantine_manager.get_quarantine_statistics()
            status["quarantine"] = {
                "total_quarantined": quarantine_stats.get("total_quarantined", 0),
                "by_status": quarantine_stats.get("by_status", {}),
                "total_size_mb": quarantine_stats.get("total_size_mb", 0),
                "oldest_quarantine": quarantine_stats.get("oldest_quarantine")
            }
        
        # Threat intelligence status
        if threat_intel:
            source_status = threat_intel.get_source_status()
            status["threat_intelligence"] = {
                "total_sources": len(source_status),
                "active_sources": len([s for s in source_status if s["enabled"]]),
                "sources": source_status
            }
        
        # Backup status
        if backup_manager:
            backups = backup_manager.list_backups()
            status["backup"] = {
                "total_backups": len(backups),
                "latest_backup": backups[0].created_at.isoformat() if backups else None,
                "total_backup_size_mb": round(sum(b.size_bytes for b in backups) / (1024 * 1024), 2)
            }
        
        # Overall health assessment
        health_score = 0
        health_factors = []
        
        # Check database health
        if status["database"]["total_signatures"] > 0:
            health_score += 20
            health_factors.append("Database has threat signatures")
        
        # Check quarantine health
        if status["quarantine"].get("total_quarantined", 0) >= 0:
            health_score += 20
            health_factors.append("Quarantine system operational")
        
        # Check threat intelligence
        if status["threat_intelligence"].get("active_sources", 0) > 0:
            health_score += 20
            health_factors.append("Threat intelligence sources active")
        
        # Check backup health
        if status["backup"].get("total_backups", 0) > 0:
            health_score += 20
            health_factors.append("Backup system operational")
        
        # Check database file
        if status["database"]["size_mb"] > 0:
            health_score += 20
            health_factors.append("Database file exists and accessible")
        
        # Determine overall health
        if health_score >= 80:
            status["overall_health"] = "excellent"
        elif health_score >= 60:
            status["overall_health"] = "good"
        elif health_score >= 40:
            status["overall_health"] = "fair"
        else:
            status["overall_health"] = "poor"
        
        status["health_score"] = health_score
        status["health_factors"] = health_factors
        
    except Exception as e:
        status["error"] = str(e)
        status["overall_health"] = "error"
    
    return status

# Convenience functions
def quick_scan_file(file_path: str, database: ThreatDatabase) -> dict:
    """
    Quick file scan against threat database
    
    Args:
        file_path: Path to file to scan
        database: ThreatDatabase instance
        
    Returns:
        Scan results dictionary
    """
    import hashlib
    
    # Calculate file hash
    sha256_hash = hashlib.sha256()
    with open(file_path, "rb") as f:
        for byte_block in iter(lambda: f.read(4096), b""):
            sha256_hash.update(byte_block)
    file_hash = sha256_hash.hexdigest()
    
    # Check against database
    signature = database.get_signature_by_hash(file_hash)
    
    result = {
        "file_path": file_path,
        "file_hash": file_hash,
        "threat_detected": signature is not None,
        "signature": signature
    }
    
    if signature:
        result["threat_name"] = signature.get("name", "Unknown")
        result["threat_level"] = signature.get("threat_level", "medium")
        result["confidence"] = signature.get("confidence_score", 0.0)
    
    return result

def generate_sample_reports(database: ThreatDatabase, analyzer: ThreatAnalyzer, output_dir: str = "reports"):
    """
    Generate sample threat analysis reports
    
    Args:
        database: ThreatDatabase instance
        analyzer: ThreatAnalyzer instance  
        output_dir: Output directory for reports
    """
    import os
    
    # Create output directory
    os.makedirs(output_dir, exist_ok=True)
    
    # Generate comprehensive report
    report = analyzer.generate_comprehensive_report("comprehensive", days=30)
    
    # Export in multiple formats
    analyzer.export_report(report, f"{output_dir}/threat_analysis_report.json", "json")
    analyzer.export_report(report, f"{output_dir}/threat_analysis_report.html", "html")
    
    # Create visualization
    analyzer.create_visualization("threat_trends", f"{output_dir}/threat_trends.png")
    
    # Export threat intelligence
    threat_intel_export = database.export_threat_intelligence("json")
    with open(f"{output_dir}/threat_intelligence_export.json", "w") as f:
        f.write(threat_intel_export)
    
    print(f"Sample reports generated in {output_dir}/")

# Module-level initialization
def _initialize_package():
    """Package-level initialization (called automatically)"""
    # Any package-level setup would go here
    pass

# Auto-initialize when module is imported
_initialize_package()

if __name__ == "__main__":
    # Demo mode
    print(f"Threat Database Management System v{__version__}")
    print("=" * 50)
    
    # Create system
    db, qm, ti, analyzer, bm = create_threat_database_system()
    
    # Initialize sample data
    initialize_sample_data(db, ti)
    
    # Get system status
    status = get_system_status(db, qm, ti, bm)
    print("System Status:", json.dumps(status, indent=2, default=str))
    
    # Generate sample reports
    generate_sample_reports(db, analyzer)
    
    # Create backup
    success, message, backup_info = bm.create_full_backup("Demo backup")
    print(f"Backup: {success} - {message}")
    
    print("\nDemo completed successfully!")