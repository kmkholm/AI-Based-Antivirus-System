#!/usr/bin/env python3
"""
Threat Intelligence Integration Module
Integrates with external threat intelligence feeds for IOCs, signatures, and behavior patterns
"""

import json
import requests
import hashlib
import yaml
import csv
import io
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any, Tuple
from pathlib import Path
import logging
from dataclasses import dataclass
from threat_database import ThreatDatabase, ThreatSignature, ThreatLevel, SignatureType

logger = logging.getLogger(__name__)

@dataclass
class ThreatIntelSource:
    """Threat intelligence source configuration"""
    name: str
    url: str
    source_type: str  # 'ioc', 'signature', 'yara', 'behavior'
    format_type: str  # 'json', 'csv', 'stix', 'misp'
    auth_token: Optional[str] = None
    api_key: Optional[str] = None
    update_frequency: int = 3600  # seconds
    enabled: bool = True
    last_update: Optional[datetime] = None
    confidence_threshold: float = 0.5
    false_positive_rate: float = 0.0

class ThreatIntelIntegrator:
    """Manages threat intelligence integration from various sources"""
    
    def __init__(self, database: ThreatDatabase, config_file: str = "threat_intel.yaml"):
        self.database = database
        self.config_file = Path(config_file)
        self.sources = self._load_configuration()
        self.session = requests.Session()
        
        # Set up request headers
        self.session.headers.update({
            'User-Agent': 'ThreatIntelIntegrator/1.0',
            'Accept': 'application/json'
        })
    
    def _load_configuration(self) -> Dict[str, ThreatIntelSource]:
        """Load threat intelligence source configuration"""
        sources = {}
        
        if self.config_file.exists():
            try:
                with open(self.config_file, 'r') as f:
                    config = yaml.safe_load(f)
                
                for source_config in config.get('sources', []):
                    source = ThreatIntelSource(
                        name=source_config['name'],
                        url=source_config['url'],
                        source_type=source_config['source_type'],
                        format_type=source_config['format_type'],
                        auth_token=source_config.get('auth_token'),
                        api_key=source_config.get('api_key'),
                        update_frequency=source_config.get('update_frequency', 3600),
                        enabled=source_config.get('enabled', True),
                        confidence_threshold=source_config.get('confidence_threshold', 0.5),
                        false_positive_rate=source_config.get('false_positive_rate', 0.0)
                    )
                    sources[source.name] = source
                    
            except Exception as e:
                logger.error(f"Error loading threat intel config: {e}")
        
        return sources
    
    def add_source(self, source: ThreatIntelSource):
        """Add a new threat intelligence source"""
        self.sources[source.name] = source
        self._save_configuration()
        logger.info(f"Added threat intel source: {source.name}")
    
    def _save_configuration(self):
        """Save threat intelligence configuration"""
        config = {
            'sources': []
        }
        
        for source in self.sources.values():
            source_config = {
                'name': source.name,
                'url': source.url,
                'source_type': source.source_type,
                'format_type': source.format_type,
                'update_frequency': source.update_frequency,
                'enabled': source.enabled,
                'confidence_threshold': source.confidence_threshold,
                'false_positive_rate': source.false_positive_rate
            }
            
            if source.auth_token:
                source_config['auth_token'] = source.auth_token
            if source.api_key:
                source_config['api_key'] = source.api_key
                
            config['sources'].append(source_config)
        
        with open(self.config_file, 'w') as f:
            yaml.dump(config, f, default_flow_style=False)
    
    def update_from_source(self, source_name: str) -> Tuple[bool, int, str]:
        """Update threat intelligence from a specific source"""
        if source_name not in self.sources:
            return False, 0, f"Source not found: {source_name}"
        
        source = self.sources[source_name]
        
        if not source.enabled:
            return False, 0, f"Source disabled: {source_name}"
        
        # Check if update is needed
        if (source.last_update and 
            datetime.now() - source.last_update < timedelta(seconds=source.update_frequency)):
            return True, 0, "Update not needed yet"
        
        try:
            # Fetch data from source
            data = self._fetch_data(source)
            
            if not data:
                return False, 0, "No data received from source"
            
            # Parse and import data
            imported_count = self._import_data(source, data)
            
            # Update last update time
            source.last_update = datetime.now()
            self._save_configuration()
            
            return True, imported_count, f"Successfully updated {imported_count} items"
            
        except Exception as e:
            logger.error(f"Error updating from source {source_name}: {e}")
            return False, 0, f"Error: {str(e)}"
    
    def _fetch_data(self, source: ThreatIntelSource) -> Optional[Any]:
        """Fetch data from threat intelligence source"""
        headers = {}
        
        if source.auth_token:
            headers['Authorization'] = f"Bearer {source.auth_token}"
        if source.api_key:
            headers['X-API-Key'] = source.api_key
        
        try:
            response = self.session.get(source.url, headers=headers, timeout=30)
            response.raise_for_status()
            
            if source.format_type == 'json':
                return response.json()
            elif source.format_type == 'csv':
                return response.text
            else:
                return response.text
                
        except Exception as e:
            logger.error(f"Error fetching data from {source.name}: {e}")
            return None
    
    def _import_data(self, source: ThreatIntelSource, data: Any) -> int:
        """Import threat intelligence data into database"""
        imported_count = 0
        
        try:
            if source.source_type == 'ioc':
                imported_count = self._import_iocs(source, data)
            elif source.source_type == 'signature':
                imported_count = self._import_signatures(source, data)
            elif source.source_type == 'yara':
                imported_count = self._import_yara_rules(source, data)
            elif source.source_type == 'behavior':
                imported_count = self._import_behavior_patterns(source, data)
            
            logger.info(f"Imported {imported_count} items from {source.name}")
            return imported_count
            
        except Exception as e:
            logger.error(f"Error importing data from {source.name}: {e}")
            return 0
    
    def _import_iocs(self, source: ThreatIntelSource, data: Any) -> int:
        """Import IOCs (Indicators of Compromise)"""
        imported_count = 0
        
        # Support multiple data formats
        if isinstance(data, list):
            items = data
        elif isinstance(data, dict):
            if 'indicators' in data:
                items = data['indicators']
            elif 'ioc' in data:
                items = data['ioc']
            else:
                items = [data]
        else:
            return 0
        
        for item in items:
            try:
                # Extract IOC details (generic approach)
                if isinstance(item, dict):
                    ioc_type = item.get('type', 'hash_sha256')
                    content = item.get('value', '') or item.get('hash', '') or item.get('indicator', '')
                    threat_name = item.get('name', item.get('threat', 'Unknown'))
                    confidence = item.get('confidence', 0.7)
                    first_seen = item.get('first_seen')
                    
                    if not content:
                        continue
                    
                    # Determine signature type
                    if ioc_type.lower() in ['md5', 'hash_md5']:
                        sig_type = SignatureType.HASH_MD5.value
                    elif ioc_type.lower() in ['sha1', 'hash_sha1']:
                        sig_type = SignatureType.HASH_SHA1.value
                    elif ioc_type.lower() in ['sha256', 'hash_sha256', 'hash']:
                        sig_type = SignatureType.HASH_SHA256.value
                    elif ioc_type.lower() in ['domain', 'ip', 'url']:
                        sig_type = SignatureType.PATTERN_STRING.value
                    else:
                        sig_type = SignatureType.HASH_SHA256.value
                    
                    signature = ThreatSignature(
                        name=threat_name,
                        type=sig_type,
                        content=content,
                        description=item.get('description', f"IOC from {source.name}"),
                        threat_level=item.get('severity', 'medium'),
                        source=source.name,
                        confidence_score=confidence,
                        false_positive_rate=source.false_positive_rate
                    )
                    
                    if signature.confidence_score >= source.confidence_threshold:
                        self.database.add_signature(signature)
                        imported_count += 1
                
            except Exception as e:
                logger.warning(f"Error importing IOC item: {e}")
                continue
        
        return imported_count
    
    def _import_signatures(self, source: ThreatIntelSource, data: Any) -> int:
        """Import threat signatures"""
        imported_count = 0
        
        if isinstance(data, list):
            items = data
        elif isinstance(data, dict) and 'signatures' in data:
            items = data['signatures']
        else:
            return 0
        
        for item in items:
            try:
                if isinstance(item, dict):
                    signature = ThreatSignature(
                        name=item.get('name', f"Signature from {source.name}"),
                        type=item.get('type', SignatureType.PATTERN_BYTES.value),
                        content=item.get('content', ''),
                        description=item.get('description', ''),
                        threat_level=item.get('threat_level', 'medium'),
                        source=source.name,
                        confidence_score=item.get('confidence_score', 0.7),
                        false_positive_rate=item.get('false_positive_rate', source.false_positive_rate)
                    )
                    
                    if signature.content and signature.confidence_score >= source.confidence_threshold:
                        self.database.add_signature(signature)
                        imported_count += 1
                        
            except Exception as e:
                logger.warning(f"Error importing signature: {e}")
                continue
        
        return imported_count
    
    def _import_yara_rules(self, source: ThreatIntelSource, data: Any) -> int:
        """Import YARA rules"""
        imported_count = 0
        
        if isinstance(data, list):
            items = data
        elif isinstance(data, dict) and 'rules' in data:
            items = data['rules']
        elif isinstance(data, str):
            # Single YARA rule
            items = [{'content': data}]
        else:
            return 0
        
        for item in items:
            try:
                if isinstance(item, dict):
                    content = item.get('content', item.get('rule', ''))
                    if content:
                        signature = ThreatSignature(
                            name=item.get('name', f"YARA rule from {source.name}"),
                            type=SignatureType.YARA_RULE.value,
                            content=content,
                            description=item.get('description', ''),
                            threat_level=item.get('threat_level', 'medium'),
                            source=source.name,
                            confidence_score=item.get('confidence_score', 0.8),
                            false_positive_rate=item.get('false_positive_rate', source.false_positive_rate),
                            metadata=json.dumps({
                                'yara_version': item.get('version'),
                                'author': item.get('author'),
                                'date': item.get('date')
                            })
                        )
                        
                        if signature.confidence_score >= source.confidence_threshold:
                            self.database.add_signature(signature)
                            imported_count += 1
                            
            except Exception as e:
                logger.warning(f"Error importing YARA rule: {e}")
                continue
        
        return imported_count
    
    def _import_behavior_patterns(self, source: ThreatIntelSource, data: Any) -> int:
        """Import behavioral patterns and IOAs"""
        imported_count = 0
        
        if isinstance(data, list):
            items = data
        elif isinstance(data, dict) and 'patterns' in data:
            items = data['patterns']
        else:
            return 0
        
        for item in items:
            try:
                if isinstance(item, dict):
                    # Add as signature first
                    signature = ThreatSignature(
                        name=item.get('name', f"Behavior pattern from {source.name}"),
                        type=SignatureType.BEHAVIORAL_IOA.value,
                        content=json.dumps(item.get('sequence', [])),
                        description=item.get('description', ''),
                        threat_level=item.get('severity', 'medium'),
                        source=source.name,
                        confidence_score=item.get('confidence_score', 0.7),
                        false_positive_rate=source.false_positive_rate,
                        metadata=json.dumps({
                            'time_window': item.get('time_window'),
                            'pattern_type': 'behavioral_ioa',
                            'events': item.get('sequence', [])
                        })
                    )
                    
                    if signature.confidence_score >= source.confidence_threshold:
                        self.database.add_signature(signature)
                        imported_count += 1
                        
            except Exception as e:
                logger.warning(f"Error importing behavior pattern: {e}")
                continue
        
        return imported_count
    
    def update_all_sources(self) -> Dict[str, Tuple[bool, int, str]]:
        """Update threat intelligence from all enabled sources"""
        results = {}
        
        for source_name in self.sources:
            if self.sources[source_name].enabled:
                results[source_name] = self.update_from_source(source_name)
        
        return results
    
    def get_source_status(self) -> List[Dict[str, Any]]:
        """Get status of all threat intelligence sources"""
        status = []
        
        for source in self.sources.values():
            source_status = {
                'name': source.name,
                'type': source.source_type,
                'enabled': source.enabled,
                'last_update': source.last_update.isoformat() if source.last_update else None,
                'url': source.url,
                'format': source.format_type,
                'confidence_threshold': source.confidence_threshold
            }
            
            # Add time until next update
            if source.last_update:
                next_update = source.last_update + timedelta(seconds=source.update_frequency)
                source_status['next_update'] = next_update.isoformat()
            else:
                source_status['next_update'] = "Never"
            
            status.append(source_status)
        
        return status
    
    def validate_source(self, source_name: str) -> Tuple[bool, str]:
        """Validate a threat intelligence source"""
        if source_name not in self.sources:
            return False, f"Source not found: {source_name}"
        
        source = self.sources[source_name]
        
        try:
            data = self._fetch_data(source)
            if data is not None:
                return True, "Source is accessible and returning data"
            else:
                return False, "Source is not accessible or returning no data"
        except Exception as e:
            return False, f"Source validation failed: {str(e)}"

# Mock threat intelligence sources for testing
class MockThreatIntelSources:
    """Mock threat intelligence sources for demonstration"""
    
    @staticmethod
    def get_sample_iocs() -> List[Dict[str, Any]]:
        """Get sample IOCs for testing"""
        return [
            {
                "type": "hash_sha256",
                "value": "a665a45920422f9d417e4867efdc4fb8a04a1f3fff1fa07e998e86f7f7a27ae3",
                "name": "Trojan.Malware.Sample1",
                "description": "Known banking trojan",
                "severity": "high",
                "confidence": 0.95,
                "first_seen": "2024-01-15T10:30:00Z"
            },
            {
                "type": "domain",
                "value": "malicious-domain.com",
                "name": "C2.Server.Malicious",
                "description": "Command and control server",
                "severity": "critical",
                "confidence": 0.90,
                "first_seen": "2024-01-10T08:00:00Z"
            }
        ]
    
    @staticmethod
    def get_sample_yara_rules() -> List[Dict[str, str]]:
        """Get sample YARA rules for testing"""
        return [
            {
                "name": "Suspicious_PowerShell",
                "content": '''
                rule Suspicious_PowerShell_Execution {
                    meta:
                        description = "Detects suspicious PowerShell execution patterns"
                        author = "threat_intel"
                        date = "2024-01-01"
                    
                    strings:
                        $ps1 = "powershell.exe" nocase
                        $encoded = "EncodedCommand" nocase
                        $download = "DownloadString" nocase
                    
                    condition:
                        $ps1 and any of ($encoded, $download)
                }
                ''',
                "description": "Detects encoded PowerShell commands",
                "severity": "medium",
                "confidence_score": 0.85
            }
        ]
    
    @staticmethod
    def get_sample_behavior_patterns() -> List[Dict[str, Any]]:
        """Get sample behavioral patterns for testing"""
        return [
            {
                "name": "Ransomware_Encryption_Pattern",
                "description": "Detects ransomware encryption behavior",
                "sequence": [
                    "file_enumeration",
                    "large_file_writes",
                    "file_rename_with_extension",
                    "volume_shadow_delete"
                ],
                "severity": "critical",
                "confidence_score": 0.90,
                "time_window": 300
            }
        ]

def main():
    """Main function to test threat intelligence integration"""
    from threat_database import ThreatDatabase
    
    # Initialize database and integrator
    db = ThreatDatabase("test_threats.db")
    integrator = ThreatIntelIntegrator(db, "test_threat_intel.yaml")
    
    # Add mock source
    mock_source = ThreatIntelSource(
        name="Mock IOC Feed",
        url="mock://iocs",
        source_type="ioc",
        format_type="json",
        enabled=True,
        confidence_threshold=0.8
    )
    
    integrator.add_source(mock_source)
    
    # Test with mock data
    mock_data = MockThreatIntelSources.get_sample_iocs()
    imported = integrator._import_data(mock_source, mock_data)
    print(f"Imported {imported} IOCs from mock source")
    
    # Test YARA rules
    yara_source = ThreatIntelSource(
        name="Mock YARA Rules",
        url="mock://yara",
        source_type="yara",
        format_type="json",
        enabled=True
    )
    
    integrator.add_source(yara_source)
    yara_data = MockThreatIntelSources.get_sample_yara_rules()
    imported_yara = integrator._import_data(yara_source, yara_data)
    print(f"Imported {imported_yara} YARA rules from mock source")
    
    # Get source status
    status = integrator.get_source_status()
    print("Source status:", json.dumps(status, indent=2, default=str))

if __name__ == "__main__":
    main()