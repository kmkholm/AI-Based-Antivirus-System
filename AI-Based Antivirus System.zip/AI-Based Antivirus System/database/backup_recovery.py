#!/usr/bin/env python3
"""
Backup and Recovery Module
Provides comprehensive backup and recovery functionality for the threat database
"""

import os
import shutil
import json
import gzip
import datetime
import sqlite3
import hashlib
import logging
from typing import Dict, List, Optional, Any, Tuple
from pathlib import Path
from dataclasses import dataclass, asdict
from concurrent.futures import ThreadPoolExecutor, as_completed
import threading
import time

logger = logging.getLogger(__name__)

@dataclass
class BackupConfig:
    """Backup system configuration"""
    backup_directory: str = "backups"
    max_backups: int = 10
    compression_enabled: bool = True
    encryption_enabled: bool = False
    encrypt_key: Optional[str] = None
    verify_backups: bool = True
    backup_schedule: Dict[str, int] = None  # frequency in seconds
    auto_cleanup: bool = True
    remote_backup: bool = False
    remote_location: Optional[str] = None
    
    def __post_init__(self):
        if self.backup_schedule is None:
            self.backup_schedule = {
                'hourly': 3600,    # 1 hour
                'daily': 86400,    # 24 hours
                'weekly': 604800,  # 7 days
                'monthly': 2592000 # 30 days
            }

@dataclass
class BackupInfo:
    """Backup information metadata"""
    backup_id: str
    filename: str
    filepath: str
    created_at: datetime.datetime
    backup_type: str  # 'full', 'incremental', ' differential'
    size_bytes: int
    compressed: bool
    encrypted: bool
    checksum: str
    database_version: str
    table_counts: Dict[str, int]
    description: str = ""

class BackupManager:
    """Manages database backup and recovery operations"""
    
    def __init__(self, database_path: str, config: BackupConfig = None):
        self.database_path = Path(database_path)
        self.config = config or BackupConfig()
        self.backup_dir = Path(self.config.backup_directory)
        self.backup_dir.mkdir(exist_ok=True)
        
        # Create subdirectories
        (self.backup_dir / "full").mkdir(exist_ok=True)
        (self.backup_dir / "incremental").mkdir(exist_ok=True)
        (self.backup_dir / "encrypted").mkdir(exist_ok=True)
        (self.backup_dir / "remote").mkdir(exist_ok=True)
        
        self.lock = threading.Lock()
        self._backup_schedules = {}
        
        logger.info(f"Backup manager initialized: {self.backup_dir}")
    
    def create_full_backup(self, description: str = "Manual full backup") -> Tuple[bool, str, Optional[BackupInfo]]:
        """Create a full database backup"""
        try:
            backup_id = f"full_{datetime.datetime.now().strftime('%Y%m%d_%H%M%S')}"
            timestamp = datetime.datetime.now()
            
            # Create backup filename
            backup_filename = f"{backup_id}.db"
            backup_filepath = self.backup_dir / "full" / backup_filename
            
            # Create backup
            success = self._create_database_backup(backup_filepath)
            if not success:
                return False, "Failed to create database backup", None
            
            # Compress if enabled
            compressed_filepath = None
            if self.config.compression_enabled:
                compressed_filepath = self._compress_backup(backup_filepath)
                backup_filepath.unlink()  # Remove uncompressed version
                backup_filename = compressed_filepath.name
                backup_filepath = compressed_filepath
            
            # Calculate checksum
            checksum = self._calculate_checksum(backup_filepath)
            
            # Get database information
            db_info = self._get_database_info()
            
            # Create backup info
            backup_info = BackupInfo(
                backup_id=backup_id,
                filename=backup_filename,
                filepath=backup_filepath.absolute().as_posix(),
                created_at=timestamp,
                backup_type='full',
                size_bytes=backup_filepath.stat().st_size,
                compressed=self.config.compression_enabled,
                encrypted=False,
                checksum=checksum,
                database_version=db_info.get('version', 'unknown'),
                table_counts=db_info.get('table_counts', {}),
                description=description
            )
            
            # Save backup metadata
            self._save_backup_metadata(backup_info)
            
            # Verify backup if enabled
            if self.config.verify_backups:
                if not self.verify_backup(backup_info):
                    return False, "Backup verification failed", None
            
            # Cleanup old backups
            if self.config.auto_cleanup:
                self._cleanup_old_backups()
            
            # Sync to remote location if enabled
            if self.config.remote_backup and self.config.remote_location:
                self._sync_to_remote(backup_filepath)
            
            logger.info(f"Full backup created: {backup_id}")
            return True, f"Full backup created successfully: {backup_id}", backup_info
            
        except Exception as e:
            logger.error(f"Error creating full backup: {e}")
            return False, f"Backup failed: {e}", None
    
    def create_incremental_backup(self, base_backup_id: str = None, 
                                description: str = "Manual incremental backup") -> Tuple[bool, str, Optional[BackupInfo]]:
        """Create an incremental backup (changes since last backup)"""
        try:
            if not base_backup_id:
                # Find the most recent full backup
                base_backup_id = self._get_most_recent_full_backup()
                if not base_backup_id:
                    # Fall back to full backup
                    return self.create_full_backup("Incremental backup fallback to full")
            
            backup_id = f"inc_{datetime.datetime.now().strftime('%Y%m%d_%H%M%S')}"
            timestamp = datetime.datetime.now()
            
            # Get base backup timestamp
            base_backup = self._get_backup_info(base_backup_id)
            if not base_backup:
                return False, f"Base backup not found: {base_backup_id}", None
            
            # Create incremental backup by copying changed records
            backup_filename = f"{backup_id}.json"
            backup_filepath = self.backup_dir / "incremental" / backup_filename
            
            # Get changes since base backup
            changes = self._get_database_changes(base_backup.created_at)
            
            # Create incremental backup file
            incremental_data = {
                'backup_type': 'incremental',
                'base_backup_id': base_backup_id,
                'created_at': timestamp.isoformat(),
                'changes': changes
            }
            
            with open(backup_filepath, 'w') as f:
                json.dump(incremental_data, f, indent=2, default=str)
            
            # Compress if enabled
            if self.config.compression_enabled:
                compressed_filepath = self._compress_backup(backup_filepath)
                backup_filepath.unlink()
                backup_filepath = compressed_filepath
                backup_filename = backup_filepath.name
            
            # Calculate checksum
            checksum = self._calculate_checksum(backup_filepath)
            
            # Create backup info
            backup_info = BackupInfo(
                backup_id=backup_id,
                filename=backup_filename,
                filepath=backup_filepath.absolute().as_posix(),
                created_at=timestamp,
                backup_type='incremental',
                size_bytes=backup_filepath.stat().st_size,
                compressed=self.config.compression_enabled,
                encrypted=False,
                checksum=checksum,
                database_version='incremental',
                table_counts={'changes': len(changes)},
                description=description
            )
            
            # Save backup metadata
            self._save_backup_metadata(backup_info)
            
            # Cleanup and verify
            if self.config.auto_cleanup:
                self._cleanup_old_backups()
            
            if self.config.verify_backups:
                if not self.verify_backup(backup_info):
                    return False, "Incremental backup verification failed", None
            
            logger.info(f"Incremental backup created: {backup_id}")
            return True, f"Incremental backup created: {backup_id}", backup_info
            
        except Exception as e:
            logger.error(f"Error creating incremental backup: {e}")
            return False, f"Incremental backup failed: {e}", None
    
    def restore_backup(self, backup_id: str, force: bool = False) -> Tuple[bool, str]:
        """Restore database from backup"""
        try:
            # Get backup info
            backup_info = self._get_backup_info(backup_id)
            if not backup_info:
                return False, f"Backup not found: {backup_id}"
            
            backup_path = Path(backup_info.filepath)
            
            if not backup_path.exists():
                return False, f"Backup file not found: {backup_path}"
            
            # Verify backup integrity
            if self.config.verify_backups:
                if not self.verify_backup(backup_info):
                    return False, "Backup integrity verification failed"
            
            # Check if database is in use
            if not force and self._is_database_in_use():
                return False, "Database appears to be in use. Use force=True to override."
            
            # Create current database backup before restore
            current_backup_id = f"pre_restore_{datetime.datetime.now().strftime('%Y%m%d_%H%M%S')}"
            current_backup_path = self.backup_dir / "full" / f"{current_backup_id}.db"
            shutil.copy2(self.database_path, current_backup_path)
            logger.info(f"Created pre-restore backup: {current_backup_path}")
            
            # Restore from backup
            with self.lock:
                if backup_info.backup_type == 'full':
                    # Restore full database
                    restored_path = backup_path
                    if backup_info.compressed:
                        # Decompress first
                        restored_path = self._decompress_backup(backup_path)
                    
                    shutil.copy2(restored_path, self.database_path)
                    
                    if backup_info.compressed and restored_path != backup_path:
                        restored_path.unlink()  # Clean up decompressed file
                
                elif backup_info.backup_type == 'incremental':
                    # Apply incremental changes
                    self._apply_incremental_backup(backup_info)
            
            logger.info(f"Database restored from backup: {backup_id}")
            return True, f"Database restored successfully from {backup_id}"
            
        except Exception as e:
            logger.error(f"Error restoring backup {backup_id}: {e}")
            return False, f"Restore failed: {e}"
    
    def verify_backup(self, backup_info: BackupInfo) -> bool:
        """Verify backup integrity"""
        try:
            backup_path = Path(backup_info.filepath)
            
            if not backup_path.exists():
                logger.error(f"Backup file not found: {backup_path}")
                return False
            
            # Check file size
            actual_size = backup_path.stat().st_size
            if actual_size != backup_info.size_bytes:
                logger.error(f"Backup size mismatch: expected {backup_info.size_bytes}, got {actual_size}")
                return False
            
            # Check checksum
            calculated_checksum = self._calculate_checksum(backup_path)
            if calculated_checksum != backup_info.checksum:
                logger.error(f"Backup checksum mismatch: expected {backup_info.checksum}, got {calculated_checksum}")
                return False
            
            # Test database connectivity if it's a full backup
            if backup_info.backup_type == 'full':
                if not self._test_database_integrity(backup_path):
                    logger.error("Database integrity check failed")
                    return False
            
            logger.info(f"Backup verification successful: {backup_info.backup_id}")
            return True
            
        except Exception as e:
            logger.error(f"Error verifying backup {backup_info.backup_id}: {e}")
            return False
    
    def list_backups(self) -> List[BackupInfo]:
        """List all available backups"""
        backups = []
        
        try:
            backups_dir = self.backup_dir
            for backup_file in backups_dir.rglob("*.db*"):
                metadata_file = backup_file.with_suffix(backup_file.suffix + ".meta")
                
                if metadata_file.exists():
                    try:
                        with open(metadata_file, 'r') as f:
                            metadata = json.load(f)
                        
                        backup_info = BackupInfo(**metadata)
                        backup_info.filepath = backup_file.absolute().as_posix()
                        backup_info.size_bytes = backup_file.stat().st_size
                        backups.append(backup_info)
                        
                    except Exception as e:
                        logger.warning(f"Error loading backup metadata {metadata_file}: {e}")
            
            # Sort by creation time (newest first)
            backups.sort(key=lambda x: x.created_at, reverse=True)
            return backups
            
        except Exception as e:
            logger.error(f"Error listing backups: {e}")
            return []
    
    def delete_backup(self, backup_id: str) -> Tuple[bool, str]:
        """Delete a specific backup"""
        try:
            backup_info = self._get_backup_info(backup_id)
            if not backup_info:
                return False, f"Backup not found: {backup_id}"
            
            backup_path = Path(backup_info.filepath)
            metadata_path = backup_path.with_suffix(backup_path.suffix + ".meta")
            
            # Delete files
            if backup_path.exists():
                backup_path.unlink()
            if metadata_path.exists():
                metadata_path.unlink()
            
            logger.info(f"Deleted backup: {backup_id}")
            return True, f"Backup {backup_id} deleted successfully"
            
        except Exception as e:
            logger.error(f"Error deleting backup {backup_id}: {e}")
            return False, f"Delete failed: {e}"
    
    def schedule_backup(self, schedule_type: str = "daily") -> bool:
        """Schedule automatic backups"""
        try:
            if schedule_type not in self.config.backup_schedule:
                logger.error(f"Unknown schedule type: {schedule_type}")
                return False
            
            frequency = self.config.backup_schedule[schedule_type]
            backup_thread = threading.Thread(
                target=self._backup_scheduler,
                args=(schedule_type, frequency),
                daemon=True
            )
            backup_thread.start()
            
            self._backup_schedules[schedule_type] = backup_thread
            logger.info(f"Scheduled {schedule_type} backup every {frequency} seconds")
            return True
            
        except Exception as e:
            logger.error(f"Error scheduling backup: {e}")
            return False
    
    def _create_database_backup(self, backup_path: Path) -> bool:
        """Create database backup using SQLite's backup API"""
        try:
            with sqlite3.connect(self.database_path) as source:
                with sqlite3.connect(backup_path) as backup:
                    source.backup(backup)
            return True
        except Exception as e:
            logger.error(f"Error creating database backup: {e}")
            return False
    
    def _compress_backup(self, backup_path: Path) -> Path:
        """Compress backup file"""
        compressed_path = backup_path.with_suffix(backup_path.suffix + ".gz")
        
        with open(backup_path, 'rb') as f_in:
            with gzip.open(compressed_path, 'wb') as f_out:
                shutil.copyfileobj(f_in, f_out)
        
        return compressed_path
    
    def _decompress_backup(self, compressed_path: Path) -> Path:
        """Decompress backup file"""
        decompressed_path = compressed_path.with_suffix('')
        decompressed_path = decompressed_path.with_suffix('')
        
        with gzip.open(compressed_path, 'rb') as f_in:
            with open(decompressed_path, 'wb') as f_out:
                shutil.copyfileobj(f_in, f_out)
        
        return decompressed_path
    
    def _calculate_checksum(self, file_path: Path) -> str:
        """Calculate SHA-256 checksum of file"""
        sha256_hash = hashlib.sha256()
        with open(file_path, "rb") as f:
            for byte_block in iter(lambda: f.read(4096), b""):
                sha256_hash.update(byte_block)
        return sha256_hash.hexdigest()
    
    def _get_database_info(self) -> Dict[str, Any]:
        """Get database information"""
        info = {'version': 'unknown', 'table_counts': {}}
        
        try:
            with sqlite3.connect(self.database_path) as conn:
                cursor = conn.cursor()
                
                # Get SQLite version
                cursor.execute("SELECT sqlite_version()")
                info['version'] = cursor.fetchone()[0]
                
                # Get table counts
                cursor.execute("SELECT name FROM sqlite_master WHERE type='table'")
                tables = cursor.fetchall()
                
                for table in tables:
                    table_name = table[0]
                    cursor.execute(f"SELECT COUNT(*) FROM {table_name}")
                    info['table_counts'][table_name] = cursor.fetchone()[0]
                
        except Exception as e:
            logger.warning(f"Error getting database info: {e}")
        
        return info
    
    def _get_database_changes(self, since_timestamp: datetime.datetime) -> Dict[str, Any]:
        """Get database changes since timestamp"""
        changes = {'tables': {}, 'new_records': [], 'modified_records': []}
        
        try:
            with sqlite3.connect(self.database_path) as conn:
                cursor = conn.cursor()
                
                # Get all tables
                cursor.execute("SELECT name FROM sqlite_master WHERE type='table'")
                tables = cursor.fetchall()
                
                for table in tables:
                    table_name = table[0]
                    
                    # Skip internal tables
                    if table_name.startswith('sqlite_'):
                        continue
                    
                    try:
                        # Get records modified since timestamp
                        cursor.execute(f"SELECT * FROM {table_name} WHERE last_updated >= ? OR first_seen >= ?", 
                                     (since_timestamp.isoformat(), since_timestamp.isoformat()))
                        records = cursor.fetchall()
                        
                        if records:
                            # Get column names
                            cursor.execute(f"PRAGMA table_info({table_name})")
                            columns = [col[1] for col in cursor.fetchall()]
                            
                            changes['tables'][table_name] = {
                                'columns': columns,
                                'record_count': len(records),
                                'records': [dict(zip(columns, record)) for record in records]
                            }
                            
                    except Exception as e:
                        logger.warning(f"Error getting changes for table {table_name}: {e}")
                        
        except Exception as e:
            logger.error(f"Error getting database changes: {e}")
        
        return changes
    
    def _apply_incremental_backup(self, backup_info: BackupInfo):
        """Apply incremental backup changes"""
        try:
            backup_path = Path(backup_info.filepath)
            
            with open(backup_path, 'r') as f:
                incremental_data = json.load(f)
            
            with sqlite3.connect(self.database_path) as conn:
                cursor = conn.cursor()
                
                # Apply changes to each table
                for table_name, table_data in incremental_data['changes']['tables'].items():
                    for record in table_data['records']:
                        # Simple upsert logic
                        try:
                            columns = list(record.keys())
                            placeholders = ', '.join(['?' for _ in columns])
                            update_placeholders = ', '.join([f"{col}=excluded.{col}" for col in columns if col != 'id'])
                            
                            values = list(record.values())
                            sql = f"""
                            INSERT INTO {table_name} ({', '.join(columns)})
                            VALUES ({placeholders})
                            ON CONFLICT(id) DO UPDATE SET {update_placeholders}
                            """
                            
                            cursor.execute(sql, values)
                            
                        except Exception as e:
                            logger.warning(f"Error applying incremental change: {e}")
                
                conn.commit()
                
        except Exception as e:
            logger.error(f"Error applying incremental backup: {e}")
            raise
    
    def _save_backup_metadata(self, backup_info: BackupInfo):
        """Save backup metadata to file"""
        metadata_path = Path(backup_info.filepath).with_suffix(Path(backup_info.filepath).suffix + ".meta")
        
        metadata = asdict(backup_info)
        metadata['created_at'] = backup_info.created_at.isoformat()
        
        with open(metadata_path, 'w') as f:
            json.dump(metadata, f, indent=2)
    
    def _get_backup_info(self, backup_id: str) -> Optional[BackupInfo]:
        """Get backup info by ID"""
        for backup in self.list_backups():
            if backup.backup_id == backup_id:
                return backup
        return None
    
    def _get_most_recent_full_backup(self) -> Optional[str]:
        """Get the most recent full backup ID"""
        full_backups = [b for b in self.list_backups() if b.backup_type == 'full']
        return full_backups[0].backup_id if full_backups else None
    
    def _is_database_in_use(self) -> bool:
        """Check if database is currently in use"""
        try:
            with sqlite3.connect(self.database_path) as conn:
                cursor = conn.cursor()
                cursor.execute("BEGIN IMMEDIATE")
                cursor.execute("COMMIT")
            return False
        except sqlite3.OperationalError as e:
            if "database is locked" in str(e).lower():
                return True
            return False
    
    def _test_database_integrity(self, db_path: Path) -> bool:
        """Test database integrity"""
        try:
            with sqlite3.connect(db_path) as conn:
                cursor = conn.cursor()
                cursor.execute("PRAGMA integrity_check")
                result = cursor.fetchone()
                return result[0] == "ok"
        except Exception:
            return False
    
    def _cleanup_old_backups(self):
        """Clean up old backups based on configuration"""
        try:
            backups = self.list_backups()
            
            if len(backups) <= self.config.max_backups:
                return
            
            # Keep only the most recent backups
            backups_to_delete = backups[self.config.max_backups:]
            
            for backup in backups_to_delete:
                self.delete_backup(backup.backup_id)
                
        except Exception as e:
            logger.error(f"Error during backup cleanup: {e}")
    
    def _backup_scheduler(self, schedule_type: str, frequency: int):
        """Background backup scheduler"""
        while True:
            try:
                if schedule_type == "full":
                    self.create_full_backup(f"Scheduled {schedule_type} backup")
                else:
                    self.create_incremental_backup(description=f"Scheduled {schedule_type} backup")
                
                time.sleep(frequency)
                
            except Exception as e:
                logger.error(f"Error in {schedule_type} backup scheduler: {e}")
                time.sleep(frequency)  # Continue scheduling even on errors
    
    def _sync_to_remote(self, backup_path: Path):
        """Sync backup to remote location (placeholder for future implementation)"""
        # This would implement remote backup sync (SFTP, cloud storage, etc.)
        logger.info(f"Remote backup sync not implemented for: {backup_path}")

def main():
    """Main function to test backup and recovery"""
    from threat_database import ThreatDatabase
    
    # Initialize database and backup manager
    db = ThreatDatabase("test_threats.db")
    backup_config = BackupConfig(
        backup_directory="test_backups",
        max_backups=5,
        compression_enabled=True,
        verify_backups=True
    )
    
    backup_manager = BackupManager("test_threats.db", backup_config)
    
    # Create full backup
    success, message, backup_info = backup_manager.create_full_backup("Test backup")
    print(f"Full backup: {success} - {message}")
    
    if backup_info:
        print(f"Backup ID: {backup_info.backup_id}")
        print(f"Backup size: {backup_info.size_bytes} bytes")
        
        # Verify backup
        verified = backup_manager.verify_backup(backup_info)
        print(f"Backup verification: {verified}")
        
        # List all backups
        backups = backup_manager.list_backups()
        print(f"Total backups: {len(backups)}")
        
        # Schedule backup
        scheduled = backup_manager.schedule_backup("daily")
        print(f"Backup scheduled: {scheduled}")

if __name__ == "__main__":
    main()