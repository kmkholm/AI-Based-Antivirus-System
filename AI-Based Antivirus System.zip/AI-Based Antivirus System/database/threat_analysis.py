#!/usr/bin/env python3
"""
Threat Analysis and Reporting Module
Provides comprehensive threat analysis, reporting, and analytics
"""

import json
import datetime
from typing import Dict, List, Optional, Any, Tuple
from dataclasses import dataclass, asdict
from pathlib import Path
import logging
import matplotlib.pyplot as plt
import pandas as pd
import numpy as np
from collections import defaultdict, Counter

from threat_database import ThreatDatabase
from quarantine_manager import QuarantineManager
from threat_intel import ThreatIntelIntegrator

logger = logging.getLogger(__name__)

@dataclass
class ThreatMetrics:
    """Threat analysis metrics"""
    total_threats: int = 0
    threats_by_level: Dict[str, int] = None
    threats_by_type: Dict[str, int] = None
    quarantine_count: int = 0
    analysis_count: int = 0
    false_positive_rate: float = 0.0
    detection_rate: float = 0.0
    time_period: str = ""

class ThreatAnalyzer:
    """Analyzes threat data and generates reports"""
    
    def __init__(self, database: ThreatDatabase, quarantine_manager: QuarantineManager = None, 
                 threat_intel: ThreatIntelIntegrator = None):
        self.database = database
        self.quarantine_manager = quarantine_manager
        self.threat_intel = threat_intel
        
    def analyze_threat_trends(self, days: int = 30) -> Dict[str, Any]:
        """Analyze threat trends over a time period"""
        try:
            end_date = datetime.datetime.now()
            start_date = end_date - datetime.timedelta(days=days)
            
            # Get events within time period
            with self.database._get_connection() as conn:
                cursor = conn.cursor()
                
                # Threat events over time
                cursor.execute('''
                    SELECT 
                        DATE(event_time) as date,
                        event_type,
                        COUNT(*) as count
                    FROM threat_events 
                    WHERE event_time >= ? AND event_time <= ?
                    GROUP BY DATE(event_time), event_type
                    ORDER BY date
                ''', (start_date.isoformat(), end_date.isoformat()))
                
                events = cursor.fetchall()
                
                # Threats by level over time
                cursor.execute('''
                    SELECT 
                        DATE(first_seen) as date,
                        threat_level,
                        COUNT(*) as count
                    FROM threat_signatures 
                    WHERE first_seen >= ? AND first_seen <= ?
                    GROUP BY DATE(first_seen), threat_level
                    ORDER BY date
                ''', (start_date.isoformat(), end_date.isoformat()))
                
                threats = cursor.fetchall()
                
                # Top threat sources
                cursor.execute('''
                    SELECT 
                        source,
                        COUNT(*) as count,
                        AVG(confidence_score) as avg_confidence
                    FROM threat_signatures 
                    WHERE first_seen >= ? AND first_seen <= ?
                    GROUP BY source
                    ORDER BY count DESC
                    LIMIT 10
                ''', (start_date.isoformat(), end_date.isoformat()))
                
                sources = cursor.fetchall()
            
            # Process data
            daily_events = defaultdict(lambda: defaultdict(int))
            daily_threats = defaultdict(lambda: defaultdict(int))
            
            for event in events:
                daily_events[event['date']][event['event_type']] = event['count']
            
            for threat in threats:
                daily_threats[threat['date']][threat['threat_level']] = threat['count']
            
            # Calculate trends
            trends = {
                'period': f"{start_date.strftime('%Y-%m-%d')} to {end_date.strftime('%Y-%m-%d')}",
                'daily_events': dict(daily_events),
                'daily_threats': dict(daily_threats),
                'top_sources': [dict(row) for row in sources],
                'summary': {
                    'total_events': sum(sum(events_by_type.values()) for events_by_type in daily_events.values()),
                    'total_threats': sum(sum(threats_by_level.values()) for threats_by_level in daily_threats.values()),
                    'unique_days_with_activity': len(daily_events),
                    'most_active_day': max(daily_events.keys(), key=lambda x: sum(daily_events[x].values())) if daily_events else None
                }
            }
            
            return trends
            
        except Exception as e:
            logger.error(f"Error analyzing threat trends: {e}")
            return {'error': str(e)}
    
    def analyze_signature_effectiveness(self) -> Dict[str, Any]:
        """Analyze the effectiveness of threat signatures"""
        try:
            with self.database._get_connection() as conn:
                cursor = conn.cursor()
                
                # Signature usage statistics
                cursor.execute('''
                    SELECT 
                        type,
                        COUNT(*) as total_signatures,
                        AVG(usage_count) as avg_usage,
                        AVG(confidence_score) as avg_confidence,
                        AVG(false_positive_rate) as avg_fp_rate,
                        SUM(usage_count) as total_usage
                    FROM threat_signatures 
                    WHERE active = 1
                    GROUP BY type
                    ORDER BY total_usage DESC
                ''')
                
                signature_stats = cursor.fetchall()
                
                # Most effective signatures (high usage, low FP rate)
                cursor.execute('''
                    SELECT 
                        name,
                        type,
                        usage_count,
                        confidence_score,
                        false_positive_rate,
                        last_updated
                    FROM threat_signatures 
                    WHERE active = 1 AND usage_count > 0
                    ORDER BY (usage_count * confidence_score) / (false_positive_rate + 0.01) DESC
                    LIMIT 20
                ''')
                
                effective_signatures = cursor.fetchall()
                
                # Detection rate by signature type
                cursor.execute('''
                    SELECT 
                        ts.type,
                        COUNT(te.id) as detections,
                        AVG(CASE WHEN te.status = 'resolved' THEN 1.0 ELSE 0.0 END) as resolution_rate
                    FROM threat_signatures ts
                    LEFT JOIN threat_events te ON ts.id = te.signature_id
                    WHERE ts.active = 1
                    GROUP BY ts.type
                ''')
                
                detection_rates = cursor.fetchall()
            
            analysis = {
                'signature_statistics': [dict(row) for row in signature_stats],
                'most_effective_signatures': [dict(row) for row in effective_signatures],
                'detection_rates': [dict(row) for row in detection_rates],
                'recommendations': self._generate_signature_recommendations(signature_stats)
            }
            
            return analysis
            
        except Exception as e:
            logger.error(f"Error analyzing signature effectiveness: {e}")
            return {'error': str(e)}
    
    def analyze_quarantine_patterns(self) -> Dict[str, Any]:
        """Analyze quarantine file patterns and trends"""
        if not self.quarantine_manager:
            return {'error': 'Quarantine manager not available'}
        
        try:
            # Get quarantine statistics
            stats = self.quarantine_manager.get_quarantine_statistics()
            
            # Analyze quarantine patterns
            with self.database._get_connection() as conn:
                cursor = conn.cursor()
                
                # Quarantine over time
                cursor.execute('''
                    SELECT 
                        DATE(quarantine_time) as date,
                        threat_level,
                        COUNT(*) as count
                    FROM quarantine_files 
                    WHERE quarantine_time >= datetime('now', '-30 days')
                    GROUP BY DATE(quarantine_time), threat_level
                    ORDER BY date
                ''')
                
                quarantine_trends = cursor.fetchall()
                
                # Most common threat names
                cursor.execute('''
                    SELECT 
                        threat_name,
                        COUNT(*) as count,
                        AVG(CASE 
                            WHEN threat_level = 'critical' THEN 4
                            WHEN threat_level = 'high' THEN 3
                            WHEN threat_level = 'medium' THEN 2
                            ELSE 1
                        END) as avg_severity_score
                    FROM quarantine_files 
                    GROUP BY threat_name
                    ORDER BY count DESC
                    LIMIT 15
                ''')
                
                common_threats = cursor.fetchall()
                
                # File types being quarantined
                cursor.execute('''
                    SELECT 
                        file_type,
                        COUNT(*) as count,
                        AVG(file_size) as avg_size
                    FROM quarantine_files 
                    WHERE file_type IS NOT NULL
                    GROUP BY file_type
                    ORDER BY count DESC
                ''')
                
                file_types = cursor.fetchall()
            
            # Process trends
            daily_quarantine = defaultdict(lambda: defaultdict(int))
            for trend in quarantine_trends:
                daily_quarantine[trend['date']][trend['threat_level']] = trend['count']
            
            analysis = {
                'current_statistics': stats,
                'daily_quarantine': dict(daily_quarantine),
                'most_common_threats': [dict(row) for row in common_threats],
                'file_type_distribution': [dict(row) for row in file_types],
                'patterns': {
                    'peak_quarantine_day': max(daily_quarantine.keys(), key=lambda x: sum(daily_quarantine[x].values())) if daily_quarantine else None,
                    'most_quarantined_threat': common_threats[0]['threat_name'] if common_threats else None,
                    'total_unique_threats': len(set(t['threat_name'] for t in common_threats))
                }
            }
            
            return analysis
            
        except Exception as e:
            logger.error(f"Error analyzing quarantine patterns: {e}")
            return {'error': str(e)}
    
    def generate_comprehensive_report(self, report_type: str = "summary", 
                                    days: int = 30) -> Dict[str, Any]:
        """Generate a comprehensive threat analysis report"""
        try:
            report_timestamp = datetime.datetime.now().isoformat()
            
            # Base report structure
            report = {
                'report_metadata': {
                    'type': report_type,
                    'generated_at': report_timestamp,
                    'period_days': days,
                    'database_path': self.database.db_path.as_posix() if hasattr(self.database, 'db_path') else 'unknown'
                },
                'executive_summary': {},
                'detailed_analysis': {},
                'recommendations': []
            }
            
            # Get basic statistics
            stats = self.database.get_statistics()
            report['executive_summary']['database_statistics'] = stats
            
            # Threat trends analysis
            if report_type in ["summary", "trends", "comprehensive"]:
                trends = self.analyze_threat_trends(days)
                report['detailed_analysis']['threat_trends'] = trends
                
                if not trends.get('error'):
                    report['executive_summary']['period_summary'] = trends['summary']
            
            # Signature effectiveness
            if report_type in ["summary", "signatures", "comprehensive"]:
                sig_analysis = self.analyze_signature_effectiveness()
                report['detailed_analysis']['signature_analysis'] = sig_analysis
                
                if not sig_analysis.get('error'):
                    report['executive_summary']['signature_effectiveness'] = {
                        'total_signature_types': len(sig_analysis.get('signature_statistics', [])),
                        'most_effective_type': sig_analysis.get('signature_statistics', [{}])[0].get('type') if sig_analysis.get('signature_statistics') else None
                    }
            
            # Quarantine analysis
            if report_type in ["summary", "quarantine", "comprehensive"] and self.quarantine_manager:
                quarantine_analysis = self.analyze_quarantine_patterns()
                report['detailed_analysis']['quarantine_analysis'] = quarantine_analysis
                
                if not quarantine_analysis.get('error'):
                    report['executive_summary']['quarantine_status'] = quarantine_analysis['current_statistics']
            
            # Threat intelligence status
            if self.threat_intel:
                source_status = self.threat_intel.get_source_status()
                report['detailed_analysis']['threat_intel_status'] = {
                    'sources': source_status,
                    'total_sources': len(source_status),
                    'active_sources': len([s for s in source_status if s['enabled']])
                }
            
            # Generate recommendations
            report['recommendations'] = self._generate_recommendations(report)
            
            return report
            
        except Exception as e:
            logger.error(f"Error generating comprehensive report: {e}")
            return {'error': str(e), 'report_metadata': {'generated_at': datetime.datetime.now().isoformat()}}
    
    def export_report(self, report_data: Dict[str, Any], output_file: str, 
                     format_type: str = "json") -> bool:
        """Export report to file"""
        try:
            output_path = Path(output_file)
            output_path.parent.mkdir(parents=True, exist_ok=True)
            
            if format_type.lower() == "json":
                with open(output_path, 'w') as f:
                    json.dump(report_data, f, indent=2, default=str)
            
            elif format_type.lower() == "html":
                html_content = self._generate_html_report(report_data)
                with open(output_path, 'w') as f:
                    f.write(html_content)
            
            elif format_type.lower() == "csv":
                self._export_csv_report(report_data, output_path)
            
            else:
                raise ValueError(f"Unsupported export format: {format_type}")
            
            logger.info(f"Report exported to: {output_path}")
            return True
            
        except Exception as e:
            logger.error(f"Error exporting report: {e}")
            return False
    
    def _generate_signature_recommendations(self, signature_stats: List) -> List[str]:
        """Generate recommendations based on signature analysis"""
        recommendations = []
        
        try:
            for stat in signature_stats:
                if stat['avg_fp_rate'] > 0.1:  # More than 10% false positive rate
                    recommendations.append(
                        f"Consider tuning {stat['type']} signatures (FP rate: {stat['avg_fp_rate']:.2%})"
                    )
                
                if stat['avg_usage'] < 1:  # Low usage
                    recommendations.append(
                        f"Review usage of {stat['type']} signatures (avg usage: {stat['avg_usage']:.1f})"
                    )
                
                if stat['avg_confidence'] < 0.5:  # Low confidence
                    recommendations.append(
                        f"Improve confidence thresholds for {stat['type']} signatures (avg confidence: {stat['avg_confidence']:.2f})"
                    )
            
            return recommendations
            
        except Exception as e:
            logger.error(f"Error generating signature recommendations: {e}")
            return ["Error generating recommendations"]
    
    def _generate_recommendations(self, report_data: Dict[str, Any]) -> List[str]:
        """Generate overall recommendations based on report data"""
        recommendations = []
        
        try:
            # Database size recommendations
            stats = report_data.get('executive_summary', {}).get('database_statistics', {})
            if stats.get('total_signatures', 0) > 10000:
                recommendations.append(
                    "Consider implementing signature lifecycle management to maintain optimal performance"
                )
            
            # Quarantine recommendations
            quarantine_stats = report_data.get('executive_summary', {}).get('quarantine_status', {})
            if quarantine_stats:
                quarantine_by_status = quarantine_stats.get('by_status', {})
                quarantined_count = quarantine_by_status.get('quarantined', 0)
                
                if quarantined_count > 1000:
                    recommendations.append(
                        f"Large number of quarantined files ({quarantined_count}) - consider cleanup policy review"
                    )
                
                # Check for old quarantined files
                oldest_quarantine = quarantine_stats.get('oldest_quarantine')
                if oldest_quarantine:
                    try:
                        oldest_date = datetime.datetime.fromisoformat(oldest_quarantine.replace('Z', '+00:00'))
                        days_old = (datetime.datetime.now() - oldest_date).days
                        
                        if days_old > 90:
                            recommendations.append(
                                f"Old quarantined files detected (oldest: {days_old} days) - review retention policy"
                            )
                    except:
                        pass
            
            # Threat trends recommendations
            trends = report_data.get('detailed_analysis', {}).get('threat_trends', {})
            if trends:
                summary = trends.get('summary', {})
                total_events = summary.get('total_events', 0)
                
                if total_events > 1000:
                    recommendations.append(
                        "High threat activity detected - consider enhancing monitoring and response capabilities"
                    )
            
            # General recommendations
            recommendations.extend([
                "Regularly update threat intelligence feeds to maintain detection accuracy",
                "Monitor false positive rates and adjust detection thresholds as needed",
                "Implement automated backup procedures for the threat database",
                "Review and update signature rules based on latest threat intelligence"
            ])
            
            return recommendations
            
        except Exception as e:
            logger.error(f"Error generating recommendations: {e}")
            return ["Error generating recommendations - please review logs"]
    
    def _generate_html_report(self, report_data: Dict[str, Any]) -> str:
        """Generate HTML report from report data"""
        try:
            html_template = """
            <!DOCTYPE html>
            <html>
            <head>
                <title>Threat Analysis Report</title>
                <style>
                    body { font-family: Arial, sans-serif; margin: 40px; }
                    h1, h2, h3 { color: #333; }
                    .header { background-color: #f4f4f4; padding: 20px; border-radius: 5px; }
                    .section { margin: 20px 0; padding: 15px; border: 1px solid #ddd; border-radius: 5px; }
                    .metric { display: inline-block; margin: 10px; padding: 10px; background-color: #e8f4f8; border-radius: 3px; }
                    .warning { color: #d9534f; }
                    .success { color: #5cb85c; }
                    table { width: 100%; border-collapse: collapse; margin: 10px 0; }
                    th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
                    th { background-color: #f2f2f2; }
                </style>
            </head>
            <body>
                <div class="header">
                    <h1>Threat Analysis Report</h1>
                    <p>Generated: {generated_at}</p>
                    <p>Report Type: {report_type}</p>
                </div>
                
                <div class="section">
                    <h2>Executive Summary</h2>
                    {executive_summary}
                </div>
                
                <div class="section">
                    <h2>Detailed Analysis</h2>
                    {detailed_analysis}
                </div>
                
                <div class="section">
                    <h2>Recommendations</h2>
                    <ul>
                        {recommendations}
                    </ul>
                </div>
            </body>
            </html>
            """
            
            # Format executive summary
            exec_summary = ""
            db_stats = report_data.get('executive_summary', {}).get('database_statistics', {})
            if db_stats:
                exec_summary += f"<p><strong>Total Signatures:</strong> {db_stats.get('total_signatures', 0)}</p>"
                exec_summary += f"<p><strong>Quarantine Files:</strong> {sum(db_stats.get('quarantine_by_status', {}).values())}</p>"
            
            # Format detailed analysis (simplified)
            detailed = "<p>See JSON report for detailed analysis data.</p>"
            
            # Format recommendations
            recommendations_html = "".join(
                f"<li>{rec}</li>" for rec in report_data.get('recommendations', [])
            )
            
            html_content = html_template.format(
                generated_at=report_data.get('report_metadata', {}).get('generated_at', 'Unknown'),
                report_type=report_data.get('report_metadata', {}).get('type', 'Unknown'),
                executive_summary=exec_summary,
                detailed_analysis=detailed,
                recommendations=recommendations_html
            )
            
            return html_content
            
        except Exception as e:
            logger.error(f"Error generating HTML report: {e}")
            return f"<html><body><h1>Error generating report</h1><p>{str(e)}</p></body></html>"
    
    def _export_csv_report(self, report_data: Dict[str, Any], output_path: Path):
        """Export selected report data to CSV"""
        import csv
        
        with open(output_path, 'w', newline='') as csvfile:
            # Export signature statistics
            if 'detailed_analysis' in report_data and 'signature_analysis' in report_data['detailed_analysis']:
                sig_stats = report_data['detailed_analysis']['signature_analysis'].get('signature_statistics', [])
                if sig_stats:
                    writer = csv.DictWriter(csvfile, fieldnames=sig_stats[0].keys())
                    writer.writeheader()
                    writer.writerows(sig_stats)
    
    def create_visualization(self, data_type: str = "threat_trends", output_file: str = "chart.png"):
        """Create visualization charts from threat data"""
        try:
            if data_type == "threat_trends":
                trends = self.analyze_threat_trends(30)
                if trends.get('error'):
                    return False
                
                # Create threat trends chart
                fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(12, 8))
                
                # Process daily events data
                daily_events = trends.get('daily_events', {})
                dates = sorted(daily_events.keys())
                
                if dates:
                    # Total events per day
                    total_events = [sum(daily_events[date].values()) for date in dates]
                    
                    ax1.plot(dates, total_events, marker='o', linewidth=2)
                    ax1.set_title('Daily Threat Events')
                    ax1.set_xlabel('Date')
                    ax1.set_ylabel('Number of Events')
                    ax1.grid(True, alpha=0.3)
                    ax1.tick_params(axis='x', rotation=45)
                    
                    # Events by type
                    event_types = set()
                    for daily_data in daily_events.values():
                        event_types.update(daily_data.keys())
                    
                    for event_type in sorted(event_types):
                        counts = [daily_events[date].get(event_type, 0) for date in dates]
                        ax2.plot(dates, counts, marker='s', label=event_type, alpha=0.7)
                    
                    ax2.set_title('Threat Events by Type')
                    ax2.set_xlabel('Date')
                    ax2.set_ylabel('Number of Events')
                    ax2.legend()
                    ax2.grid(True, alpha=0.3)
                    ax2.tick_params(axis='x', rotation=45)
                
                plt.tight_layout()
                plt.savefig(output_file, dpi=300, bbox_inches='tight')
                plt.close()
                
                logger.info(f"Visualization saved to: {output_file}")
                return True
                
        except Exception as e:
            logger.error(f"Error creating visualization: {e}")
            return False

def main():
    """Main function to test threat analysis and reporting"""
    from threat_database import ThreatDatabase
    from quarantine_manager import QuarantineManager, QuarantineConfig
    
    # Initialize components
    db = ThreatDatabase("test_threats.db")
    quarantine_config = QuarantineConfig(quarantine_directory="test_quarantine")
    qm = QuarantineManager(db, quarantine_config)
    
    # Initialize analyzer
    analyzer = ThreatAnalyzer(db, qm)
    
    # Generate comprehensive report
    report = analyzer.generate_comprehensive_report("comprehensive", days=30)
    print("Generated comprehensive report")
    
    # Export report
    success = analyzer.export_report(report, "reports/threat_analysis_report.json", "json")
    print(f"Report exported: {success}")
    
    # Create visualization
    chart_success = analyzer.create_visualization("threat_trends", "reports/threat_trends.png")
    print(f"Visualization created: {chart_success}")
    
    # Analyze signature effectiveness
    sig_analysis = analyzer.analyze_signature_effectiveness()
    print("Signature effectiveness analysis completed")
    
    # Analyze quarantine patterns
    quarantine_analysis = analyzer.analyze_quarantine_patterns()
    print("Quarantine pattern analysis completed")

if __name__ == "__main__":
    main()