# Threat Database and Management System

A comprehensive threat intelligence and malware management system built on SQLite, implementing signature-based and heuristic detection methods as outlined in our signature/heuristic research.

## Overview

This system provides enterprise-grade threat management capabilities including:

- **SQLite-based threat database** with comprehensive schema for threat intelligence
- **Threat intelligence integration** from multiple sources (IOCs, YARA rules, behavioral patterns)
- **Malware signature storage and retrieval** supporting hash-based, pattern, and YARA signatures
- **Quarantine file management** with security controls and audit trails
- **Threat history and reporting** with comprehensive analytics and visualizations
- **Database backup and recovery** with automated scheduling and verification

## Architecture

The system is built around five core components:

```
┌─────────────────┐    ┌──────────────────┐    ┌─────────────────┐
│ Threat Intel    │    │  SQLite Database │    │ Quarantine      │
│ Integration     │◄──►│  - Signatures    │◄──►│ Management      │
│ - IOC Feeds     │    │  - Analysis      │    │ - File Storage  │
│ - YARA Rules    │    │  - History       │    │ - Restoration   │
│ - Behavior      │    │  - Metadata      │    │ - Security      │
└─────────────────┘    └──────────────────┘    └─────────────────┘
         │                        │                        │
         ▼                        ▼                        ▼
┌─────────────────┐    ┌──────────────────┐    ┌─────────────────┐
│ Threat Analysis │    │ Backup &         │    │ Reporting &     │
│ & Reporting     │    │ Recovery         │    │ Analytics       │
│ - Trends        │    │ - Full Backups   │    │ - Comprehensive │
│ - Effectiveness │    │ - Incremental    │    │ - Visualizations│
│ - Patterns      │    │ - Verification   │    │ - Export Formats│
│ - IOA           │    │ - Scheduling     │    │ - CLI Interface │
└─────────────────┘    └──────────────────┘    └─────────────────┘
```

## Key Features

### 1. Threat Signature Management

Supports multiple signature types based on our research taxonomy:

- **Hash-based signatures** (MD5, SHA-1, SHA-256) for exact matching
- **Pattern matching** (string/byte patterns) for fine-grained detection
- **YARA rules** with logical expressions and metadata
- **Static heuristics** for code structure analysis
- **Behavioral IOA patterns** for runtime detection

### 2. Threat Intelligence Integration

- Multiple feed formats (JSON, CSV, STIX, MISP)
- Configurable confidence thresholds
- Automatic signature generation
- Source validation and health monitoring
- Support for popular sources (AlienVault OTX, VirusTotal, MISP, etc.)

### 3. Quarantine Management

- Secure file quarantining with metadata preservation
- Automatic backup before quarantine
- Configurable retention policies
- File restoration with integrity verification
- Comprehensive audit logging

### 4. Advanced Analytics

- Threat trend analysis over time
- Signature effectiveness metrics
- False positive tracking
- Performance benchmarking
- Behavioral pattern analysis

### 5. Enterprise Features

- Scheduled automatic backups
- Incremental backup support
- Backup verification and integrity checking
- CLI management interface
- RESTful API support (planned)

## Installation

### Prerequisites

- Python 3.8+
- Required Python packages:
  ```bash
  pip install sqlite3 pathlib logging dataclasses
  # Optional for advanced features:
  pip install matplotlib pandas numpy pyyaml requests
  ```

### Setup

1. **Clone and setup the database system:**
   ```bash
   cd code/database
   python -m database.threat_db_cli init --sample-data --create-backup
   ```

2. **Configure threat intelligence sources:**
   ```bash
   # Edit threat_intel.yaml with your sources
   nano threat_intel.yaml
   ```

3. **Verify installation:**
   ```bash
   python -m database.threat_db_cli status --verbose
   ```

## Quick Start

### Initialize Database

```bash
# Initialize with sample data
python -m database.threat_db_cli init --sample-data --create-backup

# Initialize minimal system
python -m database.threat_db_cli init
```

### Scan Files

```bash
# Quick file scan
python -m database.threat_db_cli scan /path/to/suspicious/file

# Verbose scan results
python -m database.threat_db_cli scan /path/to/file --verbose
```

### Add Threat Signatures

```bash
# Add hash signature
python -m database.threat_db_cli add-signature \
  --name "Known Malware Sample" \
  --type hash_sha256 \
  --content "a665a45920422f9d417e4867efdc4fb8a04a1f3fff1fa07e998e86f7f7a27ae3" \
  --threat-level high \
  --description "SHA-256 of banking trojan"

# Add YARA rule
python -m database.threat_db_cli add-signature \
  --name "Suspicious PowerShell" \
  --type yara_rule \
  --content 'rule Suspicious_PowerShell { strings: $s1 = "powershell.exe" condition: $s1 }' \
  --threat-level medium
```

### Quarantine Management

```bash
# Quarantine a suspicious file
python -m database.threat_db_cli quarantine /path/to/file \
  --threat-name "Suspicious Executable" \
  --threat-level high \
  --reason "Behavioral analysis flagged as malicious"

# List quarantined files (via Python API)
python -c "from database import create_threat_database_system; _, qm, _, _, _ = create_threat_database_system(); print(qm.get_quarantine_statistics())"
```

### Generate Reports

```bash
# Generate comprehensive report
python -m database.threat_db_cli report --type comprehensive --format html --create-charts

# Generate trend analysis
python -m database.threat_db_cli report --type trends --format json
```

### Backup Management

```bash
# Create full backup
python -m database.threat_db_cli backup create --type full --description "Weekly backup"

# Create incremental backup
python -m database.threat_db_cli backup create --type incremental

# List backups
python -m database.threat_db_cli backup list
```

### Update Threat Intelligence

```bash
# Update all sources
python -m database.threat_db_cli update-intel

# Update specific source
python -m database.threat_db_cli update-intel --source "AlienVault OTX"
```

## API Usage

### Python API

```python
from database import create_threat_database_system, ThreatSignature, ThreatLevel, SignatureType

# Create system
database, quarantine, threat_intel, analyzer, backup = create_threat_database_system()

# Add signature
signature = ThreatSignature(
    name="My Malware Sample",
    type=SignatureType.HASH_SHA256.value,
    content="a665a45920422f9d417e4867efdc4fb8a04a1f3fff1fa07e998e86f7f7a27ae3",
    description="Known malicious sample",
    threat_level=ThreatLevel.HIGH.value,
    source="manual"
)

signature_id = database.add_signature(signature)
print(f"Added signature ID: {signature_id}")

# Scan file
import hashlib
file_hash = hashlib.sha256(open('suspicious_file.exe', 'rb').read()).hexdigest()
signature = database.get_signature_by_hash(file_hash)
if signature:
    print(f"Threat detected: {signature['name']}")

# Generate report
report = analyzer.generate_comprehensive_report("comprehensive", days=30)
analyzer.export_report(report, "threat_report.json")

# Quarantine file
success, message, qid = quarantine.quarantine_file(
    "suspicious_file.exe",
    threat_name="Suspicious Executable",
    threat_level="high"
)
print(f"Quarantine result: {success}")
```

### Database Schema

The system uses the following main tables:

- `threat_signatures` - Core signature storage
- `yara_rules` - YARA rule components
- `heuristic_rules` - Static/dynamic heuristic analysis rules
- `behavioral_patterns` - IOA behavioral patterns
- `quarantine_files` - Quarantined file metadata
- `threat_analysis` - Analysis results
- `threat_events` - Event history and audit trail
- `system_config` - System configuration

## Configuration

### Threat Intelligence Sources

Configure sources in `threat_intel.yaml`:

```yaml
sources:
  - name: "AlienVault OTX"
    url: "https://otx.alienvault.com/api/v1/pulses/subscribed"
    source_type: "ioc"
    format_type: "json"
    enabled: true
    update_frequency: 3600
    confidence_threshold: 0.7
```

### System Configuration

Key configuration options:

```python
# Database settings
DATABASE_CONFIG = {
    "path": "threats.db",
    "backup_directory": "backups",
    "max_backup_count": 10,
    "auto_backup": True
}

# Quarantine settings
QUARANTINE_CONFIG = {
    "directory": "quarantine",
    "max_size": 1073741824,  # 1GB
    "auto_delete_days": 30,
    "allow_restore": True
}
```

## Advanced Features

### YARA Rule Management

```python
# Add YARA rule with full components
yara_rule = '''
rule Banking_Trojan_Detection {
    meta:
        description = "Detects banking trojan patterns"
        author = "threat_analyst"
        date = "2024-01-01"
        version = "1.0"
    
    strings:
        $mz = { 4D 5A }
        $bank_strings = "bank" ascii nocase
        $steal_function = "GetAsyncKeyState" ascii
    
    condition:
        $mz at 0 and any of ($bank_strings, $steal_function)
}
'''

signature = ThreatSignature(
    name="Banking Trojan Detection",
    type=SignatureType.YARA_RULE.value,
    content=yara_rule,
    threat_level=ThreatLevel.HIGH.value,
    source="custom_rules"
)
```

### Behavioral Analysis

```python
# Add behavioral pattern for ransomware
behavioral_pattern = ThreatSignature(
    name="Ransomware_Encryption_Pattern",
    type=SignatureType.BEHAVIORAL_IOA.value,
    content=json.dumps([
        "file_enumeration",
        "large_file_writes", 
        "file_rename_with_extension",
        "volume_shadow_delete"
    ]),
    metadata=json.dumps({
        "time_window": 300,  # 5 minutes
        "pattern_type": "ransomware_behavior",
        "severity_score": 0.9
    })
)
```

### Backup Strategies

```python
# Automated backup scheduling
backup_manager.schedule_backup("daily")
backup_manager.schedule_backup("weekly")

# Custom backup configuration
backup_config = BackupConfig(
    backup_directory="secure_backups",
    max_backups=30,
    compression_enabled=True,
    encryption_enabled=True,
    encrypt_key="your_encryption_key"
)
```

## Monitoring and Maintenance

### System Health Check

```bash
# Check overall system status
python -m database.threat_db_cli status

# Detailed health report
python -m database.threat_db_cli status --verbose
```

### Database Maintenance

```python
from database import ThreatDatabase

db = ThreatDatabase()

# Clean up old events
db.cleanup_old_events(days=90)

# Get database statistics
stats = db.get_statistics()
print(f"Total signatures: {stats['total_signatures']}")

# Export threat intelligence
export_data = db.export_threat_intelligence()
```

### Backup Verification

```python
# Verify backup integrity
backup_info = backup_manager._get_backup_info("backup_id")
is_valid = backup_manager.verify_backup(backup_info)
print(f"Backup valid: {is_valid}")
```

## Security Considerations

1. **File Quarantine Security:**
   - Files are moved, not copied, to prevent duplication
   - Original file permissions preserved in metadata
   - Automatic backup before quarantine operations
   - Integrity verification for all operations

2. **Database Security:**
   - SQLite WAL mode for improved concurrency
   - Backup verification with checksums
   - Encrypted backup support (configurable)
   - Audit trail for all operations

3. **Threat Intelligence:**
   - Source validation and health monitoring
   - Configurable confidence thresholds
   - False positive rate tracking
   - Automatic source rotation

## Performance Optimization

1. **Database Indexing:**
   - All critical columns are indexed
   - Query optimization for common operations
   - Connection pooling and reuse

2. **Memory Management:**
   - Streaming for large dataset processing
   - Configurable batch sizes
   - Automatic cleanup of temporary data

3. **Backup Efficiency:**
   - Incremental backup support
   - Compression to reduce storage
   - Parallel processing for large databases

## Troubleshooting

### Common Issues

1. **Database locked errors:**
   ```bash
   # Check for active connections
   lsof threats.db
   # Force cleanup if needed
   python -c "from database import ThreatDatabase; db = ThreatDatabase(); db.cleanup_old_events()"
   ```

2. **Quarantine permission errors:**
   ```bash
   # Check directory permissions
   ls -la quarantine/
   # Fix permissions if needed
   chmod 755 quarantine/
   ```

3. **Backup failures:**
   ```bash
   # Check disk space
   df -h
   # Verify backup directory
   ls -la backups/
   ```

### Log Analysis

Enable verbose logging:

```python
import logging
logging.basicConfig(level=logging.DEBUG)

# Check log files for errors
tail -f threat_database.log
```

## Contributing

1. **Code Structure:**
   - Follow the existing module organization
   - Add comprehensive docstrings
   - Include unit tests for new features
   - Update this README for major changes

2. **Testing:**
   ```bash
   # Run basic functionality test
   python -c "from database import create_threat_database_system; print('System OK')"
   
   # Test with sample data
   python database/__init__.py
   ```

3. **Performance Testing:**
   - Test with large signature databases
   - Verify backup/restore performance
   - Monitor memory usage during operations

## License

This threat database system is provided under the MIT License. See LICENSE file for details.

## Support

For issues and questions:

1. Check the troubleshooting section above
2. Review the log files for error details
3. Create an issue with:
   - System configuration
   - Error messages/logs
   - Steps to reproduce
   - Expected vs actual behavior

## Acknowledgments

This system is based on comprehensive research into signature-based and heuristic detection methods, incorporating best practices from:

- AV-Comparatives testing methodologies
- NIST Cybersecurity Framework
- MITRE ATT&CK framework
- Industry standard threat intelligence formats
- Modern NGAV architecture patterns

The system implements the taxonomy and recommendations from our signature/heuristic research, providing a practical implementation of academic and industry findings.