#!/usr/bin/env python3
"""
Complete Threat Database Management System
Main orchestrator for the antivirus threat database and management system
Integrates all components: database manager, quarantine, threat intelligence, backup/recovery, 
performance optimization, and analysis/reporting based on signature heuristic research
"""

import json
import yaml
import datetime
import logging
import threading
from typing import Dict, List, Optional, Any, Tuple
from pathlib import Path
from dataclasses import dataclass, asdict
import time
import schedule

from threat_database import ThreatDatabase, ThreatSignature, QuarantineEntry
from database_manager import DatabaseManager
from quarantine_manager import QuarantineManager, QuarantineConfig
from threat_intel import ThreatIntelIntegrator
from backup_recovery import BackupManager, BackupConfig
from performance_optimizer import DatabasePerformanceOptimizer
from threat_analysis import ThreatAnalyzer
from enhanced_signature_manager import EnhancedSignatureManager, DetectionMethod

logger = logging.getLogger(__name__)

@dataclass
class SystemConfig:
    """Complete system configuration"""
    database_path: str = "threats.db"
    backup_directory: str = "backups"
    quarantine_directory: str = "quarantine"
    config_file: str = "threat_database.yaml"
    threat_intel_file: str = "threat_intel.yaml"
    
    # System settings
    enable_auto_backup: bool = True
    enable_auto_maintenance: bool = True
    enable_threat_intel_updates: bool = True
    enable_signature_lifecycle: bool = True
    
    # Performance settings
    performance_monitoring: bool = True
    optimization_interval: int = 3600  # 1 hour
    health_check_interval: int = 300   # 5 minutes
    
    # Security settings
    audit_logging: bool = True
    integrity_checking: bool = True
    encryption_enabled: bool = False

@dataclass
class SystemStatus:
    """System health and status information"""
    status: str = "unknown"
    uptime_seconds: float = 0.0
    database_size_mb: float = 0.0
    total_signatures: int = 0
    quarantined_files: int = 0
    last_backup: Optional[str] = None
    last_optimization: Optional[str] = None
    last_threat_intel_update: Optional[str] = None
    performance_score: float = 0.0
    active_issues: List[str] = None
    
    def __post_init__(self):
        if self.active_issues is None:
            self.active_issues = []

class ThreatDatabaseSystem:
    """
    Complete threat database management system
    Main orchestrator for all threat database functionality
    """
    
    def __init__(self, config_file: str = "threat_database.yaml"):
        self.config_file = Path(config_file)
        self.config = self._load_system_config()
        self._lock = threading.RLock()
        self._start_time = time.time()
        
        # Initialize all system components
        self._initialize_system()
        
        # Start background services
        self._start_background_services()
        
        logger.info("Threat Database System initialized successfully")
    
    def _load_system_config(self) -> SystemConfig:
        """Load system configuration from file"""
        default_config = SystemConfig()
        
        if self.config_file.exists():
            try:
                with open(self.config_file, 'r') as f:
                    config_data = yaml.safe_load(f) or {}
                
                # Update default config with loaded values
                for key, value in config_data.items():
                    if hasattr(default_config, key):
                        setattr(default_config, key, value)
                        
            except Exception as e:
                logger.warning(f"Error loading config: {e}. Using defaults.")
        
        return default_config
    
    def _initialize_system(self):
        """Initialize all system components"""
        try:
            # Core database components
            self.database_manager = DatabaseManager(
                database_path=self.config.database_path,
                config_file=str(self.config_file)
            )
            
            # Initialize threat database
            self.threat_database = ThreatDatabase(self.config.database_path)
            
            # Initialize quarantine manager
            quarantine_config = QuarantineConfig(
                quarantine_directory=self.config.quarantine_directory
            )
            self.quarantine_manager = QuarantineManager(
                self.threat_database, quarantine_config
            )
            
            # Initialize threat intelligence integrator
            self.threat_intel = ThreatIntelIntegrator(
                self.threat_database, 
                self.config.threat_intel_file
            )
            
            # Initialize backup manager
            backup_config = BackupConfig(
                backup_directory=self.config.backup_directory,
                auto_cleanup=True
            )
            self.backup_manager = BackupManager(
                self.config.database_path, backup_config
            )
            
            # Initialize performance optimizer
            self.performance_optimizer = DatabasePerformanceOptimizer(
                self.config.database_path,
                str(self.config_file)
            )
            
            # Initialize threat analyzer
            self.threat_analyzer = ThreatAnalyzer(
                self.threat_database,
                self.quarantine_manager,
                self.threat_intel
            )
            
            # Initialize enhanced signature manager
            self.signature_manager = EnhancedSignatureManager(
                self.database_manager,
                str(self.config_file)
            )
            
            # System status tracking
            self.system_status = SystemStatus()
            self._update_system_status()
            
            logger.info("All system components initialized successfully")
            
        except Exception as e:
            logger.error(f"Error initializing system components: {e}")
            raise
    
    def _start_background_services(self):
        """Start background maintenance and monitoring services"""
        try:
            if self.config.enable_auto_backup:
                self._schedule_backups()
            
            if self.config.enable_auto_maintenance:
                self._schedule_maintenance()
            
            if self.config.enable_threat_intel_updates:
                self._schedule_threat_intel_updates()
            
            if self.config.enable_signature_lifecycle:
                self._schedule_signature_lifecycle_management()
            
            if self.config.performance_monitoring:
                self._start_performance_monitoring()
            
            logger.info("Background services started")
            
        except Exception as e:
            logger.error(f"Error starting background services: {e}")
    
    def _schedule_backups(self):
        """Schedule automatic backups"""
        def daily_backup():
            try:
                success, message, backup_info = self.backup_manager.create_full_backup(
                    "Scheduled daily backup"
                )
                if success:
                    logger.info(f"Daily backup completed: {backup_info.backup_id}")
                else:
                    logger.error(f"Daily backup failed: {message}")
            except Exception as e:
                logger.error(f"Error in daily backup: {e}")
        
        # Schedule daily backup at 2 AM
        schedule.every().day.at("02:00").do(daily_backup)
        
        # Start scheduler in background thread
        def run_scheduler():
            while True:
                schedule.run_pending()
                time.sleep(60)  # Check every minute
        
        scheduler_thread = threading.Thread(target=run_scheduler, daemon=True)
        scheduler_thread.start()
        
        logger.info("Backup scheduling started")
    
    def _schedule_maintenance(self):
        """Schedule database maintenance"""
        def run_maintenance():
            try:
                success, message = self.performance_optimizer.optimize_database()
                if success:
                    logger.info(f"Database maintenance completed: {message}")
                else:
                    logger.error(f"Database maintenance failed: {message}")
            except Exception as e:
                logger.error(f"Error in database maintenance: {e}")
        
        # Schedule maintenance every 6 hours
        schedule.every(6).hours.do(run_maintenance)
        
        # Start scheduler in background thread
        def run_maintenance_scheduler():
            while True:
                schedule.run_pending()
                time.sleep(60)
        
        maintenance_thread = threading.Thread(target=run_maintenance_scheduler, daemon=True)
        maintenance_thread.start()
        
        logger.info("Maintenance scheduling started")
    
    def _schedule_threat_intel_updates(self):
        """Schedule threat intelligence updates"""
        def update_threat_intel():
            try:
                results = self.threat_intel.update_all_sources()
                for source_name, (success, count, message) in results.items():
                    if success:
                        logger.info(f"Threat intel update - {source_name}: {count} items imported")
                    else:
                        logger.warning(f"Threat intel update failed - {source_name}: {message}")
            except Exception as e:
                logger.error(f"Error updating threat intelligence: {e}")
        
        # Schedule threat intel updates every hour
        schedule.every().hour.do(update_threat_intel)
        
        # Start scheduler
        def run_intel_scheduler():
            while True:
                schedule.run_pending()
                time.sleep(60)
        
        intel_thread = threading.Thread(target=run_intel_scheduler, daemon=True)
        intel_thread.start()
        
        logger.info("Threat intelligence scheduling started")
    
    def _schedule_signature_lifecycle_management(self):
        """Schedule signature lifecycle management"""
        def manage_signature_lifecycle():
            try:
                results = self.signature_manager.manage_signature_lifecycle()
                logger.info(f"Signature lifecycle management completed: {results}")
            except Exception as e:
                logger.error(f"Error in signature lifecycle management: {e}")
        
        # Schedule lifecycle management daily
        schedule.every().day.at("03:00").do(manage_signature_lifecycle)
        
        # Start scheduler
        def run_lifecycle_scheduler():
            while True:
                schedule.run_pending()
                time.sleep(60)
        
        lifecycle_thread = threading.Thread(target=run_lifecycle_scheduler, daemon=True)
        lifecycle_thread.start()
        
        logger.info("Signature lifecycle scheduling started")
    
    def _start_performance_monitoring(self):
        """Start performance monitoring"""
        def monitor_performance():
            try:
                self._update_system_status()
                metrics = self.database_manager.get_database_metrics()
                
                # Check for performance issues
                if metrics.avg_query_time > 1.0:
                    self.system_status.active_issues.append(
                        f"High average query time: {metrics.avg_query_time:.2f}s"
                    )
                
                if metrics.database_size_mb > 1000:  # 1GB
                    self.system_status.active_issues.append(
                        f"Large database size: {metrics.database_size_mb:.1f}MB"
                    )
                
                # Calculate performance score
                self._calculate_performance_score(metrics)
                
            except Exception as e:
                logger.error(f"Error in performance monitoring: {e}")
        
        # Start monitoring
        def run_monitoring():
            while True:
                monitor_performance()
                time.sleep(self.config.health_check_interval)
        
        monitor_thread = threading.Thread(target=run_monitoring, daemon=True)
        monitor_thread.start()
        
        logger.info("Performance monitoring started")
    
    def _update_system_status(self):
        """Update system status information"""
        try:
            self.system_status.uptime_seconds = time.time() - self._start_time
            
            # Get database statistics
            stats = self.threat_database.get_statistics()
            self.system_status.total_signatures = stats.get('total_signatures', 0)
            
            # Get quarantine statistics
            quarantine_stats = self.quarantine_manager.get_quarantine_statistics()
            self.system_status.quarantined_files = quarantine_stats.get('total_quarantined', 0)
            
            # Get database size
            db_path = Path(self.config.database_path)
            if db_path.exists():
                self.system_status.database_size_mb = db_path.stat().st_size / (1024 * 1024)
            
            # Update status
            if self.system_status.active_issues:
                self.system_status.status = "warning" if len(self.system_status.active_issues) < 3 else "error"
            else:
                self.system_status.status = "healthy"
                
        except Exception as e:
            logger.error(f"Error updating system status: {e}")
            self.system_status.status = "error"
    
    def _calculate_performance_score(self, metrics):
        """Calculate overall performance score"""
        try:
            score = 100.0
            
            # Deduct for slow queries
            if metrics.avg_query_time > 0.1:
                score -= 10
            if metrics.avg_query_time > 0.5:
                score -= 20
            
            # Deduct for high database size
            if metrics.database_size_mb > 500:
                score -= 10
            if metrics.database_size_mb > 1000:
                score -= 20
            
            # Deduct for high query count
            if metrics.total_queries > 10000:
                score -= 5
            
            self.system_status.performance_score = max(0, score)
            
        except Exception as e:
            logger.error(f"Error calculating performance score: {e}")
            self.system_status.performance_score = 0
    
    # Public API Methods
    
    def get_system_status(self) -> SystemStatus:
        """Get comprehensive system status"""
        self._update_system_status()
        return self.system_status
    
    def get_comprehensive_statistics(self) -> Dict[str, Any]:
        """Get comprehensive system statistics"""
        try:
            with self._lock:
                stats = {
                    "system_status": asdict(self.get_system_status()),
                    "database_statistics": self.threat_database.get_statistics(),
                    "quarantine_statistics": self.quarantine_manager.get_quarantine_statistics(),
                    "performance_metrics": asdict(self.database_manager.get_database_metrics()),
                    "backup_status": {
                        "total_backups": len(self.backup_manager.list_backups()),
                        "latest_backup": self.backup_manager.list_backups()[0] if self.backup_manager.list_backups() else None
                    },
                    "threat_intel_status": self.threat_intel.get_source_status(),
                    "signature_taxonomy": self.signature_manager.get_signature_taxonomy_report()
                }
                
                return stats
                
        except Exception as e:
            logger.error(f"Error getting comprehensive statistics: {e}")
            return {"error": str(e)}
    
    def run_full_system_maintenance(self) -> Dict[str, Any]:
        """Run complete system maintenance"""
        results = {
            "start_time": datetime.datetime.now().isoformat(),
            "operations": [],
            "success": True,
            "errors": []
        }
        
        try:
            with self._lock:
                # 1. Database optimization
                success, message = self.performance_optimizer.optimize_database()
                results["operations"].append({
                    "operation": "database_optimization",
                    "success": success,
                    "message": message
                })
                if not success:
                    results["success"] = False
                    results["errors"].append(f"Database optimization failed: {message}")
                
                # 2. Backup creation
                success, message, backup_info = self.backup_manager.create_full_backup(
                    "Full system maintenance backup"
                )
                results["operations"].append({
                    "operation": "backup_creation",
                    "success": success,
                    "message": message,
                    "backup_info": asdict(backup_info) if backup_info else None
                })
                if not success:
                    results["success"] = False
                    results["errors"].append(f"Backup creation failed: {message}")
                
                # 3. Threat intelligence updates
                intel_results = self.threat_intel.update_all_sources()
                results["operations"].append({
                    "operation": "threat_intel_update",
                    "success": True,
                    "details": {k: {"success": v[0], "count": v[1], "message": v[2]} 
                              for k, v in intel_results.items()}
                })
                
                # 4. Signature lifecycle management
                lifecycle_results = self.signature_manager.manage_signature_lifecycle()
                results["operations"].append({
                    "operation": "signature_lifecycle",
                    "success": True,
                    "details": lifecycle_results
                })
                
                # 5. Quarantine cleanup
                deleted_count, cleanup_message = self.quarantine_manager.cleanup_expired_files()
                results["operations"].append({
                    "operation": "quarantine_cleanup",
                    "success": True,
                    "deleted_count": deleted_count,
                    "message": cleanup_message
                })
                
                # 6. Generate system report
                report = self.generate_system_report("maintenance")
                results["operations"].append({
                    "operation": "system_report",
                    "success": True,
                    "report_path": report
                })
                
                results["end_time"] = datetime.datetime.now().isoformat()
                results["total_duration"] = (
                    datetime.datetime.fromisoformat(results["end_time"]) - 
                    datetime.datetime.fromisoformat(results["start_time"])
                ).total_seconds()
                
                logger.info(f"Full system maintenance completed in {results['total_duration']:.1f}s")
                return results
                
        except Exception as e:
            error_msg = f"Error during full system maintenance: {e}"
            logger.error(error_msg)
            results["success"] = False
            results["errors"].append(error_msg)
            return results
    
    def generate_system_report(self, report_type: str = "summary") -> str:
        """Generate comprehensive system report"""
        try:
            timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
            report_filename = f"system_report_{report_type}_{timestamp}.json"
            report_path = Path("reports") / report_filename
            report_path.parent.mkdir(exist_ok=True)
            
            # Generate comprehensive report
            report_data = self.threat_analyzer.generate_comprehensive_report(
                report_type=report_type,
                days=30
            )
            
            # Add system-specific information
            report_data["system_information"] = {
                "system_status": asdict(self.get_system_status()),
                "comprehensive_stats": self.get_comprehensive_statistics(),
                "maintenance_schedule": {
                    "auto_backup_enabled": self.config.enable_auto_backup,
                    "auto_maintenance_enabled": self.config.enable_auto_maintenance,
                    "threat_intel_updates_enabled": self.config.enable_threat_intel_updates,
                    "signature_lifecycle_enabled": self.config.enable_signature_lifecycle
                },
                "configuration": asdict(self.config)
            }
            
            # Add recommendations based on research
            research_recommendations = [
                "Implement layered security: combine signature-based and heuristic detection methods",
                "Regular threat intelligence integration to maintain detection accuracy",
                "Monitor false positive rates and adjust detection thresholds accordingly",
                "Use YARA rules for advanced threat hunting and family classification",
                "Implement behavioral analysis for detecting unknown and fileless threats",
                "Regularly update and test signature rules with CI/CD processes",
                "Monitor system performance impact and optimize database settings",
                "Maintain comprehensive backup and recovery procedures"
            ]
            
            report_data["research_based_recommendations"] = research_recommendations
            
            # Export report
            success = self.threat_analyzer.export_report(
                report_data, str(report_path), "json"
            )
            
            if success:
                logger.info(f"System report generated: {report_path}")
                return str(report_path)
            else:
                logger.error("Failed to export system report")
                return ""
                
        except Exception as e:
            logger.error(f"Error generating system report: {e}")
            return ""
    
    def create_research_based_signatures(self) -> Dict[str, Any]:
        """Create signatures based on research taxonomy"""
        try:
            results = self.signature_manager.generate_research_based_signatures()
            
            successful = sum(1 for success, _, _ in results if success)
            failed = len(results) - successful
            
            response = {
                "total_generated": len(results),
                "successful": successful,
                "failed": failed,
                "details": [
                    {"success": success, "signature_id": sig_id, "message": message}
                    for success, sig_id, message in results
                ]
            }
            
            logger.info(f"Research-based signature generation: {successful} successful, {failed} failed")
            return response
            
        except Exception as e:
            logger.error(f"Error creating research-based signatures: {e}")
            return {"error": str(e)}
    
    def search_threats(self, search_criteria: Dict[str, Any]) -> List[Dict[str, Any]]:
        """Advanced threat search functionality"""
        try:
            return self.database_manager.search_signatures_advanced(search_criteria)
        except Exception as e:
            logger.error(f"Error searching threats: {e}")
            return []
    
    def quarantine_file_advanced(self, file_path: str, threat_analysis: Dict[str, Any]) -> Dict[str, Any]:
        """Advanced file quarantine with threat analysis integration"""
        try:
            # Extract threat information
            threat_name = threat_analysis.get("threat_name", "Unknown")
            threat_level = threat_analysis.get("threat_level", "medium")
            signature_id = threat_analysis.get("signature_id")
            
            # Quarantine file
            success, message, quarantine_id = self.quarantine_manager.quarantine_file(
                file_path=file_path,
                threat_name=threat_name,
                threat_level=threat_level,
                signature_id=signature_id,
                reason=threat_analysis.get("reason", "Threat detected"),
                metadata=threat_analysis
            )
            
            return {
                "success": success,
                "message": message,
                "quarantine_id": quarantine_id,
                "threat_analysis": threat_analysis
            }
            
        except Exception as e:
            logger.error(f"Error in advanced quarantine: {e}")
            return {"success": False, "error": str(e)}
    
    def export_threat_intelligence(self, format_type: str = "json") -> str:
        """Export threat intelligence for external sharing"""
        try:
            return self.threat_database.export_threat_intelligence(format_type)
        except Exception as e:
            logger.error(f"Error exporting threat intelligence: {e}")
            return f"Export failed: {e}"
    
    def perform_integrity_check(self) -> Dict[str, Any]:
        """Perform system integrity check"""
        try:
            integrity_results = {
                "timestamp": datetime.datetime.now().isoformat(),
                "checks": [],
                "overall_status": "pass"
            }
            
            # Check database integrity
            try:
                with self.threat_database._get_connection() as conn:
                    cursor = conn.cursor()
                    cursor.execute("PRAGMA integrity_check")
                    result = cursor.fetchone()
                    
                    integrity_results["checks"].append({
                        "check": "database_integrity",
                        "status": "pass" if result[0] == "ok" else "fail",
                        "details": result[0]
                    })
                    
            except Exception as e:
                integrity_results["checks"].append({
                    "check": "database_integrity",
                    "status": "error",
                    "details": str(e)
                })
                integrity_results["overall_status"] = "warning"
            
            # Check file integrity
            try:
                db_path = Path(self.config.database_path)
                if db_path.exists():
                    import hashlib
                    with open(db_path, 'rb') as f:
                        file_hash = hashlib.sha256(f.read()).hexdigest()
                    
                    integrity_results["checks"].append({
                        "check": "file_integrity",
                        "status": "pass",
                        "database_hash": file_hash
                    })
                else:
                    integrity_results["checks"].append({
                        "check": "file_integrity",
                        "status": "warning",
                        "details": "Database file not found"
                    })
                    
            except Exception as e:
                integrity_results["checks"].append({
                    "check": "file_integrity",
                    "status": "error",
                    "details": str(e)
                })
                integrity_results["overall_status"] = "warning"
            
            # Check configuration integrity
            try:
                config_path = Path(self.config_file)
                if config_path.exists():
                    integrity_results["checks"].append({
                        "check": "configuration_integrity",
                        "status": "pass",
                        "config_file": str(config_path)
                    })
                else:
                    integrity_results["checks"].append({
                        "check": "configuration_integrity",
                        "status": "warning",
                        "details": "Configuration file not found"
                    })
                    
            except Exception as e:
                integrity_results["checks"].append({
                    "check": "configuration_integrity",
                    "status": "error",
                    "details": str(e)
                })
            
            return integrity_results
            
        except Exception as e:
            logger.error(f"Error performing integrity check: {e}")
            return {
                "timestamp": datetime.datetime.now().isoformat(),
                "overall_status": "error",
                "error": str(e)
            }
    
    def shutdown(self):
        """Gracefully shutdown the system"""
        try:
            logger.info("Shutting down Threat Database System...")
            
            # Stop background services (they're daemon threads, so they'll stop automatically)
            
            # Close database manager
            if hasattr(self, 'database_manager'):
                self.database_manager.close()
            
            # Final system status update
            self.system_status.status = "shutdown"
            self.system_status.uptime_seconds = time.time() - self._start_time
            
            logger.info("Threat Database System shutdown completed")
            
        except Exception as e:
            logger.error(f"Error during system shutdown: {e}")

def main():
    """Main function to test the complete system"""
    # Initialize the system
    system = ThreatDatabaseSystem()
    
    try:
        # Get system status
        status = system.get_system_status()
        print(f"System Status: {status.status}")
        print(f"Database Size: {status.database_size_mb:.1f}MB")
        print(f"Total Signatures: {status.total_signatures}")
        print(f"Quarantined Files: {status.quarantined_files}")
        
        # Get comprehensive statistics
        stats = system.get_comprehensive_statistics()
        print(f"Total Backups: {stats['backup_status']['total_backups']}")
        print(f"Threat Intel Sources: {len(stats['threat_intel_status'])}")
        
        # Generate research-based signatures
        sig_results = system.create_research_based_signatures()
        print(f"Generated {sig_results['successful']} research-based signatures")
        
        # Run full maintenance
        maintenance_results = system.run_full_system_maintenance()
        print(f"Maintenance operations: {len(maintenance_results['operations'])}")
        
        # Generate system report
        report_path = system.generate_system_report("comprehensive")
        print(f"System report generated: {report_path}")
        
        # Perform integrity check
        integrity = system.perform_integrity_check()
        print(f"Integrity check: {integrity['overall_status']}")
        
    except KeyboardInterrupt:
        print("Shutting down system...")
    except Exception as e:
        print(f"Error: {e}")
    finally:
        system.shutdown()

if __name__ == "__main__":
    main()
