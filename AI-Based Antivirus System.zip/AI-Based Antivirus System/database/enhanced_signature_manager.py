#!/usr/bin/env python3
"""
Enhanced Signature Management System
Based on signature/heuristic research from docs/signature_heuristic.md
Implements layered detection: signature-based, heuristic, behavioral, and AI/ML approaches
"""

import json
import hashlib
import datetime
import logging
import re
from typing import Dict, List, Optional, Any, Tuple
from dataclasses import dataclass, asdict
from enum import Enum
from pathlib import Path
import threading
import uuid
import yaml

from threat_database import ThreatDatabase, ThreatSignature, SignatureType, ThreatLevel
from database_manager import DatabaseManager

logger = logging.getLogger(__name__)

class DetectionMethod(Enum):
    """Detection methods based on research taxonomy"""
    HASH_SIGNATURE = "hash_signature"
    PATTERN_MATCHING = "pattern_matching"
    YARA_RULES = "yara_rules"
    STATIC_HEURISTICS = "static_heuristics"
    DYNAMIC_HEURISTICS = "dynamic_heuristics"
    BEHAVIORAL_ANALYSIS = "behavioral_analysis"
    AI_ML_CLASSIFICATION = "ai_ml_classification"
    SANDBOX_ANALYSIS = "sandbox_analysis"

class SignatureStatus(Enum):
    """Signature lifecycle status"""
    DRAFT = "draft"
    TESTING = "testing"
    ACTIVE = "active"
    DEPRECATED = "deprecated"
    DISABLED = "disabled"
    FALSE_POSITIVE = "false_positive"

class MalwareCategory(Enum):
    """Malware categories based on threat intelligence"""
    TROJAN = "trojan"
    RANSOMWARE = "ransomware"
    BACKDOOR = "backdoor"
    WORM = "worm"
    VIRUS = "virus"
    SPYWARE = "spyware"
    ADWARE = "adware"
    ROOTKIT = "rootkit"
    BOTNET = "botnet"
    APT = "apt"
    FAMLESS = "fileless"
    PUA = "pua"  # Potentially Unwanted Application
    UNKNOWN = "unknown"

@dataclass
class SignatureMetrics:
    """Signature performance metrics"""
    signature_id: int
    detection_count: int = 0
    false_positive_count: int = 0
    last_detection: Optional[str] = None
    detection_rate: float = 0.0
    false_positive_rate: float = 0.0
    effectiveness_score: float = 0.0
    time_to_detection: float = 0.0
    performance_impact: float = 0.0

@dataclass
class HeuristicRule:
    """Heuristic rule for static/dynamic analysis"""
    id: Optional[int] = None
    name: str = ""
    analysis_type: str = ""  # static, dynamic
    condition_type: str = ""  # file_entropy, import_analysis, etc.
    threshold_value: float = 0.0
    weight: float = 1.0
    description: str = ""
    metadata: Optional[str] = None
    active: bool = True
    created_date: Optional[str] = None

@dataclass
class BehavioralPattern:
    """Behavioral pattern for IOA detection"""
    id: Optional[int] = None
    pattern_name: str = ""
    event_sequence: str = ""  # JSON array of events
    description: str = ""
    severity_score: float = 1.0
    time_window: int = 300  # seconds
    malware_category: str = "unknown"
    ioa_type: str = "process_behavior"
    confidence_threshold: float = 0.7
    active: bool = True

class EnhancedSignatureManager:
    """
    Enhanced signature management system implementing research-based detection methods
    """
    
    def __init__(self, database_manager: DatabaseManager, config_file: str = "threat_database.yaml"):
        self.db_manager = database_manager
        self.config_file = Path(config_file)
        self.config = self._load_configuration()
        self._lock = threading.RLock()
        
        # Initialize signature taxonomy
        self.signature_taxonomy = self._initialize_signature_taxonomy()
        
        # Initialize heuristic rules
        self.heuristic_rules = self._initialize_heuristic_rules()
        
        # Initialize behavioral patterns
        self.behavioral_patterns = self._initialize_behavioral_patterns()
        
        logger.info("Enhanced signature manager initialized")
    
    def _load_configuration(self) -> Dict[str, Any]:
        """Load signature management configuration"""
        default_config = {
            "signature_management": {
                "auto_lifecycle_management": True,
                "false_positive_threshold": 0.1,
                "effectiveness_threshold": 0.3,
                "max_signature_age_days": 365,
                "retention_period_days": 90
            },
            "heuristic_settings": {
                "file_entropy_threshold": 7.5,
                "suspicious_import_threshold": 3,
                "packer_indicators": ["UPX", "ASPack", "PECompact", "Themida"],
                "suspicious_strings": ["CreateRemoteThread", "WriteProcessMemory", "VirtualAlloc"]
            },
            "behavioral_settings": {
                "process_injection_indicators": [
                    "CreateRemoteThread", "SetWindowsHookEx", "QueueUserAPC"
                ],
                "file_encryption_patterns": [
                    "multiple_file_writes", "volume_shadow_delete", "file_rename"
                ],
                "network_exfiltration_indicators": [
                    "large_upload", "unusual_port", "encrypted_channel"
                ]
            },
            "ai_ml_settings": {
                "model_path": "./models/",
                "confidence_threshold": 0.7,
                "retrain_frequency_days": 30,
                "feature_extraction": ["pe_headers", "imports", "strings", "entropy"]
            }
        }
        
        if self.config_file.exists():
            try:
                with open(self.config_file, 'r') as f:
                    loaded_config = yaml.safe_load(f) or {}
                    # Merge with defaults
                    for section, values in loaded_config.items():
                        if section in default_config:
                            default_config[section].update(values)
                        else:
                            default_config[section] = values
            except Exception as e:
                logger.warning(f"Error loading config: {e}. Using defaults.")
        
        return default_config
    
    def _initialize_signature_taxonomy(self) -> Dict[str, Dict[str, Any]]:
        """Initialize signature taxonomy based on research"""
        return {
            "hash_signature": {
                "description": "Hash-based signatures for exact file matching",
                "use_cases": ["IOC sharing", "threat hunting", "regression checks"],
                "advantages": ["Very fast exact matching", "Ideal for known malware"],
                "limitations": ["No coverage for unknowns", "Fragile against modifications"],
                "maintenance": "Automatic hash list updates from threat intelligence",
                "false_positive_risk": "Very low"
            },
            "pattern_matching": {
                "description": "String/byte pattern matching for malware families",
                "use_cases": ["Family classification", "Rapid response signatures", "Legacy AV rules"],
                "advantages": ["Fine-grained matching", "Adaptable rules"],
                "limitations": ["Fragile against obfuscation", "Requires maintenance"],
                "maintenance": "Regular rule updates and testing",
                "false_positive_risk": "Medium"
            },
            "yara_rules": {
                "description": "YARA rules with logical conditions",
                "use_cases": ["Threat hunting", "Research classification", "Detection engineering"],
                "advantages": ["Human-readable", "Logical expressions", "Extensible"],
                "limitations": ["Matching can be evaded by packing", "Rule quality matters"],
                "maintenance": "CI/testing with YARA-CI, versioned rule sets",
                "false_positive_risk": "Low to medium"
            },
            "static_heuristics": {
                "description": "Static code analysis without execution",
                "use_cases": ["Pre-execution filtering", "Triage of unknown files"],
                "advantages": ["Detects unknown/modified malware", "Scalable"],
                "limitations": ["Potential false positives", "Packing/obfuscation evasion"],
                "maintenance": "Heuristic database updates, threshold tuning",
                "false_positive_risk": "Medium to high"
            },
            "dynamic_heuristics": {
                "description": "Dynamic analysis in controlled environment",
                "use_cases": ["In-depth analysis", "Enrichment for response"],
                "advantages": ["True behavior visibility", "Strong for zero-day attacks"],
                "limitations": ["Evasion via VM detection", "Higher resource cost"],
                "maintenance": "Sandbox environment updates, evasion counter-measures",
                "false_positive_risk": "Low"
            },
            "behavioral_analysis": {
                "description": "Runtime event correlation for IOA detection",
                "use_cases": ["Real-time detection", "EDR/XDR analytics"],
                "advantages": ["Detects malicious intent", "Signature-less prevention"],
                "limitations": ["Requires tuning", "False positives if baselines noisy"],
                "maintenance": "IOA pattern updates, baseline learning",
                "false_positive_risk": "Medium"
            },
            "ai_ml_classification": {
                "description": "Machine learning models for threat classification",
                "use_cases": ["Priority scoring", "IOA correlation", "Automated response"],
                "advantages": ["Scales to large data", "Continuous learning"],
                "limitations": ["Model drift", "Adversarial evasion", "Explainability"],
                "maintenance": "Model retraining, feature engineering, drift monitoring",
                "false_positive_risk": "Variable"
            }
        }
    
    def _initialize_heuristic_rules(self) -> List[HeuristicRule]:
        """Initialize heuristic rules for static/dynamic analysis"""
        return [
            HeuristicRule(
                name="High File Entropy",
                analysis_type="static",
                condition_type="file_entropy",
                threshold_value=self.config.get("heuristic_settings", {}).get("file_entropy_threshold", 7.5),
                weight=0.8,
                description="Files with high entropy may be packed or encrypted"
            ),
            HeuristicRule(
                name="Suspicious PE Imports",
                analysis_type="static",
                condition_type="suspicious_imports",
                threshold_value=3.0,
                weight=0.7,
                description="PE files importing suspicious API functions"
            ),
            HeuristicRule(
                name="Packaged Executable",
                analysis_type="static",
                condition_type="packer_indicators",
                threshold_value=1.0,
                weight=0.6,
                description="Executable appears to be packed or obfuscated"
            ),
            HeuristicRule(
                name="Network Connection Pattern",
                analysis_type="dynamic",
                condition_type="network_behavior",
                threshold_value=1.0,
                weight=0.9,
                description="Unusual network connection patterns detected"
            ),
            HeuristicRule(
                name="File System Modifications",
                analysis_type="dynamic",
                condition_type="filesystem_changes",
                threshold_value=5.0,
                weight=0.8,
                description="Suspicious file system modification patterns"
            )
        ]
    
    def _initialize_behavioral_patterns(self) -> List[BehavioralPattern]:
        """Initialize behavioral patterns for IOA detection"""
        return [
            BehavioralPattern(
                pattern_name="Process Injection",
                event_sequence=json.dumps([
                    "process_spawn", "memory_allocate", "remote_thread_create"
                ]),
                description="Process injection technique detection",
                severity_score=0.8,
                time_window=60,
                malware_category="backdoor",
                ioa_type="process_behavior"
            ),
            BehavioralPattern(
                pattern_name="Ransomware Encryption",
                event_sequence=json.dumps([
                    "file_enumeration", "large_file_writes", "file_rename_with_extension"
                ]),
                description="Ransomware encryption behavior",
                severity_score=0.9,
                time_window=300,
                malware_category="ransomware",
                ioa_type="file_behavior"
            ),
            BehavioralPattern(
                pattern_name="Credential Dumping",
                event_sequence=json.dumps([
                    "process_access", "registry_query", "memory_read"
                ]),
                description="Credential dumping behavior",
                severity_score=0.8,
                time_window=120,
                malware_category="trojan",
                ioa_type="system_behavior"
            ),
            BehavioralPattern(
                pattern_name="Lateral Movement",
                event_sequence=json.dumps([
                    "network_scan", "remote_execution", "service_creation"
                ]),
                description="Lateral movement in network",
                severity_score=0.9,
                time_window=600,
                malware_category="apt",
                ioa_type="network_behavior"
            )
        ]
    
    def create_signature_from_research(self, name: str, detection_method: DetectionMethod,
                                     content: str, threat_name: str,
                                     metadata: Dict[str, Any] = None) -> Tuple[bool, int, str]:
        """
        Create a signature based on research taxonomy
        
        Args:
            name: Signature name
            detection_method: Detection method from research taxonomy
            content: Signature content (hash, pattern, YARA rule, etc.)
            threat_name: Name of the threat
            metadata: Additional metadata
            
        Returns:
            Tuple of (success, signature_id, message)
        """
        try:
            with self._lock:
                # Map detection method to signature type
                sig_type = self._map_detection_method_to_signature_type(detection_method)
                
                # Get taxonomy information
                taxonomy_info = self.signature_taxonomy.get(detection_method.value, {})
                
                # Create signature with enhanced metadata
                enhanced_metadata = {
                    "detection_method": detection_method.value,
                    "taxonomy_info": taxonomy_info,
                    "research_based": True,
                    "classification": "signature_based" if sig_type in [
                        SignatureType.HASH_SHA256.value, SignatureType.PATTERN_BYTES.value, 
                        SignatureType.YARA_RULE.value
                    ] else "heuristic_based",
                    "created_from": "research_taxonomy",
                    "maintenance_strategy": taxonomy_info.get("maintenance", "Manual"),
                    "false_positive_risk": taxonomy_info.get("false_positive_risk", "Medium")
                }
                
                if metadata:
                    enhanced_metadata.update(metadata)
                
                # Determine threat level based on detection method and metadata
                threat_level = self._determine_threat_level(detection_method, enhanced_metadata)
                
                # Create signature
                signature = ThreatSignature(
                    name=name,
                    type=sig_type,
                    content=content,
                    description=f"Research-based {detection_method.value} signature for {threat_name}",
                    threat_level=threat_level,
                    source="research_taxonomy",
                    confidence_score=0.8,  # Default based on research
                    false_positive_rate=self._estimate_false_positive_rate(detection_method, taxonomy_info),
                    metadata=json.dumps(enhanced_metadata),
                    usage_count=0
                )
                
                # Validate signature
                if not self.db_manager.validate_signature(signature):
                    return False, 0, "Signature validation failed"
                
                # Create signature
                success, sig_id, message = self.db_manager.create_threat_signature(
                    signature, validate_content=True
                )
                
                if success:
                    # If it's a heuristic or behavioral rule, store additional information
                    if detection_method in [DetectionMethod.STATIC_HEURISTICS, DetectionMethod.DYNAMIC_HEURISTICS]:
                        self._store_heuristic_rule(sig_id, detection_method, content)
                    elif detection_method == DetectionMethod.BEHAVIORAL_ANALYSIS:
                        self._store_behavioral_pattern(sig_id, content)
                    
                    logger.info(f"Created research-based signature: {name} (ID: {sig_id})")
                
                return success, sig_id, message
                
        except Exception as e:
            logger.error(f"Error creating research-based signature: {e}")
            return False, 0, f"Error: {str(e)}"
    
    def _map_detection_method_to_signature_type(self, detection_method: DetectionMethod) -> str:
        """Map detection method to signature type"""
        mapping = {
            DetectionMethod.HASH_SIGNATURE: SignatureType.HASH_SHA256.value,
            DetectionMethod.PATTERN_MATCHING: SignatureType.PATTERN_BYTES.value,
            DetectionMethod.YARA_RULES: SignatureType.YARA_RULE.value,
            DetectionMethod.STATIC_HEURISTICS: SignatureType.STATIC_HEURISTIC.value,
            DetectionMethod.DYNAMIC_HEURISTICS: SignatureType.STATIC_HEURISTIC.value,
            DetectionMethod.BEHAVIORAL_ANALYSIS: SignatureType.BEHAVIORAL_IOA.value,
            DetectionMethod.AI_ML_CLASSIFICATION: SignatureType.PATTERN_BYTES.value,
            DetectionMethod.SANDBOX_ANALYSIS: SignatureType.STATIC_HEURISTIC.value
        }
        return mapping.get(detection_method, SignatureType.HASH_SHA256.value)
    
    def _determine_threat_level(self, detection_method: DetectionMethod, 
                              metadata: Dict[str, Any]) -> str:
        """Determine threat level based on detection method and metadata"""
        # Base threat levels by detection method
        base_levels = {
            DetectionMethod.HASH_SIGNATURE: "high",  # Known threats
            DetectionMethod.PATTERN_MATCHING: "medium",  # Family characteristics
            DetectionMethod.YARA_RULES: "medium",  # Pattern-based
            DetectionMethod.STATIC_HEURISTICS: "medium",  # Suspicious but not confirmed
            DetectionMethod.DYNAMIC_HEURISTICS: "high",  # Observed behavior
            DetectionMethod.BEHAVIORAL_ANALYSIS: "high",  # Confirmed malicious intent
            DetectionMethod.AI_ML_CLASSIFICATION: "medium",  # Model prediction
            DetectionMethod.SANDBOX_ANALYSIS: "high"  # Full analysis
        }
        
        base_level = base_levels.get(detection_method, "medium")
        
        # Adjust based on metadata
        severity_indicators = metadata.get("severity_indicators", [])
        if "critical" in severity_indicators:
            return "critical"
        elif "high" in severity_indicators and base_level in ["medium", "low"]:
            return "high"
        
        return base_level
    
    def _estimate_false_positive_rate(self, detection_method: DetectionMethod,
                                    taxonomy_info: Dict[str, Any]) -> float:
        """Estimate false positive rate based on detection method"""
        fp_risk = taxonomy_info.get("false_positive_risk", "Medium")
        
        risk_mapping = {
            "Very low": 0.01,
            "Low": 0.05,
            "Low to medium": 0.08,
            "Medium": 0.10,
            "Medium to high": 0.15,
            "High": 0.20,
            "Variable": 0.10  # Default for AI/ML
        }
        
        return risk_mapping.get(fp_risk, 0.10)
    
    def _store_heuristic_rule(self, signature_id: int, detection_method: DetectionMethod, content: str):
        """Store heuristic rule for static/dynamic analysis"""
        try:
            # Find matching heuristic rule template
            analysis_type = "static" if detection_method == DetectionMethod.STATIC_HEURISTICS else "dynamic"
            
            # For now, create a basic heuristic rule
            # In a full implementation, you would parse the content to extract conditions
            with self.db_manager._get_connection() as conn:
                cursor = conn.cursor()
                
                cursor.execute('''
                    INSERT INTO heuristic_rules 
                    (signature_id, rule_name, analysis_type, condition_type, description, active)
                    VALUES (?, ?, ?, ?, ?, ?)
                ''', (
                    signature_id,
                    f"Heuristic rule for signature {signature_id}",
                    analysis_type,
                    "custom",
                    f"Auto-generated {analysis_type} heuristic rule",
                    True
                ))
                
                conn.commit()
                
        except Exception as e:
            logger.error(f"Error storing heuristic rule: {e}")
    
    def _store_behavioral_pattern(self, signature_id: int, content: str):
        """Store behavioral pattern for IOA detection"""
        try:
            # For behavioral patterns, store the content as a sequence
            with self.db_manager._get_connection() as conn:
                cursor = conn.cursor()
                
                cursor.execute('''
                    INSERT INTO behavioral_patterns 
                    (signature_id, pattern_name, event_sequence, description, active)
                    VALUES (?, ?, ?, ?, ?)
                ''', (
                    signature_id,
                    f"Behavioral pattern for signature {signature_id}",
                    content,  # This would be a sequence of events
                    "Auto-generated behavioral pattern",
                    True
                ))
                
                conn.commit()
                
        except Exception as e:
            logger.error(f"Error storing behavioral pattern: {e}")
    
    def generate_research_based_signatures(self) -> List[Tuple[bool, int, str]]:
        """
        Generate signatures based on research taxonomy
        
        Returns:
            List of (success, signature_id, message) tuples
        """
        results = []
        
        try:
            # Generate signature-based signatures
            results.extend(self._generate_hash_signatures())
            results.extend(self._generate_pattern_signatures())
            results.extend(self._generate_yara_signatures())
            
            # Generate heuristic signatures
            results.extend(self._generate_heuristic_signatures())
            
            # Generate behavioral signatures
            results.extend(self._generate_behavioral_signatures())
            
            logger.info(f"Generated {len(results)} research-based signatures")
            return results
            
        except Exception as e:
            logger.error(f"Error generating research-based signatures: {e}")
            return []
    
    def _generate_hash_signatures(self) -> List[Tuple[bool, int, str]]:
        """Generate hash-based signatures from IOCs"""
        results = []
        
        # Example IOCs for demonstration
        sample_iocs = [
            {
                "hash": "a665a45920422f9d417e4867efdc4fb8a04a1f3fff1fa07e998e86f7f7a27ae3",
                "name": "Known Trojan Sample",
                "threat_level": "high"
            }
        ]
        
        for ioc in sample_iocs:
            success, sig_id, message = self.create_signature_from_research(
                name=f"Hash IOC: {ioc['name']}",
                detection_method=DetectionMethod.HASH_SIGNATURE,
                content=ioc['hash'],
                threat_name=ioc['name'],
                metadata={"threat_level": ioc['threat_level']}
            )
            results.append((success, sig_id, message))
        
        return results
    
    def _generate_pattern_signatures(self) -> List[Tuple[bool, int, str]]:
        """Generate pattern matching signatures"""
        results = []
        
        # Example patterns based on research
        patterns = [
            {
                "pattern": "CreateRemoteThread",
                "description": "Process injection pattern",
                "threat": "Process Injection Malware"
            },
            {
                "pattern": "VirtualAlloc",
                "description": "Memory allocation pattern",
                "threat": "Memory-based Malware"
            }
        ]
        
        for pattern_data in patterns:
            # Convert pattern to bytes
            pattern_bytes = pattern_data['pattern'].encode('utf-8').hex().upper()
            
            success, sig_id, message = self.create_signature_from_research(
                name=f"Pattern: {pattern_data['description']}",
                detection_method=DetectionMethod.PATTERN_MATCHING,
                content=pattern_bytes,
                threat_name=pattern_data['threat'],
                metadata={"pattern_type": "string"}
            )
            results.append((success, sig_id, message))
        
        return results
    
    def _generate_yara_signatures(self) -> List[Tuple[bool, int, str]]:
        """Generate YARA signatures"""
        results = []
        
        # Example YARA rule based on research
        yara_rule = '''
        rule Suspicious_PowerShell_Execution {
            meta:
                description = "Detects suspicious PowerShell execution patterns"
                author = "threat_research"
                date = "2024-01-01"
            
            strings:
                $ps1 = "powershell.exe" nocase
                $encoded = "EncodedCommand" nocase
                $download = "DownloadString" nocase
            
            condition:
                $ps1 and any of ($encoded, $download)
        }
        '''
        
        success, sig_id, message = self.create_signature_from_research(
            name="Suspicious PowerShell Execution",
            detection_method=DetectionMethod.YARA_RULES,
            content=yara_rule,
            threat_name="PowerShell-based Malware",
            metadata={"yara_version": "4.0", "rule_complexity": "medium"}
        )
        results.append((success, sig_id, message))
        
        return results
    
    def _generate_heuristic_signatures(self) -> List[Tuple[bool, int, str]]:
        """Generate heuristic signatures"""
        results = []
        
        for rule in self.heuristic_rules:
            # Create heuristic content
            heuristic_content = json.dumps({
                "type": rule.analysis_type,
                "condition": rule.condition_type,
                "threshold": rule.threshold_value,
                "weight": rule.weight
            })
            
            success, sig_id, message = self.create_signature_from_research(
                name=f"Heuristic: {rule.name}",
                detection_method=DetectionMethod.STATIC_HEURISTICS,
                content=heuristic_content,
                threat_name=f"heuristic_{rule.condition_type}",
                metadata={
                    "heuristic_type": rule.analysis_type,
                    "condition": rule.condition_type,
                    "weight": rule.weight
                }
            )
            results.append((success, sig_id, message))
        
        return results
    
    def _generate_behavioral_signatures(self) -> List[Tuple[bool, int, str]]:
        """Generate behavioral signatures"""
        results = []
        
        for pattern in self.behavioral_patterns:
            success, sig_id, message = self.create_signature_from_research(
                name=f"Behavioral: {pattern.pattern_name}",
                detection_method=DetectionMethod.BEHAVIORAL_ANALYSIS,
                content=pattern.event_sequence,
                threat_name=f"behavioral_{pattern.ioa_type}",
                metadata={
                    "ioa_type": pattern.ioa_type,
                    "severity_score": pattern.severity_score,
                    "time_window": pattern.time_window,
                    "malware_category": pattern.malware_category
                }
            )
            results.append((success, sig_id, message))
        
        return results
    
    def manage_signature_lifecycle(self) -> Dict[str, Any]:
        """
        Manage signature lifecycle based on research recommendations
        """
        try:
            lifecycle_results = {
                "evaluated": 0,
                "updated": 0,
                "deprecated": 0,
                "false_positives_identified": 0,
                "recommendations": []
            }
            
            # Get all active signatures
            signatures, _ = self.db_manager.read_threat_signatures(
                filters={"active_only": True}
            )
            
            for signature in signatures:
                lifecycle_results["evaluated"] += 1
                
                # Check false positive rate
                if signature.get('false_positive_rate', 0) > 0.1:  # 10% threshold
                    lifecycle_results["false_positives_identified"] += 1
                    
                    # Evaluate if should be deprecated
                    if signature.get('usage_count', 0) < 5:  # Low usage
                        self._deprecate_signature(signature['id'])
                        lifecycle_results["deprecated"] += 1
                
                # Check for outdated signatures
                signature_age = self._calculate_signature_age(signature)
                if signature_age > 365:  # 1 year
                    lifecycle_results["recommendations"].append(
                        f"Signature {signature['name']} is {signature_age} days old - consider review"
                    )
            
            # Add general recommendations based on research
            lifecycle_results["recommendations"].extend([
                "Implement signature lifecycle management for optimal performance",
                "Regularly update threat intelligence feeds to maintain detection accuracy",
                "Monitor false positive rates and adjust detection thresholds",
                "Use layered detection combining signature and heuristic methods"
            ])
            
            logger.info(f"Signature lifecycle management: {lifecycle_results}")
            return lifecycle_results
            
        except Exception as e:
            logger.error(f"Error in signature lifecycle management: {e}")
            return {"error": str(e)}
    
    def _deprecate_signature(self, signature_id: int):
        """Mark signature as deprecated"""
        try:
            success, message = self.db_manager.update_threat_signature(
                signature_id, {"active": False}
            )
            if success:
                logger.info(f"Deprecated signature: {signature_id}")
        except Exception as e:
            logger.error(f"Error deprecating signature {signature_id}: {e}")
    
    def _calculate_signature_age(self, signature: Dict[str, Any]) -> int:
        """Calculate signature age in days"""
        try:
            created_date = signature.get('first_seen')
            if created_date:
                created = datetime.datetime.fromisoformat(created_date.replace('Z', '+00:00'))
                age = (datetime.datetime.now() - created).days
                return age
            return 0
        except:
            return 0
    
    def get_signature_taxonomy_report(self) -> Dict[str, Any]:
        """Generate signature taxonomy report based on research"""
        try:
            # Get signature statistics by type
            stats = self.db_manager.get_signature_statistics()
            
            # Map statistics to taxonomy
            taxonomy_report = {
                "research_taxonomy": self.signature_taxonomy,
                "current_distribution": {},
                "coverage_analysis": {},
                "recommendations": []
            }
            
            # Analyze current distribution
            for sig_type in stats.get('by_type', []):
                detection_method = self._signature_type_to_detection_method(sig_type['type'])
                taxonomy_report["current_distribution"][detection_method.value] = {
                    "count": sig_type['count'],
                    "avg_confidence": sig_type.get('avg_confidence', 0),
                    "avg_false_positive_rate": sig_type.get('avg_fp_rate', 0)
                }
            
            # Generate recommendations
            taxonomy_report["recommendations"] = self._generate_taxonomy_recommendations(
                taxonomy_report["current_distribution"]
            )
            
            return taxonomy_report
            
        except Exception as e:
            logger.error(f"Error generating taxonomy report: {e}")
            return {"error": str(e)}
    
    def _signature_type_to_detection_method(self, signature_type: str) -> DetectionMethod:
        """Map signature type to detection method"""
        mapping = {
            SignatureType.HASH_SHA256.value: DetectionMethod.HASH_SIGNATURE,
            SignatureType.PATTERN_BYTES.value: DetectionMethod.PATTERN_MATCHING,
            SignatureType.YARA_RULE.value: DetectionMethod.YARA_RULES,
            SignatureType.STATIC_HEURISTIC.value: DetectionMethod.STATIC_HEURISTICS,
            SignatureType.BEHAVIORAL_IOA.value: DetectionMethod.BEHAVIORAL_ANALYSIS
        }
        return mapping.get(signature_type, DetectionMethod.HASH_SIGNATURE)
    
    def _generate_taxonomy_recommendations(self, distribution: Dict[str, Any]) -> List[str]:
        """Generate recommendations based on signature distribution"""
        recommendations = []
        
        total_signatures = sum(item['count'] for item in distribution.values())
        
        if total_signatures == 0:
            return ["No signatures found - consider generating research-based signatures"]
        
        # Check balance across detection methods
        method_counts = {method: data['count'] for method, data in distribution.items()}
        
        if method_counts.get('hash_signature', 0) / total_signatures > 0.7:
            recommendations.append("High reliance on hash signatures - consider adding heuristic methods")
        
        if method_counts.get('behavioral_analysis', 0) / total_signatures < 0.1:
            recommendations.append("Low behavioral analysis coverage - consider adding IOA patterns")
        
        if method_counts.get('yara_rules', 0) / total_signatures < 0.2:
            recommendations.append("Limited YARA rule coverage - consider expanding YARA-based detection")
        
        # General recommendations
        recommendations.extend([
            "Maintain balanced signature portfolio across all detection methods",
            "Regular evaluation of signature effectiveness and false positive rates",
            "Integration of threat intelligence feeds for automatic signature updates"
        ])
        
        return recommendations

def main():
    """Test the enhanced signature manager"""
    # Initialize database manager and signature manager
    from database_manager import DatabaseManager
    
    db_manager = DatabaseManager("test_threats.db")
    sig_manager = EnhancedSignatureManager(db_manager)
    
    # Generate research-based signatures
    results = sig_manager.generate_research_based_signatures()
    print(f"Generated {len(results)} signatures")
    
    # Manage signature lifecycle
    lifecycle_results = sig_manager.manage_signature_lifecycle()
    print(f"Lifecycle management: {lifecycle_results}")
    
    # Get taxonomy report
    report = sig_manager.get_signature_taxonomy_report()
    print(f"Taxonomy report: {len(report.get('recommendations', []))} recommendations")
    
    # Create specific signature
    success, sig_id, message = sig_manager.create_signature_from_research(
        name="Research-based Hash Signature",
        detection_method=DetectionMethod.HASH_SIGNATURE,
        content="a" * 64,
        threat_name="Test Malware",
        metadata={"test": True}
    )
    print(f"Create research signature: {success} - {message}")

if __name__ == "__main__":
    main()
