#!/usr/bin/env python3
"""
Database Performance Optimization Module
Provides comprehensive database optimization, maintenance, and performance tuning
"""

import sqlite3
import json
import time
import threading
import logging
import datetime
from typing import Dict, List, Optional, Any, Tuple
from pathlib import Path
from dataclasses import dataclass
from enum import Enum
import yaml
import shutil
import os

logger = logging.getLogger(__name__)

class OptimizationType(Enum):
    """Types of database optimizations"""
    VACUUM = "vacuum"
    ANALYZE = "analyze"
    REINDEX = "reindex"
    STATISTICS_UPDATE = "statistics_update"
    INDEX_CREATION = "index_creation"
    CACHE_OPTIMIZATION = "cache_optimization"
    CONNECTION_TUNING = "connection_tuning"

@dataclass
class OptimizationResult:
    """Result of database optimization operation"""
    optimization_type: OptimizationType
    success: bool
    start_time: float
    end_time: float
    duration_seconds: float
    details: str
    performance_impact: str  # "positive", "neutral", "negative"
    error_message: Optional[str] = None

@dataclass
class DatabaseStats:
    """Database performance statistics"""
    page_count: int = 0
    page_size: int = 0
    freelist_count: int = 0
    table_count: int = 0
    index_count: int = 0
    record_count: Dict[str, int] = None
    index_usage: Dict[str, int] = None
    query_performance: Dict[str, float] = None
    last_vacuum: Optional[str] = None
    last_analyze: Optional[str] = None

class DatabasePerformanceOptimizer:
    """
    Comprehensive database performance optimization system
    """
    
    def __init__(self, database_path: str = "threats.db", 
                 config_file: str = "threat_database.yaml"):
        self.database_path = Path(database_path)
        self.config_file = Path(config_file)
        self.config = self._load_configuration()
        self._optimization_history = []
        self._lock = threading.RLock()
        
        # Performance monitoring
        self._performance_logs = []
        self._slow_queries = []
        self._query_stats = {}
        
        logger.info(f"Database optimizer initialized for: {self.database_path}")
    
    def _load_configuration(self) -> Dict[str, Any]:
        """Load optimizer configuration"""
        default_config = {
            "performance": {
                "enable_wal_mode": True,
                "cache_size": 10000,
                "synchronous_mode": "NORMAL",
                "temp_store": "MEMORY",
                "mmap_size": 268435456,  # 256MB
                "busy_timeout": 30000
            },
            "maintenance": {
                "auto_vacuum": True,
                "auto_analyze": True,
                "vacuum_threshold": 100,  # MB
                "analyze_frequency": 86400,  # 24 hours
                "index_rebuild_threshold": 0.25  # 25% fragmentation
            },
            "monitoring": {
                "slow_query_threshold": 1.0,  # seconds
                "performance_logging": True,
                "health_check_interval": 300  # 5 minutes
            }
        }
        
        if self.config_file.exists():
            try:
                with open(self.config_file, 'r') as f:
                    loaded_config = yaml.safe_load(f) or {}
                
                # Merge with defaults
                for section, values in loaded_config.items():
                    if section in default_config:
                        default_config[section].update(values)
                    else:
                        default_config[section] = values
                        
            except Exception as e:
                logger.warning(f"Error loading config: {e}. Using defaults.")
        
        return default_config
    
    def optimize_database(self) -> Tuple[bool, str]:
        """
        Run comprehensive database optimization
        
        Returns:
            Tuple of (success, message)
        """
        start_time = time.time()
        
        try:
            with self._lock:
                results = []
                
                # VACUUM
                logger.info("Starting VACUUM operation")
                vacuum_result = self._run_vacuum()
                results.append(vacuum_result)
                
                # ANALYZE
                logger.info("Starting ANALYZE operation")
                analyze_result = self._run_analyze()
                results.append(analyze_result)
                
                # REINDEX
                logger.info("Starting REINDEX operation")
                reindex_result = self._run_reindex()
                results.append(reindex_result)
                
                # Update statistics
                logger.info("Updating database statistics")
                stats_result = self._update_statistics()
                results.append(stats_result)
                
                # Create missing indexes
                logger.info("Creating missing indexes")
                index_result = self._create_missing_indexes()
                results.append(index_result)
                
                # Optimize settings
                logger.info("Optimizing database settings")
                settings_result = self._optimize_settings()
                results.append(settings_result)
                
                # Store results
                self._optimization_history.extend(results)
                
                duration = time.time() - start_time
                successful_ops = sum(1 for r in results if r.success)
                
                message = f"Optimization completed: {successful_ops}/{len(results)} operations successful in {duration:.2f}s"
                logger.info(message)
                
                return True, message
                
        except Exception as e:
            error_msg = f"Error during database optimization: {e}"
            logger.error(error_msg)
            return False, error_msg
    
    def _run_vacuum(self) -> OptimizationResult:
        """Run VACUUM operation to reclaim space"""
        start_time = time.time()
        
        try:
            with sqlite3.connect(self.database_path) as conn:
                cursor = conn.cursor()
                
                # Get initial database size
                initial_size = self.database_path.stat().st_size if self.database_path.exists() else 0
                
                # Check if vacuum is needed
                cursor.execute("PRAGMA freelist_count")
                freelist_count = cursor.fetchone()[0]
                
                if freelist_count < 100:  # Not much fragmentation
                    return OptimizationResult(
                        optimization_type=OptimizationType.VACUUM,
                        success=True,
                        start_time=start_time,
                        end_time=time.time(),
                        duration_seconds=time.time() - start_time,
                        details=f"VACUUM skipped - only {freelist_count} free pages",
                        performance_impact="neutral"
                    )
                
                # Run VACUUM
                cursor.execute("VACUUM")
                
                # Get final database size
                final_size = self.database_path.stat().st_size if self.database_path.exists() else initial_size
                space_saved = initial_size - final_size
                
                return OptimizationResult(
                    optimization_type=OptimizationType.VACUUM,
                    success=True,
                    start_time=start_time,
                    end_time=time.time(),
                    duration_seconds=time.time() - start_time,
                    details=f"VACUUM completed - {space_saved} bytes reclaimed, {freelist_count} free pages processed",
                    performance_impact="positive"
                )
                
        except Exception as e:
            return OptimizationResult(
                optimization_type=OptimizationType.VACUUM,
                success=False,
                start_time=start_time,
                end_time=time.time(),
                duration_seconds=time.time() - start_time,
                details="VACUUM operation failed",
                performance_impact="negative",
                error_message=str(e)
            )
    
    def _run_analyze(self) -> OptimizationResult:
        """Run ANALYZE operation to update query planner statistics"""
        start_time = time.time()
        
        try:
            with sqlite3.connect(self.database_path) as conn:
                cursor = conn.cursor()
                
                # Get table information
                cursor.execute("PRAGMA table_info(threat_signatures)")
                sig_columns = cursor.fetchall()
                
                cursor.execute("PRAGMA table_info(quarantine_files)")
                q_columns = cursor.fetchall()
                
                # Run ANALYZE
                cursor.execute("ANALYZE")
                
                # Get updated statistics
                cursor.execute("PRAGMA database_list")
                db_info = cursor.fetchall()
                
                return OptimizationResult(
                    optimization_type=OptimizationType.ANALYZE,
                    success=True,
                    start_time=start_time,
                    end_time=time.time(),
                    duration_seconds=time.time() - start_time,
                    details=f"ANALYZE completed for {len(db_info)} databases",
                    performance_impact="positive"
                )
                
        except Exception as e:
            return OptimizationResult(
                optimization_type=OptimizationType.ANALYZE,
                success=False,
                start_time=start_time,
                end_time=time.time(),
                duration_seconds=time.time() - start_time,
                details="ANALYZE operation failed",
                performance_impact="negative",
                error_message=str(e)
            )
    
    def _run_reindex(self) -> OptimizationResult:
        """Run REINDEX operation to rebuild all indexes"""
        start_time = time.time()
        
        try:
            with sqlite3.connect(self.database_path) as conn:
                cursor = conn.cursor()
                
                # Get index information
                cursor.execute("PRAGMA index_list(threat_signatures)")
                sig_indexes = cursor.fetchall()
                
                cursor.execute("PRAGMA index_list(quarantine_files)")
                q_indexes = cursor.fetchall()
                
                initial_index_count = len(sig_indexes) + len(q_indexes)
                
                # Run REINDEX
                cursor.execute("REINDEX")
                
                return OptimizationResult(
                    optimization_type=OptimizationType.REINDEX,
                    success=True,
                    start_time=start_time,
                    end_time=time.time(),
                    duration_seconds=time.time() - start_time,
                    details=f"REINDEX completed - rebuilt {initial_index_count} indexes",
                    performance_impact="positive"
                )
                
        except Exception as e:
            return OptimizationResult(
                optimization_type=OptimizationType.REINDEX,
                success=False,
                start_time=start_time,
                end_time=time.time(),
                duration_seconds=time.time() - start_time,
                details="REINDEX operation failed",
                performance_impact="negative",
                error_message=str(e)
            )
    
    def _update_statistics(self) -> OptimizationResult:
        """Update detailed database statistics"""
        start_time = time.time()
        
        try:
            with sqlite3.connect(self.database_path) as conn:
                cursor = conn.cursor()
                
                # Get comprehensive statistics
                stats = self._collect_detailed_stats()
                
                # Update SQLite user_version to track last optimization
                cursor.execute("PRAGMA user_version = 1")
                
                return OptimizationResult(
                    optimization_type=OptimizationType.STATISTICS_UPDATE,
                    success=True,
                    start_time=start_time,
                    end_time=time.time(),
                    duration_seconds=time.time() - start_time,
                    details=f"Statistics updated: {stats.page_count} pages, {stats.record_count} total records",
                    performance_impact="neutral"
                )
                
        except Exception as e:
            return OptimizationResult(
                optimization_type=OptimizationType.STATISTICS_UPDATE,
                success=False,
                start_time=start_time,
                end_time=time.time(),
                duration_seconds=time.time() - start_time,
                details="Statistics update failed",
                performance_impact="negative",
                error_message=str(e)
            )
    
    def _create_missing_indexes(self) -> OptimizationResult:
        """Create missing indexes for optimal performance"""
        start_time = time.time()
        
        try:
            with sqlite3.connect(self.database_path) as conn:
                cursor = conn.cursor()
                
                # Define recommended indexes
                recommended_indexes = [
                    ("threat_signatures", ["type", "threat_level"], "idx_threat_sig_type_level"),
                    ("threat_signatures", ["active", "confidence_score"], "idx_threat_sig_active_conf"),
                    ("quarantine_files", ["file_hash"], "idx_quarantine_hash"),
                    ("quarantine_files", ["status", "quarantine_time"], "idx_quarantine_status_time"),
                    ("threat_events", ["event_type", "event_time"], "idx_events_type_time"),
                    ("threat_analysis", ["file_hash", "analysis_type"], "idx_analysis_hash_type")
                ]
                
                created_indexes = 0
                
                for table, columns, index_name in recommended_indexes:
                    # Check if index exists
                    cursor.execute(
                        "SELECT name FROM sqlite_master WHERE type='index' AND name=?",
                        (index_name,)
                    )
                    
                    if not cursor.fetchone():
                        # Create the index
                        columns_str = ", ".join(columns)
                        sql = f"CREATE INDEX {index_name} ON {table} ({columns_str})"
                        cursor.execute(sql)
                        created_indexes += 1
                
                return OptimizationResult(
                    optimization_type=OptimizationType.INDEX_CREATION,
                    success=True,
                    start_time=start_time,
                    end_time=time.time(),
                    duration_seconds=time.time() - start_time,
                    details=f"Created {created_indexes} missing indexes",
                    performance_impact="positive"
                )
                
        except Exception as e:
            return OptimizationResult(
                optimization_type=OptimizationType.INDEX_CREATION,
                success=False,
                start_time=start_time,
                end_time=time.time(),
                duration_seconds=time.time() - start_time,
                details="Index creation failed",
                performance_impact="negative",
                error_message=str(e)
            )
    
    def _optimize_settings(self) -> OptimizationResult:
        """Optimize database settings"""
        start_time = time.time()
        
        try:
            with sqlite3.connect(self.database_path) as conn:
                cursor = conn.cursor()
                
                # Apply performance settings
                perf_config = self.config.get("performance", {})
                
                # WAL mode
                if perf_config.get("enable_wal_mode", True):
                    cursor.execute("PRAGMA journal_mode=WAL")
                    wal_result = cursor.fetchone()[0]
                    wal_status = "enabled" if wal_result == "wal" else "failed"
                
                # Cache size
                cache_size = perf_config.get("cache_size", 10000)
                cursor.execute(f"PRAGMA cache_size={cache_size}")
                
                # Synchronous mode
                sync_mode = perf_config.get("synchronous_mode", "NORMAL")
                cursor.execute(f"PRAGMA synchronous={sync_mode}")
                
                # Temp store
                temp_store = perf_config.get("temp_store", "MEMORY")
                temp_setting = 2 if temp_store == "MEMORY" else 0
                cursor.execute(f"PRAGMA temp_store={temp_setting}")
                
                # Memory map size
                mmap_size = perf_config.get("mmap_size", 268435456)
                cursor.execute(f"PRAGMA mmap_size={mmap_size}")
                
                # Busy timeout
                busy_timeout = perf_config.get("busy_timeout", 30000)
                cursor.execute(f"PRAGMA busy_timeout={busy_timeout}")
                
                return OptimizationResult(
                    optimization_type=OptimizationType.CONNECTION_TUNING,
                    success=True,
                    start_time=start_time,
                    end_time=time.time(),
                    duration_seconds=time.time() - start_time,
                    details=f"Settings optimized: WAL={wal_status}, cache={cache_size}, sync={sync_mode}",
                    performance_impact="positive"
                )
                
        except Exception as e:
            return OptimizationResult(
                optimization_type=OptimizationType.CONNECTION_TUNING,
                success=False,
                start_time=start_time,
                end_time=time.time(),
                duration_seconds=time.time() - start_time,
                details="Settings optimization failed",
                performance_impact="negative",
                error_message=str(e)
            )
    
    def _collect_detailed_stats(self) -> DatabaseStats:
        """Collect detailed database statistics"""
        try:
            with sqlite3.connect(self.database_path) as conn:
                cursor = conn.cursor()
                
                stats = DatabaseStats()
                
                # Get page information
                cursor.execute("PRAGMA page_count")
                stats.page_count = cursor.fetchone()[0]
                
                cursor.execute("PRAGMA page_size")
                stats.page_size = cursor.fetchone()[0]
                
                cursor.execute("PRAGMA freelist_count")
                stats.freelist_count = cursor.fetchone()[0]
                
                # Get table and index counts
                cursor.execute("SELECT COUNT(*) FROM sqlite_master WHERE type='table'")
                stats.table_count = cursor.fetchone()[0]
                
                cursor.execute("SELECT COUNT(*) FROM sqlite_master WHERE type='index'")
                stats.index_count = cursor.fetchone()[0]
                
                # Get record counts for main tables
                stats.record_count = {}
                tables = ["threat_signatures", "quarantine_files", "threat_events", "threat_analysis"]
                
                for table in tables:
                    try:
                        cursor.execute(f"SELECT COUNT(*) FROM {table}")
                        stats.record_count[table] = cursor.fetchone()[0]
                    except sqlite3.OperationalError:
                        stats.record_count[table] = 0
                
                return stats
                
        except Exception as e:
            logger.error(f"Error collecting detailed stats: {e}")
            return DatabaseStats()
    
    def analyze_query_performance(self, query: str) -> Dict[str, Any]:
        """Analyze performance of a specific query"""
        try:
            with sqlite3.connect(self.database_path) as conn:
                cursor = conn.cursor()
                
                # Enable query planner debugging
                cursor.execute("EXPLAIN QUERY PLAN " + query)
                plan = cursor.fetchall()
                
                # Execute query with timing
                start_time = time.time()
                cursor.execute(query)
                results = cursor.fetchall()
                execution_time = time.time() - start_time
                
                # Analyze plan
                plan_analysis = {
                    "query_type": self._analyze_query_plan(plan),
                    "complexity": self._estimate_query_complexity(plan),
                    "uses_index": self._check_index_usage(plan),
                    "estimated_rows": self._estimate_rows(plan)
                }
                
                return {
                    "query": query,
                    "execution_time": execution_time,
                    "result_count": len(results),
                    "plan": [dict(row) for row in plan],
                    "plan_analysis": plan_analysis,
                    "performance_rating": self._rate_performance(execution_time, plan_analysis)
                }
                
        except Exception as e:
            return {"error": str(e)}
    
    def _analyze_query_plan(self, plan: List) -> str:
        """Analyze query plan to determine type"""
        scan_types = set()
        
        for row in plan:
            detail = row[3] if len(row) > 3 else str(row)
            if "SCAN" in detail.upper():
                scan_types.add("SCAN")
            elif "SEARCH" in detail.upper():
                scan_types.add("SEARCH")
            elif "USE TEMP B-TREE" in detail.upper():
                scan_types.add("TEMP_BTREE")
            else:
                scan_types.add("OTHER")
        
        return " + ".join(sorted(scan_types))
    
    def _estimate_query_complexity(self, plan: List) -> str:
        """Estimate query complexity based on plan"""
        has_scans = any("SCAN" in str(row[3]).upper() for row in plan)
        has_temp = any("TEMP" in str(row[3]).upper() for row in plan)
        has_joins = len(plan) > 3
        
        if has_scans and has_temp:
            return "High"
        elif has_scans or has_joins:
            return "Medium"
        else:
            return "Low"
    
    def _check_index_usage(self, plan: List) -> List[str]:
        """Check which indexes are used"""
        indexes = []
        for row in plan:
            detail = row[3] if len(row) > 3 else str(row)
            if "INDEX" in detail.upper():
                indexes.append(detail.strip())
        return indexes
    
    def _estimate_rows(self, plan: List) -> int:
        """Estimate number of rows to be processed"""
        # Simple heuristic - count tables and conditions
        return max(1, len(plan) * 100)  # Very rough estimate
    
    def _rate_performance(self, execution_time: float, plan_analysis: Dict[str, Any]) -> str:
        """Rate query performance"""
        complexity = plan_analysis.get("complexity", "Low")
        
        if execution_time > 5.0:
            return "Poor"
        elif execution_time > 1.0:
            return "Fair" if complexity != "High" else "Poor"
        elif execution_time > 0.1:
            return "Good"
        else:
            return "Excellent"
    
    def get_optimization_history(self) -> List[OptimizationResult]:
        """Get history of optimization operations"""
        return self._optimization_history.copy()
    
    def get_database_health(self) -> Dict[str, Any]:
        """Get overall database health assessment"""
        try:
            stats = self._collect_detailed_stats()
            
            # Calculate health metrics
            total_pages = stats.page_count
            free_pages = stats.freelist_count
            fragmentation_ratio = free_pages / total_pages if total_pages > 0 else 0
            
            # Health score calculation
            health_score = 100
            issues = []
            
            # Check fragmentation
            if fragmentation_ratio > 0.1:  # More than 10% free pages
                health_score -= 20
                issues.append("High fragmentation detected")
            
            # Check table sizes
            for table, count in stats.record_count.items():
                if count > 100000:  # Large tables
                    issues.append(f"Large table: {table} ({count} records)")
            
            # Check index usage
            total_records = sum(stats.record_count.values())
            if stats.index_count < total_records / 1000:  # Low index density
                health_score -= 10
                issues.append("Potential missing indexes")
            
            # Determine health status
            if health_score >= 90:
                status = "Excellent"
            elif health_score >= 75:
                status = "Good"
            elif health_score >= 50:
                status = "Fair"
            else:
                status = "Poor"
            
            return {
                "health_score": health_score,
                "status": status,
                "fragmentation_ratio": fragmentation_ratio,
                "total_pages": total_pages,
                "free_pages": free_pages,
                "table_counts": stats.record_count,
                "index_count": stats.index_count,
                "issues": issues,
                "last_optimization": self._get_last_optimization_time()
            }
            
        except Exception as e:
            return {"error": str(e), "status": "Unknown"}
    
    def _get_last_optimization_time(self) -> Optional[str]:
        """Get time of last optimization"""
        if self._optimization_history:
            latest = max(self._optimization_history, key=lambda x: x.end_time)
            return datetime.datetime.fromtimestamp(latest.end_time).isoformat()
        return None
    
    def schedule_maintenance(self) -> bool:
        """Schedule automatic maintenance operations"""
        try:
            maintenance_config = self.config.get("maintenance", {})
            
            # Schedule vacuum if enabled and threshold is met
            if maintenance_config.get("auto_vacuum", True):
                if self._should_run_vacuum():
                    logger.info("Running automatic VACUUM")
                    result = self._run_vacuum()
                    self._optimization_history.append(result)
            
            # Schedule analyze if enabled
            if maintenance_config.get("auto_analyze", True):
                if self._should_run_analyze():
                    logger.info("Running automatic ANALYZE")
                    result = self._run_analyze()
                    self._optimization_history.append(result)
            
            return True
            
        except Exception as e:
            logger.error(f"Error in scheduled maintenance: {e}")
            return False
    
    def _should_run_vacuum(self) -> bool:
        """Check if VACUUM should be run"""
        try:
            with sqlite3.connect(self.database_path) as conn:
                cursor = conn.cursor()
                cursor.execute("PRAGMA freelist_count")
                free_pages = cursor.fetchone()[0]
                
                cursor.execute("PRAGMA page_count")
                total_pages = cursor.fetchone()[0]
                
                # Run if more than 10% pages are free
                return free_pages / total_pages > 0.1
                
        except Exception as e:
            logger.error(f"Error checking vacuum criteria: {e}")
            return False
    
    def _should_run_analyze(self) -> bool:
        """Check if ANALYZE should be run"""
        try:
            # Run if it's been more than 24 hours since last analyze
            # This is a simplified check - in practice, you'd want to track this properly
            if not self._optimization_history:
                return True
            
            last_analyze = None
            for result in reversed(self._optimization_history):
                if result.optimization_type == OptimizationType.ANALYZE and result.success:
                    last_analyze = result
                    break
            
            if not last_analyze:
                return True
            
            # Check if it's been more than 24 hours
            time_diff = time.time() - last_analyze.end_time
            return time_diff > 86400  # 24 hours
            
        except Exception as e:
            logger.error(f"Error checking analyze criteria: {e}")
            return False

def main():
    """Test the database performance optimizer"""
    # Initialize optimizer
    optimizer = DatabasePerformanceOptimizer("test_threats.db")
    
    # Run optimization
    success, message = optimizer.optimize_database()
    print(f"Optimization: {success} - {message}")
    
    # Get database health
    health = optimizer.get_database_health()
    print(f"Database health: {health}")
    
    # Get optimization history
    history = optimizer.get_optimization_history()
    print(f"Optimization history: {len(history)} operations")
    
    # Test query analysis
    test_query = "SELECT * FROM threat_signatures WHERE type = 'hash_sha256'"
    query_analysis = optimizer.analyze_query_performance(test_query)
    print(f"Query analysis: {query_analysis['performance_rating']}")

if __name__ == "__main__":
    main()
