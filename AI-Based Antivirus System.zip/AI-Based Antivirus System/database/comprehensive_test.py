#!/usr/bin/env python3
"""
Comprehensive Threat Database System Test Suite
Tests all components including the new integrated system and performance optimizations
"""

import os
import sys
import json
import time
import tempfile
import shutil
import threading
from pathlib import Path
import datetime
import hashlib
import sqlite3

# Add current directory to path
sys.path.insert(0, str(Path(__file__).parent))

class ComprehensiveTestSuite:
    """Comprehensive test suite for the threat database system"""
    
    def __init__(self):
        self.test_results = []
        self.performance_metrics = {}
        self.start_time = time.time()
        
    def log_test_result(self, test_name, success, message="", duration=0.0):
        """Log test result"""
        result = {
            "test_name": test_name,
            "success": success,
            "message": message,
            "duration": duration,
            "timestamp": datetime.datetime.now().isoformat()
        }
        self.test_results.append(result)
        status = "✓ PASS" if success else "✗ FAIL"
        print(f"{status}: {test_name} ({duration:.2f}s) - {message}")
        
    def test_system_initialization(self):
        """Test 1: Complete system initialization"""
        print("\n" + "="*60)
        print("TEST 1: SYSTEM INITIALIZATION")
        print("="*60)
        
        start_time = time.time()
        
        try:
            # Create temporary directory for test
            temp_dir = tempfile.mkdtemp()
            original_cwd = os.getcwd()
            os.chdir(temp_dir)
            
            print(f"Testing in temporary directory: {temp_dir}")
            
            # Import the complete system
            from threat_database_system import ThreatDatabaseSystem, SystemConfig
            
            # Create custom config for testing
            config = SystemConfig(
                database_path="test_threats.db",
                backup_directory="test_backups",
                quarantine_directory="test_quarantine",
                enable_auto_backup=False,  # Disable for testing
                enable_auto_maintenance=False,  # Disable for testing
                enable_threat_intel_updates=False  # Disable for testing
            )
            
            # Initialize system
            system = ThreatDatabaseSystem("test_config.yaml")
            
            # Verify components were initialized
            assert system.database_manager is not None, "Database manager not initialized"
            assert system.threat_database is not None, "Threat database not initialized"
            assert system.quarantine_manager is not None, "Quarantine manager not initialized"
            assert system.threat_intel is not None, "Threat intelligence not initialized"
            assert system.backup_manager is not None, "Backup manager not initialized"
            assert system.performance_optimizer is not None, "Performance optimizer not initialized"
            assert system.signature_manager is not None, "Signature manager not initialized"
            assert system.threat_analyzer is not None, "Threat analyzer not initialized"
            
            # Test system status
            status = system.get_system_status()
            assert status is not None, "System status not available"
            assert status.status in ["healthy", "warning", "critical"], f"Invalid system status: {status.status}"
            
            duration = time.time() - start_time
            self.log_test_result("System Initialization", True, f"All components initialized successfully", duration)
            
            # Cleanup
            os.chdir(original_cwd)
            shutil.rmtree(temp_dir)
            
            return system
            
        except Exception as e:
            duration = time.time() - start_time
            self.log_test_result("System Initialization", False, f"Error: {str(e)}", duration)
            
            # Cleanup on error
            try:
                os.chdir(original_cwd)
                shutil.rmtree(temp_dir)
            except:
                pass
                
            return None
    
    def test_database_operations(self, system):
        """Test 2: Database CRUD operations"""
        print("\n" + "="*60)
        print("TEST 2: DATABASE CRUD OPERATIONS")
        print("="*60)
        
        start_time = time.time()
        
        try:
            # Test basic database operations
            db = system.threat_database
            
            # Add test signatures
            test_signatures = []
            
            # Create multiple test signatures
            for i in range(10):
                sig_id = db.add_threat_signature(
                    name=f"Test Malware {i}",
                    signature_type="hash_sha256",
                    content=f"test_hash_{i}_" + "a" * 47,  # 64 character hash
                    description=f"Test signature {i}",
                    threat_level="high",
                    source="test",
                    first_seen=datetime.datetime.now()
                )
                test_signatures.append(sig_id)
            
            # Verify signatures were added
            all_signatures = db.get_all_signatures()
            assert len(all_signatures) >= 10, f"Expected at least 10 signatures, found {len(all_signatures)}"
            
            # Test signature retrieval
            retrieved_sig = db.get_threat_signature(test_signatures[0])
            assert retrieved_sig is not None, "Failed to retrieve signature"
            assert retrieved_sig[1] == f"Test Malware 0", "Retrieved wrong signature"
            
            # Test signature search
            found_signatures = db.search_signatures("Test Malware")
            assert len(found_signatures) > 0, "Search returned no results"
            
            # Test signature update
            updated = db.update_threat_signature(
                test_signatures[0],
                description="Updated test signature"
            )
            assert updated, "Failed to update signature"
            
            # Test signature deletion
            deleted = db.delete_threat_signature(test_signatures[-1])
            assert deleted, "Failed to delete signature"
            
            # Verify deletion
            remaining_signatures = db.get_all_signatures()
            remaining_ids = [sig[0] for sig in remaining_signatures]
            assert test_signatures[-1] not in remaining_ids, "Signature was not deleted"
            
            duration = time.time() - start_time
            self.log_test_result("Database CRUD Operations", True, 
                               f"Created, retrieved, updated, and deleted signatures successfully", duration)
            
            return True
            
        except Exception as e:
            duration = time.time() - start_time
            self.log_test_result("Database CRUD Operations", False, f"Error: {str(e)}", duration)
            return False
    
    def test_performance_optimization(self, system):
        """Test 3: Performance optimization features"""
        print("\n" + "="*60)
        print("TEST 3: PERFORMANCE OPTIMIZATION")
        print("="*60)
        
        start_time = time.time()
        
        try:
            # Add a large number of signatures to test performance
            db = system.threat_database
            optimizer = system.performance_optimizer
            
            print("Adding 1000 test signatures for performance testing...")
            signature_ids = []
            for i in range(1000):
                sig_id = db.add_threat_signature(
                    name=f"PerfTest Malware {i}",
                    signature_type="hash_sha256",
                    content=f"perf_test_hash_{i}_" + "b" * 47,
                    description=f"Performance test signature {i}",
                    threat_level="medium",
                    source="performance_test",
                    first_seen=datetime.datetime.now()
                )
                signature_ids.append(sig_id)
            
            # Test performance optimization
            print("Running database optimization...")
            success, message = optimizer.optimize_database()
            assert success, f"Database optimization failed: {message}"
            
            # Test index analysis
            print("Analyzing database indexes...")
            index_stats = optimizer.analyze_indexes()
            assert index_stats is not None, "Index analysis failed"
            
            # Test query optimization
            print("Testing query optimization...")
            query_stats = optimizer.analyze_queries()
            assert query_stats is not None, "Query analysis failed"
            
            # Test performance statistics
            print("Getting performance statistics...")
            perf_stats = optimizer.get_performance_statistics()
            assert perf_stats is not None, "Performance statistics failed"
            
            # Test signature lookup performance
            print("Testing signature lookup performance...")
            lookup_start = time.time()
            
            # Test 100 lookups
            for i in range(100):
                hash_value = f"perf_test_hash_{i}_" + "b" * 47
                signature = db.get_signature_by_hash(hash_value)
                assert signature is not None, f"Lookup failed for hash {i}"
            
            lookup_duration = time.time() - lookup_start
            avg_lookup_time = lookup_duration / 100
            
            print(f"Average signature lookup time: {avg_lookup_time*1000:.2f}ms")
            
            # Verify performance is acceptable (< 10ms average)
            assert avg_lookup_time < 0.01, f"Lookup performance too slow: {avg_lookup_time*1000:.2f}ms"
            
            duration = time.time() - start_time
            self.log_test_result("Performance Optimization", True, 
                               f"Optimized database with 1000 signatures, avg lookup: {avg_lookup_time*1000:.2f}ms", duration)
            
            return True
            
        except Exception as e:
            duration = time.time() - start_time
            self.log_test_result("Performance Optimization", False, f"Error: {str(e)}", duration)
            return False
    
    def test_signature_manager_features(self, system):
        """Test 4: Enhanced signature manager features"""
        print("\n" + "="*60)
        print("TEST 4: ENHANCED SIGNATURE MANAGER")
        print("="*60)
        
        start_time = time.time()
        
        try:
            signature_manager = system.signature_manager
            
            # Test different signature types
            signature_types = [
                ("hash_md5", f"md5_test_" + "c" * 24),
                ("hash_sha1", f"sha1_test_" + "d" * 31),
                ("hash_sha256", f"sha256_test_" + "e" * 47),
                ("yara_rule", "rule TestYara { strings: $s1 = \"malicious\" condition: $s1 }"),
                ("pattern", "suspicious.*pattern.*detection")
            ]
            
            added_signatures = []
            for sig_type, content in signature_types:
                sig_id = signature_manager.add_signature(
                    name=f"Manager Test {sig_type}",
                    signature_type=sig_type,
                    content=content,
                    description=f"Test {sig_type} signature",
                    threat_level="high",
                    source="signature_manager_test"
                )
                added_signatures.append((sig_id, sig_type))
            
            # Test signature matching
            print("Testing signature matching...")
            test_files = [
                ("test_file.exe", "This is a test file with malicious content"),
                ("scan_file.txt", "Normal text file without suspicious patterns"),
                ("pattern_file.log", "This file contains suspicious.*pattern.*detection")
            ]
            
            for filename, content in test_files:
                # Test if signature manager can detect patterns
                matches = signature_manager.find_matching_signatures(content)
                print(f"File {filename}: {len(matches)} matches found")
            
            # Test signature lifecycle management
            print("Testing signature lifecycle management...")
            lifecycle_results = signature_manager.manage_signature_lifecycle()
            assert lifecycle_results is not None, "Lifecycle management failed"
            
            # Test signature statistics
            print("Getting signature statistics...")
            stats = signature_manager.get_signature_statistics()
            assert stats is not None, "Signature statistics failed"
            
            duration = time.time() - start_time
            self.log_test_result("Enhanced Signature Manager", True, 
                               f"Tested {len(signature_types)} signature types and matching", duration)
            
            return True
            
        except Exception as e:
            duration = time.time() - start_time
            self.log_test_result("Enhanced Signature Manager", False, f"Error: {str(e)}", duration)
            return False
    
    def test_quarantine_operations(self, system):
        """Test 5: Quarantine file management"""
        print("\n" + "="*60)
        print("TEST 5: QUARANTINE OPERATIONS")
        print("="*60)
        
        start_time = time.time()
        
        try:
            quarantine_manager = system.quarantine_manager
            
            # Create test files
            test_files = []
            for i in range(3):
                filename = f"suspicious_file_{i}.exe"
                with open(filename, 'wb') as f:
                    f.write(b"MZ" + f"Suspicious content {i}".encode() * 100)
                test_files.append(filename)
            
            # Test quarantine operations
            quarantined_files = []
            for i, filename in enumerate(test_files):
                success, message, qid = quarantine_manager.quarantine_file(
                    filename,
                    threat_name=f"Test Malware {i}",
                    threat_level="high",
                    reason=f"Test quarantine operation {i}"
                )
                assert success, f"Quarantine failed for {filename}: {message}"
                assert qid is not None, f"No quarantine ID returned for {filename}"
                quarantined_files.append((qid, filename))
            
            # Test quarantine listing
            print("Testing quarantine listing...")
            quarantine_list = quarantine_manager.list_quarantined_files()
            assert len(quarantine_list) >= 3, f"Expected at least 3 quarantined files, found {len(quarantine_list)}"
            
            # Test quarantine status
            for qid, original_filename in quarantined_files:
                status = quarantine_manager.get_quarantine_status(qid)
                assert status is not None, f"No status found for quarantine ID {qid}"
                assert status['status'] == 'quarantined', f"Wrong status for {qid}"
            
            # Test file restore
            print("Testing file restore...")
            for qid, original_filename in quarantined_files[:1]:  # Restore first file
                success, restore_message = quarantine_manager.restore_file(qid, force=True)
                assert success, f"Restore failed for {qid}: {restore_message}"
                assert os.path.exists(original_filename), f"File {original_filename} was not restored"
            
            # Test quarantine cleanup
            print("Testing quarantine cleanup...")
            cleanup_stats = quarantine_manager.cleanup_old_quarantined_files(30)  # 30 days
            assert cleanup_stats is not None, "Quarantine cleanup failed"
            
            duration = time.time() - start_time
            self.log_test_result("Quarantine Operations", True, 
                               f"Quarantined and restored {len(test_files)} files successfully", duration)
            
            # Cleanup
            for filename in test_files:
                if os.path.exists(filename):
                    os.remove(filename)
            
            return True
            
        except Exception as e:
            duration = time.time() - start_time
            self.log_test_result("Quarantine Operations", False, f"Error: {str(e)}", duration)
            
            # Cleanup on error
            for filename in test_files:
                if os.path.exists(filename):
                    os.remove(filename)
                    
            return False
    
    def test_threat_intelligence(self, system):
        """Test 6: Threat intelligence integration"""
        print("\n" + "="*60)
        print("TEST 6: THREAT INTELLIGENCE")
        print("="*60)
        
        start_time = time.time()
        
        try:
            threat_intel = system.threat_intel
            
            # Test sample IOCs data
            print("Testing with sample IOCs...")
            sample_iocs = [
                {
                    "indicator": "test.badsite.com",
                    "type": "domain",
                    "malware_family": "TestMalware",
                    "confidence": "high"
                },
                {
                    "indicator": "192.168.1.100",
                    "type": "ip",
                    "malware_family": "TestRAT",
                    "confidence": "medium"
                },
                {
                    "indicator": "malware_hash_123",
                    "type": "hash",
                    "malware_family": "Generic",
                    "confidence": "low"
                }
            ]
            
            # Test IOC import
            imported_count = threat_intel._import_iocs_from_json(sample_iocs, "sample_test")
            assert imported_count > 0, "No IOCs were imported"
            
            # Test source status
            print("Testing source status...")
            source_status = threat_intel.get_source_status()
            assert source_status is not None, "Source status failed"
            
            # Test threat intelligence updates (mock)
            print("Testing threat intelligence updates...")
            update_results = threat_intel.update_all_sources()
            assert update_results is not None, "Threat intelligence update failed"
            
            # Test IOC analysis
            print("Testing IOC analysis...")
            test_indicators = ["test.badsite.com", "192.168.1.100"]
            ioc_analysis = threat_intel.analyze_iocs(test_indicators)
            assert ioc_analysis is not None, "IOC analysis failed"
            
            duration = time.time() - start_time
            self.log_test_result("Threat Intelligence", True, 
                               f"Imported {imported_count} IOCs and tested analysis features", duration)
            
            return True
            
        except Exception as e:
            duration = time.time() - start_time
            self.log_test_result("Threat Intelligence", False, f"Error: {str(e)}", duration)
            return False
    
    def test_backup_and_recovery(self, system):
        """Test 7: Backup and recovery operations"""
        print("\n" + "="*60)
        print("TEST 7: BACKUP AND RECOVERY")
        print("="*60)
        
        start_time = time.time()
        
        try:
            backup_manager = system.backup_manager
            
            # Create a backup
            print("Creating full backup...")
            success, message, backup_info = backup_manager.create_full_backup("Test comprehensive backup")
            assert success, f"Backup creation failed: {message}"
            assert backup_info is not None, "No backup info returned"
            
            # Verify backup
            print("Verifying backup...")
            is_valid = backup_manager.verify_backup(backup_info)
            assert is_valid, "Backup verification failed"
            
            # List backups
            print("Listing backups...")
            backups = backup_manager.list_backups()
            assert len(backups) > 0, "No backups found after creation"
            
            # Test incremental backup
            print("Creating incremental backup...")
            success, message, inc_backup_info = backup_manager.create_incremental_backup(
                base_backup_id=backup_info.backup_id,
                description="Test incremental backup"
            )
            assert success, f"Incremental backup failed: {message}"
            
            # Test backup cleanup
            print("Testing backup cleanup...")
            cleanup_result = backup_manager.cleanup_old_backups(30)  # 30 days
            assert cleanup_result is not None, "Backup cleanup failed"
            
            duration = time.time() - start_time
            self.log_test_result("Backup and Recovery", True, 
                               f"Created and verified backup with ID: {backup_info.backup_id}", duration)
            
            return True
            
        except Exception as e:
            duration = time.time() - start_time
            self.log_test_result("Backup and Recovery", False, f"Error: {str(e)}", duration)
            return False
    
    def test_threat_analysis(self, system):
        """Test 8: Threat analysis and reporting"""
        print("\n" + "="*60)
        print("TEST 8: THREAT ANALYSIS AND REPORTING")
        print("="*60)
        
        start_time = time.time()
        
        try:
            threat_analyzer = system.threat_analyzer
            
            # Test signature effectiveness analysis
            print("Testing signature effectiveness analysis...")
            sig_analysis = threat_analyzer.analyze_signature_effectiveness()
            assert sig_analysis is not None, "Signature analysis failed"
            
            # Test threat trends analysis
            print("Testing threat trends analysis...")
            trends = threat_analyzer.analyze_threat_trends(days=30)
            assert trends is not None, "Threat trends analysis failed"
            
            # Test quarantine pattern analysis
            print("Testing quarantine pattern analysis...")
            quarantine_analysis = threat_analyzer.analyze_quarantine_patterns()
            assert quarantine_analysis is not None, "Quarantine analysis failed"
            
            # Test comprehensive report generation
            print("Testing comprehensive report generation...")
            report = threat_analyzer.generate_comprehensive_report("comprehensive", days=30)
            assert report is not None, "Report generation failed"
            assert 'report_metadata' in report, "Report missing metadata"
            assert 'executive_summary' in report, "Report missing executive summary"
            
            # Test report export
            print("Testing report export...")
            os.makedirs("test_reports", exist_ok=True)
            success = threat_analyzer.export_report(report, "test_reports/test_report.json", "json")
            assert success, "Report export failed"
            assert os.path.exists("test_reports/test_report.json"), "Report file not created"
            
            duration = time.time() - start_time
            self.log_test_result("Threat Analysis and Reporting", True, 
                               f"Generated comprehensive analysis report with all sections", duration)
            
            return True
            
        except Exception as e:
            duration = time.time() - start_time
            self.log_test_result("Threat Analysis and Reporting", False, f"Error: {str(e)}", duration)
            return False
    
    def test_maintenance_utils(self, system):
        """Test 9: Database maintenance utilities"""
        print("\n" + "="*60)
        print("TEST 9: DATABASE MAINTENANCE UTILITIES")
        print("="*60)
        
        start_time = time.time()
        
        try:
            # Import maintenance utilities
            from maintenance_utils import MaintenanceUtils, CleanupManager
            
            # Initialize maintenance utilities
            maintenance = MaintenanceUtils(system.config.database_path)
            cleanup_manager = CleanupManager(system.config.database_path)
            
            # Test database integrity check
            print("Testing database integrity check...")
            integrity_result = maintenance.check_database_integrity()
            assert integrity_result is not None, "Integrity check failed"
            assert integrity_result['status'] == 'healthy', f"Database integrity issue: {integrity_result}"
            
            # Test vacuum operation
            print("Testing database vacuum...")
            vacuum_result = maintenance.vacuum_database()
            assert vacuum_result is not None, "Vacuum operation failed"
            
            # Test orphan cleanup
            print("Testing orphan cleanup...")
            orphan_stats = cleanup_manager.cleanup_orphaned_records()
            assert orphan_stats is not None, "Orphan cleanup failed"
            
            # Test maintenance scheduling
            print("Testing maintenance scheduling...")
            schedule_result = maintenance.schedule_maintenance(
                frequency="weekly",
                operations=["vacuum", "integrity_check", "cleanup"]
            )
            assert schedule_result is not None, "Maintenance scheduling failed"
            
            # Test statistics collection
            print("Testing maintenance statistics...")
            maint_stats = maintenance.get_maintenance_statistics()
            assert maint_stats is not None, "Maintenance statistics failed"
            
            duration = time.time() - start_time
            self.log_test_result("Database Maintenance Utilities", True, 
                               f"Successfully tested integrity check, vacuum, and cleanup operations", duration)
            
            return True
            
        except Exception as e:
            duration = time.time() - start_time
            self.log_test_result("Database Maintenance Utilities", False, f"Error: {str(e)}", duration)
            return False
    
    def test_threat_intel_updater(self, system):
        """Test 10: Threat intelligence updater"""
        print("\n" + "="*60)
        print("TEST 10: THREAT INTELLIGENCE UPDATER")
        print("="*60)
        
        start_time = time.time()
        
        try:
            # Import threat intelligence updater
            from threat_intel_updater import ThreatIntelUpdater, UpdateScheduler
            
            # Initialize updater
            updater = ThreatIntelUpdater(
                threat_database=system.threat_database,
                threat_intel=system.threat_intel,
                config_file="threat_intel.yaml"
            )
            
            # Test update scheduling
            print("Testing update scheduling...")
            scheduler = UpdateScheduler(updater)
            schedule_result = scheduler.schedule_updates(
                frequency="hourly",
                sources=["test_feed", "sample_feed"]
            )
            assert schedule_result is not None, "Update scheduling failed"
            
            # Test version management
            print("Testing version management...")
            version_info = updater.create_version_checkpoint("test_checkpoint")
            assert version_info is not None, "Version checkpoint creation failed"
            
            # Test update conflict resolution
            print("Testing update conflict resolution...")
            # Create test conflicting updates
            test_updates = [
                {"id": 1, "indicator": "test.com", "version": 1},
                {"id": 1, "indicator": "test.com", "version": 2}
            ]
            resolved = updater.resolve_update_conflicts(test_updates)
            assert resolved is not None, "Conflict resolution failed"
            
            # Test delta updates
            print("Testing delta updates...")
            base_version = "1.0.0"
            current_version = "1.1.0"
            delta_result = updater.generate_delta_update(base_version, current_version)
            assert delta_result is not None, "Delta update generation failed"
            
            # Test rollback functionality
            print("Testing rollback functionality...")
            rollback_result = updater.rollback_to_version(version_info['version_id'])
            assert rollback_result is not None, "Rollback failed"
            
            duration = time.time() - start_time
            self.log_test_result("Threat Intelligence Updater", True, 
                               f"Tested scheduling, versioning, conflict resolution, and rollback", duration)
            
            return True
            
        except Exception as e:
            duration = time.time() - start_time
            self.log_test_result("Threat Intelligence Updater", False, f"Error: {str(e)}", duration)
            return False
    
    def test_concurrent_operations(self, system):
        """Test 11: Concurrent operations and thread safety"""
        print("\n" + "="*60)
        print("TEST 11: CONCURRENT OPERATIONS")
        print("="*60)
        
        start_time = time.time()
        
        try:
            # Test concurrent signature operations
            def add_signatures_thread(thread_id, count):
                """Thread function to add signatures"""
                for i in range(count):
                    try:
                        sig_id = system.threat_database.add_threat_signature(
                            name=f"Concurrent Test {thread_id}-{i}",
                            signature_type="hash_sha256",
                            content=f"concurrent_hash_{thread_id}_{i}_" + "f" * 47,
                            description=f"Concurrent test signature {thread_id}-{i}",
                            threat_level="medium",
                            source="concurrent_test",
                            first_seen=datetime.datetime.now()
                        )
                    except Exception as e:
                        print(f"Thread {thread_id} failed to add signature {i}: {e}")
            
            # Start multiple threads
            threads = []
            num_threads = 5
            signatures_per_thread = 20
            
            print(f"Starting {num_threads} threads with {signatures_per_thread} signatures each...")
            
            for thread_id in range(num_threads):
                thread = threading.Thread(
                    target=add_signatures_thread,
                    args=(thread_id, signatures_per_thread)
                )
                threads.append(thread)
                thread.start()
            
            # Wait for all threads to complete
            for thread in threads:
                thread.join()
            
            # Verify all signatures were added
            all_signatures = system.threat_database.get_all_signatures()
            concurrent_signatures = [sig for sig in all_signatures if "Concurrent Test" in sig[1]]
            
            expected_count = num_threads * signatures_per_thread
            assert len(concurrent_signatures) >= expected_count * 0.8, \
                f"Expected at least {expected_count * 0.8} signatures, found {len(concurrent_signatures)}"
            
            # Test concurrent database queries
            def query_signatures_thread(thread_id):
                """Thread function to query signatures"""
                for i in range(10):
                    try:
                        # Test search
                        results = system.threat_database.search_signatures("Concurrent Test")
                        # Test get by hash
                        if len(results) > 0:
                            hash_value = results[0][3]  # signature content
                            signature = system.threat_database.get_signature_by_hash(hash_value)
                    except Exception as e:
                        print(f"Thread {thread_id} query failed: {e}")
            
            print("Testing concurrent database queries...")
            query_threads = []
            for thread_id in range(3):
                thread = threading.Thread(target=query_signatures_thread, args=(thread_id,))
                query_threads.append(thread)
                thread.start()
            
            # Wait for query threads
            for thread in query_threads:
                thread.join()
            
            duration = time.time() - start_time
            self.log_test_result("Concurrent Operations", True, 
                               f"Successfully handled {num_threads} concurrent threads with {expected_count} total operations", duration)
            
            return True
            
        except Exception as e:
            duration = time.time() - start_time
            self.log_test_result("Concurrent Operations", False, f"Error: {str(e)}", duration)
            return False
    
    def generate_test_report(self):
        """Generate comprehensive test report"""
        print("\n" + "="*80)
        print("COMPREHENSIVE TEST REPORT")
        print("="*80)
        
        total_tests = len(self.test_results)
        passed_tests = sum(1 for result in self.test_results if result['success'])
        failed_tests = total_tests - passed_tests
        total_duration = time.time() - self.start_time
        
        print(f"\nTest Summary:")
        print(f"  Total Tests: {total_tests}")
        print(f"  Passed: {passed_tests}")
        print(f"  Failed: {failed_tests}")
        print(f"  Success Rate: {(passed_tests/total_tests)*100:.1f}%")
        print(f"  Total Duration: {total_duration:.2f} seconds")
        
        print(f"\nDetailed Results:")
        for result in self.test_results:
            status = "✓ PASS" if result['success'] else "✗ FAIL"
            print(f"  {status} - {result['test_name']} ({result['duration']:.2f}s)")
            if result['message']:
                print(f"        {result['message']}")
        
        # Performance summary
        if self.performance_metrics:
            print(f"\nPerformance Metrics:")
            for metric, value in self.performance_metrics.items():
                print(f"  {metric}: {value}")
        
        # System features tested
        features_tested = [
            "System initialization and component integration",
            "Database CRUD operations with transaction support",
            "Performance optimization with indexing and caching",
            "Enhanced signature management with multiple detection methods",
            "Quarantine file management with restore capabilities",
            "Threat intelligence integration and IOC processing",
            "Backup and recovery with integrity verification",
            "Threat analysis and comprehensive reporting",
            "Database maintenance with integrity checks",
            "Threat intelligence updater with versioning",
            "Concurrent operations and thread safety"
        ]
        
        print(f"\nSystem Features Tested:")
        for i, feature in enumerate(features_tested, 1):
            print(f"  {i}. {feature}")
        
        # Final assessment
        print(f"\nSystem Assessment:")
        if failed_tests == 0:
            print("  🎉 ALL TESTS PASSED! The threat database system is fully functional.")
            print("  ✅ Ready for production deployment")
            print("  ✅ All core components working correctly")
            print("  ✅ Performance optimizations active")
            print("  ✅ Thread safety verified")
        else:
            print(f"  ⚠️  {failed_tests} tests failed. Review the detailed results above.")
            print("  🔧 System may need additional configuration or fixes")
        
        print(f"\n" + "="*80)
        
        return {
            "total_tests": total_tests,
            "passed_tests": passed_tests,
            "failed_tests": failed_tests,
            "success_rate": (passed_tests/total_tests)*100,
            "total_duration": total_duration,
            "test_results": self.test_results
        }

def main():
    """Run the comprehensive test suite"""
    print("THREAT DATABASE SYSTEM - COMPREHENSIVE TEST SUITE")
    print("=" * 80)
    print("This test suite validates all components of the threat database system")
    print("including the new integrated system and performance optimizations.")
    print("=" * 80)
    
    # Initialize test suite
    test_suite = ComprehensiveTestSuite()
    
    try:
        # Test 1: System Initialization
        system = test_suite.test_system_initialization()
        if not system:
            print("❌ System initialization failed. Cannot continue with other tests.")
            return False
        
        # Test 2: Database Operations
        test_suite.test_database_operations(system)
        
        # Test 3: Performance Optimization
        test_suite.test_performance_optimization(system)
        
        # Test 4: Enhanced Signature Manager
        test_suite.test_signature_manager_features(system)
        
        # Test 5: Quarantine Operations
        test_suite.test_quarantine_operations(system)
        
        # Test 6: Threat Intelligence
        test_suite.test_threat_intelligence(system)
        
        # Test 7: Backup and Recovery
        test_suite.test_backup_and_recovery(system)
        
        # Test 8: Threat Analysis
        test_suite.test_threat_analysis(system)
        
        # Test 9: Maintenance Utilities
        test_suite.test_maintenance_utils(system)
        
        # Test 10: Threat Intel Updater
        test_suite.test_threat_intel_updater(system)
        
        # Test 11: Concurrent Operations
        test_suite.test_concurrent_operations(system)
        
    except KeyboardInterrupt:
        print("\n\n⚠️  Test suite interrupted by user")
        return False
    except Exception as e:
        print(f"\n\n❌ Unexpected error during test execution: {e}")
        import traceback
        traceback.print_exc()
        return False
    
    # Generate final report
    report = test_suite.generate_test_report()
    
    # Save report to file
    report_file = "comprehensive_test_report.json"
    try:
        with open(report_file, 'w') as f:
            json.dump(report, f, indent=2, default=str)
        print(f"\nTest report saved to: {report_file}")
    except Exception as e:
        print(f"Warning: Could not save test report: {e}")
    
    # Return success status
    return report['failed_tests'] == 0

if __name__ == "__main__":
    success = main()
    exit_code = 0 if success else 1
    print(f"\nExiting with code: {exit_code}")
    sys.exit(exit_code)