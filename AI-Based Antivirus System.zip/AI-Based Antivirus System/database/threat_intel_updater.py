#!/usr/bin/env python3
"""
Threat Intelligence Update System
Automated threat intelligence update and management system
"""

import json
import requests
import datetime
import logging
import threading
import time
from typing import Dict, List, Optional, Any, Tuple
from pathlib import Path
from dataclasses import dataclass, asdict
from enum import Enum
import schedule
import hashlib

from threat_database import ThreatDatabase, ThreatSignature
from threat_intel import ThreatIntelIntegrator
from enhanced_signature_manager import EnhancedSignatureManager, DetectionMethod

logger = logging.getLogger(__name__)

class UpdateStatus(Enum):
    """Update operation status"""
    SUCCESS = "success"
    FAILED = "failed"
    PARTIAL = "partial"
    SKIPPED = "skipped"
    IN_PROGRESS = "in_progress"

class UpdateType(Enum):
    """Types of threat intelligence updates"""
    IOC_UPDATE = "ioc_update"
    SIGNATURE_UPDATE = "signature_update"
    YARA_RULE_UPDATE = "yara_rule_update"
    BEHAVIORAL_PATTERN_UPDATE = "behavioral_pattern_update"
    FULL_SYNC = "full_sync"
    DELTA_UPDATE = "delta_update"

@dataclass
class UpdateSource:
    """Update source configuration"""
    name: str
    url: str
    source_type: UpdateType
    format_type: str  # json, csv, xml
    auth_token: Optional[str] = None
    api_key: Optional[str] = None
    enabled: bool = True
    update_frequency: int = 3600  # seconds
    last_update: Optional[str] = None
    success_count: int = 0
    failure_count: int = 0
    last_error: Optional[str] = None

@dataclass
class UpdateResult:
    """Result of update operation"""
    source_name: str
    update_type: UpdateType
    status: UpdateStatus
    start_time: float
    end_time: float
    duration_seconds: float
    items_processed: int = 0
    items_added: int = 0
    items_updated: int = 0
    items_failed: int = 0
    new_signatures_created: int = 0
    error_details: Optional[str] = None
    warnings: List[str] = None
    
    def __post_init__(self):
        if self.warnings is None:
            self.warnings = []

class ThreatIntelligenceUpdater:
    """
    Automated threat intelligence update system
    """
    
    def __init__(self, database: ThreatDatabase, 
                 integrator: ThreatIntelIntegrator,
                 signature_manager: EnhancedSignatureManager,
                 config_file: str = "threat_intel.yaml"):
        self.database = database
        self.integrator = integrator
        self.signature_manager = signature_manager
        self.config_file = Path(config_file)
        
        # Update sources
        self.update_sources = self._load_update_sources()
        
        # Update history
        self.update_history = []
        self._update_lock = threading.RLock()
        
        # Update statistics
        self.stats = {
            "total_updates": 0,
            "successful_updates": 0,
            "failed_updates": 0,
            "total_items_processed": 0,
            "total_signatures_created": 0,
            "last_full_sync": None,
            "update_frequency": 3600
        }
        
        logger.info("Threat intelligence updater initialized")
    
    def _load_update_sources(self) -> List[UpdateSource]:
        """Load update sources configuration"""
        sources = []
        
        if self.config_file.exists():
            try:
                import yaml
                with open(self.config_file, 'r') as f:
                    config = yaml.safe_load(f) or {}
                
                for source_config in config.get('sources', []):
                    source = UpdateSource(
                        name=source_config['name'],
                        url=source_config['url'],
                        source_type=UpdateType(source_config.get('source_type', 'ioc_update')),
                        format_type=source_config.get('format_type', 'json'),
                        auth_token=source_config.get('auth_token'),
                        api_key=source_config.get('api_key'),
                        enabled=source_config.get('enabled', True),
                        update_frequency=source_config.get('update_frequency', 3600)
                    )
                    sources.append(source)
                    
            except Exception as e:
                logger.error(f"Error loading update sources: {e}")
        
        # Add default sources if none loaded
        if not sources:
            sources = self._get_default_sources()
        
        return sources
    
    def _get_default_sources(self) -> List[UpdateSource]:
        """Get default update sources"""
        return [
            UpdateSource(
                name="Local IOC Feed",
                url="file://./sample_iocs.json",
                source_type=UpdateType.IOC_UPDATE,
                format_type="json",
                update_frequency=300  # 5 minutes
            ),
            UpdateSource(
                name="Local YARA Rules",
                url="file://./sample_yara.json",
                source_type=UpdateType.YARA_RULE_UPDATE,
                format_type="json",
                update_frequency=600  # 10 minutes
            ),
            UpdateSource(
                name="Behavioral Patterns",
                url="file://./sample_behaviors.json",
                source_type=UpdateType.BEHAVIORAL_PATTERN_UPDATE,
                format_type="json",
                update_frequency=1800  # 30 minutes
            )
        ]
    
    def schedule_updates(self) -> bool:
        """Schedule automatic updates"""
        try:
            # Schedule updates for each source
            for source in self.update_sources:
                if source.enabled:
                    self._schedule_source_update(source)
            
            # Start update scheduler
            self._start_update_scheduler()
            
            logger.info("Threat intelligence updates scheduled")
            return True
            
        except Exception as e:
            logger.error(f"Error scheduling updates: {e}")
            return False
    
    def _schedule_source_update(self, source: UpdateSource):
        """Schedule update for a specific source"""
        def update_source():
            try:
                self.update_from_source(source.name)
            except Exception as e:
                logger.error(f"Error in scheduled update for {source.name}: {e}")
        
        # Convert frequency to schedule job
        if source.update_frequency <= 3600:  # Hourly or less
            minutes = source.update_frequency // 60
            if minutes == 0:
                minutes = 1
            schedule.every(minutes).minutes.do(update_source)
        else:  # Daily or longer
            hours = source.update_frequency // 3600
            schedule.every(hours).hours.do(update_source)
    
    def _start_update_scheduler(self):
        """Start the update scheduler"""
        def run_scheduler():
            while True:
                schedule.run_pending()
                time.sleep(60)  # Check every minute
        
        scheduler_thread = threading.Thread(target=run_scheduler, daemon=True)
        scheduler_thread.start()
    
    def update_from_source(self, source_name: str) -> UpdateResult:
        """Update threat intelligence from a specific source"""
        start_time = time.time()
        
        try:
            with self._update_lock:
                # Find source
                source = None
                for s in self.update_sources:
                    if s.name == source_name:
                        source = s
                        break
                
                if not source:
                    return UpdateResult(
                        source_name=source_name,
                        update_type=UpdateType.IOC_UPDATE,
                        status=UpdateStatus.FAILED,
                        start_time=start_time,
                        end_time=time.time(),
                        duration_seconds=time.time() - start_time,
                        error_details=f"Source not found: {source_name}"
                    )
                
                if not source.enabled:
                    return UpdateResult(
                        source_name=source_name,
                        update_type=source.source_type,
                        status=UpdateStatus.SKIPPED,
                        start_time=start_time,
                        end_time=time.time(),
                        duration_seconds=time.time() - start_time,
                        error_details="Source is disabled"
                    )
                
                logger.info(f"Starting update from source: {source_name}")
                
                # Fetch and process data based on source type
                if source.source_type == UpdateType.IOC_UPDATE:
                    return self._update_iocs(source, start_time)
                elif source.source_type == UpdateType.SIGNATURE_UPDATE:
                    return self._update_signatures(source, start_time)
                elif source.source_type == UpdateType.YARA_RULE_UPDATE:
                    return self._update_yara_rules(source, start_time)
                elif source.source_type == UpdateType.BEHAVIORAL_PATTERN_UPDATE:
                    return self._update_behavioral_patterns(source, start_time)
                else:
                    return UpdateResult(
                        source_name=source_name,
                        update_type=source.source_type,
                        status=UpdateStatus.FAILED,
                        start_time=start_time,
                        end_time=time.time(),
                        duration_seconds=time.time() - start_time,
                        error_details=f"Unsupported update type: {source.source_type}"
                    )
                
        except Exception as e:
            end_time = time.time()
            logger.error(f"Error updating from source {source_name}: {e}")
            
            return UpdateResult(
                source_name=source_name,
                update_type=UpdateType.IOC_UPDATE,
                status=UpdateStatus.FAILED,
                start_time=start_time,
                end_time=end_time,
                duration_seconds=end_time - start_time,
                error_details=str(e)
            )
    
    def _update_iocs(self, source: UpdateSource, start_time: float) -> UpdateResult:
        """Update IOCs from source"""
        try:
            # Use existing integrator
            success, imported_count, message = self.integrator.update_from_source(source.name)
            
            if success:
                source.success_count += 1
                source.last_update = datetime.datetime.now().isoformat()
                new_signatures = imported_count
            else:
                source.failure_count += 1
                source.last_error = message
                new_signatures = 0
            
            end_time = time.time()
            
            return UpdateResult(
                source_name=source.name,
                update_type=source.source_type,
                status=UpdateStatus.SUCCESS if success else UpdateStatus.FAILED,
                start_time=start_time,
                end_time=end_time,
                duration_seconds=end_time - start_time,
                items_processed=imported_count,
                items_added=imported_count,
                new_signatures_created=new_signatures,
                error_details=message if not success else None
            )
            
        except Exception as e:
            end_time = time.time()
            return UpdateResult(
                source_name=source.name,
                update_type=source.source_type,
                status=UpdateStatus.FAILED,
                start_time=start_time,
                end_time=end_time,
                duration_seconds=end_time - start_time,
                error_details=str(e)
            )
    
    def _update_signatures(self, source: UpdateSource, start_time: float) -> UpdateResult:
        """Update signatures from source"""
        try:
            # Fetch data
            data = self._fetch_source_data(source)
            if data is None:
                raise Exception("Failed to fetch source data")
            
            # Process signatures
            signatures_added = 0
            signatures_updated = 0
            items_processed = 0
            
            if isinstance(data, list):
                for item in data:
                    items_processed += 1
                    
                    try:
                        # Create signature from data
                        success, sig_id, message = self.signature_manager.create_signature_from_research(
                            name=item.get('name', f"Signature from {source.name}"),
                            detection_method=DetectionMethod.PATTERN_MATCHING,
                            content=item.get('content', ''),
                            threat_name=item.get('threat_name', 'Unknown'),
                            metadata=item
                        )
                        
                        if success:
                            signatures_added += 1
                        else:
                            signatures_updated += 1  # Might be update
                            
                    except Exception as e:
                        logger.warning(f"Error processing signature item: {e}")
            
            end_time = time.time()
            
            # Update source stats
            source.success_count += 1
            source.last_update = datetime.datetime.now().isoformat()
            
            return UpdateResult(
                source_name=source.name,
                update_type=source.source_type,
                status=UpdateStatus.SUCCESS,
                start_time=start_time,
                end_time=end_time,
                duration_seconds=end_time - start_time,
                items_processed=items_processed,
                items_added=signatures_added,
                items_updated=signatures_updated,
                new_signatures_created=signatures_added
            )
            
        except Exception as e:
            end_time = time.time()
            source.failure_count += 1
            source.last_error = str(e)
            
            return UpdateResult(
                source_name=source.name,
                update_type=source.source_type,
                status=UpdateStatus.FAILED,
                start_time=start_time,
                end_time=end_time,
                duration_seconds=end_time - start_time,
                error_details=str(e)
            )
    
    def _update_yara_rules(self, source: UpdateSource, start_time: float) -> UpdateResult:
        """Update YARA rules from source"""
        try:
            # Fetch data
            data = self._fetch_source_data(source)
            if data is None:
                raise Exception("Failed to fetch source data")
            
            # Process YARA rules
            rules_added = 0
            items_processed = 0
            
            if isinstance(data, list):
                for item in data:
                    items_processed += 1
                    
                    try:
                        # Create YARA signature
                        success, sig_id, message = self.signature_manager.create_signature_from_research(
                            name=item.get('name', f"YARA rule from {source.name}"),
                            detection_method=DetectionMethod.YARA_RULES,
                            content=item.get('content', item.get('rule', '')),
                            threat_name=item.get('threat_name', 'YARA Rule'),
                            metadata={
                                'rule_type': 'yara',
                                'version': item.get('version'),
                                'author': item.get('author'),
                                'date': item.get('date')
                            }
                        )
                        
                        if success:
                            rules_added += 1
                            
                    except Exception as e:
                        logger.warning(f"Error processing YARA rule: {e}")
            
            end_time = time.time()
            
            # Update source stats
            source.success_count += 1
            source.last_update = datetime.datetime.now().isoformat()
            
            return UpdateResult(
                source_name=source.name,
                update_type=source.source_type,
                status=UpdateStatus.SUCCESS,
                start_time=start_time,
                end_time=end_time,
                duration_seconds=end_time - start_time,
                items_processed=items_processed,
                items_added=rules_added,
                new_signatures_created=rules_added
            )
            
        except Exception as e:
            end_time = time.time()
            source.failure_count += 1
            source.last_error = str(e)
            
            return UpdateResult(
                source_name=source.name,
                update_type=source.source_type,
                status=UpdateStatus.FAILED,
                start_time=start_time,
                end_time=end_time,
                duration_seconds=end_time - start_time,
                error_details=str(e)
            )
    
    def _update_behavioral_patterns(self, source: UpdateSource, start_time: float) -> UpdateResult:
        """Update behavioral patterns from source"""
        try:
            # Fetch data
            data = self._fetch_source_data(source)
            if data is None:
                raise Exception("Failed to fetch source data")
            
            # Process behavioral patterns
            patterns_added = 0
            items_processed = 0
            
            if isinstance(data, list):
                for item in data:
                    items_processed += 1
                    
                    try:
                        # Create behavioral signature
                        success, sig_id, message = self.signature_manager.create_signature_from_research(
                            name=item.get('name', f"Behavioral pattern from {source.name}"),
                            detection_method=DetectionMethod.BEHAVIORAL_ANALYSIS,
                            content=json.dumps(item.get('sequence', [])),
                            threat_name=item.get('threat_name', 'Behavioral Pattern'),
                            metadata={
                                'pattern_type': 'behavioral',
                                'ioa_type': item.get('ioa_type', 'process_behavior'),
                                'severity_score': item.get('severity_score', 0.5),
                                'time_window': item.get('time_window', 300)
                            }
                        )
                        
                        if success:
                            patterns_added += 1
                            
                    except Exception as e:
                        logger.warning(f"Error processing behavioral pattern: {e}")
            
            end_time = time.time()
            
            # Update source stats
            source.success_count += 1
            source.last_update = datetime.datetime.now().isoformat()
            
            return UpdateResult(
                source_name=source.name,
                update_type=source.source_type,
                status=UpdateStatus.SUCCESS,
                start_time=start_time,
                end_time=end_time,
                duration_seconds=end_time - start_time,
                items_processed=items_processed,
                items_added=patterns_added,
                new_signatures_created=patterns_added
            )
            
        except Exception as e:
            end_time = time.time()
            source.failure_count += 1
            source.last_error = str(e)
            
            return UpdateResult(
                source_name=source.name,
                update_type=source.source_type,
                status=UpdateStatus.FAILED,
                start_time=start_time,
                end_time=end_time,
                duration_seconds=end_time - start_time,
                error_details=str(e)
            )
    
    def _fetch_source_data(self, source: UpdateSource) -> Optional[Any]:
        """Fetch data from source"""
        try:
            headers = {}
            
            if source.auth_token:
                headers['Authorization'] = f"Bearer {source.auth_token}"
            if source.api_key:
                headers['X-API-Key'] = source.api_key
            
            # Handle file URLs
            if source.url.startswith('file://'):
                file_path = source.url[7:]  # Remove 'file://' prefix
                file_path = Path(file_path)
                
                if file_path.exists():
                    with open(file_path, 'r') as f:
                        if source.format_type == 'json':
                            return json.load(f)
                        else:
                            return f.read()
                else:
                    logger.error(f"File not found: {file_path}")
                    return None
            
            # HTTP/HTTPS requests
            response = requests.get(source.url, headers=headers, timeout=30)
            response.raise_for_status()
            
            if source.format_type == 'json':
                return response.json()
            elif source.format_type == 'csv':
                # Parse CSV (simplified)
                import csv
                import io
                return list(csv.DictReader(io.StringIO(response.text)))
            else:
                return response.text
                
        except Exception as e:
            logger.error(f"Error fetching data from {source.name}: {e}")
            return None
    
    def run_full_update(self) -> List[UpdateResult]:
        """Run updates from all enabled sources"""
        results = []
        
        try:
            with self._update_lock:
                for source in self.update_sources:
                    if source.enabled:
                        result = self.update_from_source(source.name)
                        results.append(result)
                        
                        # Update overall statistics
                        self.stats["total_updates"] += 1
                        if result.status == UpdateStatus.SUCCESS:
                            self.stats["successful_updates"] += 1
                        else:
                            self.stats["failed_updates"] += 1
                        
                        self.stats["total_items_processed"] += result.items_processed
                        self.stats["total_signatures_created"] += result.new_signatures_created
                        
                        # Store in history
                        self.update_history.append(result)
                
                # Update last full sync
                self.stats["last_full_sync"] = datetime.datetime.now().isoformat()
                
                logger.info(f"Full update completed: {len(results)} sources processed")
                return results
                
        except Exception as e:
            logger.error(f"Error running full update: {e}")
            return results
    
    def get_update_status(self) -> Dict[str, Any]:
        """Get current update status and statistics"""
        with self._update_lock:
            return {
                "statistics": self.stats.copy(),
                "sources": [asdict(source) for source in self.update_sources],
                "recent_history": [
                    asdict(result) for result in self.update_history[-10:]  # Last 10 updates
                ],
                "next_scheduled_update": self._get_next_scheduled_update()
            }
    
    def _get_next_scheduled_update(self) -> Optional[str]:
        """Get next scheduled update time"""
        # This is a simplified calculation
        if self.update_sources:
            min_frequency = min(source.update_frequency for source in self.update_sources if source.enabled)
            return (datetime.datetime.now() + datetime.timedelta(seconds=min_frequency)).isoformat()
        return None
    
    def validate_source(self, source_name: str) -> Tuple[bool, str]:
        """Validate a threat intelligence source"""
        try:
            source = None
            for s in self.update_sources:
                if s.name == source_name:
                    source = s
                    break
            
            if not source:
                return False, f"Source not found: {source_name}"
            
            # Test data fetch
            data = self._fetch_source_data(source)
            if data is not None:
                return True, "Source is accessible and returning data"
            else:
                return False, "Source is not accessible or returning no data"
                
        except Exception as e:
            return False, f"Source validation failed: {str(e)}"
    
    def add_source(self, source: UpdateSource) -> bool:
        """Add a new update source"""
        try:
            with self._update_lock:
                # Check for duplicates
                for existing in self.update_sources:
                    if existing.name == source.name:
                        return False  # Already exists
                
                self.update_sources.append(source)
                logger.info(f"Added update source: {source.name}")
                return True
                
        except Exception as e:
            logger.error(f"Error adding source: {e}")
            return False
    
    def remove_source(self, source_name: str) -> bool:
        """Remove an update source"""
        try:
            with self._update_lock:
                for i, source in enumerate(self.update_sources):
                    if source.name == source_name:
                        del self.update_sources[i]
                        logger.info(f"Removed update source: {source_name}")
                        return True
                return False
                
        except Exception as e:
            logger.error(f"Error removing source: {e}")
            return False
    
    def update_source_config(self, source_name: str, updates: Dict[str, Any]) -> bool:
        """Update source configuration"""
        try:
            with self._update_lock:
                for source in self.update_sources:
                    if source.name == source_name:
                        for key, value in updates.items():
                            if hasattr(source, key):
                                setattr(source, key, value)
                        logger.info(f"Updated source configuration: {source_name}")
                        return True
                return False
                
        except Exception as e:
            logger.error(f"Error updating source config: {e}")
            return False

def main():
    """Test the threat intelligence updater"""
    from threat_database import ThreatDatabase
    from threat_intel import ThreatIntelIntegrator
    from enhanced_signature_manager import EnhancedSignatureManager
    from database_manager import DatabaseManager
    
    # Initialize components
    db = ThreatDatabase("test_threats.db")
    db_manager = DatabaseManager("test_threats.db")
    integrator = ThreatIntelIntegrator(db, "test_threat_intel.yaml")
    sig_manager = EnhancedSignatureManager(db_manager)
    
    # Initialize updater
    updater = ThreatIntelligenceUpdater(db, integrator, sig_manager)
    
    # Schedule updates
    updater.schedule_updates()
    
    # Run full update
    results = updater.run_full_update()
    
    for result in results:
        print(f"{result.source_name}: {result.status.value} - {result.items_processed} items processed")
    
    # Get status
    status = updater.get_update_status()
    print(f"Update statistics: {status['statistics']}")
    
    # Validate source
    valid, message = updater.validate_source("Local IOC Feed")
    print(f"Source validation: {valid} - {message}")

if __name__ == "__main__":
    main()
