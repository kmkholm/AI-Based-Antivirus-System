#!/usr/bin/env python3
"""
Threat Database Management System
A comprehensive SQLite-based threat intelligence and malware management system
Based on signature/heuristic research from docs/signature_heuristic.md
"""

import sqlite3
import json
import hashlib
import datetime
from typing import Optional, List, Dict, Any, Tuple
from pathlib import Path
import logging
from dataclasses import dataclass, asdict
from enum import Enum
import threading
import shutil
import os

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

class ThreatLevel(Enum):
    """Threat severity levels"""
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"

class SignatureType(Enum):
    """Types of threat signatures"""
    HASH_MD5 = "hash_md5"
    HASH_SHA1 = "hash_sha1"
    HASH_SHA256 = "hash_sha256"
    PATTERN_STRING = "pattern_string"
    PATTERN_BYTES = "pattern_bytes"
    YARA_RULE = "yara_rule"
    STATIC_HEURISTIC = "static_heuristic"
    BEHAVIORAL_IOA = "behavioral_ioa"

class QuarantineStatus(Enum):
    """Quarantine file statuses"""
    QUARANTINED = "quarantined"
    RESTORED = "restored"
    DELETED = "deleted"
    PENDING_ANALYSIS = "pending_analysis"

class AnalysisType(Enum):
    """Types of threat analysis"""
    STATIC = "static"
    DYNAMIC = "dynamic"
    BEHAVIORAL = "behavioral"
    YARA = "yara"
    HASH = "hash"
    SANDBOX = "sandbox"

@dataclass
class ThreatSignature:
    """Threat signature data model"""
    id: Optional[int] = None
    name: str = ""
    type: str = ""
    content: str = ""  # Hash value, pattern, YARA rule, etc.
    description: str = ""
    threat_level: str = "medium"
    first_seen: Optional[str] = None
    last_updated: Optional[str] = None
    source: str = ""  # Source of the signature
    metadata: Optional[str] = None  # JSON string for additional data
    confidence_score: float = 0.0
    false_positive_rate: float = 0.0
    usage_count: int = 0
    active: bool = True

@dataclass
class QuarantineEntry:
    """Quarantine file entry data model"""
    id: Optional[int] = None
    original_path: str = ""
    quarantine_path: str = ""
    file_hash: str = ""
    threat_name: str = ""
    threat_level: str = "medium"
    signature_id: Optional[int] = None
    status: str = "quarantined"
    quarantine_time: Optional[str] = None
    analysis_time: Optional[str] = None
    reason: str = ""
    metadata: Optional[str] = None

class ThreatDatabase:
    """Main threat database management class"""
    
    def __init__(self, db_path: str = "threats.db", backup_dir: str = "backups"):
        self.db_path = Path(db_path)
        self.backup_dir = Path(backup_dir)
        self.backup_dir.mkdir(exist_ok=True)
        self.lock = threading.Lock()
        
        # Initialize database
        self._init_database()
        logger.info(f"Threat database initialized: {self.db_path}")
    
    def _get_connection(self) -> sqlite3.Connection:
        """Get database connection with row factory"""
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        return conn
    
    def _init_database(self):
        """Initialize database tables and indexes"""
        with self._get_connection() as conn:
            cursor = conn.cursor()
            
            # Threat signatures table
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS threat_signatures (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    name TEXT NOT NULL,
                    type TEXT NOT NULL,
                    content TEXT NOT NULL,
                    description TEXT,
                    threat_level TEXT DEFAULT 'medium',
                    first_seen TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    last_updated TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    source TEXT,
                    metadata TEXT,
                    confidence_score REAL DEFAULT 0.0,
                    false_positive_rate REAL DEFAULT 0.0,
                    usage_count INTEGER DEFAULT 0,
                    active BOOLEAN DEFAULT 1,
                    UNIQUE(type, content)
                )
            ''')
            
            # YARA rules table (extended signature storage)
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS yara_rules (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    signature_id INTEGER,
                    rule_name TEXT NOT NULL,
                    meta_section TEXT,
                    strings_section TEXT,
                    conditions_section TEXT,
                    version TEXT,
                    author TEXT,
                    description TEXT,
                    date_created TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    date_updated TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    test_results TEXT,
                    FOREIGN KEY (signature_id) REFERENCES threat_signatures (id)
                )
            ''')
            
            # Heuristic rules table
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS heuristic_rules (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    signature_id INTEGER,
                    rule_name TEXT NOT NULL,
                    analysis_type TEXT NOT NULL, -- static, dynamic
                    condition_type TEXT NOT NULL, -- file_entropy, import_analysis, etc.
                    threshold_value REAL,
                    description TEXT,
                    weight REAL DEFAULT 1.0,
                    active BOOLEAN DEFAULT 1,
                    metadata TEXT,
                    date_created TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    date_updated TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    FOREIGN KEY (signature_id) REFERENCES threat_signatures (id)
                )
            ''')
            
            # Behavioral IOA patterns
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS behavioral_patterns (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    signature_id INTEGER,
                    pattern_name TEXT NOT NULL,
                    event_sequence TEXT NOT NULL, -- JSON array of events
                    description TEXT,
                    severity_score REAL DEFAULT 1.0,
                    time_window INTEGER DEFAULT 300, -- seconds
                    active BOOLEAN DEFAULT 1,
                    metadata TEXT,
                    created_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    updated_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    FOREIGN KEY (signature_id) REFERENCES threat_signatures (id)
                )
            ''')
            
            # Threat intelligence feeds
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS threat_intel_feeds (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    feed_name TEXT NOT NULL,
                    feed_url TEXT,
                    feed_type TEXT NOT NULL, -- IOC, signature, behavior
                    last_update TIMESTAMP,
                    status TEXT DEFAULT 'active', -- active, inactive, error
                    confidence_score REAL DEFAULT 0.5,
                    update_frequency INTEGER DEFAULT 3600, -- seconds
                    metadata TEXT,
                    date_added TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            ''')
            
            # Quarantine files table
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS quarantine_files (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    original_path TEXT NOT NULL,
                    quarantine_path TEXT NOT NULL,
                    file_hash TEXT NOT NULL,
                    threat_name TEXT,
                    threat_level TEXT DEFAULT 'medium',
                    signature_id INTEGER,
                    status TEXT DEFAULT 'quarantined',
                    quarantine_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    analysis_time TIMESTAMP,
                    reason TEXT,
                    metadata TEXT,
                    file_size INTEGER,
                    file_type TEXT,
                    FOREIGN KEY (signature_id) REFERENCES threat_signatures (id)
                )
            ''')
            
            # Threat analysis results
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS threat_analysis (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    file_hash TEXT NOT NULL,
                    file_path TEXT,
                    analysis_type TEXT NOT NULL,
                    analysis_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    analyzer_version TEXT,
                    result TEXT NOT NULL, -- JSON result data
                    threat_level TEXT,
                    confidence_score REAL,
                    processing_time REAL,
                    resource_usage TEXT,
                    findings TEXT, -- JSON array of findings
                    recommendations TEXT
                )
            ''')
            
            # Threat history/events
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS threat_events (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    event_type TEXT NOT NULL, -- detection, quarantine, analysis, etc.
                    file_hash TEXT,
                    signature_id INTEGER,
                    event_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    severity TEXT,
                    source TEXT, -- endpoint_id, scanner_name, etc.
                    details TEXT, -- JSON event details
                    user_action TEXT,
                    automated_response TEXT,
                    status TEXT DEFAULT 'open' -- open, resolved, false_positive
                )
            ''')
            
            # System configuration
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS system_config (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    config_key TEXT UNIQUE NOT NULL,
                    config_value TEXT,
                    description TEXT,
                    last_updated TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            ''')
            
            # Create indexes for performance
            indexes = [
                "CREATE INDEX IF NOT EXISTS idx_threat_signatures_type ON threat_signatures(type)",
                "CREATE INDEX IF NOT EXISTS idx_threat_signatures_active ON threat_signatures(active)",
                "CREATE INDEX IF NOT EXISTS idx_threat_signatures_threat_level ON threat_signatures(threat_level)",
                "CREATE INDEX IF NOT EXISTS idx_quarantine_files_hash ON quarantine_files(file_hash)",
                "CREATE INDEX IF NOT EXISTS idx_quarantine_files_status ON quarantine_files(status)",
                "CREATE INDEX IF NOT EXISTS idx_analysis_hash ON threat_analysis(file_hash)",
                "CREATE INDEX IF NOT EXISTS idx_analysis_type ON threat_analysis(analysis_type)",
                "CREATE INDEX IF NOT EXISTS idx_events_time ON threat_events(event_time)",
                "CREATE INDEX IF NOT EXISTS idx_events_type ON threat_events(event_type)"
            ]
            
            for index in indexes:
                cursor.execute(index)
            
            conn.commit()
            logger.info("Database schema initialized successfully")
    
    def add_signature(self, signature: ThreatSignature) -> int:
        """Add a new threat signature to the database"""
        with self.lock, self._get_connection() as conn:
            cursor = conn.cursor()
            
            # Check if signature already exists
            cursor.execute(
                "SELECT id FROM threat_signatures WHERE type = ? AND content = ?",
                (signature.type, signature.content)
            )
            existing = cursor.fetchone()
            
            if existing:
                logger.warning(f"Signature already exists: {signature.name}")
                return existing['id']
            
            cursor.execute('''
                INSERT INTO threat_signatures 
                (name, type, content, description, threat_level, source, metadata, 
                 confidence_score, false_positive_rate)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            ''', (
                signature.name, signature.type, signature.content,
                signature.description, signature.threat_level, signature.source,
                signature.metadata, signature.confidence_score,
                signature.false_positive_rate
            ))
            
            signature_id = cursor.lastrowid
            
            # If it's a YARA rule, also store in yara_rules table
            if signature.type == SignatureType.YARA_RULE.value:
                self._add_yara_rule(cursor, signature_id, signature)
            
            conn.commit()
            logger.info(f"Added signature: {signature.name} (ID: {signature_id})")
            return signature_id
    
    def _add_yara_rule(self, cursor, signature_id: int, signature: ThreatSignature):
        """Parse and store YARA rule components"""
        try:
            content = signature.content
            
            # Basic YARA rule parsing (simplified)
            meta_section = ""
            strings_section = ""
            conditions_section = ""
            
            # Extract rule name from content
            rule_name = signature.name
            
            # Parse meta section
            if "meta:" in content:
                meta_start = content.find("meta:") + 5
                meta_end = content.find("strings:") if "strings:" in content else content.find("condition:")
                if meta_end == -1:
                    meta_end = len(content)
                meta_section = content[meta_start:meta_end].strip()
            
            # Parse strings section
            if "strings:" in content:
                strings_start = content.find("strings:") + 8
                strings_end = content.find("condition:") if "condition:" in content else len(content)
                strings_section = content[strings_start:strings_end].strip()
            
            # Parse conditions section
            if "condition:" in content:
                conditions_start = content.find("condition:") + 10
                conditions_section = content[conditions_start:].strip()
            
            cursor.execute('''
                INSERT INTO yara_rules 
                (signature_id, rule_name, meta_section, strings_section, conditions_section)
                VALUES (?, ?, ?, ?, ?)
            ''', (signature_id, rule_name, meta_section, strings_section, conditions_section))
            
        except Exception as e:
            logger.error(f"Error parsing YARA rule: {e}")
    
    def search_signatures(self, query_type: str = None, threat_level: str = None, 
                         active_only: bool = True) -> List[Dict[str, Any]]:
        """Search for threat signatures"""
        with self._get_connection() as conn:
            cursor = conn.cursor()
            
            sql = "SELECT * FROM threat_signatures WHERE 1=1"
            params = []
            
            if query_type:
                sql += " AND type = ?"
                params.append(query_type)
            
            if threat_level:
                sql += " AND threat_level = ?"
                params.append(threat_level)
            
            if active_only:
                sql += " AND active = 1"
            
            sql += " ORDER BY last_updated DESC"
            
            cursor.execute(sql, params)
            return [dict(row) for row in cursor.fetchall()]
    
    def get_signature_by_hash(self, file_hash: str) -> Optional[Dict[str, Any]]:
        """Get signature by file hash"""
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute(
                "SELECT * FROM threat_signatures WHERE content = ? AND type LIKE 'hash_%'",
                (file_hash,)
            )
            row = cursor.fetchone()
            return dict(row) if row else None
    
    def get_yara_rule(self, signature_id: int) -> Optional[Dict[str, Any]]:
        """Get YARA rule details by signature ID"""
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute(
                "SELECT * FROM yara_rules WHERE signature_id = ?",
                (signature_id,)
            )
            row = cursor.fetchone()
            return dict(row) if row else None
    
    def add_quarantine_entry(self, entry: QuarantineEntry) -> int:
        """Add a file to quarantine"""
        with self.lock, self._get_connection() as conn:
            cursor = conn.cursor()
            
            cursor.execute('''
                INSERT INTO quarantine_files 
                (original_path, quarantine_path, file_hash, threat_name, threat_level,
                 signature_id, reason, metadata, file_size, file_type)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ''', (
                entry.original_path, entry.quarantine_path, entry.file_hash,
                entry.threat_name, entry.threat_level, entry.signature_id,
                entry.reason, entry.metadata, None, None  # file_size and file_type to be updated
            ))
            
            quarantine_id = cursor.lastrowid
            conn.commit()
            
            # Add event log
            self._add_event("quarantine", file_hash=entry.file_hash, 
                          signature_id=entry.signature_id,
                          details={"action": "file_quarantined", "path": entry.original_path})
            
            logger.info(f"Quarantined file: {entry.original_path} (ID: {quarantine_id})")
            return quarantine_id
    
    def restore_quarantined_file(self, quarantine_id: int) -> bool:
        """Restore a quarantined file to its original location"""
        with self.lock, self._get_connection() as conn:
            cursor = conn.cursor()
            
            # Get quarantine entry
            cursor.execute("SELECT * FROM quarantine_files WHERE id = ?", (quarantine_id,))
            entry = cursor.fetchone()
            
            if not entry:
                logger.error(f"Quarantine entry not found: {quarantine_id}")
                return False
            
            try:
                # Move file back to original location
                if os.path.exists(entry['quarantine_path']):
                    shutil.move(entry['quarantine_path'], entry['original_path'])
                    
                    # Update status
                    cursor.execute(
                        "UPDATE quarantine_files SET status = 'restored' WHERE id = ?",
                        (quarantine_id,)
                    )
                    
                    conn.commit()
                    
                    # Add event log
                    self._add_event("quarantine", file_hash=entry['file_hash'],
                                  details={"action": "file_restored", "path": entry['original_path']})
                    
                    logger.info(f"Restored file: {entry['original_path']}")
                    return True
                else:
                    logger.error(f"Quarantined file not found: {entry['quarantine_path']}")
                    return False
                    
            except Exception as e:
                logger.error(f"Error restoring file: {e}")
                return False
    
    def add_analysis_result(self, file_hash: str, file_path: str, analysis_type: str,
                          result: Dict[str, Any], threat_level: str = "medium",
                          confidence_score: float = 0.0) -> int:
        """Add threat analysis result"""
        with self.lock, self._get_connection() as conn:
            cursor = conn.cursor()
            
            cursor.execute('''
                INSERT INTO threat_analysis 
                (file_hash, file_path, analysis_type, result, threat_level, confidence_score)
                VALUES (?, ?, ?, ?, ?, ?)
            ''', (
                file_hash, file_path, analysis_type, json.dumps(result),
                threat_level, confidence_score
            ))
            
            analysis_id = cursor.lastrowid
            conn.commit()
            
            # Add event log
            self._add_event("analysis", file_hash=file_hash,
                          details={"action": "analysis_completed", "type": analysis_type,
                                 "threat_level": threat_level, "confidence": confidence_score})
            
            logger.info(f"Added analysis result for {file_hash} (ID: {analysis_id})")
            return analysis_id
    
    def _add_event(self, event_type: str, file_hash: str = None, signature_id: int = None,
                  severity: str = "medium", source: str = "threat_database",
                  details: Dict[str, Any] = None, user_action: str = None,
                  automated_response: str = None):
        """Add event to threat history"""
        with self._get_connection() as conn:
            cursor = conn.cursor()
            
            cursor.execute('''
                INSERT INTO threat_events 
                (event_type, file_hash, signature_id, severity, source, details, 
                 user_action, automated_response)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            ''', (
                event_type, file_hash, signature_id, severity, source,
                json.dumps(details) if details else None,
                user_action, automated_response
            ))
            
            conn.commit()
    
    def get_threat_history(self, limit: int = 100, event_type: str = None) -> List[Dict[str, Any]]:
        """Get threat history/events"""
        with self._get_connection() as conn:
            cursor = conn.cursor()
            
            sql = "SELECT * FROM threat_events"
            params = []
            
            if event_type:
                sql += " WHERE event_type = ?"
                params.append(event_type)
            
            sql += " ORDER BY event_time DESC LIMIT ?"
            params.append(limit)
            
            cursor.execute(sql, params)
            return [dict(row) for row in cursor.fetchall()]
    
    def get_quarantine_list(self, status: str = None) -> List[Dict[str, Any]]:
        """Get list of quarantined files"""
        with self._get_connection() as conn:
            cursor = conn.cursor()
            
            sql = "SELECT * FROM quarantine_files"
            params = []
            
            if status:
                sql += " WHERE status = ?"
                params.append(status)
            
            sql += " ORDER BY quarantine_time DESC"
            
            cursor.execute(sql, params)
            return [dict(row) for row in cursor.fetchall()]
    
    def get_statistics(self) -> Dict[str, Any]:
        """Get database statistics"""
        with self._get_connection() as conn:
            cursor = conn.cursor()
            
            stats = {}
            
            # Count signatures by type
            cursor.execute('''
                SELECT type, COUNT(*) as count 
                FROM threat_signatures WHERE active = 1 
                GROUP BY type
            ''')
            stats['signatures_by_type'] = {row['type']: row['count'] for row in cursor.fetchall()}
            
            # Total signatures
            cursor.execute("SELECT COUNT(*) as count FROM threat_signatures WHERE active = 1")
            stats['total_signatures'] = cursor.fetchone()['count']
            
            # Quarantine statistics
            cursor.execute('''
                SELECT status, COUNT(*) as count 
                FROM quarantine_files 
                GROUP BY status
            ''')
            stats['quarantine_by_status'] = {row['status']: row['count'] for row in cursor.fetchall()}
            
            # Recent events
            cursor.execute('''
                SELECT event_type, COUNT(*) as count 
                FROM threat_events 
                WHERE event_time > datetime('now', '-24 hours')
                GROUP BY event_type
            ''')
            stats['events_last_24h'] = {row['event_type']: row['count'] for row in cursor.fetchall()}
            
            return stats
    
    def create_backup(self, backup_name: str = None) -> str:
        """Create database backup"""
        if not backup_name:
            timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
            backup_name = f"threats_backup_{timestamp}.db"
        
        backup_path = self.backup_dir / backup_name
        
        with self.lock:
            shutil.copy2(self.db_path, backup_path)
            logger.info(f"Database backup created: {backup_path}")
            return str(backup_path)
    
    def restore_backup(self, backup_path: str) -> bool:
        """Restore database from backup"""
        backup_file = Path(backup_path)
        if not backup_file.exists():
            logger.error(f"Backup file not found: {backup_path}")
            return False
        
        with self.lock:
            try:
                # Create backup of current database
                current_backup = self.db_path.with_suffix(f".backup_{datetime.datetime.now().strftime('%Y%m%d_%H%M%S')}.db")
                shutil.copy2(self.db_path, current_backup)
                
                # Restore from backup
                shutil.copy2(backup_path, self.db_path)
                logger.info(f"Database restored from: {backup_path}")
                return True
                
            except Exception as e:
                logger.error(f"Error restoring backup: {e}")
                return False
    
    def cleanup_old_events(self, days: int = 30):
        """Clean up old events from the database"""
        with self._get_connection() as conn:
            cursor = conn.cursor()
            
            cursor.execute('''
                DELETE FROM threat_events 
                WHERE event_time < datetime('now', '-{} days')
            '''.format(days))
            
            deleted_count = cursor.rowcount
            conn.commit()
            
            logger.info(f"Cleaned up {deleted_count} old events")
            return deleted_count
    
    def export_threat_intelligence(self, format_type: str = "json") -> str:
        """Export threat intelligence data"""
        with self._get_connection() as conn:
            cursor = conn.cursor()
            
            # Get all active signatures
            cursor.execute("SELECT * FROM threat_signatures WHERE active = 1")
            signatures = [dict(row) for row in cursor.fetchall()]
            
            # Get YARA rules
            cursor.execute("SELECT * FROM yara_rules")
            yara_rules = [dict(row) for row in cursor.fetchall()]
            
            export_data = {
                "export_time": datetime.datetime.now().isoformat(),
                "signatures": signatures,
                "yara_rules": yara_rules,
                "statistics": self.get_statistics()
            }
            
            if format_type.lower() == "json":
                return json.dumps(export_data, indent=2, default=str)
            else:
                raise ValueError(f"Unsupported export format: {format_type}")

def main():
    """Main function to test the threat database"""
    # Initialize database
    db = ThreatDatabase("test_threats.db")
    
    # Add a sample hash signature
    hash_sig = ThreatSignature(
        name="Known Malware Sample 1",
        type=SignatureType.HASH_SHA256.value,
        content="a665a45920422f9d417e4867efdc4fb8a04a1f3fff1fa07e998e86f7f7a27ae3",
        description="SHA-256 hash of known malware sample",
        threat_level=ThreatLevel.HIGH.value,
        source="internal_analysis",
        confidence_score=0.95
    )
    
    signature_id = db.add_signature(hash_sig)
    print(f"Added signature with ID: {signature_id}")
    
    # Add a YARA rule signature
    yara_content = '''
    rule Suspicious_PE {
        meta:
            description = "Detects suspicious PE files"
            author = "threat_intel"
            date = "2024-01-01"
        
        strings:
            $mz = { 4D 5A }
            $suspicious = "CreateRemoteThread" ascii
        
        condition:
            $mz at 0 and any of ($suspicious)
    }
    '''
    
    yara_sig = ThreatSignature(
        name="Suspicious PE Files",
        type=SignatureType.YARA_RULE.value,
        content=yara_content,
        description="YARA rule to detect suspicious PE files",
        threat_level=ThreatLevel.MEDIUM.value,
        source="custom_rules",
        confidence_score=0.8
    )
    
    yara_id = db.add_signature(yara_sig)
    print(f"Added YARA signature with ID: {yara_id}")
    
    # Search signatures
    all_signatures = db.search_signatures()
    print(f"Total active signatures: {len(all_signatures)}")
    
    # Get statistics
    stats = db.get_statistics()
    print("Database statistics:", json.dumps(stats, indent=2))
    
    # Create backup
    backup_path = db.create_backup()
    print(f"Backup created: {backup_path}")

if __name__ == "__main__":
    main()